# Instagram-style filters in HTML5 Canvas

Read the article here:

https://www.viget.com/article/9726-instagram-style-filters-in-html5-canvas

To run this project locally, you'll need to run a local web server to
get around CORS issues. Start one up with:

```
make start
```
