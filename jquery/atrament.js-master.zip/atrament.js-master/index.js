module.exports = require('./src/atrament.js');
