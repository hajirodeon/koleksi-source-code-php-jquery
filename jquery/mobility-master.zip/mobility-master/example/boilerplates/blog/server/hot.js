module.exports = {
	"error": false,
	"results": [
		{
			"slug": "budi-the-orangutan",
			"title": "Budi the orangutan is recovering after almost a year of neglect",
			"image": "/images/africa-139343_640.jpg",
			"category": "watercooler",
			"shares": "2845"
		},
		{
			"slug": "a-knife-in-an-enchilada",
			"title": "A knife in an enchilada: The oddest thing the TSA seized in 2014",
			"image": "/images/american-football-63109_640.jpg",
			"category": "watercooler",
			"shares": "814"
		},
		{
			"slug": "nhl-teams-up-with-gopro",
			"title": "NHL teams up with GoPro to broadcast games from new angles",
			"image": "/images/couple-168191_640.jpg",
			"category": "entertainment",
			"shares": "924"
		},
		{
			"slug": "young-women-are-the-heroes",
			"title": "Young women are the heroes of campus rape doc 'The Huntting Ground'",
			"image": "/images/daisy-75190_640.jpg",
			"category": "entertainment",
			"shares": "793"
		},
		{
			"slug": "exodus-from-egypt",
			"title": "Exodus from Egypt: The country's youth move on",
			"image": "/images/dependent-100343_640.jpg",
			"category": "world",
			"shares": "753"
		},
		{
			"slug": "major-measles-outbreak",
			"title": "Major measles outbreak linked to Disneyland infects 78",
			"image": "/images/girl-102831_640.jpg",
			"category": "world",
			"shares": "1145"
		},
		{
			"slug": "leatherman-to-debut",
			"title": "Leatherman to debut a wearable multi-tool this summer",
			"image": "/images/lacrosse-165576_640.jpg",
			"category": "lifestyle",
			"shares": "1235"
		},
		{
			"slug": "elon-musk-is-peak",
			"title": "Elon Musk is peak Elon Musk in 'Simpsons' sneak peek",
			"image": "/images/mountain-91385_640.jpg",
			"category": "entertainment",
			"shares": "1335"
		}
	]
}