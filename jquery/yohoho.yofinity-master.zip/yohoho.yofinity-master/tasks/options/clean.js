module.exports = {
  dist: [
    './dist/standalone/*',
    './dist/*'
  ]
};
