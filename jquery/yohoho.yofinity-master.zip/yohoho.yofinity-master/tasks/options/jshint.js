module.exports = {
  src: {
    src: [
      './src/yofinity.js'
    ]
  },

  options: {
    force: true
  }
};
