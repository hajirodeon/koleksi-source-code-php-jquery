
'use strict'

import './polyfills/CustomEvent';
import './polyfills/ConstructorName';
import './polyfills/Promise';
import './polyfills/ObjectAssign';
import './polyfills/SelectSelectedOptions';
import './polyfills/fetch';

import './shims/ForEach';
import './shims/ObjectCreateDeepCopy';

import './constants/keycodes';
