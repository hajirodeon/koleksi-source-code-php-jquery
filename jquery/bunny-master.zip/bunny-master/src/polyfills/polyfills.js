
import './ArrayFrom';
import './ObjectAssign';
import './Promise';
import './template';
import './CustomEvent';
import './fetch';
