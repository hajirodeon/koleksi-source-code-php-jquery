
(function() {
    window.KEY_BACKSPACE = 8;
    window.KEY_TAB = 9;
    window.KEY_ENTER = 13;
    window.KEY_SHIFT = 16;
    window.KEY_CTRL = 17;
    window.KEY_ALT = 18;
    window.KEY_ESCAPE = 27;
    window.KEY_SPACE = 32;
    window.KEY_PAGE_UP = 33;
    window.KEY_PAGE_DOWN = 34;
    window.KEY_ARROW_LEFT = 37;
    window.KEY_ARROW_UP = 38;
    window.KEY_ARROW_RIGHT = 39;
    window.KEY_ARROW_DOWN = 40;
    window.KEY_DELETE = 46
})();
