
import '../../src/polyfills/Promise';
import {Validation} from "../../src/Validation";

Validation.init(document.forms[0], true);
