
export var ColorProvider = {
    color: '#FBB'
};
