bootstrap-select-togglebutton
=============================

A simple plugin [jQuery](http://jquery.com/) to convert select boxes to [Bootstrap](http://getbootstrap.com/) toggle button group.

![togglebutton screenshot](screenshot.png)

Usage
=====

Create a select element and use the plugin.

`$('select').togglebutton();`

You can also check it out on the [example file](example.html).

Options
=======

No options for this version.
