# advanced-autocomplete.jquery
Add filter and autocomplete functionality to inputs, with or without the use of ajax, with or without the need for the user to start searching for a therm before showing results.

http://www.alotropico.com/projects/advanced-autocomplete/
