Portfilter
===========

Very Lightweight Portfolio Filter for Bootstrap


Usage
-----

	For handlers
		<tag data-toggle="portfilter" data-target="targetname">...
	For items
		<tag data-tag="targetname">...
Requisites
----------
	jQuery (http://jquery.com/)
About
-----
http://geedmo.com

