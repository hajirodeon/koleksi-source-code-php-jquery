## Contributing guide

1. Always use `develop` branch.

2. Make sure your code style is valid using [pandatool](https://github.com/ekelokorpi/panda.js-tool)

        $ npm install -g pandatool
        $ cd panda.js
        $ panda test
        Checking code style...
        Your code is valid!
