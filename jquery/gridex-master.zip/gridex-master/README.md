Gridex
===========

Expandable Grid for Twitter Bootstrap grid system


Usage
-----

Add class .gridex to a .thumbnails container

	<ul class="thumbnails gridex">

Add elements with class .gd-expander to show as expandable content

	<a class="thumbnail" href="#">..</a>
	<div class="gd-expander">..</div>

Note
-----
Gridex works with standard jQuery animation to support older browser.
Requisites
----------
	jQuery 1.9 (http://jquery.com/)
About
-----
http://geedmo.com
