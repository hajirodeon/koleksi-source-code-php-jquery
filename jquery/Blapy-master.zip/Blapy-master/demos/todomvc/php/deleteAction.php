<?php

$getAction = 'deleteAction';
$actionId = empty($_REQUEST['actionId'])?'':$_REQUEST['actionId'];

include ('getTodo.php');