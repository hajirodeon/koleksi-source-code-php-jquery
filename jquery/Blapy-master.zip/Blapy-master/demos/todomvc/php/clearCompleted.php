<?php

$getAction = 'clearCompleted';

include ('getTodo.php');