		<div 	data-blapy-container="true" 
				data-blapy-container-name="mainContainerApp3" 
				data-blapy-container-content="aContent1" 
		>
			<h3>Content 1 for APP 1 and 3</h3>
			This is content 1 for app 1 and 3 part
		</div>
