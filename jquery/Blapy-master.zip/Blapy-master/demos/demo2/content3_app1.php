		<div 	data-blapy-container="true" 
				data-blapy-container-name="mainContainerApp3" 
				data-blapy-container-content="aContent2" 
				data-blapy-applyon="myBlapyApp1"
		>
			<h3>Content 3 for APP 1</h3>
			This is content 3 for app1 part
		</div>
