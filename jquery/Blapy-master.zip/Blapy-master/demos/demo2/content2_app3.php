		<div 	data-blapy-container="true" 
				data-blapy-container-name="mainContainerApp3" 
				data-blapy-container-content="aContent2" 
				data-blapy-applyon="myBlapyApp3"
		>
			<h3>Content 2 for APP 3</h3>
			This is content 2 for app3 part
		</div>
