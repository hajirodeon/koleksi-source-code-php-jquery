<div id="results" 
	data-blapy-container="true" 
	data-blapy-container-name="results" 
	data-blapy-container-content="resultsnew"<?php echo time();?>
>
[
	{email: "emmanuel.podvin@intersel.fr"},
	{email: "em.blapy@yahoo.com"},
	{email: "blapy"},
	{email: "blapy@yahoo"},
	{email: "blapy@yahoo.fr.com"},
]
</div>