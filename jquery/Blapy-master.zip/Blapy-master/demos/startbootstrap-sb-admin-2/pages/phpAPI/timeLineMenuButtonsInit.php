<ul class="dropdown-menu" role="menu"
		data-blapy-container="true"
		data-blapy-container-name="timeLineMenuButtons"
		data-blapy-container-content="timeLineMenuButtonsVoid"
		data-blapy-template-init="phpAPI/timeLineMenuButtonsInit.php"
		data-blapy-update="json"
		>
[
	{URL:"#",action:"Action"},
	{URL:"#",action:"Another action"},
	{URL:"#",action:"Something else here"},
	{class:"divider",URL:"#",action:""},
	{URL:"#",action:"Separated link"},
]
</ul>