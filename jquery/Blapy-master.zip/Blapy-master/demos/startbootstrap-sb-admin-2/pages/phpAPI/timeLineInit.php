<ul class="timeline"
	data-blapy-container="true" 
	data-blapy-container-name="timeLine" 
	data-blapy-updateblock-ondisplay="true"
 >
 [
 		{timeblockPlace:""
 		,timelineClass: "badge"
 		,timelineType: "check"
 		,timelineTitle:"Lorem ipsum dolor"
 		,textMutedClass:"clock-o"
 		,textMuted:" 11 hours ago via Twitter"
 		,timeBody:"<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Libero laboriosam dolor perspiciatis omnis exercitationem. Beatae, officia pariatur? Est cum veniam excepturi. Maiores praesentium, porro voluptas suscipit facere rem dicta, debitis.</p>"
 		},
 		{timeblockPlace:"inverted"
 		,timelineClass: "badge warning"
 		,timelineType: "credit-card"
 		,timelineTitle:"Lorem ipsum dolor"
 		,textMutedClass:""
 		,textMuted:""
 		,timeBody:"<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Autem dolorem quibusdam, tenetur commodi provident cumque magni voluptatem libero, quis rerum. Fugiat esse debitis optio, tempore. Animi officiis alias, officia repellendus.</p>
                   <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laudantium maiores odit qui est tempora eos, nostrum provident explicabo dignissimos debitis vel! Adipisci eius voluptates, ad aut recusandae minus eaque facere.</p>
 		"
 		},
  		{timeblockPlace:""
 		,timelineClass: "badge danger"
 		,timelineType: "bomb"
 		,timelineTitle:"Lorem ipsum dolor"
 		,textMutedClass:""
 		,textMuted:""
 		,timeBody:"<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Libero laboriosam dolor perspiciatis omnis exercitationem. Beatae, officia pariatur? Est cum veniam excepturi. Maiores praesentium, porro voluptas suscipit facere rem dicta, debitis.</p>"
 		},
  		{timeblockPlace:"inverted"
 		,timelineClass: "badge bomb"
 		,timelineType: "check"
 		,timelineTitle:"Lorem ipsum dolor"
 		,textMutedClass:""
 		,textMuted:""
 		,timeBody:"<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Libero laboriosam dolor perspiciatis omnis exercitationem. Beatae, officia pariatur? Est cum veniam excepturi. Maiores praesentium, porro voluptas suscipit facere rem dicta, debitis.</p>"
 		},
  		{timeblockPlace:"inverted"
 		,timelineClass: "badge panel"
 		,timelineType: "check"
 		,timelineTitle:"Lorem ipsum dolor"
 		,textMutedClass:"clock-o"
 		,textMuted:" 11 hours ago via Twitter"
 		,timeBody:"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Libero laboriosam dolor perspiciatis omnis exercitationem. Beatae, officia pariatur? Est cum veniam excepturi. Maiores praesentium, porro voluptas suscipit facere rem dicta, debitis."
 		},
  		{timeblockPlace:""
 		,timelineClass: "badge info"
 		,timelineType: "save"
 		,timelineTitle:"Lorem ipsum dolor last"
 		,textMutedClass:""
 		,textMuted:""
 		,timeBody:"<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Libero laboriosam dolor perspiciatis omnis exercitationem. Beatae, officia pariatur? Est cum veniam excepturi. Maiores praesentium, porro voluptas suscipit facere rem dicta, debitis.</p>"
 		},
  		{timeblockPlace:""
 		,timelineClass: "badge"
 		,timelineType: "check"
 		,timelineTitle:"Lorem ipsum dolor"
 		,textMutedClass:"clock-o"
 		,textMuted:" 11 hours ago via Twitter"
 		,timeBody:'<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nobis minus modi quam ipsum alias at est molestiae excepturi delectus nesciunt, quibusdam debitis amet, beatae consequuntur impedit nulla qui! Laborum, atque.</p>
                                            <hr>
                                            <div class="btn-group">
                                                <button type="button" class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown">
                                                    <i class="fa fa-gear"></i>  <span class="caret"></span>
                                                </button>
                                                <ul class="dropdown-menu" role="menu"
					                            	data-blapy-container="true" 
													data-blapy-container-name="timeLineMenuButtons" 
													data-blapy-container-content="timeLineMenuButtonsVoid"
													data-blapy-template-init="phpAPI/timeLineMenuButtonsInit.php"
													data-blapy-update="json"
                                                >
                                                	<li class="${class}"><a href="${URL}">${action}</a>
                                                    </li>
                                                </ul>
                                            </div>
 		'
 		},
  		{timeblockPlace:"inverted"
 		,timelineClass: "heading"
 		,timelineType: ""
 		,timelineTitle:"Lorem ipsum dolor last"
 		,textMutedClass:""
 		,textMuted:""
 		,timeBody:"<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Libero laboriosam dolor perspiciatis omnis exercitationem. Beatae, officia pariatur? Est cum veniam excepturi. Maiores praesentium, porro voluptas suscipit facere rem dicta, debitis.</p>"
 		},
  		{timeblockPlace:"inverted"
 		,timelineClass: "badge success"
 		,timelineType: "graduation-cap"
 		,timelineTitle:"Lorem ipsum dolor last"
 		,textMutedClass:""
 		,textMuted:""
 		,timeBody:"<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Libero laboriosam dolor perspiciatis omnis exercitationem. Beatae, officia pariatur? Est cum veniam excepturi. Maiores praesentium, porro voluptas suscipit facere rem dicta, debitis.</p>"
 		},
 ]
</ul>