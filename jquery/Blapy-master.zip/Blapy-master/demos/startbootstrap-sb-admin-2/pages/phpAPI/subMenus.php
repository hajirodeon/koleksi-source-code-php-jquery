
<ul class="nav nav-second-level"
		data-blapy-container="true"
		data-blapy-container-name="UIChartsList"
		data-blapy-container-content="UIChartsListInit"
		data-blapy-update="json"
>
	[
	{menuURL:"flot.html",menuTitle:"Flot Charts"},
	{menuURL:"morris.html",menuTitle:"Morris.js Charts"},
	]
</ul>

<ul class="nav nav-second-level"
	data-blapy-container="true" 
	data-blapy-container-name="UIElementsList" 
	data-blapy-container-content="UIElementsListInit-$currentTime"
	data-blapy-update="json"
>
[
		{menuURL:"panels-wells.html",menuTitle:"Panels and Wells"},
		{menuURL:"buttons.html",menuTitle:"Buttons"},
					{menuURL:"notifications.html",menuTitle:"Notifications"},
					{menuURL:"typography.html",menuTitle:"Typography"},
					{menuURL:"icons.html",menuTitle:"Icons"},
					{menuURL:"grid.html",menuTitle:"Grid"},
			]
</ul>
			

									