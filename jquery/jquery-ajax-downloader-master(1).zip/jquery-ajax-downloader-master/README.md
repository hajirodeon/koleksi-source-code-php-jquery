# jQuery AjaxDownloader
A jQuery Plugin to perform Ajax style downloads

---

Documentation and examples at http://gasparesganga.com/labs/jquery-ajax-downloader/
