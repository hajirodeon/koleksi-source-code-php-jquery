(function () {
  var ug = window.ug = angular.module('ug', ['ug.dataentry'])
	.run(["$http", function (http) {

	}]);
  
})();