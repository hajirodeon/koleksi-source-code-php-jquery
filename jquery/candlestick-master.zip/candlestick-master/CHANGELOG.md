# Changelog

### Version 1.4.1 | 09/11/2016

* fix #14 afterAction parameters return undefined

### Version 1.4.0 | 29/07/2016

* Add allowManualDefault configuration

### Version 1.3.1 | 26/07/2016

* Bug fix, jQuery.noConflict() works now

### Version 1.3.0 | 12/07/2016

* Bug fix, default settings was in conflict with options mode. eg: candlestick('reset'). Rename in 'nc' name
* Store Candlestick settings for options use
* Optimizing code
* CleanUp code

### Version 1.2.3 | 18/06/2016

* Merge fix #1
* fix #2
* fix #3

### Version 1.2 | 25/04/2016

* add a new mode called "options"
* add swipe event to this mode

### Version 1.1 | 30/03/2016

* reset option set

### Version 1.0 | 29/12/2015

* First stable version
