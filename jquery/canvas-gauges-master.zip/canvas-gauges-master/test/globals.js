window.ns = window;
