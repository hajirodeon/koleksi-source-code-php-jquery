app.init.utils(app);
app.init.instruments(app);
app.init.loopTracks(app);
app.init.trackActions(app);
app.init.midiRigs(app);
app.init.dom(app);
app.init.tooltips(app);
