// Get a reference to the global object
}( (function() {
    return this;
})() ));
