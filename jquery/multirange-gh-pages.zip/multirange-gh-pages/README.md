# multirange
A tiny polyfill for HTML5 multi-handle sliders

For docs, check out the website: http://leaverou.github.io/multirange/
