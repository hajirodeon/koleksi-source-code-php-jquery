How to build grid-editor
========================

Do NOT make changes to the files in the `dist` directory. 

Instead, update the files in the `src` directory. Then install the dependencies:

* `npm install`
* `sudo npm install -g grunt-cli`

From then on out, you can build the files in the `dist` directory by running:

* `grunt`

You can also run `grunt watch` to automatically rebuild on changes.
