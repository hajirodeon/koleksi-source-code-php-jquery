<?
  /*
  **  Sample document
  **
  **  This will create simple wml page with two linked cards (decks).
  */
  require("mlswap.php");

  $wml = new wml_doc;
  $card1 = new wml_card;
  $card2 = new wml_card;

  $card1 -> create("Test card");
  $card1 -> add_button("Second card", "options", "#card2");
  $card1 -> add("<p>");
  $card1 -> add("This is sample file for mlswap php class.<br/>");
  $card1 -> add("<a href=\"#card2\">Card 2</a>");
  $card1 -> add("</p>");

  $card2 -> create("Second card", "card2");
  $card2 -> add("<p>");
  $card2 -> add("This is second sample card :-)<br/>");
  $card2 -> add("<a href=\"#main\">Back to main card</a>");
  $card2 -> add("</p>");

  $wml -> add_card($card1);
  $wml -> add_card($card2);

  $wml -> show();
?>