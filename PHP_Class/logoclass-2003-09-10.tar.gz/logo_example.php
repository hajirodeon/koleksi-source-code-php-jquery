<?

require("logo.php");

/*
   A eimple helper function:
   function sft (string from template) (simplified)
   input:  - one array with substitute values
           - a template file
   output: - a (html) stream
*/
function sft($pairs, $template)
{
	$str = implode(file($template), "");
	$res = preg_replace("/\\{\\{(\\w+)\\}\\}/Ue", "\$pairs['\\1']", $str);
	return $res;
}

/*
   To get started, we include a simple logo program.
   This function returns a simple logo program that serves as an example.
*/
function get_program()
{
	$res = <<<EOH
to triangle :sides
    make "angle 120
    repeat 360 / :angle [forward :sides left :angle]
end

to house
    forward 50
    Right 90
    forward 50
    left 135
    forward 35
    left 90
    forward 35
    right 270
    forward 70
    left 135
    forward 50
    left 135
    forward 70
    left 135
    fd 50
end

house
penup
lt 90
backward 50
pendown
triangle 20
EOH;
	return $res;
}

/*
   We are going to store the program that one is typing in the current
   session, so the student does not have to do a lot of re-typing.
*/
session_start();
session_register("theprogram");

switch ($cmd) {
case "swf":
/*
	The template calls this example with cmd=swf.
	We output the results of the program here.
*/
	$logo = new logoclass($theprogram);
	$logo->output();
	break;
default:
	if (empty($program)) {
		$program = get_program();
	}
	$program = stripslashes($program);
	$theprogram = $program;
	$arr = compact("program");
	echo sft($arr, "logo.tem.html");
}
?>
