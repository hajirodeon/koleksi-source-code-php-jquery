This is the readme that goes with the logo class
from Rene Kluwen <rene.kluwen@chimit.nl>.

This class is an implementation of a Logo interpreter
(parser and graphical output).
The whole thing consists of one single PHP class.

License: LGPL. See: http://www.gnu.org/copyleft/lesser.html.

Parsing is mostly done using regular expressions.
Arithmetic functionality is 'borrowed' from PHP, using
the eval() function.
Output needs SWF support in your PHP version.


Logo resume:

**
** The basic Logo commands:
**
** FD 100  Move the turtle forward 100 steps.
** RT 90  Turn the turtle to the right 90�.
** LT 90  Turn the turtle to the left 90�.
** BK 100  Move the turtle backwards 100 steps.
** PU  Pick the turtle's pen up off the paper.
** PD  Put the turtles pen back down on the paper.
** CS  Clear the screen and start over.
** HT  Hide the turtle (triangle).
** ST  Show the turtle (triangle).
** REPEAT 3 [...]  Repeat the commands 3 times.
** MAKE "var value Set variabele var to value
** TO wordname :par1 :par2 ... Wordname is a new word with par1, par2... as parameters
**

Todo: implement some music commands.
Todo: Conditional execution (IF), Local variables, more commands
      (such as POLY, SETXY, etc.).
