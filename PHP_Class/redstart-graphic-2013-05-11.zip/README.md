Redstart-Graphic
================

Robust And Extendable PHP5 OO Graphic Framework , It Was Built On PHP Gd Extnesion 
It Supports Wide Range Of Filters And The Three Basic Resources(jpg,png,gif) .
It Can Be Extended To Support New Resource , Filters And Actions , It Also Comes 
Prepared With 2D Drawing Capabilities To Draw On Empty Resources Or Images

see full documentation ,demos and more at : http://www.phpbeat.com/doc/graphic