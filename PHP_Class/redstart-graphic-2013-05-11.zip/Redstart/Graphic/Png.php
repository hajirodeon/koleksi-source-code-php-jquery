<?php

namespace Redstart\Graphic;

use Redstart\Graphic\GraphicException\ResourceCreationException;
use Redstart\Graphic\GraphicException\EmptyResource;

/**
 * Png Image Object
 * 
 * @package Redstart
 * @subpackage Redstart_Graphic
 * 
 * @author Hyyan Abo Fakher
 * @since Redstart 1.0
 * @version 1.0
 */
class Png extends CompressedImage {

    /**
     * whether to save alpha information or not
     * @var boolean
     */
    private $PNGIsSaveAlpha;

    /**
     * Construct new Png Resource
     * @param \Redstart\Graphic\Dimension $dimension
     * @param boolean $trueColor
     * @param boolean $saveAlpha
     */
    public function __construct(Dimension $dimension = null, $trueColor = true, $saveAlpha = true) {
        parent::__construct($dimension, $trueColor);
        $this->setQuality(40);
        $this->setSaveAlpha($saveAlpha);
    }

    /**
     * Save Alpha Channel Information
     * 
     * <b>Note :</b>
     * Sets the flag to attempt to save full alpha channel information 
     * (as opposed to single-color transparency) when <b>saving</b> PNG images. 
     * 
     * <b>Png::alphaBelnding</b> will be set to false. 
     *
     * Alpha channel is not supported by all browsers.
     *
     * @param boolean $bool Default to true. 
     */
    public function setSaveAlpha($bool) {
        $this->PNGIsSaveAlpha = $bool;
    }

    /**
     * Get Save Alpha 
     * 
     * Check if the channel information will be saved with resourse or not
     * @return boolean
     * 
     */
    public function getSaveAlpha() {
        return $this->PNGIsSaveAlpha;
    }

    /**
     * Save The Alpha Channel Information For Png Resource
     * @param \Redstart\Graphic\Png $png
     * @param boolean $flag true to save
     * @throws EmptyResource
     */
    protected function saveAlpha(Png $png, $flag) {
        if (!$png->isHandlerSet()) {
            throw new EmptyResource(
                    "Can Not Save Alpha Channel Information - Png Resource Is Empty");
        }
        if ($flag && $png->isTrueColor()) {
            $png->alphaBlending(false);
        }
        imagesavealpha($png->getHandler(), $flag);
    }

    /**
     * Load From File
     * @param string $filename
     * @throws ResourceOutputException
     */
    protected function doSave($filename) {
        $this->saveAlpha($this, $this->getSaveAlpha());
        $quality = 9 - floor(($this->getQuality() * 9) / 100);
        if (!imagepng($this->getHandler(), $filename, $quality)) {
            throw new ResourceOutputException(
                    sprintf("Could Not Save Resource To (%s)", $filename)
            );
        }
    }

    /**
     * Check If The File Is valid png file
     * @param string $filename
     * @throws \InvalidArgumentException
     * @throws InvalidImageFileException
     * @throw \RuntimeException
     */
    protected function assertPngFile($filename) {
        $image = new ImageFile($filename);
        if (strtolower($image->getMime()) != "image/png") {
            throw new \InvalidArgumentException(
                    sprintf("(%s) Is Not valid PNG File", $filename)
            );
        }
    }

    /**
     * Load Png File from File
     * @param string $filename
     * @throws ResourceCreationException
     */
    protected function doLoadFromFile($filename) {
        $this->assertPngFile($filename);
        $handler = imagecreatefrompng($filename);
        if ($handler === false) {
            throw new ResourceCreationException(
                    sprintf("Could Not Create Resource From (%s)", $filename)
            );
        }
        $this->setHandler($handler);
    }

    /**
     * Get Copy from this Png Resource
     * @return Png 
     */
    public function doGetCopy() {
        $clone = new Png($this->getDimension());
        $alpha = $this->getSaveAlpha();
        $clone->setSaveAlpha($alpha);
        $this->saveAlpha($clone, $alpha);
        $clone->merge($this);
        return $clone;
    }

}

