<?php

namespace Redstart\Graphic;

use Redstart\Graphic\GraphicException\ShapeException;

/**
 * Polygon Object
 * 
 * @package Redstart
 * @subpackage Redstart_Graphic
 * 
 * @author Hyyan Abo Fakher
 * @since Redstart 1.0
 * @version 1.0
 */
class Polygon extends FilledShape {

    /**
     * Ploygon Points Array
     * @var array
     */
    private $PolygonPoints = array();

    /**
     * Polygon points num
     * @var int
     */
    private $PolygonPointsNum = 0;

    /**
     * Default length for points array
     * @var int
     */
    private static $MIN_LENGTH = 6;

    public function __construct(array $points = null, $pointsnum = null) {
        parent::__construct();
        $this->setPoints(($points === null) ? array() : $points);
        $number = ($pointsnum === null) ? count(($points))/2 : $pointsnum;
        $this->setNumber($number);
    }

    /**
     * Add new ploygon point
     * @param int $x
     * @param int $y
     */
    public function addPoint($x, $y) {
        $this->PolygonPoints[] = $x;
        $this->PolygonPoints [] = $y;
        $this->PolygonPointsNum++;
    }

    /**
     * Set an array containing the x and y coordinates of the polygons points 
     * consecutively
     * @param array $points
     */
    public function setPoints($points) {
        $this->PolygonPoints = $points;
    }

    /**
     * Get polygon points array
     * @return array
     */
    public function getPoints() {
        return $this->PolygonPoints;
    }

    /**
     * Set Ploygon points number
     * @param type $num
     * @throws \RuntimeException
     * @throws \OutOfBoundsException
     */
    public function setNumber($num) {
        if ($num < 0) {
            throw new \RuntimeException(" number must be greater than zero");
        }
        $count = count($this->getPoints());
        if ($num > $count) {
            throw new \OutOfBoundsException(
                    sprintf("(%s) Points Number > (%s) Points Array Size "
                            , $num, $count)
            );
        }
        $this->PolygonPointsNum = $num;
    }

    /**
     * Get ploygon points number
     * @return int
     */
    public function getNumber() {
        return $this->PolygonPointsNum;
    }

    /**
     * Assert Points Array Length
     * @throws \RuntimeException
     */
    private function assertPointsArrayLength() {
        if (count($this->getPoints()) < self::$MIN_LENGTH) {
            throw new \RuntimeException("You Must Have At Least 3 Points");
        }
    }

    protected function doDrawFilledShape(Resource $resource, $color) {
        $this->assertPointsArrayLength();
        if (!imagefilledpolygon(
                        $resource->getHandler()
                        , $this->getPoints()
                        , $this->getNumber()
                        , $color
                )
        ) {
            throw new ShapeException("Could Not Draw Filled Polygon");
        }
    }

    protected function doDrawNonFilledShape(Resource $resource, $color) {
        $this->assertPointsArrayLength();
        if (!imagepolygon(
                        $resource->getHandler()
                        , $this->getPoints()
                        , $this->getNumber()
                        , $color
                )
        ) {
            throw new ShapeException("Could Not Draw Polygon");
        }
    }

    /**
     * Returns a string representation of this <code>Polygon</code> Object
     * @return string
     */
    public function __toString() {
        return get_called_class()
                . "[points={$this->getNumber()}]";
    }

}

