<?php

namespace Redstart\Graphic;

use Redstart\Graphic\GraphicException\InvalidImageFileException;

/**
 * Image File 
 * 
 * @package Redstart
 * @subpackage Redstart_Graphic
 * 
 * @author Hyyan Abo Fakher
 * @since Redstart 1.0
 * @version 1.0
 */
class ImageFile extends \SplFileInfo {

    /**
     * Image Extension
     * @var string
     */
    private $imageExtension;

    /**
     * Image Mime Type
     * @var stirng
     */
    protected $imageMime = null;

    /**
     * Image Height
     * @var int
     */
    protected $imageY = 0;

    /**
     * Image Width
     * @var int
     */
    protected $imageX = 0;

    /**
     * Construct new Image File Object
     * @param string $file
     * @throws \RuntimeException
     * @throws InvalidImageFileException
     */
    public function __construct($file) {
        parent::__construct($file);
        if (!$this->isFile()) {
            throw new \RuntimeException(
                    sprintf("(%s) Is Not File", $file)
            );
        }
        if (!$this->isReadable()) {
            throw new \RuntimeException(
                    sprintf("(%s) Is Not Readable", $file)
            );
        }
        $imageInfo = @getimagesize($file);
        $pathInfo = @pathinfo($file);
        
        if (!$imageInfo || !$pathInfo) {
            throw new InvalidImageFileException(
                    sprintf("(%s) is Not Valid Image File ", $file)
            );
        }

        $this->imageExtension = $pathInfo['extension'];
        $this->imageMime = $imageInfo['mime'];
        $this->imageX = $imageInfo[0];
        $this->imageY = $imageInfo[1];
    }

    /**
     * Get Image File Extension
     * @return string
     */
    public function getExtension() {
        return $this->imageExtension;
    }

    /**
     * Get Image Mime Type
     * @return string
     */
    public function getMime() {
        return $this->imageMime;
    }

    /**
     * Get Image Width
     * @return int
     */
    public function getWidth() {
        return $this->imageX;
    }

    /**
     * Get Image Height
     * @return int
     */
    public function getHeight() {
        return $this->imageY;
    }

}