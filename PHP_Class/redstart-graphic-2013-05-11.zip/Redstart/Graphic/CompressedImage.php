<?php

namespace Redstart\Graphic;

/**
 * Compressed Image Object
 * 
 * @package Redstart
 * @subpackage Redstart_Graphic
 * 
 * @author Hyyan Abo Fakher
 * @since Redstart 1.0
 * @version 1.0
 */
abstract class CompressedImage extends ImageResource {

    /**
     * Image quality
     * @var int
     */
    private $quality;

    public function __construct(Dimension $dimension = null, $trueColor = true) {
        parent::__construct($dimension, $trueColor);
        $this->setQuality(75);
    }

    /**
     * Set Image Output Quality
     * @param int $quality ranges from 0 (worst quality, smaller file) to 100 
     * (best quality, biggest file)
     * @throws \InvalidArgumentException
     */
    public function setQuality($quality) {
        if ($quality >= 0 && $quality <= 100) {
            $this->quality = $quality;
        } else {
            throw new \InvalidArgumentException("Quality should be in range(0,100)");
        }
    }

    /**
     * Get Image Output Quality
     * @return int
     */
    public function getQuality() {
        return $this->quality;
    }

}

