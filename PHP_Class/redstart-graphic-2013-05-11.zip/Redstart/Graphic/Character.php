<?php

namespace Redstart\Graphic;

use Redstart\Graphic\GraphicException\EmptyResource;

/**
 * Character Object
 * 
 * @package Redstart
 * @subpackage Redstart_Graphic
 * 
 * @author Hyyan Abo Fakher
 * @since Redstart 1.0
 * @version 1.0
 */
abstract class Character implements Drawable {

    /**
     * Pixel Color
     * @var Color
     */
    private $StringColor;

    /**
     * String text
     * @var string
     */
    private $StringText;

    /**
     * String Position
     * @var Coordinate
     */
    private $StringPosition;

    /**
     * Construct new Character Object
     * @param string $string text
     * @param \Redstart\Graphic\Coordinate $position
     * @param \Redstart\Graphic\Color $color
     */
    public function __construct($string = null, Coordinate $position = null, Color $color = null) {
        $this->setCoordinate($position === null ? new Coordinate() : $position);
        $this->setColor($color === null ? new Color(0, 0, 0) : $color);
        $this->setString($string);
    }

    /**
     * Set Color 
     * @param \Redstart\Graphic\Color $color
     */
    public function setColor(Color $color) {
        $this->StringColor = $color;
    }

    /**
     * Get Color
     * @return \Redstart\Graphic\Color
     */
    public function getColor() {
        return $this->StringColor;
    }

    /**
     * Set String Text To Be Written
     * @param string $string
     */
    public function setString($string) {
        $this->StringText = $string;
    }

    /**
     * Get String Text
     * @return string
     */
    public function getString() {
        return $this->StringText;
    }

    /**
     * Set String Coordinate
     * @param \Redstart\Graphic\Coordinate $coordinate
     */
    public function setCoordinate(Coordinate $coordinate) {
        $this->StringPosition = $coordinate;
    }

    /**
     * Get String Position
     * @return Coordinate
     */
    public function getCoordinate() {
        return $this->StringPosition;
    }

    /**
     * Draw String On Resource
     * @param Resource $resource
     * @throws EmptyResource
     */
    public function draw(Resource $resource) {
        if (!$resource->isHandlerSet()) {
            throw new EmptyResource("Resource Is Empty");
        }
        $this->doDraw($resource);
    }

    abstract protected function doDraw(Resource $resource);
}

