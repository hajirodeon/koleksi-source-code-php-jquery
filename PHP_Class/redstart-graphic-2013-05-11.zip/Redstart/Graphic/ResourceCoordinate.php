<?php

namespace Redstart\Graphic;

use Redstart\Graphic\GraphicException\EmptyResource;

/**
 * Resource Coordinates System
 * 
 * @package Redstart
 * @subpackage Redstart_Graphic
 * 
 * @author Hyyan Abo Fakher
 * @since Redstart 1.0
 * @version 1.0
 */
class ResourceCoordinate extends CoordinateSystem {

    /**
     * The Second Resource
     * @var Resource 
     */
    private $SecondResource;

    /**
     * Construct New Resource Coordinate System
     * @param Resource $resource 
     * @param Resource $resource2
     */
    public function __construct(Resource $resource, Resource $resource2) {
        parent::__construct($resource);
        $this->setResource($resource);
        $this->setResource2($resource2);
    }

    /**
     * Set Second Resource
     * @param Resource $secondResource
     * @throws EmptyResource
     */
    public function setResource2(Resource $secondResource) {
        if (!$secondResource->isHandlerSet()) {
            throw new EmptyResource("Second Resource Is Empty");
        }
        $this->SecondResource = $secondResource;
    }

    /**
     * Get The Second Resource
     * @return Resource
     */
    public function getResource2() {
        return $this->SecondResource;
    }

    protected function bottomLeft() {
        $height1 = $this->getResource()->getDimension()->getHeight();
        $height2 = $this->getResource2()->getDimension()->getHeight();
        $height = $height1 - $height2;
        return new Coordinate(0, $height);
    }

    protected function bottomRight() {
        $width1 = $this->getResource()->getDimension()->getWidth();
        $width2 = $this->getResource2()->getDimension()->getWidth();

        $height1 = $this->getResource()->getDimension()->getHeight();
        $height2 = $this->getResource2()->getDimension()->getHeight();

        $width = $width1 - $width2;
        $height = $height1 - $height2;

        return new Coordinate($width, $height);
    }

    protected function center() {
        $width1 = $this->getResource()->getDimension()->getWidth() / 2.0;
        $width2 = $this->getResource2()->getDimension()->getWidth() / 2.0;

        $height1 = $this->getResource()->getDimension()->getHeight() / 2.0;
        $height2 = $this->getResource2()->getDimension()->getHeight() / 2.0;

        $width = $width1 - $width2;
        $height = $height1 - $height2;

        return new Coordinate($width, $height);
    }

    protected function centerBottom() {
        $width1 = $this->getResource()->getDimension()->getWidth() / 2.0;
        $width2 = $this->getResource2()->getDimension()->getWidth() / 2.0;

        $height1 = $this->getResource()->getDimension()->getHeight();
        $height2 = $this->getResource2()->getDimension()->getHeight();

        $width = $width1 - $width2;
        $height = $height1 - $height2;

        return new Coordinate($width, $height);
    }

    protected function centerLeft() {

        $height1 = $this->getResource()->getDimension()->getHeight() / 2.0;
        $height2 = $this->getResource2()->getDimension()->getHeight() / 2.0;
        $height = $height1 - $height2;

        return new Coordinate(0, $height);
    }

    protected function centerRight() {
        $width1 = $this->getResource()->getDimension()->getWidth();
        $width2 = $this->getResource2()->getDimension()->getWidth();

        $height1 = $this->getResource()->getDimension()->getHeight() / 2.0;
        $height2 = $this->getResource2()->getDimension()->getHeight() / 2.0;

        $width = $width1 - $width2;
        $height = $height1 - $height2;

        return new Coordinate($width, $height);
    }

    protected function centerTop() {
        $width1 = $this->getResource()->getDimension()->getWidth() / 2.0;
        $width2 = $this->getResource2()->getDimension()->getWidth() / 2.0;
        $width = $width1 - $width2;
        return new Coordinate($width, 0);
    }

    protected function topLeft() {
        return new Coordinate(0, 0);
    }

    protected function topRight() {
        $width1 = $this->getResource()->getDimension()->getWidth();
        $width2 = $this->getResource2()->getDimension()->getWidth();
        $width = $width1 - $width2;
        return new Coordinate($width, 0);
    }

}

