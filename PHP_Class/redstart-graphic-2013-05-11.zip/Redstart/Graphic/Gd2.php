<?php

namespace Redstart\Graphic;

use Redstart\Graphic\GraphicException\ResourceOutputException;
use Redstart\Graphic\GraphicException\ResourceCreationException;
use Redstart\Graphic\GraphicException\EmptyResource;
use Redstart\Graphic\Coordinate;
use Redstart\Graphic\Dimension;

/**
 * GD2 Resource Object
 * 
 * @package Redstart
 * @subpackage Redstart_Graphic
 * 
 * @author Hyyan Abo Fakher
 * @since Redstart 1.0
 * @version 1.0
 */
class Gd2 extends Gd {

    /**
     * GD2 Compressed 
     * @var boolean
     */
    private $GD2Compressed = true;

    /**
     * Chunk Size
     * @var int
     */
    private $GD2chunkSize = 0;

    public function __construct() {
        parent::__construct();
        $this->setCompressed(true);
    }

    /**
     * Set Compressed
     * @param boolean $bool true to compresse the resource
     */
    public function setCompressed($bool) {
        $this->GD2Compressed = $bool;
    }

    /**
     * Get Compressed
     * @return boolean
     */
    public function getCompressed() {
        return $this->GD2Compressed;
    }

    /**
     * Set Chunk Size
     * @param int $size
     */
    public function setChunkSize($size) {
        $this->GD2chunkSize = $size;
    }

    /**
     * Get Chunk Size
     * @return int
     */
    public function getChunkSize() {
        return $this->GD2chunkSize;
    }

    /**
     * Assert Can Load From File
     * @param string $filename
     * @throws \RuntimeException
     */
    private function assertCanLoad($filename) {
        if (empty($filename)) {
            throw \RuntimeException("File Name Can Not Be Empty");
        }
        if (!file_exists($filename)) {
            throw new \RuntimeException(
                    sprintf("(%s) Is Not Exist", $filename)
            );
        }
        if (!is_readable($filename)) {
            throw new \RuntimeException(
                    sprintf("(%s) Is Not Readable", $filename)
            );
        }
    }

    /**
     * Load Part Of GD Resource From File
     * 
     * <b>Note :</b>
     * This method will not check if the coordinat is valid coordinate for the 
     * resource and it won't check Dimension either .
     * @param string $filename
     * @param \Redstart\Graphic\Coordinate $coordinate Coordinate of source point
     * @param \Redstart\Graphic\Dimension $dimension Source Dimension
     * @throws ResourceCreationException
     */
    public function LoadPartFromFile($filename, Coordinate $coordinate, Dimension $dimension) {
        $this->assertCanLoad($filename);
        $x = $coordinate->getX();
        $y = $coordinate->getY();
        $width = $dimension->getWidth();
        $height = $dimension->getHeight();
        $result = imagecreatefromgd2part($filename, $x, $y, $width, $height);
        if ($result == false) {
            throw new ResourceCreationException(
                    sprintf("Could Not Load The Gd Resource From (%s)"
                            , $filename)
            );
        }
        $this->setHandler($result);
    }

    /**
     * Load GD Resource
     * @param string $filename
     * @throws \InvalidArgumentException if file name is empty
     * @throws \RuntimeException if file does not exist
     * @throws ResourceCreationException if loading resource failed
     */
    public function doLoadFromFile($filename) {
        $this->assertCanLoad($filename);
        $result = imagecreatefromgd2($filename);
        if ($result === false) {
            throw new ResourceCreationException(
                    sprintf("Could Not Load The Gd Resource From (%s)"
                            , $filename)
            );
        }
        $this->setHandler($result);
    }

    /**
     * Outputs a GD image to the given filename. 
     * @param string $filename The path to save the file to. If NULL, the raw image 
     * stream will be outputted directly.
     * @throws ResourceOutputException if output failed
     * @throws EmptyResource
     */
    protected function doSave($filename) {
        $compressed = $this->getCompressed() == true ? IMG_GD2_COMPRESSED : IMG_GD2_RAW;
        if (!imagegd2($this->getHandler(), $filename, $this->getChunkSize(), $compressed)) {
            throw new ResourceOutputException("Output Failed");
        }
    }

    /**
     * Get Copy from this GD2 Resource
     * @return GD2 
     */
    public function doGetCopy() {
        $clone = new Gd2();
        // to avoid the Empty resorce exception we have to create new resource
        $clone->loadFromResource(new Png($this->getDimension()));
        $clone->merge($this);
        return $clone;
    }

}

