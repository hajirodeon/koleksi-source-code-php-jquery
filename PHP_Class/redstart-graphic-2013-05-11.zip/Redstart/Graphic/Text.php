<?php

namespace Redstart\Graphic;

use Redstart\Graphic\GraphicException\CharacterException;

/**
 * Text Object
 * 
 * Draw Text On Resource Object
 * 
 * @package Redstart
 * @subpackage Redstart_Graphic
 * 
 * @author Hyyan Abo Fakher
 * @since Redstart 1.0
 * @version 1.0
 */
class Text extends Character {

    /**
     * Text Angle
     * @var angle
     */
    private $TextAngle;

    /**
     * Font File
     * @var string
     */
    private $TextFontFile;

    /**
     * Set Font Size
     * @var int
     */
    private $TextFontSize;

    /**
     * Construct New Text Object
     * @param string $string 
     * @param \Redstart\Graphic\Coordinate $position
     * @param \Redstart\Graphic\Color $color
     */
    public function __construct($string = null, Coordinate $position = null, Color $color = null) {
        parent::__construct($string, $position, $color);
        $this->setSize(9);
    }

    /**
     * Set Font File
     * @param \SplFileInfo $file True font file only
     * @throws \RuntimeException
     */
    public function setFont(\SplFileInfo $file) {
        if (!$file->isFile()) {
            throw new \RuntimeException(
                    sprintf("(%s) Is Not File", $file->getPath())
            );
        }
        if (!$file->isReadable()) {
            throw new \RuntimeException(
                    sprintf("(%s) Is Not Readable", $file->getPath())
            );
        }
        $this->TextFontFile = $file;
    }

    /**
     * Get Font File
     * @return \SplFileInfo
     */
    public function getFont() {
        return $this->TextFontFile;
    }

    /**
     * Set Font size
     * @param int $size
     */
    public function setSize($size) {
        $this->TextFontSize = $size;
    }

    /**
     * Get Font Size
     * @return int
     */
    public function getSize() {
        return $this->TextFontSize;
    }

    /**
     * Set text angle
     * @param int $angle
     */
    public function setAngle($angle) {
        $this->TextAngle = $angle;
    }

    /**
     * Get text angle
     * @return int
     */
    public function getAngle() {
        return $this->TextAngle;
    }
    
    /**
     * Draw text on the resource
     * @param Resource $resource
     * @throws \RuntimeException
     * @throws CharacterException
     */
    protected function doDraw(Resource $resource) {
        if ($this->getFont() == null) {
            throw new \RuntimeException("No Font Was set");
        }
        $bound = new TextBound($this);
        $fp = $bound->getFixedPosition();
        if (
                !imagettftext($resource->getHandler()
                        , $this->getSize()
                        , $this->getAngle()
                        , $fp->getX()
                        , $fp->getY()
                        , $this->getColor()->allocate($resource)
                        , $this->getFont()
                        , $this->getString()
                )
        ) {
            throw new CharacterException("Could Not Draw The Text");
        }
    }

}

