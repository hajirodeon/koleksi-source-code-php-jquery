<?php

namespace Redstart\Graphic;

/**
 * Coordinates System
 * 
 * @package Redstart
 * @subpackage Redstart_Graphic
 * 
 * @author Hyyan Abo Fakher
 * @since Redstart 1.0
 * @version 1.0
 */
abstract class CoordinateSystem {

    /**
     * Resource Object
     * @var Resource
     */
    private $ResourceObject;

    /**
     * Construct New Text Coordinate System Object
     * @param Resource $resource 
     */
    public function __construct(Resource $resource) {
        $this->setResource($resource);
    }

    /**
     * Set Resource Object
     * @param Resource $resource
     */
    public function setResource(Resource $resource) {
        $this->ResourceObject = $resource;
    }

    /**
     * Get Resource Object
     * @return Resource
     */
    public function getResource() {
        return $this->ResourceObject;
    }

    /**
     * Check If The Given Object Is Coordinate Object
     * @param Coordinate $object
     * @throws \UnexpectedValueException
     */
    protected function assertCoordinate($object) {
        if (!($object instanceof Coordinate)) {
            throw new \UnexpectedValueException(
                    sprintf("Expect Return value Coorindate Object But () Was Return"
                            , gettype($object))
            );
        }
    }

    /**
     * Get Center Coordinate
     * @return Coordinate 
     * @throws \UnexpectedValueException
     */
    public function getCenter() {
        $result = $this->center();
        $this->assertCoordinate($result);
        return $result;
    }

    /**
     * Get Center Coordinate
     * @return Coordinate 
     */
    abstract protected function center();

    /**
     * Get Top Left Coordinate
     * @return Coordinate 
     * @throws \UnexpectedValueException
     */
    public function getTopLeft() {
        $result = $this->topLeft();
        $this->assertCoordinate($result);
        return $result;
    }

    /**
     * Get Top Left Coordinate
     * @return Coordinate 
     */
    abstract protected function topLeft();

    /**
     * Get Top Right Coordinate
     * @return Coordinate 
     * @throws \UnexpectedValueException
     */
    public function getTopRight() {
        $result = $this->topRight();
        $this->assertCoordinate($result);
        return $result;
    }

    /**
     * Get Top Right Coordinate
     * @return Coordinate 
     */
    abstract protected function topRight();

    /**
     * Get Bottom Left Coordinate
     * @return Coordinate 
     * @throws \UnexpectedValueException
     */
    public function getBottomLeft() {
        $result = $this->bottomLeft();
        $this->assertCoordinate($result);
        return $result;
    }

    /**
     * Get Bottom Left Coordinate
     * @return Coordinate 
     */
    abstract protected function bottomLeft();

    /**
     * Get Bottom Right Coordinate
     * @return Coordinate 
     * @throws \UnexpectedValueException
     */
    public function getBottomRight() {
        $result = $this->bottomRight();
        $this->assertCoordinate($result);
        return $result;
    }

    /**
     * Get Bottom Right Coordinate
     * @return Coordinate 
     */
    abstract protected function bottomRight();

    /**
     * Get Center Left Coordinate
     * @return Coordinate 
     * @throws \UnexpectedValueException
     */
    public function getCenterLeft() {
        $result = $this->centerLeft();
        $this->assertCoordinate($result);
        return $result;
    }

    /**
     * Get Center Left Coordinate
     * @return Coordinate 
     */
    abstract protected function centerLeft();

    /**
     * Get Center Right Coordinate
     * @return Coordinate 
     * @throws \UnexpectedValueException
     */
    public function getCenterRight() {
        $result = $this->centerRight();
        $this->assertCoordinate($result);
        return $result;
    }

    /**
     * Get Center Right Coordinate
     * @return Coordinate 
     */
    abstract protected function centerRight();

    /**
     * Get Center Top Coordinate
     * @return Coordinate 
     * @throws \UnexpectedValueException
     */
    public function getCenterTop() {
        $result = $this->centerTop();
        $this->assertCoordinate($result);
        return $result;
    }

    /**
     * Get Center Top Coordinate
     * @return Coordinate 
     */
    abstract protected function centerTop();

    /**
     * Get Center Bottom Coordinate
     * @return Coordinate 
     * @throws \UnexpectedValueException
     */
    public function getCenterBottom() {
        $result = $this->centerBottom();
        $this->assertCoordinate($result);
        return $result;
    }

    /**
     * Get Center Bottom Coordinate
     * @return Coordinate 
     */
    abstract protected function centerBottom();
}
