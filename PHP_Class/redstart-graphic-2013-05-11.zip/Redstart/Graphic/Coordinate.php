<?php

namespace Redstart\Graphic;

/**
 * Coordinate Object
 * 
 * @package Redstart
 * @subpackage Redstart_Graphic
 * 
 * @author Hyyan Abo Fakher
 * @since Redstart 1.0
 * @version 1.0
 */
class Coordinate {

    /**
     * X position
     * @var int
     */
    private $x;

    /**
     * Y Position
     * @var int
     */
    private $y;

    /**
     * Coordinate Color
     * @var Color
     */
    private $color;

    /**
     * Construct New Coordinate Object
     * @param int $x x pos
     * @param int $y y pos
     */
    public function __construct($x = 0, $y = 0) {
        $this->setLocation($x, $y);
    }

    /**
     * Set X Position
     * @param int $x
     */
    public function setX($x) {
        $this->x = $x;
    }

    /**
     * Get X Position
     * @return int
     */
    public function getX() {
        return $this->x;
    }

    /**
     * Set Y Position
     * @param int $y
     */
    public function setY($y) {
        $this->y = $y;
    }

    /**
     * Get Y position
     * @return int
     */
    public function getY() {
        return $this->y;
    }

    /**
     * Set Coordinate Location 
     * @param int $x
     * @param int $y
     */
    public function setLocation($x, $y) {
        $this->setX($x);
        $this->setY($y);
    }

    /**
     * Get New Coordinate Object with same coordinates
     * @return \Redstart\Graphic\Coordinate
     */
    public function getLocation() {
        return new Coordinate($this->getX(), $this->getY());
    }

    /**
     * Returns a string representation of this <code>Coordinate</code>
     * @return string
     */
    public function __toString() {
        return get_called_class() . "[x={$this->getX()},y={$this->getY()}]";
    }

}

