<?php

namespace Redstart\Graphic;

use Redstart\Graphic\GraphicException\ShapeException;
/**
 * Arc Object
 * 
 * @package Redstart
 * @subpackage Redstart_Graphic
 * 
 * @author Hyyan Abo Fakher
 * @since Redstart 1.0
 * @version 1.0
 */
class Arc extends RectangleShape {

    /**
     * Arc Center
     * @var Coordinate
     */
    private $ArcCenter;

    /**
     * Start Degree
     * @var int
     */
    private $StartDegree;

    /**
     * End Degree
     * @var int
     */
    private $EndDegree;

    /**
     * Is Angles Connected 
     * @var boolean
     */
    private $AnglesConnected = false;

    /**
     * Is Rounded Edge
     * @var boolean
     */
    private $RoundedEdge = true;

    /**
     * Angles Is Connected To Center
     * @var boolean
     */
    private $AnglesConnectedToCenter = false;

    /**
     * Construct New Arc Object
     * @param \Redstart\Graphic\Dimension $dimension
     * @param \Redstart\Graphic\Coordinate $center
     */
    public function __construct(Dimension $dimension = null, Coordinate $center = null) {
        parent::__construct($dimension);
        $this->setCenter($center === null ? new Coordinate() : $center);
        $this->setDegree(0, 360);
    }

    /**
     * Set Center
     * @param Coordinate $center
     */
    public function setCenter(Coordinate $center) {
        $this->ArcCenter = $center;
    }

    /**
     * Get Center
     * @return Coordinate
     */
    public function getCenter() {
        return $this->ArcCenter;
    }

    /**
     * Set Start Degree
     * @param int $degree
     */
    public function setStartDegree($degree) {
        $this->StartDegree = $degree;
    }

    /**
     * Get Start Degree
     * @return int
     */
    public function getStartDegree() {
        return $this->StartDegree;
    }

    /**
     * Set End Degree
     * @param int $degree
     */
    public function setEndDegree($degree) {
        $this->EndDegree = $degree;
    }

    /**
     * get End Degree
     * @return int
     */
    public function getEndDegree() {
        return $this->EndDegree;
    }

    /**
     * Set Start And End Degree
     * @param int $start start degree
     * @param int $end end degree
     */
    public function setDegree($start, $end) {
        $this->setStartDegree($start);
        $this->setEndDegree($end);
    }

    /**
     * Connect Angles
     * Connet the starting and ending angles with a straight line
     * @param boolean $boolean True To Connect Angles togther
     */
    public function connectAngles($boolean) {
        $this->AnglesConnected = $boolean;
    }

    /**
     * Is Angles Connected Toghter
     * @return boolean
     */
    public function isAnglesConnected() {
        return $this->AnglesConnected;
    }

    /**
     * Set Roundded Edge
     * @param boolean $boolean
     */
    public function setRounded($boolean) {
        $this->RoundedEdge = $boolean;
    }

    /**
     * Get is rounded
     * @return boolean
     */
    public function isRounded() {
        return $this->RoundedEdge;
    }

    /**
     * Set Connected To Center
     * @param boolean $boolean true indicates that the beginning and ending angles
     * should be connected to the center 
     */
    public function connectAnglesToCenter($boolean) {
        $this->AnglesConnectedToCenter = $boolean;
    }

    /**
     * Get Angles Connected to center
     * @return boolean
     */
    public function isAnglesConnectedToCenter() {
        return $this->AnglesConnectedToCenter;
    }

    /**
     * Get Bitflags
     * @param array $flags
     * @return int
     */
    private function getBitflags(array $flags) {
        $val = null;
        foreach ($flags as $flag)
            $val = $val | $flag;
        return $val;
    }

    /**
     * Draw Any Kind Of Arcs
     * @param Resource $resource
     * @param boolean $fill true to fill arc
     * @param string $color color identifier
     * @throws ShapeException
     */
    private function drawGeneralArc(Resource $resource, $color, $fill = false) {
        $falgs = array();
        if ($this->isRounded()) {
            $falgs[] = IMG_ARC_PIE;
        }

        if ($this->isAnglesConnected()) {
            $falgs[] = IMG_ARC_CHORD;
        }

        if ($this->isAnglesConnectedToCenter()) {
            $falgs[] = IMG_ARC_EDGED;
        }
        if ($fill == false) {
            $falgs[] = IMG_ARC_NOFILL;
        }

        if (
                !imagefilledarc(
                        $resource->getHandler()
                        , $this->getCenter()->getX()
                        , $this->getCenter()->getY()
                        , $this->getDimension()->getWidth()
                        , $this->getDimension()->getHeight()
                        , $this->getStartDegree()
                        , $this->getEndDegree()
                        , $color
                        , $this->getBitflags($falgs)
                )
        ) {
            throw new ShapeException("Could Not Draw The Arc");
        }
    }

    protected function doDrawFilledShape(Resource $resource, $color) {
        $this->drawGeneralArc($resource, $color, true);
    }

    protected function doDrawNonFilledShape(Resource $resource, $color) {
        $this->drawGeneralArc($resource, $color, false);
    }

    /**
     * Returns a string representation of this <code>Arc</code> Object
     * @return string
     */
    public function __toString() {
        return get_called_class()
                . "["
                . "dimension={$this->getDimension()}"
                . ",startDegree={$this->getStartDegree()}"
                . ",endDegree={$this->getEndDegree()}"
                . ",center={$this->getCenter()}"
                . "]";
    }

}

