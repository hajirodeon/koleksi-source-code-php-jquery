<?php

namespace Redstart\Graphic;

/**
 * Box Object
 * 
 * @package Redstart
 * @subpackage Redstart_Graphic
 * 
 * @author Hyyan Abo Fakher
 * @since Redstart 1.0
 * @version 1.0
 */
class Box {

    /**
     * Coordinate Object
     * @var Coordinate
     */
    private $BoxCoordinateObject;

    /**
     * Dimension Object
     * @var Dimesnion
     */
    private $BoxDimensionObject;

    /**
     * Construct New Box Object
     * @param \Redstart\Graphic\Dimension $dimension
     * @param \Redstart\Graphic\Coordinate $coordinate
     */
    public function __construct(Dimension $dimension, Coordinate $coordinate = null) {
        $this->setCoordinate(($coordinate === null) ? new Coordinate(0, 0) : $coordinate);
        $this->setDimension($dimension);
    }

    /**
     * Set Box Coordinate(Top Left)
     * @param \Redstart\Graphic\Coordinate $coordinate
     */
    public function setCoordinate(Coordinate $coordinate) {
        $this->BoxCoordinateObject = $coordinate;
    }

    /**
     * Get Box Coordinate
     * @return Coordinate
     */
    public function getCoordinate() {
        return $this->BoxCoordinateObject;
    }

    /**
     * Set Box Dimension (Width and Height)
     * @param \Redstart\Graphic\Dimension $dimension
     */
    public function setDimension(Dimension $dimension) {
        $this->BoxDimensionObject = $dimension;
    }

    /**
     * Get Box Dimension
     * @return Dimension
     */
    public function getDimension() {
        return $this->BoxDimensionObject;
    }

    /**
     * Returns a string representation of the values of this 
     * <code>Box</code> object's <code>dimension</code> and 
     * <code>coordinate</code> fields.
     * @return string
     */
    public function __toString() {
        return get_called_class() . "[{$this->getDimension()},{$this->getCoordinate()}]";
    }

}

