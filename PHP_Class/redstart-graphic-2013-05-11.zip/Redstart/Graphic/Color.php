<?php

namespace Redstart\Graphic;

use Redstart\Graphic\GraphicException\ColorAllocateException;
use Redstart\Graphic\GraphicException\ColorException;
use Redstart\Graphic\GraphicException\EmptyResource;

/**
 * Color Object
 * 
 * @package Redstart
 * @subpackage Redstart_Graphic
 * 
 * @author Hyyan Abo Fakher
 * @since Redstart 1.0
 * @version 1.0
 */
class Color {

    /**
     * Red
     * @var int
     */
    private $red;

    /**
     * Green
     * @var int
     */
    private $green;

    /**
     * Blue
     * @var int
     */
    private $blue;

    /**
     * Alpha
     * @var int 
     */
    private $alpha;

    /**
     * Construct New Color Object
     * @param int $red red value in range (0->255) or in hex in range(0x00 -> 0xFF) 
     * @param int $green green value in range (0->255) or in hex in range(0x00 -> 0xFF) 
     * @param int $blue blue value in range (0->255) or in hex in range(0x00 -> 0xFF) 
     * @param int $alpha alpha value in range (0->127) where 0 indicates completely
     * opaque while 127 indicates completely transparent.
     * @throws \InvalidArgumentException
     */
    public function __construct($red = 0, $green = 0, $blue = 0, $alpha = 0) {
        $this->setColor($red, $green, $blue, $alpha);
    }

    /**
     * Set red value
     * @param type $red
     */
    public function setRed($red) {
        $this->red = $red;
    }

    /**
     * Get Red value
     * @return int
     */
    public function getRed() {
        return $this->red;
    }

    /**
     * Set green value
     * @param int $green
     */
    public function setGreen($green) {
        $this->green = $green;
    }

    /**
     * Get Green Value
     * @return int
     */
    public function getGreen() {
        return $this->green;
    }

    /**
     * Set blue value
     * @param int $blue
     */
    public function setBlue($blue) {
        $this->blue = $blue;
    }

    /**
     * Get Blue Value
     * @return int
     */
    public function getBlue() {
        return $this->blue;
    }

    /**
     * Set Alpha
     * @param int $alpha value between 0 and 127. 0 indicates completely opaque 
     * while 127 indicates completely transparent
     * <b>Note :</b>
     * Alpha is not color property becuase of that some resources might not
     * support the alpha option
     * @throws \InvalidArgumentException
     */
    public function setAlpha($alpha) {
        if (!($alpha >= 0 && $alpha <= 127)) {
            throw new \InvalidArgumentException("Alpha Value Must Be between 0 and 127 ");
        }
        $this->alpha = $alpha;
    }

    /**
     * Get Alpha
     * @return type
     */
    public function getAlpha() {
        return $this->alpha;
    }

    /**
     * Set Color
     * @param int $red
     * @param int $green
     * @param int $blue
     * @param int $alpha 
     */
    public function setColor($red, $green, $blue, $alpha) {
        $this->setRed($red);
        $this->setGreen($green);
        $this->setBlue($blue);
        $this->setAlpha($alpha);
    }

    /**
     * Get New Color object with same valu of this object
     * @return \Redstart\Graphic\Color
     */
    public function getColor() {
        return new Color($this->getRed(), $this->getGreen(), $this->getBlue(), $this->getAlpha());
    }

    /**
     * Check If Resource Is valid Handler
     * @param Resource $resource
     * @throws EmptyResource
     */
    protected static function assertResourceHandler(Resource $resource) {
        if (!$resource->isHandlerSet()) {
            throw new EmptyResource("Resource Is Empty");
        }
    }

    /**
     * Returns a color (or the closest) identifier representing the color composed 
     * of the given RGB components.  
     * @param Resource $resource
     * @throws ColorAllocateException
     * @throws EmptyResource
     */
    public function allocate(Resource $resource) {
        self::assertResourceHandler($resource);
        $result = imagecolorallocatealpha(
                $resource->getHandler()
                , $this->getRed()
                , $this->getGreen()
                , $this->getBlue()
                , $this->getAlpha()
        );
        if ($result === false) {
            $result = imagecolorclosestalpha(
                    $resource->getHandler()
                    , $this->getRed()
                    , $this->getGreen()
                    , $this->getBlue()
                    , $this->getAlpha()
            );
            if ($result === false) {
                throw new ColorAllocateException(
                        sprintf("([r=%d,g=%d,b=%s,alpha=%s]) Color Allocation Failed"
                                , $this->getRed()
                                , $this->getGreen()
                                , $this->getBlue()
                                , $this->getAlpha()
                        )
                );
            }
        }

        return $result;
    }

    private static $FATCOR = 0.7;

    /**
     * Create New Color Object that is darker version of this color
     * @return \Redstart\Graphic\Color
     */
    public function darker() {
        return new Color(
                        max(array((int) $this->getRed() * self::$FATCOR, 0))
                        , max(array((int) $this->getGreen() * self::$FATCOR, 0))
                        , max(array((int) $this->getBlue() * self::$FATCOR, 0))
                        , $this->getAlpha()
        );
    }

    /**
     * Create Brighter version of this color
     * @return \Redstart\Graphic\Color
     */
    public function brighter() {
        $r = $this->getRed();
        $g = $this->getGreen();
        $b = $this->getBlue();
        $alpha = $this->getAlpha();
        $i = (int) (1.0 / (1.0 - self::$FATCOR));
        if ($r == 0 && $g == 0 && $b == 0) {
            return new Color($i, $i, $i, $alpha);
        }
        if ($r > 0 && $r < $i)
            $r = $i;
        if ($g > 0 && $g < $i)
            $g = $i;
        if ($b > 0 && $b < $i)
            $b = $i;

        return new Color(
                        min(array((int) ($r / self::$FATCOR), 255))
                        , min(array((int) ($g / self::$FATCOR), 255))
                        , min(array((int) ($b / self::$FATCOR), 255))
                        , $alpha
        );
    }

    /**
     * Get the index of the color of the pixel at the specified location in the 
     * Resource.
     * @param Resource $resource
     * @param \Redstart\Graphic\Coordinate $coordinate
     * @return int the index of the color
     * @throws \OutOfBoundsException
     */
    protected static function getColorIndex(Resource $resource, Coordinate $coordinate) {
        self::assertResourceHandler($resource);
        $width = $resource->getWidth();
        $height = $resource->getHeight();
        $x = $coordinate->getX();
        $y = $coordinate->getY();
        if ($x >= $width || $y >= $height) {
            throw new \OutOfBoundsException(
                    sprintf("Could Not Get Color At (%s,%s) -  Out of bounds", $x, $y)
            );
        }
        return imagecolorat($resource->getHandler(), $x, $y);
    }

    /**
     * Gets the color for a specified coordinate. 
     * @param Resource $resource
     * @param \Redstart\Graphic\Coordinate $coordinate
     * @return \Redstart\Graphic\Color
     * @throws ColorException
     * @throws EmptyResource
     */
    public static function getColorAt(Resource $resource, Coordinate $coordinate) {
        self::assertResourceHandler($resource);
        $x = $coordinate->getX();
        $y = $coordinate->getY();
        $color = new Color();
        $result = imagecolorsforindex(
                $resource->getHandler(), self::getColorIndex($resource, $coordinate)
        );
        if (is_array($result)) {
            $color->setColor($result["red"], $result["green"], $result["blue"], $result["alpha"]);
        } else {
            throw new ColorException(
                    sprintf("Could Not Retrive Color In (%s,%s)", $x, $y)
            );
        }
        return $color;
    }

    /**
     * Get The Color In The Resource which is "closest" to the specified color
     * @param Resource $resource
     * @param \Redstart\Graphic\Color $color
     * @return \Redstart\Graphic\Color
     * @throws ColorException
     */
    public static function getClosestColor(Resource $resource, Color $color) {
        self::assertResourceHandler($resource);
        $resultColor = new Color();
        $result = imagecolorsforindex(
                $resource->getHandler()
                , imagecolorclosestalpha(
                        $resource->getHandler()
                        , $color->getRed()
                        , $color->getGreen()
                        , $color->getBlue()
                        , $color->getAlpha()
                )
        );

        if (is_array($result)) {
            $resultColor->setColor($result["red"], $result["green"], $result["blue"], $result["alpha"]);
        } else {
            throw new ColorException(
                    sprintf("Could Not Get The Closest Color For [r=%s,g=%s,b=%s,alpha=%s]"
                            , $color->getRed()
                            , $color->getGreen()
                            , $color->getBlue()
                            , $color->getAlpha()
                    )
            );
        }
        return $resultColor;
    }

    /**
     * Create new Color Object From Color in hex
     * @param string $hex color in hex 
     * @return \Redstart\Graphic\Color
     * @throws ColorException
     */
    public static function HEXtoRGB($hex) {
        $org = $hex;
        $hex = preg_replace("/[^0-9A-Fa-f]/", '', $hex);
        $rgb = array();
        if (strlen($hex) == 6) {
            $color = hexdec($hex);
            $rgb[0] = 0xFF & ($color >> 0x10);
            $rgb[1] = 0xFF & ($color >> 0x8);
            $rgb[2] = 0xFF & $color;
        } elseif (strlen($hex) == 3) {
            $rgb[0] = hexdec(str_repeat(substr($hex, 0, 1), 2));
            $rgb[1] = hexdec(str_repeat(substr($hex, 1, 1), 2));
            $rgb[2] = hexdec(str_repeat(substr($hex, 2, 1), 2));
        }
        if (empty($rgb)) {
            throw new ColorException(
                    sprintf("(%s) Is Not Valid Color", $org)
            );
        }
        return new self($rgb[0], $rgb[1], $rgb[2]);
    }

    /**
     * Returns a string representation of this <code>Color</code>
     * @return string
     */
    public function __toString() {
        return get_called_class() . "
            [r={$this->getRed()},g={$this->getGreen()},b={$this->getBlue()},alpha={$this->getAlpha()}]";
    }

}
