<?php

namespace Redstart\Graphic;

use Redstart\Graphic\GraphicException\EmptyResource;
use Redstart\Graphic\GraphicException\PixelException;

/**
 * Pixel Object
 * 
 * @package Redstart
 * @subpackage Redstart_Graphic
 * 
 * @author Hyyan Abo Fakher
 * @since Redstart 1.0
 * @version 1.0
 */
class Pixel extends Coordinate implements Drawable {

    /**
     * Pixel Color
     * @var Color
     */
    private $PixelColor;

    /**
     * Construct New Pixel Object
     * @param int $x x pos
     * @param int $y y pos
     */
    public function __construct($x = 0, $y = 0, $color = null) {
        parent::__construct($x, $y);
        $this->setColor($color === null ? new Color(0, 0, 0) : $color);
    }

    /**
     * Get Color
     * @return \Redstart\Graphic\Color
     */
    public function getColor() {
        return $this->PixelColor;
    }

    /**
     * Set Color 
     * @param \Redstart\Graphic\Color $color
     */
    public function setColor(Color $color) {
        $this->PixelColor = $color;
    }

    /**
     * Get Color Distance
     * @param \Redstart\Graphic\Color $color
     * @return int
     */
    public function colorDistance(Color $color) {
        $pixelColor = $this->getColor();

        $R1 = $pixelColor->getRed();
        $G1 = $pixelColor->getGreen();
        $B1 = $pixelColor->getBlue();

        $R2 = $color->getRed();
        $G2 = $color->getGreen();
        $B2 = $color->getBlue();

        $result = sqrt(
                ( $R1 - $R2 ) * ( $R1 - $R2 )
                + ( $G1 - $G2 ) * ( $G1 - $G2 )
                + ( $B1 - $B2 ) * ( $B1 - $B2 )
        );
        return $result;
    }

    /**
     * Draw Piexl On Resource
     * @param Resource $resource
     * @throws EmptyResource
     * @throws PixelException
     */
    public function draw(Resource $resource) {
        if (!$resource->isHandlerSet()) {
            throw new EmptyResource("Resource Is Empty");
        }

        $x = $this->getX();
        $y = $this->getY();
        if (
                !imagesetpixel(
                        $resource->getHandler()
                        , $x
                        , $y
                        , $this->getColor()->allocate($resource)
                )
        ) {
            throw new PixelException(
                    sprintf("Could Not Draw The Pixel At (%s,%s)", $x, $y)
            );
        }
    }

    /**
     * Returns a string representation of this <code>Pixel</code>
     * @return string
     */
    public function __toString() {
        return get_called_class() .
                "[x={$this->getX()},y={$this->getY()},r={$this->getColor()->getRed()}"
                . ",g={$this->getColor()->getGreen()},b={$this->getColor()->getBlue()}"
                . ",alpah={$this->getColor()->getAlpha()}]";
    }

}