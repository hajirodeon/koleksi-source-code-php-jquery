<?php

namespace Redstart\Graphic;

use Redstart\Graphic\GraphicException\EmptyResource;
use Redstart\Graphic\GraphicException\ShapeException;

/**
 * Shape Object
 * 
 * @package Redstart
 * @subpackage Redstart_Graphic
 * 
 * @author Hyyan Abo Fakher
 * @since Redstart 1.0
 * @version 1.0
 */
abstract class Shape implements Drawable {

    /**
     * Shape Color
     * @var Color
     */
    private $shapeColor;

    /**
     * Construct Abstract Shape Object
     */
    public function __construct() {
        $this->setColor(new Color());
    }

    /**
     * Set Color
     * @param \Redstart\Graphic\Color  $color Color object or GD special color
     */
    public function setColor($color) {
        $this->shapeColor = $color;
    }

    /**
     * Get Color
     * @return Color
     */
    public function getColor() {
        return $this->shapeColor;
    }

    /**
     * Check if resource hansler is empty
     * @param Resource $resource
     * @throws EmptyResource
     */
    protected function assertEmptyHandler(Resource $resource) {
        if (!$resource->getHandler()) {
            throw new EmptyResource("Resource Is Empty");
        }
    }

    /**
     * Set Line Thickness 
     * @param Resource $resource
     * @param int $thickness
     * @throws EmptyResource
     * @throws ShapeException
     */
    public static function setLineThickness(Resource $resource, $thickness) {
        if (!$resource->isHandlerSet()) {
            throw new EmptyResource("Resource Is Empty");
        }
        if (!imagesetthickness($resource->getHandler(), $thickness)) {
            throw new ShapeException("Could Not Set The Line Thickness");
        }
    }

    /**
     * Draw On Resource
     * @param Resource $resource
     * @throws EmptyResource
     * @throws ShapeException
     */
    public function draw(Resource $resource) {
        $this->assertEmptyHandler($resource);
        $this->doDraw($resource);
    }

    /**
     * Draw On Resource
     * @param Resource $resource
     * @throws EmptyResource
     */
    abstract protected function doDraw(Resource $resource);
}

