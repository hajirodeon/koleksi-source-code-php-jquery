<?php

namespace Redstart\Graphic;

use Redstart\Graphic\GraphicException\ResourceCreationException;

/**
 * Gif Image Object
 * 
 * @package Redstart
 * @subpackage Redstart_Graphic
 * 
 * @author Hyyan Abo Fakher
 * @since Redstart 1.0
 * @version 1.0
 */
class Gif extends ImageResource {

    /**
     * Load From File
     * @param string $filename
     * @throws ResourceOutputException
     */
    protected function doSave($filename) {
        if (!imagegif($this->getHandler(), $filename)) {
            throw new ResourceOutputException(
                    sprintf("Could Not Save Resource To (%s)", $filename)
            );
        }
    }

    /**
     * Check If The File Is valid gif file
     * @param string $filename
     * @throws \InvalidArgumentException
     * @throws InvalidImageFileException
     * @throw \RuntimeException
     */
    protected function assertGifFile($filename) {
        $image = new ImageFile($filename);
        if (strtolower($image->getMime()) != "image/gif") {
            throw new \InvalidArgumentException(
                    sprintf("(%s) Is Not valid Gif File", $filename)
            );
        }
    }

    /**
     * Load Png File from File
     * @param string $filename
     * @throws ResourceCreationException
     */
    protected function doLoadFromFile($filename) {
        $this->assertGifFile($filename);
        $handler = imagecreatefromgif($filename);
        if ($handler === false) {
            throw new ResourceCreationException(
                    sprintf("Could Not Create Resource From (%s)", $filename)
            );
        }
        $this->setHandler($handler);
    }

    /**
     * Get Copy from this Gif Resource
     * @return Gif 
     */
    public function doGetCopy() {
        $clone = new Gif($this->getDimension());
        $clone->merge($this);
        return $clone;
    }

}

