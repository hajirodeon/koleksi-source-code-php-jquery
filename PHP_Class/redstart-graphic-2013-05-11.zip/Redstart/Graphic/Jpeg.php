<?php

namespace Redstart\Graphic;

use Redstart\Graphic\GraphicException\ResourceCreationException;

/**
 * Jpeg Image Object
 * 
 * @package Redstart
 * @subpackage Redstart_Graphic
 * 
 * @author Hyyan Abo Fakher
 * @since Redstart 1.0
 * @version 1.0
 */
class Jpeg extends CompressedImage {

    public function __construct(Dimension $dimension = null, $trueColor = true) {
        parent::__construct($dimension, $trueColor);
    }

    /**
     * Load From File
     * @param string $filename
     * @throws ResourceOutputException
     */
    protected function doSave($filename) {
        if (!imagejpeg($this->getHandler(), $filename, $this->getQuality())) {
            throw new ResourceOutputException(
                    sprintf("Could Not Save Resource To (%s)", $filename)
            );
        }
    }

    /**
     * Check If The File Is valid jpeg file
     * @param string $filename
     * @throws \InvalidArgumentException
     * @throws InvalidImageFileException
     */
    protected function assertJpegFile($filename) {
        $image = new ImageFile($filename);
        if (strtolower($image->getMime()) != "image/jpeg") {
            throw new \InvalidArgumentException(
                    sprintf("(%s) Is Not valid JPEG File", $filename)
            );
        }
    }

    protected function doLoadFromFile($filename) {
        $this->assertJpegFile($filename);
        $handler = imagecreatefromjpeg($filename);
        if ($handler === false) {
            throw new ResourceCreationException(
                    sprintf("Could Not Create Resource From (%s)", $filename)
            );
        }
        $this->setHandler($handler);
    }

    /**
     * Get Copy from this Jpeg Resource
     * @return Jpeg 
     */
    public function doGetCopy() {
        $clone = new Jpeg($this->getDimension());
        $clone->merge($this);
        return $clone;
    }

}

