<?php

namespace Redstart\Graphic;

use Redstart\Graphic\GraphicException\ResourceCreationException;
use Redstart\Graphic\GraphicException\InvalidDimension;

/**
 * Image Resource Object
 * 
 * @package Redstart
 * @subpackage Redstart_Graphic
 * 
 * @author Hyyan Abo Fakher
 * @since Redstart 1.0
 * @version 1.0
 */
abstract class ImageResource extends Resource {

    /**
     * Image Dimension
     * @var Dimension
     */
    protected $imageDimension;

    /**
     * is true color image
     * @var boolean
     */
    protected $isTrueColorImage;

    /**
     * Create New Image Resource
     * @param \Redstart\Graphic\Dimension $dimension
     * @param boolean $trueColor
     * @throws ResourceCreationException
     */
    public function __construct(Dimension $dimension = null, $trueColor = true) {
        parent::__construct();
        $this->imageDimension = $dimension;
        $this->isTrueColorImage = $trueColor;
        if ($this->imageDimension != null) {
            $this->buildResource();
        }
    }

    /**
     * Build The Image Resource
     * @throws ResourceCreationException
     */
    private function buildResource() {
        if ($this->imageDimension != null) {
            $x = $this->imageDimension->getWidth();
            $y = $this->imageDimension->getHeight();
            if ($x <= 0 || $y <= 0) {
                throw new InvalidDimension(
                        sprintf("Invalid Dimension(%s,%s)", $x, $y)
                );
            }
            if ($this->isTrueColorImage) {
                $handler = imagecreatetruecolor($x, $y);
            } else {
                $handler = imagecreate($x, $y);
            }
        }
        if ($handler === false) {
            throw new ResourceCreationException("Could Not Create The Image");
        }
        $this->setHandler($handler);
        $this->fill(new Color(255, 255, 255));
    }

    /**
     * Create Resource 
     * @param \Redstart\Graphic\Dimension $dimension
     * @param boolean $trueColor
     */
    public function create(Dimension $dimension, $trueColor = true) {
        $this->imageDimension = $dimension;
        $this->isTrueColorImage = $trueColor;
        $this->buildResource();
    }

    /**
     * Create Resource from GD resource file
     * @param string $filename
     */
    public function createFromGdFile($filename) {
        $gd = new Gd();
        $gd->loadFromFile($filename);
        $this->loadFromResource($gd);
        $gd->destroy();
    }

    /**
     * Convert Current Resource Into GD Resource
     * @return \Redstart\Graphic\Gd
     */
    public function convertToGd() {
        $gd = new Gd();
        $gd->loadFromResource($this);
        return $gd;
    }

    /**
     * Create Resource from GD2 resource file
     * @param string $filename
     */
    public function createFromGd2File($filename) {
        $gd2 = new Gd2();
        $gd2->loadFromFile($filename);
        $this->loadFromResource($gd2);
        $gd2->destroy();
    }

    /**
     * Convert Current Resource Into GD2 Resource
     * @return \Redstart\Graphic\Gd2
     */
    public function convertToGd2() {
        $gd2 = new Gd2();
        $gd2->loadFromResource($this);
        return $gd2;
    }

}