<?php

namespace Redstart\Graphic;

/**
 * Drawable Interface
 * 
 * Every Object wants to darw itself on resource should implement this interface
 * 
 * @package Redstart
 * @subpackage Redstart_Graphic
 * 
 * @author Hyyan Abo Fakher
 * @since Redstart 1.0
 * @version 1.0
 */
interface Drawable {

    /**
     * @param Resource $resource
     */
    public function draw(Resource $resource);
}
