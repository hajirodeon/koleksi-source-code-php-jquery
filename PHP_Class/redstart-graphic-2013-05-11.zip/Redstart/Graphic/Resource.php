<?php

namespace Redstart\Graphic;

use Redstart\Graphic\GraphicException\ResourceDestroyException;
use Redstart\Graphic\GraphicException\ResourceException;
use Redstart\Graphic\GraphicException\EmptyResource;
use Redstart\Graphic\GraphicException\InvalidCoordinate;
use Redstart\Graphic\Action\ResourceAction;

/**
 * Resource Object
 * 
 * @package Redstart
 * @subpackage Redstart_Graphic
 * 
 * @author Hyyan Abo Fakher
 * @since Redstart 1.0
 * @version 1.0
 */
abstract class Resource {

    /**
     * GD Resource
     * @var Resource
     */
    private $GdResourceHandler = null;

    /**
     * Construct New Resource
     */
    public function __construct() {
        
    }

    /**
     * Set Resource Handler
     * @param resource $handler GD Resource 
     * @throws ResourceException
     */
    public function setHandler($handler) {
        $this->isValidGdResource($handler);
        $this->GdResourceHandler = $handler;
    }

    /**
     * Get Resource Handler
     * @return resource
     */
    public function getHandler() {
        return $this->GdResourceHandler;
    }

    /**
     * Get Width
     * @return int width or 0 if resource is empty
     */
    public function getWidth() {
        return $this->isHandlerSet() ? imagesx($this->getHandler()) : 0;
    }

    /**
     * Get Height
     * @return int height or 0 if resource is empty
     */
    public function getHeight() {
        return $this->isHandlerSet() ? imagesy($this->getHandler()) : 0;
    }

    /**
     * Get image dimension
     * @return \Redstart\Graphic\Dimension
     */
    public function getDimension() {
        return new Dimension($this->getWidth(), $this->getHeight());
    }

    /**
     * Check if the resource represents a true resource color
     * @return boolean 
     * @throws EmptyResource
     */
    public function isTrueColor() {
        $this->assertEmpty();
        return imageistruecolor($this->getHandler()) ? true : false;
    }

    /**
     * Get Copy of this Resource object
     * @return \Redstart\Graphic\Resource
     * @throws EmptyResource
     */
    public function getCopy() {
        $this->assertEmpty();
        return $this->doGetCopy();
    }

    /**
     * Get Copy Of The Current Resource
     * @return Resource
     * @throws EmptyResource
     */
    abstract public function doGetCopy();

    /**
     * Load From Another Resource 
     * 
     * <b>Note :</b>
     * New Resource Object Will Be Created And any change to the dest resource
     * (loaded Resource) will not afect the current resource
     * @param Resource $resource
     * @throws ResourceException
     */
    public function loadFromResource(Resource $resource) {
        $copy = $resource->getCopy();
        $this->setHandler($copy->getHandler());
    }

    /**
     * Load Resource From File
     * @throws \InvalidArgumentException
     */
    public function loadFromFile($filename) {
        if (empty($filename)) {
            throw new \InvalidArgumentException("File Name Can Not Be Empty");
        }
        $this->doLoadFromFile($filename);
    }

    /**
     * Load Resource From String
     * @param type $string
     * @throws \InvalidArgumentException
     * @throws ResourceException
     */
    public function loadFromString($string) {
        if (empty($string)) {
            throw new \InvalidArgumentException("String Can Not Be Empty");
        }
        $result = imagecreatefromstring($string);
        if ($result === false) {
            throw new ResourceException("Invalid Resource String");
        }
        $this->setHandler($result);
    }

    /**
     * Load Resource From File
     * @throws \InvalidArgumentException
     */
    abstract protected function doLoadFromFile($filename);

    /**
     * Fill Image with Color
     * 
     * @param \Redstart\Graphic\Color $color
     * @param Coordinate $coordinate coordinate of start point
     * @throws EmptyResource
     * @throws ColorException
     */
    public function fill(Color $color, Coordinate $coordinate = null) {
        $this->assertEmpty();
        $coordinate = ($coordinate === null) ? new Coordinate() : $coordinate;
        if (!
                imagefill(
                        $this->getHandler()
                        , $coordinate->getX()
                        , $coordinate->getY()
                        , $color->allocate($this)
                )
        ) {
            throw new ColorException(
                    sprintf("Could Not Set Color To[r=%d,g=%d,b=%d,alpha=%d]"
                            , $this->getColor()->getRed()
                            , $this->getColor()->getGreen()
                            , $this->getColor()->getBlue()
                            , $this->getColor()->getAlpha()
                    )
            );
        }
    }

    /**
     * Fille resource with pattern
     * @param Resource $pattern another resource
     * @param Coordinate$coordinate $coordinate coordinate of start point
     * @throws ResourceException
     */
    public function fillPattern(Resource $pattern, Coordinate $coordinate = null) {
        $copy = $pattern->getCopy();
        if (
                !imagesettile(
                        $this->getHandler()
                        , $copy->getHandler())
        ) {
            throw new ResourceException("Could Not Set Tile");
        }
        $coordinate = ($coordinate === null) ? new Coordinate() : $coordinate;
        if (
                !imagefill(
                        $this->getHandler()
                        , $coordinate->getX()
                        , $coordinate->getY()
                        , IMG_COLOR_TILED
                )
        ) {
            throw new ResourceException("Could Not Fill The Resource With The Given Pattern");
        }
        $copy->destroy();
    }

    /**
     * Draw Drawable Object On The Resource
     * @param \Redstart\Graphic\Drawable $drawable
     * @throws EmptyResource
     */
    public function draw(Drawable $drawable) {
        $this->assertEmpty();
        $drawable->draw($this);
    }

    /**
     * Set Alpha Blending
     * 
     * <b>Note :</b>
     * Blending mode is not available when drawing on palette resources. 
     * 
     * On true color images the default value is true otherwise the default value 
     * is false
     *  
     * @param boolean $bool
     * @throws \RuntimeException
     */
    public function alphaBlending($bool) {
        if (!$this->isTrueColor()) {
            throw new \RuntimeException("Blending Mode Is Not Availabe For Non True Color Resources");
        }
        imagealphablending($this->getHandler(), $bool);
    }

    /**
     * Execute Action On The Resource
     * @param \Redstart\Graphic\Action\ResourceAction $action
     */
    public function executeAction(ResourceAction $action) {
        $action->executeAction($this);
    }

    /**
     * Merge two resources together 
     * 
     * <b>Note :</b>
     * if <code>$srcBox</code> or <code>$destBox</code> is empty then new Box 
     * object will be created its dimension is the same as <code>$src</code>
     * dimension and with coordinate (0,0)
     * 
     * @param Resource $src Resource that should be merged into current resource
     * @param \Redstart\Graphic\Box $srcBox Box from src Resource
     * @param \Redstart\Graphic\Box $destBox box for the current resource 
     * @throws EmptyResource
     * @throws ResourceException
     */
    public function merge(Resource $src, Box $srcBox = null, Box $destBox = null) {
        $this->assertEmpty();
        if (!$src->isHandlerSet()) {
            throw new EmptyResource("Source Resource Is Empty");
        }
        $srcDimension = $src->getDimension();
        $srcBox = ($srcBox === null) ? new Box($srcDimension) : $srcBox;
        $destBox = ($destBox === null) ? new Box($srcDimension) : $destBox;
        if (!imagecopyresampled(
                        $this->getHandler()
                        , $src->getHandler()
                        , $destBox->getCoordinate()->getX()
                        , $destBox->getCoordinate()->getY()
                        , $srcBox->getCoordinate()->getX()
                        , $srcBox->getCoordinate()->getY()
                        , $destBox->getDimension()->getWidth()
                        , $destBox->getDimension()->getHeight()
                        , $srcBox->getDimension()->getWidth()
                        , $srcBox->getDimension()->getHeight()
                )
        ) {
            throw new ResourceException("Could Not Merge Resources");
        }
    }

    /**
     * Get Pixel at specific coordinate
     * @param \Redstart\Graphic\Coordinate $coordinate
     * @return \Redstart\Graphic\Pixel
     */
    public function getPixel(Coordinate $coordinate) {
        $x = $coordinate->getX();
        $y = $coordinate->getY();
        if (($x < 0 || $x > $this->getWidth()) || ($y < 0 || $y > $this->getHeight())) {
            throw new InvalidCoordinate(
                    sprintf("Invalid Coordinate (%s,%s)", $x, $y)
            );
        }
        $pixel = new Pixel($x, $y);
        $pixelColor = Color::getColorAt($this, $coordinate);
        $pixel->setColor($pixelColor);
        return $pixel;
    }

    /**
     * Save Resource
     * @param string $path
     * @throws EmptyResource
     */
    public function save($path) {
        $this->assertEmpty();
        $this->doSave($path);
    }

    /**
     * Save Resource
     * @param string $filename
     */
    abstract protected function doSave($filename);

    /**
     * Destroy The Resource Handler
     * @throws ResourceDestroyException on failure
     */
    public function destroy() {
        if (!imagedestroy($this->getHandler())) {
            throw new ResourceDestroyException("Could Not Destroy The Resource");
        }
        $this->releaseHandler();
    }

    /**
     * Check if the handler is empty or not
     * @return Boolean
     */
    public function isHandlerSet() {
        return $this->getHandler() == null ? false : true;
    }

    /**
     * Check if the given handler represents a valid gd resource
     * @param resource $handler
     * @throws ResourceException
     */
    private function isValidGdResource($handler) {
        if (!(is_resource($handler) && get_resource_type($handler) == "gd")) {
            throw new ResourceException("Inavalid Resource Handler");
        }
    }

    /**
     * Check If The Resource is empty or not
     * @throws EmptyResource
     */
    protected function assertEmpty() {
        if (!$this->isHandlerSet()) {
            throw new EmptyResource("Empty Resource");
        }
    }

    /**
     * Reslease Resource Handler
     */
    protected function releaseHandler() {
        $this->GdResourceHandler = null;
    }

    /**
     * Returns a string representation of this <code>Resource</code> Object
     * @return string
     */
    public function __toString() {
        $result = get_called_class();
        if ($this->isHandlerSet()) {
            $trueColor = $this->isTrueColor() ? "true" : "false";
            $result.="[dimension={$this->getDimension()},trueColor={$trueColor}]";
        } else {
            $result.="[Empty Resource]";
        }
        return $result;
    }
}