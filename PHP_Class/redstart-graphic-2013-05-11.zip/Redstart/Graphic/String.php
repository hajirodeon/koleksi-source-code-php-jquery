<?php

namespace Redstart\Graphic;

use Redstart\Graphic\GraphicException\CharacterException;

/**
 * String Object
 * 
 * Draw String On Resource Object
 * 
 * @package Redstart
 * @subpackage Redstart_Graphic
 * 
 * @author Hyyan Abo Fakher
 * @since Redstart 1.0
 * @version 1.0
 */
class String extends Character {

    /**
     * Draw string Vertically or horizontally
     * @var boolean
     */
    private $isDrawVertical = false;

    /**
     * String font
     * @var int
     */
    protected $StringCharacterFont = 5;

    /**
     * Set font
     * 
     * <b>Note :</b>
     * Can be 1, 2, 3, 4, 5 for built-in fonts in latin2 encoding (where higher 
     * numbers corresponding to larger fonts) or any of your own font identifiers
     * registered with <code>imageloadfont()</code>
     * 
     * @param int $size
     */
    public function setFont($font) {
        $this->StringCharacterFont = $font;
    }

    /**
     * Get Font Width
     * @return int
     */
    public function getFontWidth() {
        return imagefontwidth($this->StringCharacterFont);
    }

    /**
     * Get Font Height
     * @return int
     */
    public function getFontHeight() {
        return imagefontheight($this->StringCharacterFont);
    }

    /**
     * Draw String Vertically
     * @param boolean $bool true to draw string vertically false to horizontally
     */
    public function drawVertically($bool) {
        $this->isDrawVertical = $bool;
    }

    /**
     * Draw Vertically
     * @return boolean
     */
    public function isVertical() {
        return $this->isDrawVertical == true ? true : false;
    }

    /**
     * Draw Horizontally
     * @return boolean
     */
    public function isHorizontal() {
        return $this->isDrawVertical == false ? true : false;
    }

    /**
     * Draw String On Resource
     * @param Resource $resource
     */
    protected function doDraw(Resource $resource) {
        $result = false;
        if ($this->isHorizontal()) {
            $result = imagestring(
                    $resource->getHandler()
                    , $this->StringCharacterFont
                    , $this->getCoordinate()->getX()
                    , $this->getCoordinate()->getY()
                    , $this->getString()
                    , $this->getColor()->allocate($resource)
            );
        } else {
            $result = imagestringup(
                    $resource->getHandler()
                    , $this->StringCharacterFont
                    , $this->getCoordinate()->getX()
                    , $this->getCoordinate()->getY()
                    , $this->getString()
                    , $this->getColor()->allocate($resource)
            );
        }

        if (!$result) {
            throw new CharacterException("Could Not Draw The Text");
        }
    }

}

