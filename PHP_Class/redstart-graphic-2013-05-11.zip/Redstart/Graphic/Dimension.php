<?php

namespace Redstart\Graphic;

/**
 * Dimension Object
 * 
 * @package Redstart
 * @subpackage Redstart_Graphic
 * 
 * @author Hyyan Abo Fakher
 * @since Redstart 1.0
 * @version 1.0
 */
class Dimension {

    /**
     * Width
     * @var int 
     */
    private $width;

    /**
     * Height
     * @var int
     */
    private $height;

    public function __construct($width = 0, $height = 0) {
        $this->setSize($width, $height);
    }

    /**
     * Set Width
     * @param int $width
     */
    public function setWidth($width) {
        $this->width = (int) $width;
    }

    /**
     * Set Height
     * @param int $height
     */
    public function setHeight($height) {
        $this->height = (int) $height;
    }

    /**
     * Get Width
     * @return int
     */
    public function getWidth() {
        return $this->width;
    }

    /**
     * Get Height
     * @return int
     */
    public function getHeight() {
        return $this->height;
    }

    /**
     * Set Dimension object size
     * @param int $width
     * @param int $height
     */
    public function setSize($width, $height) {
        $this->setWidth($width);
        $this->setHeight($height);
    }

    /**
     * Get new Dimension object with same width and height
     * @return \Redstart\Graphic\Dimension
     */
    public function getSize() {
        return new Dimension($this->getWidth(), $this->getHeight());
    }

    /**
     * Returns a string representation of the values of this 
     * <code>Dimension</code> object's <code>height</code> and 
     * <code>width</code> fields.
     * @return string
     */
    public function __toString() {
        return get_called_class() . "[width={$this->getWidth()},height={$this->getHeight()}]";
    }

}

