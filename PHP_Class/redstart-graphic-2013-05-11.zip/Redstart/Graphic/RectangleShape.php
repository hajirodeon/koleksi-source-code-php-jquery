<?php

namespace Redstart\Graphic;

/**
 * Rectangle Shape Object
 * 
 * @package Redstart
 * @subpackage Redstart_Graphic
 * 
 * @author Hyyan Abo Fakher
 * @since Redstart 1.0
 * @version 1.0
 */
abstract class RectangleShape extends FilledShape {

    /**
     * Shape Dimension
     * @var Dimension
     */
    private $ShapeDimension;

    /**
     * Construct New Rectangle Shape
     * @param \Redstart\Graphic\Dimension $dimension
     */
    public function __construct(Dimension $dimension = null) {
        parent::__construct();
        $this->setDimension($dimension === null ? new Dimension() : $dimension);
    }

    /**
     * Set Dimension (Width and Height)
     * @param \Redstart\Graphic\Dimension $dimension
     */
    public function setDimension(Dimension $dimension) {
        $this->ShapeDimension = $dimension;
    }

    /**
     * Get Dimension
     * @return Dimension
     */
    public function getDimension() {
        return $this->ShapeDimension;
    }


}

