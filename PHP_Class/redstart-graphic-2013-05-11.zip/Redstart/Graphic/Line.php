<?php

namespace Redstart\Graphic;

use Redstart\Graphic\GraphicException\ShapeException;

/**
 * Line Object
 * 
 * @package Redstart
 * @subpackage Redstart_Graphic
 * 
 * @author Hyyan Abo Fakher
 * @since Redstart 1.0
 * @version 1.0
 */
class Line extends Shape {

    /**
     * Start Coordinate
     * @var Coordinate
     */
    private $startCoordinate;

    /**
     * End Coordinate
     * @var Coordinate
     */
    private $endCoordinate;

    /**
     * Line Color
     * @var Color
     */
    private $lineColor;

    /**
     * Construct new Line object  
     * @param \Redstart\Graphic\Coordinate $startCoor
     * @param \Redstart\Graphic\Coordinate $endCoor
     */
    public function __construct(Coordinate $startCoor = null, Coordinate $endCoor = null) {
        parent::__construct();
        $start = $startCoor === null ? new Coordinate() : $startCoor;
        $end = $endCoor === null ? new Coordinate() : $endCoor;
        $this->setLocation($start, $end);
    }

    /**
     * Set Start Coordinate
     * @param \Redstart\Graphic\Coordinate $startCoor
     */
    public function setStart(Coordinate $startCoor) {
        $this->startCoordinate = $startCoor;
    }

    /**
     * Get Start Coordinate
     * @return Coordinate
     */
    public function getStart() {
        return $this->startCoordinate;
    }

    /**
     * Set End Coordinate
     * @param \Redstart\Graphic\Coordinate $endCoor
     */
    public function setEnd(Coordinate $endCoor) {
        $this->endCoordinate = $endCoor;
    }

    /**
     * Get End Coordinate
     * @return Coordinate
     */
    public function getEnd() {
        return $this->endCoordinate;
    }
    
    /**
     * Set Line Start And End Coordinate
     * @param \Redstart\Graphic\Coordinate $start
     * @param \Redstart\Graphic\Coordinate $end
     */
    public function setLocation(Coordinate $start, Coordinate $end) {
        $this->setStart($start);
        $this->setEnd($end);
    }

    /**
     * Draw on resource
     * @param Resource $resource
     * @throws ShapeException
     */
    protected function doDraw(Resource $resource) {
        $sx = $this->getStart()->getX();
        $sy = $this->getStart()->getY();
        $ex = $this->getEnd()->getX();
        $ey = $this->getEnd()->getY();
        if (!imageline(
                        $resource->getHandler()
                        , $sx
                        , $sy
                        , $ex
                        , $ey
                        , $this->getColor()->allocate($resource)
                )
        ) {
            throw new ShapeException(
                    sprintf("Colud Not Draw The Line From (%s,%s) To (%s,%s)"
                            , $sx, $sy, $ex, $ey)
            );
        }
    }

    /**
     * Returns a string representation of the values of this 
     * <code>Line</code> object's <code>Strat</code> and 
     * <code>End</code> coordinates.
     * @return string
     */
    public function __toString() {
        return get_called_class()
                . "[start={$this->getStart()},end={$this->getEnd()}]";
    }

}

