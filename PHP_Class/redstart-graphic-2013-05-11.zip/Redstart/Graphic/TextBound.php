<?php

namespace Redstart\Graphic;

/**
 * Text Bound Object
 * 
 * Draw Text On Resource Object
 * 
 * @package Redstart
 * @subpackage Redstart_Graphic
 * 
 * @author Hyyan Abo Fakher
 * @since Redstart 1.0
 * @version 1.0
 */
class TextBound {

    /**
     * Text Object
     * @var Text
     */
    protected $TextObject;

    /**
     * Text Coordinate
     * @var Coordinate
     */
    protected $TextCoordinate;

    /**
     * Text Dimension
     * @var Dimension
     */
    protected $TextDimesnion;

    /**
     * Text Box
     * @var array
     */
    protected $TextBox;

    /**
     * Construct New Text Bounder Object
     * @param \Redstart\Graphic\Text $text
     */
    public function __construct(Text $text) {
        $this->TextObject = $text;

        $rect = imagettfbbox(
                $text->getSize()
                , $text->getAngle()
                , $text->getFont()
                , $text->getString()
        );
        if (!$rect) {
            throw new \RuntimeException("Could Not Calculate The Bounds");
        }


        $minX = min(array($rect[0], $rect[2], $rect[4], $rect[6]));
        $maxX = max(array($rect[0], $rect[2], $rect[4], $rect[6]));
        $minY = min(array($rect[1], $rect[3], $rect[5], $rect[7]));
        $maxY = max(array($rect[1], $rect[3], $rect[5], $rect[7]));


        $left = abs($minX) - 1;
        $top = abs($minY) - 1;

        $width = $maxX - $minX;
        $height = $maxY - $minY;


        $this->TextCoordinate = new Coordinate($left, $top);
        $this->TextDimesnion = new Dimension($width, $height);
        $this->TextBox = $rect;
    }

    /**
     * Get Text box
     * @return array
     */
    public function getBox() {
        return $this->TextBox;
    }

    /**
     * Get Coordinate (Top Left)
     * @return Coordinate
     */
    public function getCoordintae() {
        return $this->TextCoordinate;
    }

    /**
     * Get Dimension 
     * @return Dimension
     */
    public function getDimension() {
        return $this->TextDimesnion;
    }

    /**
     * Get Fixed Position
     * @return \Redstart\Graphic\Coordinate
     */
    public function getFixedPosition() {
        $rx = $this->getCoordintae()->getX();
        $ry = $this->getCoordintae()->getY();
        $fx = $rx + $this->TextObject->getCoordinate()->getX();
        $fy = $ry + $this->TextObject->getCoordinate()->getY();
        return new Coordinate($fx, $fy);
    }

    /**
     * Get Text Dimension
     * @return \Redstart\Graphic\Dimension
     */
    public function getTextDimension() {
        $fp = $this->getFixedPosition();
        $tw = $fp->getX() + $this->getDimension()->getWidth();
        $th = $fp->getY() + $this->getDimension()->getHeight();
        return new Dimension($tw, $th);
    }

}

