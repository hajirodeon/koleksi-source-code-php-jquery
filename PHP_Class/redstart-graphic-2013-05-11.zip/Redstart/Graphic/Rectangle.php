<?php

namespace Redstart\Graphic;

use Redstart\Graphic\GraphicException\ShapeException;

/**
 * Rectangle Object
 * 
 * @package Redstart
 * @subpackage Redstart_Graphic
 * 
 * @author Hyyan Abo Fakher
 * @since Redstart 1.0
 * @version 1.0
 */
class Rectangle extends RectangleShape {

    /**
     * Upper Left Coordinate
     * @var Coordinate
     */
    private $UppeLeftCoordinate;

    /**
     * Construct New Rectangle Object
     * @param \Redstart\Graphic\Dimension $size Rectangle Dimension(Width and Height)
     * @param \Redstart\Graphic\Coordinate $start The Upper Left Point
     */
    public function __construct(Dimension $size = null, Coordinate $start = null) {
        parent::__construct($size);
        $this->setStart($start === null ? new Coordinate() : $start);
    }

    /**
     * Set Start Coordinate (Upper Left Coordinate)
     * @param \Redstart\Graphic\Coordinate $coordinate
     */
    public function setStart(Coordinate $coordinate) {
        $this->UppeLeftCoordinate = $coordinate;
    }

    /**
     * Get Start Coordinate
     * @return Coordinate
     */
    public function getStart() {
        return $this->UppeLeftCoordinate;
    }

    protected function doDrawFilledShape(Resource $resource, $color) {
        $x = $this->getStart()->getX();
        $y = $this->getStart()->getY();
        if (
                !imagefilledrectangle(
                        $resource->getHandler()
                        , $x
                        , $y
                        , $this->getDimension()->getWidth() + $x
                        , $this->getDimension()->getHeight() + $y
                        , $color
                )
        ) {
            throw new ShapeException("Could Not Draw The Rectangle");
        }
    }

    protected function doDrawNonFilledShape(Resource $resource, $color) {
        $x = $this->getStart()->getX();
        $y = $this->getStart()->getY();
        if (
                !imagerectangle(
                        $resource->getHandler()
                        , $x
                        , $y
                        , $this->getDimension()->getWidth() + $x
                        , $this->getDimension()->getHeight() + $y
                        , $color
                )
        ) {
            throw new ShapeException("Could Not Draw The Rectangle");
        }
    }

    /**
     * Returns a string representation of the values of this 
     * <code>Rectangle</code> object's <code>dimesnion</code> and 
     * <code>coordinate</code> fields.
     * @return string
     */
    public function __toString() {
        return get_called_class()
                . "[dimension={$this->getDimension()},startCoordinate={$this->getStart()}]";
    }

}

