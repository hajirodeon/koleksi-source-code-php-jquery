<?php

namespace Redstart\Graphic\Action;

use Redstart\Graphic\Resource;
use Redstart\Graphic\Box;
use Redstart\Graphic\Coordinate;
use Redstart\Graphic\GraphicException\EmptyResource;

/**
 * Watermark Action
 * 
 * @see Redstart\Graphic\ResourceCoordinate
 * 
 * @package Redstart
 * @subpackage Redstart_Graphic_Action
 * 
 * @author Hyyan Abo Fakher
 * @since Redstart 1.0
 * @version 1.0
 */
class WatermarkAction extends AbstractResourceAction {

    /**
     * Watermark resource
     * @var Resource
     */
    private $WatermarkResource;

    /**
     * Watermark position
     * @var \Redstart\Graphic\Coordinate
     */
    private $WatermarkPosition;

    /**
     * Construct New Watermark Action
     * 
     * @param Resource $watermark
     * @param \Redstart\Graphic\Coordinate $coordinate
     */
    public function __construct(Resource $watermark, Coordinate $coordinate = null) {
        parent::__construct();
        $this->setCoordinate($coordinate === null ? new Coordinate() : $coordinate);
        $this->setWatermark($watermark);
    }

    /**
     * Set Watermark
     * @param Resource $watermark
     * @throws EmptyResource
     */
    public function setWatermark(Resource $watermark) {
        if (!$watermark->isHandlerSet()) {
            throw new EmptyResource("Resource Is Empty");
        }
        $this->WatermarkResource = $watermark;
    }

    /**
     * Get watermark
     * @return Resource
     */
    public function getWatermark() {
        return $this->WatermarkResource;
    }

    /**
     * Set Watermark Coordinate
     * @param \Redstart\Graphic\Coordinate $coordinate
     */
    public function setCoordinate(Coordinate $coordinate) {
        $this->WatermarkPosition = $coordinate;
    }

    /**
     * Get Watermark Coordinate
     * @return type
     */
    public function getCoordinate() {
        return $this->WatermarkPosition;
    }

    protected function doExecuteAction(Resource $resource) {
        $dimension = $this->getWatermark()->getDimension();
        $resource->merge(
                $this->getWatermark()
                , new Box($dimension)
                , new Box($dimension, $this->getCoordinate())
        );
    }

}

