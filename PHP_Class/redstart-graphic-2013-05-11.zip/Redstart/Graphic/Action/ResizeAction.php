<?php

namespace Redstart\Graphic\Action;

use Redstart\Graphic\Resource;
use Redstart\Graphic\Box;
use Redstart\Graphic\Png;
use Redstart\Graphic\Dimension;

/**
 * Resize Action
 * 
 * @package Redstart
 * @subpackage Redstart_Graphic_Action
 * 
 * @author Hyyan Abo Fakher
 * @since Redstart 1.0
 * @version 1.0
 */
class ResizeAction extends AbstractResourceAction {

    /**
     * New Resource Dimension
     * @var Dimension
     */
    private $ResizeDimension;

    /**
     * Construct New Resize Action
     * @param \Redstart\Graphic\Dimension $dimension The new dimension
     */
    public function __construct(Dimension $dimension) {
        parent::__construct();
        $this->setDimension($dimension);
    }

    /**
     * Set New Dimension
     * @param \Redstart\Graphic\Dimension $dimension
     */
    public function setDimension(Dimension $dimension) {
        $this->ResizeDimension = $dimension;
    }

    /**
     * Get Dimension
     * @return Dimension
     */
    public function getDimension() {
        return $this->ResizeDimension;
    }

    protected function doExecuteAction(Resource $resource) {

        $dimension = $this->getDimension();
        $box = new Box($dimension);
        $copy = new Png($dimension);
        
        $copy->alphaBlending(false);
        $copy->merge($resource, null, $box);
        $copy->alphaBlending(true);
        
        $resource->destroy();
        $resource->loadFromResource($copy);
        $copy->destroy();
    }

}

