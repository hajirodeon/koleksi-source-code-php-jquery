<?php

namespace Redstart\Graphic\Action;

use Redstart\Graphic\Resource;
use Redstart\Graphic\Box;
use Redstart\Graphic\Png;
use Redstart\Graphic\Dimension;

/**
 * Crop Action
 * 
 * @package Redstart
 * @subpackage Redstart_Graphic_Action
 * 
 * @author Hyyan Abo Fakher
 * @since Redstart 1.0
 * @version 1.0
 */
class CropAction extends AbstractResourceAction {

    /**
     * Crop Dimension
     * @var Dimension
     */
    private $CropBox;

    /**
     * Construct New Crop Action
     * @param \Redstart\Graphic\Box $box
     */
    public function __construct(Box $box = null) {
        parent::__construct();
        $this->setBox($box === null ? new Box(new Dimension(1, 1)) : $box);
    }

    /**
     * Set Crop Box
     * @param \Redstart\Graphic\Box $box
     */
    public function setBox(Box $box) {
        $this->CropBox = $box;
    }

    /**
     * Get Crop Box
     * @return Box
     */
    public function getBox() {
        return $this->CropBox;
    }

    protected function doExecuteAction(Resource $resource) {

        $dimension = $this->getBox()->getDimension();
        $coordinate = $this->getBox()->getCoordinate();
        
        $new = new Png($dimension);
        
        $new->alphaBlending(false);
        $new->merge($resource, new Box($dimension, $coordinate), new Box($dimension));
        $new->alphaBlending(true);
        
        $resource->destroy();
        $resource->loadFromResource($new);
        $new->destroy();
    }

}

