<?php

namespace Redstart\Graphic\Action;

use Redstart\Graphic\Resource;

/**
 * Resource Action
 * 
 * @package Redstart
 * @subpackage Redstart_Graphic_Action
 * 
 * @author Hyyan Abo Fakher
 * @since Redstart 1.0
 * @version 1.0
 */
interface ResourceAction {

    /**
     * Execute Action On Resource
     * @param Resource $resource
     */
    public function executeAction(Resource $resource);
}

