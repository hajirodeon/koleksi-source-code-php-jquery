<?php

namespace Redstart\Graphic\Action\Filter;

use Redstart\Graphic\Action\AbstractResourceAction;
use Redstart\Graphic\Resource;
use Redstart\Graphic\GraphicException\ResourceException;
use Redstart\Graphic\GraphicException\GraphicBaseException;

/**
 * Convolution Filter
 * 
 * @package Redstart
 * @subpackage Redstart_Graphic_Action_Filter
 * 
 * @author Hyyan Abo Fakher
 * @since Redstart 1.0
 * @version 1.0
 */
class ConvolutionFilter extends AbstractResourceAction {

    /**
     * Color Offset
     * @var float
     */
    private $ConvolutionColorOffset;

    /**
     * The divisor of the result of the convolution
     * @var float
     */
    private $ConvolutionDivisor;

    /**
     * Convolution Matrix (3*3)
     * @var array
     */
    private $ConvolutionMatrix;

    /**
     * Auto Divisor Compute
     * @var boolean 
     */
    private $ConvolutionAutoDivisorCompute;

    /**
     * Construct New Convolution Filter
     * @param array $matrix
     * @param float $offset
     * @param float $divisor
     */
    public function __construct(array $matrix = null, $offset = 0.0, $divisor = 1.0) {
        parent::__construct();
        $this->setColorOffset($offset);
        $this->setDivisor($divisor);
        $this->setMatrix($matrix === null ? array(
                    array(0, 0, 0)
                    , array(0, 0, 0)
                    , array(0, 0, 0)) : $matrix);
        $this->setAutoDivCompute(false);
    }

    /**
     * Set Auto Divispr Compute
     * @param boolean $bool true for auto compute
     */
    public function setAutoDivCompute($bool) {
        $this->ConvolutionAutoDivisorCompute = $bool;
    }

    /**
     * Get Auto Divisor Compute
     * @return boolean
     */
    public function getAutoDivCompute() {
        return $this->ConvolutionAutoDivisorCompute;
    }

    /**
     * Set Color Offset
     * @param float $offset
     */
    public function setColorOffset($offset) {
        $this->ConvolutionColorOffset = $offset;
    }

    /**
     * Get color offset
     * @return float
     */
    public function getColorOffset() {
        return $this->ConvolutionColorOffset;
    }

    /**
     * Set The divisor of the result of the convolution, used for normalization.
     * @param float $divisor
     */
    public function setDivisor($divisor) {
        $this->ConvolutionDivisor = $divisor;
    }

    /**
     * Get the divisor of the result of the convolution
     * @return float
     */
    public function getDivisor() {
        return $this->ConvolutionDivisor;
    }

    /**
     * 
     * @param array $matrix
     * @return type
     * @throws \RuntimeException
     */
    public function setMatrix(array $matrix) {
        $count = count($matrix);
        if ($count === 3) {
            for ($x = 0; $x < $count; $x++) {
                if (!is_array($matrix[$x])) {
                    throw new \RuntimeException(
                            sprintf("Item (%d) In The Matrix Is Not An Array", $x)
                    );
                }

                $subcount = count($matrix[$x]);
                if ($subcount < 3 || $subcount > 3) {
                    throw new \RuntimeException(
                            sprintf("Item (%d) In The Matrix Must Be An Array With (3) Flotas But(%d) Float(s) Was Found"
                                    , $x, $subcount)
                    );
                }
                $this->ConvolutionMatrix = $matrix;
            }
        } else {
            throw new \RuntimeException(
                    sprintf("Expect Matrix (3*3) But The Given Matrix Length is (%s)"
                            , $count)
            );
        }
    }

    /**
     * Get convolution matrix
     * @return array matrix 3*3
     */
    protected function getMatrix() {
        return $this->ConvolutionMatrix;
    }

    /**
     * Compute Matrix Divisor
     * @param array $array
     * @return number
     */
    public function computeMatrixDivisor(array $matrix) {
        return array_sum(array_map('array_sum', $matrix));
    }

    /**
     * Apply Convoluation Filter On The Given resource
     * @param Resource $resource
     * @throws ResourceException
     * @throws GraphicBaseException
     */
    protected function doExecuteAction(Resource $resource) {
        $handler = $resource->getHandler();
        $matrix = $this->getMatrix();
        $divisor = $this->getAutoDivCompute() ?
                $this->computeMatrixDivisor($matrix) : $this->getDivisor();
        if (function_exists("imageconvolution")) {
            if (
                    !imageconvolution(
                            $handler
                            , $matrix
                            , $divisor
                            , $this->getColorOffset()
                    )
            ) {
                throw new ResourceException("Could Not Apply The Convoluation Filter");
            }
        } else {
            throw new GraphicBaseException("Convoluation Filters Are Not Supported");
        }
    }

}

