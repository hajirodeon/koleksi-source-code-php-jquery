<?php

namespace Redstart\Graphic\Action\Filter\Color;

use Redstart\Graphic\Action\AbstractResourceAction;
use Redstart\Graphic\Resource;
use Redstart\Graphic\Coordinate;
use Redstart\Graphic\GraphicException\ResourceException;
use Redstart\Graphic\Color;

/**
 * Colorize Color Filter
 * 
 * Apply Colorize Filter on resource .
 * 
 * <b>Note :</b>
 * This filter will chack first for <code>imagefilter()</code> function if it 
 * exists the <code>ColorizeFilter</code> will use it to apply the colorize effect 
 * otherwise it will will use its own algorithm to apply the filter but it may 
 * lead to slow performance on big resources
 * 
 * @package Redstart
 * @subpackage Redstart_Graphic_Action_Filter_Color
 * 
 * @author Hyyan Abo Fakher
 * @since Redstart 1.0
 * @version 1.0
 */
class ColorizeFilter extends AbstractResourceAction {

    /**
     * Colorize Color
     * @var Color
     */
    private $ColorizeColor;

    /**
     * Construct New Colorize Filter
     * @param \Redstart\Graphic\Color $color
     */
    public function __construct(Color $color = null) {
        parent::__construct();
        $this->setColor($color === null ? new Color() : $color);
    }

    /**
     * Set Colorize Filter Color
     * @param \Redstart\Graphic\Color $color
     */
    public function setColor(Color $color) {
        $this->ColorizeColor = $color;
    }

    /**
     * Get The Colorize Color
     * @return Color
     */
    public function getColor() {
        return $this->ColorizeColor;
    }

    protected function doExecuteAction(Resource $resource) {

        $handler = $resource->getHandler();

        $red = $this->getColor()->getRed();
        $green = $this->getColor()->getBlue();
        $blue = $this->getColor()->getBlue();
        $alpha = $this->getColor()->getAlpha();

        $result = false;

        if (function_exists('imagefilter')) {
            $result = imagefilter($handler, IMG_FILTER_COLORIZE, $red, $green, $blue, $alpha);
        }

        if (!$result) {

            $width = $resource->getWidth();
            $height = $resource->getHeight();

            for ($x = 0; $x < $width; $x++) {
                for ($y = 0; $y < $height; $y++) {
                    $pixel = $resource->getPixel(new Coordinate($x, $y));
                    $color = $pixel->getColor();

                    $r = $color->getRed() + $red;
                    $g = $color->getGreen() + $green;
                    $b = $color->getBlue() + $blue;
                    $a = $color->getAlpha() + $alpha;

                    $r2 = min(255, max(0, $r));
                    $g2 = min(255, max(0, $g));
                    $b2 = min(255, max(0, $b));
                    $a2 = min(127, max(0, $a));


                    $color->setColor($r2, $g2, $b2, $a2);
                    $pixel->draw($resource);
                }
            }

            $result = true;
        }

        if (!$result) {
            throw new ResourceException('Could Not Apply The Colorize Filter On The Resource');
        }
    }

}

