<?php

namespace Redstart\Graphic\Action\Filter\Color;

use Redstart\Graphic\Resource;
use Redstart\Graphic\Coordinate;
use Redstart\Graphic\GraphicException\ResourceException;
use Redstart\Graphic\Action\AbstractResourceAction;

/**
 * GrayScale Color Filter
 * 
 * Apply Grayscale Filter on resource .
 * 
 * <b>Note :</b>
 * This filter will chack first for <code>imagefilter()</code> function if it 
 * exists the <code>GrayScaleFilter</code> will use it to apply the grayscale effect 
 * otherwise it will will use its own algorithm to apply the filter but it may 
 * lead to slow performance on big resources
 * 
 * @package Redstart
 * @subpackage Redstart_Graphic_Action_Filter_Color
 * 
 * @author Hyyan Abo Fakher
 * @since Redstart 1.0
 * @version 1.0
 */
class GrayScaleFilter extends AbstractResourceAction {

    private static $RED_FACTOR = 0.299;
    private static $GREEN_FACTOR = 0.587;
    private static $BLUE_FACTOR = 0.114;

    protected function doExecuteAction(Resource $resource) {
        $handler = $resource->getHandler();
        $result = false;

        if (function_exists('imagefilter')) {
            $result = imagefilter($handler, IMG_FILTER_GRAYSCALE);
        }

        if (!$result) {

            $width = $resource->getWidth();
            $height = $resource->getHeight();

            for ($x = 0; $x < $width; $x++) {
                for ($y = 0; $y < $height; $y++) {
                    $pixel = $resource->getPixel(new Coordinate($x, $y));
                    $color = $pixel->getColor();

                    $r = $color->getRed() * self::$RED_FACTOR;
                    $g = $color->getGreen() * self::$GREEN_FACTOR;
                    $b = $color->getBlue() * self::$BLUE_FACTOR;

                    $scale = min(255, max(0, ($r + $g + $b)));

                    $color->setColor($scale, $scale, $scale, $color->getAlpha());
                    $pixel->draw($resource);
                }
            }

            $result = true;
        }

        if (!$result) {
            throw new ResourceException('Could Not Apply The GrayScale Filter On The Resource');
        }
    }

}

