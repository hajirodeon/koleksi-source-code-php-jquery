<?php

namespace Redstart\Graphic\Action\Filter\Color;

use Redstart\Graphic\Resource;
use Redstart\Graphic\Action\AbstractResourceAction;
use Redstart\Graphic\Coordinate;

/**
 * Gamma Filter 2
 * 
 * Apply Gamma Filter 2 on resource
 * 
 * This Filter Allow To Set (Red,Green,Blue) Correction and it can preserve the
 * alpha channel information but it can lead to slow performance on big resources 
 * 
 * You can get the same result of <code>GammaFilter</code> by setting (red,green,blue)
 * values to be equal
 * 
 * <b>Note :</b>
 * <code>GammaFilter</code> is much faster than <code>GammaFilter2</code>
 * 
 * @see GammaFilter
 * 
 * @package Redstart
 * @subpackage Redstart_Graphic_Action_Filter_Color
 * 
 * @author Hyyan Abo Fakher
 * @since Redstart 1.0
 * @version 1.0
 */
class GammaFilter2 extends AbstractResourceAction {

    /**
     * Red Correction
     * @var float
     */
    private $GammaRedCorrection;

    /**
     * Green Correction
     * @var float
     */
    private $GammaGreenCorrection;

    /**
     * Blue Correction
     * @var float
     */
    private $GammaBlueCorrection;

    /**
     * Construct New Gamma2 Filter 
     * @param float $red in range (0.1,4.99)
     * @param float $green in range (0.1,4.99)
     * @param float $blue in range (0.1,4.99)
     * @throws \InvalidArgumentException
     */
    public function __construct($red = 1.0, $green = 1.0, $blue = 1.0) {
        parent::__construct();
        $this->setCorrection($red, $green, $blue);
    }

    /**
     * Check If Correction value Is Valid Correction
     * @param float $correction
     * @throws InvalidArgumentException
     */
    private function isValidCorrection($correction) {
        if ($correction < 0.01 || $correction > 4.99) {
            throw new \InvalidArgumentException("Correction Must Be In Range (0.1,4.99)");
        }
    }

    /**
     * Set Red Correction
     * @param float $correction
     * @throws \InvalidArgumentException
     */
    public function setRedCorrection($correction) {
        $this->isValidCorrection($correction);
        $this->GammaRedCorrection = $correction;
    }

    /**
     * Get Red Correction
     * @return float
     */
    public function getRedCorrection() {
        return $this->GammaRedCorrection;
    }

    /**
     * Set Green Correction
     * @param float $correction
     * @throws \InvalidArgumentException
     */
    public function setGreenCorrection($correction) {
        $this->isValidCorrection($correction);
        $this->GammaGreenCorrection = $correction;
    }

    /**
     * Get Green Correction
     * @return float
     */
    public function getGreenCorrection() {
        return $this->GammaGreenCorrection;
    }

    /**
     * Set Blue Correction
     * @param float $correction
     * @throws \InvalidArgumentException
     */
    public function setBlueCorrection($correction) {
        $this->isValidCorrection($correction);
        $this->GammaBlueCorrection = $correction;
    }

    /**
     * Get Blue Correction
     * @return float
     */
    public function getBlueCorrection() {
        return $this->GammaBlueCorrection;
    }

    /**
     * Set Color Correction
     * @param float $red in range (0.1,4.99)
     * @param float $green in range (0.1,4.99)
     * @param float $blue in range (0.1,4.99)
     * @throws \InvalidArgumentException
     */
    public function setCorrection($red, $green, $blue) {
        $this->setRedCorrection($red);
        $this->setGreenCorrection($green);
        $this->setBlueCorrection($blue);
    }
    
    /**
     * Apply GammaFilter2 On The Given Resource
     * @param Resource $resource
     */
    protected function doExecuteAction(Resource $resource) {

        $rc = $this->getRedCorrection();
        $gc = $this->getGreenCorrection();
        $bc = $this->getBlueCorrection();

        $gammaRed = array();
        $gammaGreen = array();
        $gammaBlue = array();

        for ($i = 0; $i < 256; $i++) {
            $gammaRed[$i] = min(255, (255 * pow($i / 255, 1 / $rc)) + .5);
            $gammaGreen[$i] = min(255, (255 * pow($i / 255, 1 / $gc)) + .5);
            $gammaBlue[$i] = min(255, (255 * pow($i / 255, 1 / $bc)) + .5);
        }

        $width = $resource->getWidth();
        $height = $resource->getHeight();

        for ($x = 0; $x < $width; $x++) {
            for ($y = 0; $y < $height; $y++) {
                $pixel = $resource->getPixel(new Coordinate($x, $y));
                $color = $pixel->getColor();
                $color->setColor(
                        $gammaRed[$color->getRed()]
                        , $gammaGreen[$color->getGreen()]
                        , $gammaBlue[$color->getBlue()]
                        , $color->getAlpha()
                );
                $pixel->draw($resource);
            }
        }
    }

}

