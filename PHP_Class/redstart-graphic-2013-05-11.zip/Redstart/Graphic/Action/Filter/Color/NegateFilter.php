<?php

namespace Redstart\Graphic\Action\Filter\Color;

use Redstart\Graphic\Resource;
use Redstart\Graphic\Coordinate;
use Redstart\Graphic\GraphicException\ResourceException;
use Redstart\Graphic\Action\AbstractResourceAction;

/**
 * Negate Filter
 * 
 * Apply Negate Filter on resource
 * 
 * <b>Note :</b>
 * 
 * This filter will chack first for <code>imagefilter()</code> function if it 
 * exists the <code>NegateFilter</code> will use it to apply the negate effect 
 * otherwise it will will use its own algorithm to apply the filter but it may 
 * lead to slow performance on big resources
 * 
 * @package Redstart
 * @subpackage Redstart_Graphic_Action_Filter_Color
 * 
 * @author Hyyan Abo Fakher
 * @since Redstart 1.0
 * @version 1.0
 */
class NegateFilter extends AbstractResourceAction {

    protected function doExecuteAction(Resource $resource) {

        $handler = $resource->getHandler();
        $result = false;

        if (function_exists('imagefilter')) {
            $result = imagefilter($handler, IMG_FILTER_NEGATE);
        }

        if (!$result) {

            $width = $resource->getWidth();
            $height = $resource->getHeight();

            for ($x = 0; $x < $width; $x++) {
                for ($y = 0; $y < $height; $y++) {

                    $pixel = $resource->getPixel(new Coordinate($x, $y));
                    $color = $pixel->getColor();

                    $r = 255 - $color->getRed();
                    $g = 255 - $color->getGreen();
                    $b = 255 - $color->getBlue();

                    $color->setColor($r, $g, $b, $color->getAlpha());
                    $pixel->draw($resource);
                }
            }

            $result = true;
        }

        if (!$result) {
            throw new ResourceException("Could Not Apply The Negate Filter On The Resource");
        }
    }

}

