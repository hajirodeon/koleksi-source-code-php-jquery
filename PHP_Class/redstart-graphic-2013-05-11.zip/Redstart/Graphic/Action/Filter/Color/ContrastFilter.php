<?php

namespace Redstart\Graphic\Action\Filter\Color;

use Redstart\Graphic\Action\AbstractResourceAction;
use Redstart\Graphic\Resource;
use Redstart\Graphic\Coordinate;
use Redstart\Graphic\GraphicException\ResourceException;

/**
 * Contrast Filter
 * 
 * Apply Contrast Filter on resource .
 * 
 * <b>Note :</b>
 * This filter will chack first for <code>imagefilter()</code> function if it 
 * exists the <code>ContrastFilter</code> will use it to apply the contrast effect 
 * otherwise it will will use its own algorithm to apply the filter but it may 
 * lead to slow performance on big resources
 * 
 * @package Redstart
 * @subpackage Redstart_Graphic_Action_Filter_Color
 * 
 * @author Hyyan Abo Fakher
 * @since Redstart 1.0
 * @version 1.0
 */
class ContrastFilter extends AbstractResourceAction {

    /**
     * Contrast Level
     * @var int
     */
    private $ContrastLevel;

    public function __construct($level = 0) {
        parent::__construct();
        $this->setLevel($level);
    }

    /**
     * Set Contrast Level
     * @param int $level in range(-100,100) where 0 = no change
     * @throws InvalidArgumentException
     */
    public function setLevel($level) {
        if ($level < -100 || $level > 100) {
            throw new \InvalidArgumentException("Contrast Level Must Be In Range(-100,100)");
        }
        $this->ContrastLevel = $level;
    }

    /**
     * Get Contrast Level
     * @return int
     */
    public function getLevel() {
        return $this->ContrastLevel;
    }

    protected function doExecuteAction(Resource $resource) {

        $handler = $resource->getHandler();
        $result = false;

        if (function_exists('imagefilter')) {
            $result = imagefilter($handler, IMG_FILTER_CONTRAST, -$this->getLevel());
        }

        if (!$result) {

            $width = $resource->getWidth();
            $height = $resource->getHeight();

            for ($x = 0; $x < $width; $x++) {
                for ($y = 0; $y < $height; $y++) {

                    $pixel = $resource->getPixel(new Coordinate($x, $y));
                    $color = $pixel->getColor();

                    $r = $color->getRed();
                    $g = $color->getGreen();
                    $b = $color->getBlue();


                    $level = pow((100 + $this->getLevel()) / 100, 2);

                    $r-= 127.5;
                    $r*= $level;
                    $r+= 127.5;

                    $g-= 127.5;
                    $g*= $level;
                    $g+= 127.5;

                    $b-= 127.5;
                    $b*= $level;
                    $b+= 127.5;

                    $r2 = min(255, max(0, $r));
                    $g2 = min(255, max(0, $g));
                    $b2 = min(255, max(0, $b));

                    $color->setColor($r2, $g2, $b2, $color->getAlpha());
                    $pixel->draw($resource);
                }
            }

            $result = true;
        }

        if (!$result) {
            throw new ResourceException(
                    sprintf("Could Not Apply The Contrast Filter (%s) On The Resource"
                            , $this->getLevel())
            );
        }
    }

}