<?php

namespace Redstart\Graphic\Action\Filter\Color;

use Redstart\Graphic\Resource;
use Redstart\Graphic\GraphicException\ResourceException;
use Redstart\Graphic\GraphicException\GraphicBaseException;
use Redstart\Graphic\Action\AbstractResourceAction;

/**
 * Gamma Filter
 * 
 * Apply Gamma Filter on resource
 * 
 * <b>Note :</b>
 * This Filter Will Not Preserve The Alpha Channel Information On Resources
 * 
 * @see GammaFilter2
 * 
 * @package Redstart
 * @subpackage Redstart_Graphic_Action_Filter_Color
 * 
 * @author Hyyan Abo Fakher
 * @since Redstart 1.0
 * @version 1.0
 */
class GammaFilter extends AbstractResourceAction {

    /**
     * Gamma Level
     * @var float
     */
    private $GammaLevel;

    /**
     * input gamma
     * @var float
     */
    private static $GAMMA_INPUT = 1.0;

    /**
     * Construct New Gamma Filter
     * @param int $level brightness level in range(-100,100)
     */
    public function __construct($level = 0) {
        parent::__construct();
        $this->setLevel($level);
    }

    /**
     * Set Gamma Level
     * @param float $level in range(0.01,4.99) 
     * @throws InvalidArgumentException
     */
    public function setLevel($level) {
        if (!($level >= 0.01 && $level <= 4.99)) {
            throw new \InvalidArgumentException("Gamma Level Must Be In Range(0.01,4.99)");
        }
        $this->GammaLevel = $level;
    }

    /**
     * Get Gamma Level
     * @return float
     */
    public function getLevel() {
        return $this->GammaLevel;
    }

    /**
     * Apply Gamma Color Filter
     * @param Resource $resource
     * @throws ResourceException
     * @throws GraphicBaseException
     */
    protected function doExecuteAction(Resource $resource) {

        $handler = $resource->getHandler();

        if (function_exists('imagegammacorrect')) {
            if (!imagegammacorrect($handler, self::$GAMMA_INPUT, $this->getLevel())) {
                throw new ResourceException(
                        sprintf("Could Not Apply The Gamma Filter (%s) On The Resource"
                                , $this->getLevel())
                );
            }
        } else {
            throw new GraphicBaseException("Unsupported Filter");
        }
    }

}

