<?php

namespace Redstart\Graphic\Action\Filter;

/**
 * Convolution Filter Factor
 * 
 * @package Redstart
 * @subpackage Redstart_Graphic_Action_Filter
 * 
 * @author Hyyan Abo Fakher
 * @since Redstart 1.0
 * @version 1.0
 */
class ConvolutionFactor {

    /**
     * Edge matrix
     * @var array
     */
    protected static $Edge_MATRIX_NATIVE = array(
        array(0, -1, 0)
        , array(-1, 4, -1)
        , array(0, -1, 0)
    );

    /**
     * Emboss Matrix
     * @var array 
     */
    protected static $Emboss_MATRIX_NATIVE = array(
        array(2, 0, 0)
        , array(0, -1, 0)
        , array(0, 0, -1)
    );

    /**
     * FindEdge matrix
     * @var array
     */
    protected static $FindEdge_MATRIX_NATIVE = array(
        array(-1, -1, -1)
        , array(-2, 8, -1)
        , array(-1, -1, -1)
    );

    /**
     * Gblur matrix
     * @var array
     */
    protected static $GBlur_MATRIX_NATIVE = array(
        array(1.0, 2.0, 1.0)
        , array(2.0, 4.0, 2.0)
        , array(1.0, 2.0, 1.0)
    );

    /**
     * Light matrix
     * @var array
     */
    protected static $Light_MATRIX_NATIVE = array(
        array(0, 0, 1)
        , array(0, 1, 0)
        , array(1, 0, 0)
    );

    /**
     * Sharpen matrix
     * @var array
     */
    protected static $SHARPEN_MATRIX_NATIVE = array(
        array(0.0, -1.0, 0.0)
        , array(-1.0, 5.0, -1.0)
        , array(0.0, -1.0, 0.0)
    );

    /**
     * Line Detection Vertical
     * @var array 
     */
    protected static $LineDetectionVertical_MATRIX_NATIVE = array(
        array(-1, 2, -1)
        , array(-1, 2, -1)
        , array(-1, 2, 0)
    );

    /**
     * Line Detection Horizontal
     * @var array 
     */
    protected static $LineDetectionHorizontal_MATRIX_NATIVE = array(
        array(-1, -1, -1)
        , array(2, 2, 2)
        , array(-1, -1, 0)
    );

    /**
     * Get Line Detection Vertical Convolution Filter 
     * @return \Redstart\Graphic\Filter\ConvolutionFilter
     */
    public static function lineDetectionVertical() {
        $cf = new ConvolutionFilter(static::$LineDetectionVertical_MATRIX_NATIVE);
        return $cf;
    }

    /**
     * Get Line Detection Horizontal Convolution Filter 
     * @return \Redstart\Graphic\Filter\ConvolutionFilter
     */
    public static function lineDetectionHorizontal() {
        $cf = new ConvolutionFilter(static::$LineDetectionHorizontal_MATRIX_NATIVE);
        return $cf;
    }

    /**
     * Get Edge Convolution Filter 
     * @return \Redstart\Graphic\Filter\ConvolutionFilter
     */
    public static function edge() {
        $cf = new ConvolutionFilter(static::$Edge_MATRIX_NATIVE);
        $cf->setDivisor(0);
        return $cf;
    }

    /**
     * Get FindEdge Convolution Filter 
     * @return \Redstart\Graphic\Filter\ConvolutionFilter
     */
    public static function findEdge() {
        $cf = new ConvolutionFilter(static::$FindEdge_MATRIX_NATIVE);
        $cf->setDivisor(-1);
        return $cf;
    }

    /**
     * Get Emboss Convolution Filter 
     * @return \Redstart\Graphic\Filter\ConvolutionFilter
     */
    public static function emboss() {
        $cf = new ConvolutionFilter(static::$Emboss_MATRIX_NATIVE);
        $cf->setDivisor(1.5);
        $cf->setColorOffset(127);
        return $cf;
    }

    /**
     * Get GaussianBlur Convolution Filter 
     * @return \Redstart\Graphic\Filter\ConvolutionFilter
     */
    public static function gaussianBlur() {
        $cf = new ConvolutionFilter(static::$GBlur_MATRIX_NATIVE);
        $cf->setDivisor(16);
        return $cf;
    }

    /**
     * Get Light Convolution Filter 
     * @return \Redstart\Graphic\Filter\ConvolutionFilter
     */
    public static function light() {
        $cf = new ConvolutionFilter(static::$Light_MATRIX_NATIVE);
        $cf->setDivisor(1);
        return $cf;
    }

    /**
     * Get Light Convolution Filter 
     * @return \Redstart\Graphic\Filter\ConvolutionFilter
     */
    public static function sharpen() {
        $cf = new ConvolutionFilter(static::$SHARPEN_MATRIX_NATIVE);
        $cf->setDivisor(1);
        return $cf;
    }

}