<?php

namespace Redstart\Graphic\Action\Filter;

use Redstart\Graphic\Resource;
use Redstart\Graphic\Box;
use Redstart\Graphic\Dimension;
use Redstart\Graphic\Coordinate;
use Redstart\Graphic\Action\AbstractResourceAction;

/**
 * Mirror Filter
 * 
 * @see Redstart\Graphic\Action\FlipAction
 * 
 * @package Redstart
 * @subpackage Redstart_Graphic_Acton_Filter
 * 
 * @author Hyyan Abo Fakher
 * @since Redstart 1.0
 * @version 1.0
 */
class MirrorFilter extends AbstractResourceAction {

    const Vertical = "VERTICAL";
    const Horizontal = "HORIZONTAL";

    /**
     * supported direction
     * @var array 
     */
    private static $SupportedMirrorDirection = array(
        self::Horizontal, self::Vertical
    );

    /**
     * Mirror Direction
     * @var string
     */
    private $MirrorDirection;

    /**
     * Construct New Mirror Filter
     * @param string $direction
     * @throws \InvalidArgumentException
     */
    public function __construct($direction = null) {
        parent::__construct();
        $this->setMirrorDirection($direction === null ? self::Horizontal : $direction);
    }

    /**
     * Set Mirror Direction
     * @param string $direction MirrorAction::Vertical Or 
     * MirrorAction::Horizontal 
     * @throws \InvalidArgumentException
     */
    public function setMirrorDirection($direction) {
        if (!in_array($direction, self::$SupportedMirrorDirection)) {
            throw new \InvalidArgumentException(
                    sprintf("(%s) Is Not Valid Mirror Direction", $direction)
            );
        }
        $this->MirrorDirection = $direction;
    }

    /**
     * Get Mirror Direction
     * @return string
     */
    public function getMirrorDirection() {
        return $this->MirrorDirection;
    }

    protected function doExecuteAction(Resource $resource) {

        $width = $resource->getWidth();
        $height = $resource->getHeight();

        $mirrorPoint = null;
        $srcBox = null;
        $destBox = null;

        switch ($this->getMirrorDirection()) {

            case self::Vertical:
                $mirrorPoint = $width / 2;
                $srcBox = new Box(
                                new Dimension(-$mirrorPoint, $height)
                                , new Coordinate($mirrorPoint - 1, 0)
                );
                $destBox = new Box(
                                new Dimension($mirrorPoint, $height)
                                , new Coordinate($mirrorPoint, 0)
                );

                break;
            case self::Horizontal:
                $mirrorPoint = $height / 2;
                $srcBox = new Box(
                                new Dimension($width, - $mirrorPoint)
                                , new Coordinate(0, $mirrorPoint - 1)
                );
                $destBox = new Box(
                                new Dimension($width, $mirrorPoint)
                                , new Coordinate(0, $mirrorPoint)
                );
                break;
        }

        $resource->merge($resource, $srcBox, $destBox);
    }

}

