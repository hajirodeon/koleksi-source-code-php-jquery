<?php

namespace Redstart\Graphic\Action\Filter;

use Redstart\Graphic\Action\AbstractResourceAction;
use Redstart\Graphic\Resource;
use Redstart\Graphic\Coordinate;
use Redstart\Graphic\Dimension;
use Redstart\Graphic\Rectangle;
use Redstart\Graphic\GraphicException\ResourceException;

/**
 * Pixelate Filter 
 * 
 * <b>Note :</b>
 * This filter will chack first for <code>imagefilter()</code> function if it 
 * exists the <code>PixelateFilter</code> will use it to apply the pixelate effect 
 * otherwise it will will use its own algorithm to apply the filter but it may 
 * lead to slow performance on big resources
 * 
 * @package Redstart
 * @subpackage Redstart_Graphic_Action_Filter
 * 
 * @author Hyyan Abo Fakher
 * @since Redstart 1.0
 * @version 1.0
 */
class PixelateFilter extends AbstractResourceAction {

    /**
     * Pixel Size
     * @var int
     */
    private $pixelSize = 0;

    /**
     * Constrict new PixelateFilter
     * @param int $pixelSize pixel size
     */
    public function __construct($pixelSize = 1) {
        parent::__construct();
        $this->setPixelSize($pixelSize);
    }

    /**
     * Set pixel size
     * @param int $size
     * @throws \InvalidArgumentException
     */
    public function setPixelSize($size) {
        if ($size <= 0) {
            throw new \InvalidArgumentException("Pixel Size <= 0");
        }
        $this->pixelSize = $size;
    }

    /**
     * Get pixel size
     * @return int
     */
    public function getPixelSize() {
        return $this->pixelSize;
    }

    /**
     * Apply Pixelate Filter On the Give Resource
     * @param Resource $resource
     * @throws ResourceException
     */
    protected function doExecuteAction(Resource $resource) {
        
        $size = $this->getPixelSize();
        $result = false;


        if (function_exists('imagefilter')) {
            $result = imagefilter($resource->getHandler(), IMG_FILTER_PIXELATE, $size);
        }

        if (!$result) {

            $width = $resource->getWidth();
            $height = $resource->getHeight();

            for ($x = 0; $x < $width; $x+=$size) {
                for ($y = 0; $y < $height; $y+=$size) {
                    $xp = $x + 1;
                    $yp = $y + 1;
                    if ($xp >= $width || $yp >= $height) {
                        break;
                    }
                    $pixel = $resource->getPixel(new Coordinate($xp + 1, $yp))->getColor();
                    $rect = new Rectangle(new Dimension($size, $size), new Coordinate($x, $y));
                    $rect->filled(true);
                    $rect->setColor($pixel->getColor());
                    $rect->draw($resource);
                }
            }
            $result = true;
        }

        if (!$result) {
            throw new ResourceException('Could Not Apply The Pixelate Filter On The Resource');
        }
    }

}

