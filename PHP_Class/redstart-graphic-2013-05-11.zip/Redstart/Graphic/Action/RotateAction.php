<?php

namespace Redstart\Graphic\Action;

use Redstart\Graphic\Resource;
use Redstart\Graphic\GraphicException\ResourceException;
use Redstart\Graphic\Color;

/**
 * Rotate Action
 * 
 * <b>Note :</b>
 * This Action Need <code>imagerotate()</code> function in order to work
 * 
 * @package Redstart
 * @subpackage Redstart_Graphic_Action
 * 
 * @author Hyyan Abo Fakher
 * @since Redstart 1.0
 * @version 1.0
 */
class RotateAction extends AbstractResourceAction {

    /**
     * Rotate Degree
     * @var int
     */
    private $RotateDegree;

    /**
     * Background Color
     * @var Color
     */
    private $RotateBackgroundColor;

    /**
     * Construct New rotate action
     * @param int $degree rotate degree
     * @param \Redstart\Graphic\Color $color background color
     */
    public function __construct($degree = 0, Color $color = null) {
        parent::__construct();
        $this->setDegree($degree);
        $this->setBackgroundColor($color === null ? new Color(0, 0, 0, 127) : $color);
    }

    /**
     * Set Rotate Degree 
     * @param int $degree
     * @throws \InvalidArgumentException
     */
    public function setDegree($degree) {
        if ($degree < -360 || $degree > 360) {
            throw new \InvalidArgumentException(
                    sprintf("Invalid Rotate Degree(%s) - Must Be In Range(-360,360)"
                            , $degree)
            );
        }
        $this->RotateDegree = $degree;
    }

    /**
     * Get Rotate Degree
     * @return int
     */
    public function getDegree() {
        return $this->RotateDegree;
    }

    /**
     * Set Background Color
     * @param \Redstart\Graphic\Color $color
     */
    public function setBackgroundColor(Color $color) {
        $this->RotateBackgroundColor = $color;
    }

    /**
     * Get Background Color
     * @return Color
     */
    public function getBackgroundColor() {
        return $this->RotateBackgroundColor;
    }

    protected function doExecuteAction(Resource $resource) {

        $handler = $resource->getHandler();
        $degree = $this->getDegree();
        $color = $this->getBackgroundColor();

        if (function_exists('imagerotate')) {
            $newHandler = imagerotate($handler, $degree, $color->allocate($resource));
            if ($newHandler) {
                $resource->destroy();
                $resource->setHandler($newHandler);
            } else {
                throw new ResourceException("Could Not Rotate The Resource");
            }
        } else {
            throw new \RuntimeException("Resource Rotate Is Not Supported");
        }
    }

}

