<?php

namespace Redstart\Graphic\Action;

use Redstart\Graphic\Resource;
use Redstart\Graphic\Box;
use Redstart\Graphic\Dimension;
use Redstart\Graphic\Coordinate;
use Redstart\Graphic\Png;


/**
 * Flip Action
 * 
 * @see Redstart\Graphic\Action\Filter\MirrorFilter
 * 
 * @package Redstart
 * @subpackage Redstart_Graphic_Action
 * 
 * @author Hyyan Abo Fakher
 * @since Redstart 1.0
 * @version 1.0
 */
class FlipAction extends AbstractResourceAction {

    const Vertical = "VERTICAL";
    const Horizontal = "HORIZONTAL";
    const Both = "BOTH";

    /**
     * supported direction
     * @var array 
     */
    private static $SupportedFlipDirection = array(
        self::Both, self::Horizontal, self::Vertical
    );

    /**
     * Flip Direction
     * @var string
     */
    private $FlipDirection;

    /**
     * Construct New Flip Action
     * @param string $direction
     * @throws \InvalidArgumentException
     */
    public function __construct($direction = null) {
        parent::__construct();
        $this->setFlipDirection($direction === null ? self::Horizontal : $direction);
    }

    /**
     * Set Flip Direction
     * @param string $direction FlipAction::Vertical Or 
     * FlipAction::Horizontal Or FlipAction::Both
     * @throws \InvalidArgumentException
     */
    public function setFlipDirection($direction) {
        if (!in_array($direction, self::$SupportedFlipDirection)) {
            throw new \InvalidArgumentException(
                    sprintf("(%s) Is Not Valid Flip Direction", $direction)
            );
        }
        $this->FlipDirection = $direction;
    }

    /**
     * Get Flip Direction
     * @return string
     */
    public function getFlipDirection() {
        return $this->FlipDirection;
    }

    protected function doExecuteAction(Resource $resource) {

        $width = $resource->getWidth();
        $height = $resource->getHeight();

        $copy = new Png(new Dimension($width, $height));
        $copy->alphaBlending(false);
        
        $srcBox = null;
        $destBox = null;

        switch ($this->getFlipDirection()) {

            case self::Vertical:
                $srcBox = new Box(
                                new Dimension($width, - $height)
                                , new Coordinate(0, $height - 1)
                );
                $destBox = new Box(
                                new Dimension($width, $height)
                                , new Coordinate(0, 0)
                );
                break;
            case self::Horizontal:
                $srcBox = new Box(
                                new Dimension(-$width, $height)
                                , new Coordinate($width - 1, 0)
                );
                $destBox = new Box(
                                new Dimension($width, $height)
                                , new Coordinate(0, 0)
                );
                break;
            case self::Both:
                $srcBox = new Box(
                                new Dimension(-$width, -$height)
                                , new Coordinate($width - 1, $height - 1)
                );
                $destBox = new Box(
                                new Dimension($width, $height)
                                , new Coordinate(0, 0)
                );
                break;
        }
        $copy->merge($resource, $srcBox, $destBox);
        $copy->alphaBlending(true);
        
        $resource->destroy();
        $resource->loadFromResource($copy);
        $copy->destroy();
    }

}

