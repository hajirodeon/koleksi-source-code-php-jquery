<?php

namespace Redstart\Graphic\Action;

use Redstart\Graphic\Resource;
use Redstart\Graphic\GraphicException\EmptyResource;

/**
 * Abstract Resource Action
 * 
 * @package Redstart
 * @subpackage Redstart_Graphic_Action
 * 
 * @author Hyyan Abo Fakher
 * @since Redstart 1.0
 * @version 1.0
 */
abstract class AbstractResourceAction implements ResourceAction {
    
    /**
     * Construct New Resource Action
     */
    public function __construct() {
        
    }
    /**
     * Execute Action On The Given Resource
     * @param Resource $resource
     * @throws EmptyResource
     */
    abstract protected function doExecuteAction(Resource $resource);

    /**
     * Execute Action On The Given Resource
     * @param Resource $resource
     * @throws EmptyResource
     */
    public function executeAction(Resource $resource) {
        if (!$resource->isHandlerSet()) {
            throw new EmptyResource("Resource Is Empty");
        }
        $this->doExecuteAction($resource);
    }

}

