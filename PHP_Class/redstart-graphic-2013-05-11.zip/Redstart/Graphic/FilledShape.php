<?php

namespace Redstart\Graphic;

use Redstart\Graphic\GraphicException\ShapeException;

/**
 * Filled Shape Object
 * 
 * @package Redstart
 * @subpackage Redstart_Graphic
 * 
 * @author Hyyan Abo Fakher
 * @since Redstart 1.0
 * @version 1.0
 */
abstract class FilledShape extends Shape {

    /**
     * Shape Is Filled
     * @var boolean
     */
    private $ShapeIsFilled = false;

    /**
     * Shape Pattern
     * @var Resource
     */
    private $shapePattern = null;

    /**
     * Construct New Filled Shape
     */
    public function __construct() {
        parent::__construct();
    }

    /**
     * Fill Shape
     * @param boolean $boolean
     */
    public function filled($boolean) {
        $this->ShapeIsFilled = $boolean;
    }

    /**
     * Is Filled Shpae
     * @return boolean
     */
    public function isFilled() {
        return $this->ShapeIsFilled;
    }

    /**
     * Set Fill Pattern
     * @param Resource $pattern
     */
    public function setPattern(Resource $pattern = null) {
        if ($pattern !== null) {
            $this->assertEmptyHandler($pattern);
        }
        $this->shapePattern = $pattern;
    }

    /**
     * Get Fill Pattern
     * @return Resource
     */
    public function getPattern() {
        return $this->shapePattern;
    }

    /**
     * Check if the pattern is enabled
     * @return boolean
     */
    protected function isPatternEnabled() {
        return $this->getPattern() === null ? false : true;
    }

    /**
     * Draw Filled Shape
     * @param Resource $resource
     * @param string $color color identifier
     */
    protected function drawFilledShape(Resource $resource, $color) {
        $this->doDrawFilledShape($resource, $color);
    }

    /**
     * Draw Filled Shape
     * @param string $color color identifier
     * @param Resource $resource
     * @param string $color color identifier
     */
    abstract protected function doDrawFilledShape(Resource $resource, $color);

    /**
     * Draw Non Filled Shape
     * @param Resource $resource
     * @param string $color color identifier
     */
    protected function drawNonFilledShape(Resource $resource, $color) {
        $this->doDrawNonFilledShape($resource, $color);
    }

    /**
     * Draw Non Filled Shape
     * @param Resource $resource
     * @param string $color color identifier
     */
    abstract protected function doDrawNonFilledShape(Resource $resource, $color);

    protected function doDraw(Resource $resource) {
        $color = $this->getColor();
        if ($color instanceof Color) {
            $color = $this->getColor()->allocate($resource);
        }
        if ($this->isFilled()) {
            if ($this->isPatternEnabled()) {
                $pattern = $this->getPattern();
                $copy = $pattern->getCopy();
                if (
                        !imagesettile(
                                $resource->getHandler()
                                , $copy->getHandler())
                ) {
                    throw new ShapeException("Could Not Apply The Fill Pattern");
                }
                $this->drawFilledShape($resource, IMG_COLOR_TILED);
                $copy->destroy();
            } else {
                $this->drawFilledShape($resource, $color);
            }
        } else {
            $this->drawNonFilledShape($resource, $color);
        }
    }

}

