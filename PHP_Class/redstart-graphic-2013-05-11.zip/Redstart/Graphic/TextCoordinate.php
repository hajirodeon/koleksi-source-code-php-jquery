<?php

namespace Redstart\Graphic;

/**
 * Text Coordinates System
 * 
 * @package Redstart
 * @subpackage Redstart_Graphic
 * 
 * @author Hyyan Abo Fakher
 * @since Redstart 1.0
 * @version 1.0
 */
class TextCoordinate extends CoordinateSystem {

    /**
     * Text Object
     * @var Text
     */
    protected $TextObject;

    /**
     * Construct new coordinate system
     * @param Resource $resource working resource
     * @param \Redstart\Graphic\Text $text
     */
    public function __construct(Resource $resource, Text $text) {
        parent::__construct($resource);
        $this->setTextObject($text);
    }

    /**
     * Set Text Object
     * @param \Redstart\Graphic\Text $text
     */
    public function setTextObject(Text $text) {
        $this->TextObject = $text;
    }

    /**
     * Get Text Object
     * @return Text
     */
    public function getTextObject() {
        return $this->TextObject;
    }

    protected function bottomLeft() {
        $bound = new TextBound($this->getTextObject());
        $y = $this->getResource()->getHeight() - $bound->getDimension()->getHeight();
        return new Coordinate(0, $y);
    }

    protected function bottomRight() {
        $bound = new TextBound($this->getTextObject());
        $x = $this->getResource()->getWidth() - $bound->getDimension()->getWidth();
        $y = $this->getResource()->getHeight() - $bound->getDimension()->getHeight();
        return new Coordinate($x, $y);
    }

    protected function center() {
        $bound = new TextBound($this->getTextObject());
        $rsize = $this->getResource()->getDimension();
        $textDimen = $bound->getDimension();
        $factor = 2.0;
        $x = ($rsize->getWidth() / $factor) - ($textDimen->getWidth() / $factor);
        $y = ($rsize->getHeight() / $factor) - ($textDimen->getHeight() / $factor);
        return new Coordinate($x, $y);
    }

    protected function centerBottom() {
        $bound = new TextBound($this->getTextObject());
        $center = $this->getCenter();
        $y = $this->getResource()->getHeight() - $bound->getDimension()->getHeight();
        $center->setY($y);
        return $center;
    }

    protected function centerLeft() {
        $center = $this->getCenter();
        $center->setX(0);
        return $center;
    }

    protected function centerRight() {
        $bound = new TextBound($this->getTextObject());
        $center = $this->getCenter();
        $x = $this->getResource()->getWidth() - $bound->getDimension()->getWidth();
        $center->setX($x);
        return $center;
    }

    protected function centerTop() {
        $bound = new TextBound($this->getTextObject());
        $x = $this->getResource()->getWidth() - $bound->getDimension()->getWidth();
        return new Coordinate($x / 2.0, 0);
    }

    protected function topLeft() {
        return new Coordinate(0, 0);
    }

    protected function topRight() {
        $bound = new TextBound($this->getTextObject());
        $x = $this->getResource()->getWidth() - $bound->getDimension()->getWidth();
        return new Coordinate($x, 0);
    }

}