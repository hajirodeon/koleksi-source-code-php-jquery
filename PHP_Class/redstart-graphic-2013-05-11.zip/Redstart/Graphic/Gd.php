<?php

namespace Redstart\Graphic;

use Redstart\Graphic\GraphicException\ResourceOutputException;
use Redstart\Graphic\GraphicException\ResourceCreationException;
use Redstart\Graphic\GraphicException\EmptyResource;


/**
 * GD Resource Object
 * 
 * @package Redstart
 * @subpackage Redstart_Graphic
 * 
 * @author Hyyan Abo Fakher
 * @since Redstart 1.0
 * @version 1.0
 */
class Gd extends Resource {

    /**
     * Load GD Resource
     * @param string $filename
     * @throws \InvalidArgumentException if file name is empty
     * @throws \RuntimeException if file does not exist
     * @throws ResourceCreationException if loading resource failed
     */
    public function doLoadFromFile($filename) {
        if (empty($filename)) {
            throw \RuntimeException("File Name Can Not Be Empty");
        }
        if (!file_exists($filename)) {
            throw new \RuntimeException(
                    sprintf("(%s) Is Not Exist", $filename)
            );
        }
        if (!is_readable($filename)) {
            throw new \RuntimeException(
                    sprintf("(%s) Is Not Readable", $filename)
            );
        }
        $result = imagecreatefromgd($filename);
        if ($result === false) {
            throw new ResourceCreationException(
                    sprintf("Could Not Load The Gd Resource From (%s)"
                            , $filename)
            );
        }
        $this->setHandler($result);
    }

    /**
     * Outputs a GD image to the given filename. 
     * @param string $filename The path to save the file to. If NULL, the raw image 
     * stream will be outputted directly.
     * @throws ResourceOutputException if output failed
     * @throws EmptyResource
     */
    protected function doSave($filename) {
        if (!imagegd($this->getHandler(), $filename)) {
            throw new ResourceOutputException("Output Failed");
        }
    }

    /**
     * Get Copy from this GD Resource
     * @return GD 
     */
    public function doGetCopy() {
        $clone = new Gd();
        // to avoid the Empty resorce exception we have to create new resource
        $clone->loadFromResource(new Png($this->getDimension()));
        $clone->merge($this);
        return $clone;
    }

}

