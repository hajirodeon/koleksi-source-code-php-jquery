<?php

namespace Redstart\Graphic\GraphicException;

/**
 * Invalid Coordinate Exception
 *
 * Thrown when Coordinat Object represents Invalid Coordinates
 * 
 * @package Redstart
 * @subpackage Redstart_Graphic_GraphicException
 * 
 * @author Hyyan Abo Fakher
 * @since Redstart 1.0
 * @version 1.0
 */
class InvalidCoordinate extends GraphicBaseException {
    
}

