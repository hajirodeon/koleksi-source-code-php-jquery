<?php

namespace Redstart\Graphic\GraphicException;

/**
 * Shape Base Exception
 *
 * Base Exceptions Class For Shapes Exceptions
 * 
 * @package Redstart
 * @subpackage Redstart_Graphic_GraphicException
 * 
 * @author Hyyan Abo Fakher
 * @since Redstart 1.0
 * @version 1.0
 */
class ShapeException extends GraphicBaseException {
    
}

