<?php

namespace Redstart\Graphic\GraphicException;

/**
 * Resource Destroy Exception
 *
 * Thrown when resource is empty
 * 
 * @package Redstart
 * @subpackage Redstart_Graphic_GraphicException
 * 
 * @author Hyyan Abo Fakher
 * @since Redstart 1.0
 * @version 1.0
 */
class EmptyResource extends ResourceException {
    
}

