<?php

namespace Redstart\Graphic\GraphicException;

/**
 * Color Base Exception
 *
 * Base Exceptions Class For Color Exceptions
 * 
 * @see AlphaChannelException
 * @see ColorAllocateException
 * 
 * @package Redstart
 * @subpackage Redstart_Graphic_GraphicException
 * 
 * @author Hyyan Abo Fakher
 * @since Redstart 1.0
 * @version 1.0
 */
class ColorException extends GraphicBaseException {
    
}

