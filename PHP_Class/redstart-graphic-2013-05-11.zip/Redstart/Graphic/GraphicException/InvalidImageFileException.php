<?php

namespace Redstart\Graphic\GraphicException;

/**
 * Invalid Image Exception
 *
 * Thrown when file is not valid image file
 * 
 * @package Redstart
 * @subpackage Redstart_Graphic_GraphicException
 * 
 * @author Hyyan Abo Fakher
 * @since Redstart 1.0
 * @version 1.0
 */
class InvalidImageFileException extends GraphicBaseException {
    
}

