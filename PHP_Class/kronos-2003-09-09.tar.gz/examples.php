<HTML>
<TITLE>Example File for KronoClass (c) Tommaso D'Argenio</TITLE>
<BODY style="font-family:verdana;font-size:12px" bgcolor="white">
<?php

/*
* KronoClass v. 0.7 - Example File
* copyright 2002-03 by Tommaso D'Argenio <rajasi@ziobudda.net>
*/

// Include class
error_reporting(E_ALL);
require_once 'class.kronos.php';

// Init new object with english parameter
// Language=english, Format of date=english (mm/dd/yyyy), Date Separator=/
$k = new Krono('en','en','en','/');


echo $k->_disclaimer();
echo $k->_debug();
// And now let's make some calculations

// We want to know if 10 of March 2005 is Friday
// The right answer is -> No!! 03/10/2005 is Thursday
// Make your own tests!
echo '<b>Is friday March 10 of 2005 ?</b>: <i>';
$i = $k->is_day('03/10/2005','Friday');
if($i === 1)
{
	echo 'March 10, 2005 is Friday!</i>';
}
else
{
	echo 'March 10, 2005 isn\'t Friday but '.$i.' !!</i>';
}


echo '<br><br>';

// Transform a simple and classic date in unix timestamp
echo '<b>Timestamp of Jan 16 2003:</b> <i>';
echo $k->date_to_timestamp('01/16/2003');
echo '</i><br><br>';


// Now calc how days are between date_from and date_to
echo '<b>How many days are between 03/20/2003 and 04/21/2003 ?: </b><i>';
echo $k->days_diff('03/20/2003','04/21/2003');
echo '</i><br><br>';

// For something reasons (what's??) we want to know the difference 
// in minutes or hours or seconds between two times...
echo '<b>How minutes are from 9.30am to 11.45am? :</b><i>';
echo $k->times_diff('9.30','11.45','m');
echo 'minutes or ';
echo $k->times_diff('9.30','11.45','s');
echo 'seconds or ';
echo $k->times_diff('9.30','11.45','h');
echo '</i><br><br>';


// Ok, this is useful... i hope ;)
// Add to a time some minutes, or seconds, or time..
// ie: Add 2 hours to 16:20 -> 18.20
// ie: Add 20 minutes to 16:20 -> 16.40
// ie: Add 1 hour and 15 minutes to 16.20 -> 17.35
echo '<b>Add 2 hours to 16:20:</b> <i>'.$k->times_add('16.20','2','h').'</i><br>';
echo '<b>Add 20 minutes to 16:20:</b> <i>'.$k->times_add('16.20','20','m').'</i><br>';
echo '<b>Add 1 hour and 15 minutes to 16:20:</b> <i>'.$k->times_add('16.20','1.15','t').'</i><br><br>';


// How days left to 4 July from today?? 167 days .. Woohoh... !!
echo '<b>How many days is away the Indipendence Day (4 July) ?</b>: <i>';
echo $k->how_to('07/04/2004');
echo '</i><br><br>';

// This is another "strange use" function ...
// We want to know how many Friday are from a date_start to a date_end
echo '<b>How Fridays are from 01/18/2003 to 03/14/2003?:</b> <i>';
echo $k->how_days('01/18/2003','03/14/2003','Friday');
echo '</i><br><br>';

// Now is the "time" to write down the Today Date..
// but on my system (i don't know why..) the LC_TIME doesn't work !!
// both on Linux and _the_other_ system .. ;)
// so i write down a my own date() function:
echo '<b>Today is: </b> <i>';
echo $k->k_date();
echo '</i><br><br>';

// Note that if u don't give the timestamp or format, the class for
// default write the today value in format: Saturday 18 January 2003.. uh.. what intelligence!
// otherwise give the right data: $k->k_date('%D %d %F %y',time());
// you have to use the same date() formatting style .. but add % as prefix !
echo '<b>another Today is: </b> <i>';
echo $k->k_date('%D %d %F %y');
echo '</i><br><br>';


// This is the function that i love overall others!!
// Now perform math operation on date..

// Add 1 month to 01/18/2003
echo '<b>Add 1 month to 01/18/2003:</b> <i>';
echo $k->operation('+','01/18/2003','1%M');
echo '</i><br>';

// Add 45 days to 01/18/2003
echo '<b>Add 45 days to 01/18/2003:</b> <i>';
echo $k->operation('+','01/18/2003','45%D');
echo '</i><br>';

// Add 5 years to 01/18/2003
echo '<b>Add 5 years to 01/18/2003:</b> <i>';
echo $k->operation('+','01/18/2003','5%Y');
echo '</i><br>';

// And now make the some operations, but 'au contraire'... subtraction but sums!

// Sub 1 month from 01/18/2003
echo '<b>Sub 1 month from 01/18/2003:</b> <i>';
echo $k->operation('-','01/18/2003','1%M');
echo '</i><br>';

// Sub 45 days from 01/18/2003
echo '<b>Sub 45 days from 01/18/2003:</b> <i>';
echo $k->operation('-','01/18/2003','45%D');
echo '</i><br>';

// Sub 5 years from 01/18/2003
echo '<b>Sub 5 years from 01/18/2003:</b> <i>';
echo $k->operation('-','01/18/2003','5%Y');
echo '</i><br><br>';


// Are your very, but VERY..  fussy??!
// if the answer is YES... this is the function for you!
// Get the time and date from an atomic watch linked on the internet
// NOTE: You have to be connected to use it!
echo '<b>EXTACT TIME: </b><i>';
echo $k->net_timestamp();
echo '</i><br>';

// For a better reading format, use it as argument of k_date function
echo '<b>Extact time for who isn\'t capable to decode on fly unix timestamp (who isn\'t capable!?!?):</b> <i>';
echo $k->k_date('%m/%d/%Y g:i a',$k->net_timestamp());
echo '</i><br><br>';


// But WHY the Swatch Company (c) has invented this devilry??
echo '<b>Swatch Time (&copy;): </b> <i>';
echo $k->swatch_time();
echo '</i><br><br>';


// Have you some trouble to read.. or to decode or to understand.. 
// a timestamp builded by MySQL?? No!!.. Why you're unable to read it, it's so easy!
// If you have the same problem or need with PostgreSQL use ->pg_time_easy() method instead of.
echo '<b>Convert MySQL timestamp 20011210002745 to a readable format: </b><i>';
echo $k->mysql_time_easy('20011210002745');
echo '</i><br><br>';

echo '<b>And now do the inverse (03/05/2003 19:54:48): </b><i>';
echo $k->mysql_time_easy('03/05/2003 19:54:48','mysqlto');
echo '</i><br><br>';

// Someone sayed to me: we get holiday on 3rd Monday of May ... 
// What!?!? and when is 3rd Monday of May !??
// The name of day can be passed either in short or long format!
// The month can be passed either with name (short or long) or its number
// Optional parameter is the year, if you want to calc on different year ..
echo '<b>When is 3rd Monday of May?</b>: <i>';
echo $k->get_nth_day(3,'Monday','May');
echo '</i><br><br>';

// The fashion of ancient and great Roman Empire...!!
echo '<b>For the Ancient Roman Empire this script will be made on: </b>';
echo $k->roman_date('01/18/2003');
echo ' <i>(01/18/2003)</i><br><br>';

// Do you want to know the Today Moon Phase for your horoscope?
echo '<b>The "today Moon Phase" : </b> <i>';
echo $k->today_moon_phase();
echo '</i><br><br>';

// Tomorrow morning want to "Say Hello" to Sun ?? and when is the SunRise at Avellino (where i live ;) )?
echo '<b>The time for sunrise/sunset at '.date('m/d/Y').': </b><i>';
echo $k->get_sun_time(0,0,1,'IT|Avellino',1,date('m/d/Y'));
echo '</i><br><br>';

// Transform a classic unix timestamp or a number of second in literal value
// so 3670 seconds mean 1 hour, 1 minute and 10 seconds.
echo '<b>Transform 3670 seconds in text format: </b><i>';
echo $k->time_to_text(3670);
echo '</i><br><br>';

// Check if a date or time or both is valid
echo '<b>Is valid 12/32/2003?: </b><i>';
switch($v = $k->is_valid("12/32/2003"))
{
    case '-1': echo "Date is not valid!"; break; 
    case '-2': echo "Time is not valid!"; break;
    case true: echo "Date and/or time are valid!"; break;
    case false: echo "None is good!"; break;
}
echo '</i><br><br>';

// Give me information about a date
echo '<b>Some info on 09/09/2003?: </b><i><br>';
echo "Monthname is: ".$k->get_info("09/09/2003","monthname","long")."<br>";
echo "Dayname is: ".$k->get_info("09/09/2003","dayname","long")."<br>";
echo "Day of week is: ".$k->get_info("09/09/2003","dayofweek","long")."<br>";
echo "Day of year is: ".$k->get_info("09/09/2003","dayofyear","long")."<br>";
echo "Week is: ".$k->get_info("09/09/2003","week","long")."<br>";
echo "Trimester is: ".$k->get_info("09/09/2003","trimester","long")."<br>";
echo '</i><br><br>';

echo '<span style="color:red;font-weight:bolder;font-style:helvetica">That\'s all !!</span><br><hr size="1px" color="black" width=50% align="left">';
?>

</BODY></HTML>