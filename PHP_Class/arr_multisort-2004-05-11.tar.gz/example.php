<?
require("arr_multisort.class.php");

//Sample array - same format will be returned by mysql_fetch_assoc.
$sample_arr = array (
                        array   (
                                    "UserName"  => "Usr1",
                                    "Sex"       => "male",
                                    "Country"   => "US",
                                    "Children"  => 3,
                                    "BirthDate" => "1970-07-21"
                                ),
                        array   (
                                    "UserName"  => "TheUser",
                                    "Sex"       => "female",
                                    "Country"   => "Canada",
                                    "Children"  => 0,
                                    "BirthDate" => "1975-11-05"
                                ),
                        array   (
                                    "UserName"  => "Blah",
                                    "Sex"       => "male",
                                    "Country"   => "US",
                                    "Children"  => 1,
                                    "BirthDate" => "13 Feb 1964"
                                ),
                        array   (
                                    "UserName"  => "Makumba",
                                    "Sex"       => "female",
                                    "Country"   => "Mozambik",
                                    "Children"  => 12,
                                    "BirthDate" => "1980-06-29"
                                ),
                    );

//Instantiate the class
$srt = new arr_multisort($sample_arr);
?>
Starting array (unsorted):<br>
<?
  $srt->sort();
  dump_arr($sample_arr);

  //Sort by sex descending and children ascending
  $srt->colNames = array("Sex",    "Children");
  $srt->colDirs  = array(SRT_DESC,SRT_ASC);
  $sample_arr = $srt->sort();
?>
Array sorted by sex descending and children ascending<br>
<?
dump_arr($sample_arr);

  //Sort by sex ascending and Birth date decending
  $srt->colNames = array("Sex",   "BirthDate");
  $srt->colDirs  = array(SRT_ASC,SRT_DESC);
  $sample_arr = $srt->sort();
?>
Array sorted by sex ascending and Birth date decending<br>
<?
dump_arr($sample_arr);
?>

<?
//Functions

//Dump the array
function dump_arr(&$sample_arr){
  ?>
  <table width="90%" border="1" cellspacing="0" cellpadding="0">
    <tr>
    <?
    $Cols = array_keys($sample_arr[0]);
    foreach($Cols as $col){
      ?>
      <td align="center"><strong><?print($col);?></strong></td>
      <?
    }
    ?>
    </tr>
    <?
    foreach($sample_arr as $row){
      ?>
      <tr>
      <?
      foreach($row as $nm => $val){
      ?>
        <td align="left"><?print($val)?></td>
      <?
      }
      ?>
      </tr>
    <?
    }
    ?>
  </table>
  <?
}
?>
