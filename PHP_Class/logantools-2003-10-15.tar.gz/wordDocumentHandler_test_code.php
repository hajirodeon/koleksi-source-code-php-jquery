<?php
//########################################################################################
// -------------- Summary
// Example of use of the wordDocumentHandler class
//
// -------------- Author
// Logan Dugenoux - 2003
// logan.dugenoux@netcourrier.com
// http://www.peous.com/logan/
//
// -------------- License
// GPL
//
//########################################################################################

	@set_time_limit( 60 );		// cleaning is sometimes very long depending on options
    require ("wordDocumentHandler.php");

    
    // ############### Put here the name of a MsWord document ###################
    $myWordFile = "my doc file.doc";
    
    // The class
    $w = new wordDocumentHandler();
    
    $txt = $w->convertWordDocumentToString( $myWordFile , "htm" );
    if (!$txt)
    {
    	die( $w->GetLastError() );
    }
    else
    {
    	echo "Conversion to string ok. Output len :".strlen($txt)."<br>";
    }
    
    $w->cleanWordHTML( $txt );
    echo "Cleaned string len :".strlen($txt)."<br>";
    

	$outFile = $myWordFile.".html";
    if (!$w->convertWordDocumentToFile( $myWordFile ,$outFile , "htm" ))
    {
    	die( $w->GetLastError() );
    }
    else
    {
    	echo "Conversion to file ok.<br>";
    }
    
?>