<?php
/**********************************************************************
 *	Sjon's PHP Classes Library -> ObjectManager
 *	Written by SJONdaMON, SPG2000. http://www.sjondamon.org/?KW=PHP
 *	All Rights Reserved. Licenced GPL. http://www.sjondamon.org/?KW=GPL
 **********************************************************************/

	class ObjectManager {
		var $_classes_root = "/home/sjondamon/include/classes";
		var $_debug = 1;

		function ObjectManager ($root = "", $debug = 1) {
			if (!empty($root)) {
				$this->_classes_root = $root;
			}
			$this->_debug = $debug;
		}

		function make ($name, $pointer) {
			$filename = (strstr($name, "::")) ? str_replace("::", "/", $name):$name;
			$classname = (strstr($filename, "/")) ? substr(strrchr($filename, "/"), 1):$filename;
			$filename = $this->_classes_root."/".$filename.".php";
			$nicename = (strstr($name, "/")) ? str_replace("/", "::", $name):$name;
			if (file_exists($filename)) {
				include_once ($filename);
				$evalstr = "\$this->".$pointer." = new ".$classname."();";
				@eval("$evalstr");
				if (@gettype($this->$pointer) == "object") {
					$this->_pointers[$pointer] = $nicename;
					return true;
				}
				else {
					unset($this->$pointer);
					return false;
				}
			}
		}

		function list_current () {
			$code = "";
			if (isset($this->_pointers)) {
				if (gettype($this->_pointers) == "array") {
					while (list($key, $val) = @each($this->_pointers)) {
						$code .= "- ObjectManager.Pointer: $key\n -- ObjectManager.NiceName: $val\n\n";
					}
					if ($this->_debug) {
						echo nl2br($code);
					}
					else {
						return $code;
					}
				}
				else {
					return;
				}
			}
			else {
				return;
			}
		}
	}

?>