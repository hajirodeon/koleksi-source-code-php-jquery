<?php 
/* 
*    Writed by Setec Astronomy - setec@freemail.it 
* 
*    This script is distributed  under the GPL License 
* 
*    This program is distributed in the hope that it will be useful, 
*    but WITHOUT ANY WARRANTY; without even the implied warranty of 
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
*    GNU General Public License for more details. 
* 
*    http://www.gnu.org/licenses/gpl.txt 
* 
*/ 

class CMovingList
{ 
    var $firstFormName; 
    var $secondFormName; 
    var $firstFieldName; 
    var $secondFieldName; 
	var $firstAlert;
	var $secondAlert;
     
    function CMovingList  () 
    {
		$this->firstFormName = ""; 
		$this->secondFormName = "";  
		$this->firstFieldName = ""; 
		$this->secondFieldName = "";  
		$this->firstAlerr = ""; 
		$this->secondAlert = "";  
	}

	function _safe_set (&$var_true, $var_false="")
	{
		if (!isset ($var_true))
		{ $var_true = $var_false; }
		return $var_true;
	}
	
	function get_function_js ()
	{
		ob_start ();
?>
<script language="JavaScript" type="text/JavaScript">
<!--
function <?php print ($this->get_function_name ()); ?> (fromForm, toForm, fromItem, toItem, advice) 
{
	var fItem = fromItem +"[]";
	var tItem = toItem +"[]";
	
	if (document.forms[fromForm].elements[fItem].options.selectedIndex >= 0) 
	{
		
		while (document.forms[fromForm].elements[fItem].options.selectedIndex >= 0) 
		{
			ind = document.forms[fromForm].elements[fItem].options.selectedIndex;
			
			text  = document.forms[fromForm].elements[fItem].options[ind].text;
			value = document.forms[fromForm].elements[fItem].options[ind].value;
			
			document.forms[fromForm].elements[fItem].options[ind] = null;
			
			var newOption = new Option(text, value);
			toFormLength = document.forms[toForm].elements[tItem].options.length;
			document.forms[toForm].elements[tItem].options[toFormLength] = newOption;
		}
	} 
	else 
	{ 
		if ((advice != null) && (advice != ""))
		{ alert (advice); }
	}
	return (false);
}
//-->
</script>
<?php
		$result = ob_get_contents ();
		ob_end_clean ();	
		return $result;
	}

	function get_function_name ()
	{
		if (empty ($this->firstFormName) || empty ($this->secondFormName) ||
			empty ($this->firstFieldName) || empty ($this->secondFieldName))
		{ return false; }
		return "MoveItems" . ucfirst ($this->firstFormName) . ucfirst ($this->firstFieldName) . "To" . ucfirst ($this->secondFormName) . ucfirst ($this->secondFieldName);
	}
	
	function get_first2second_js ()
	{
		if (empty ($this->firstFormName) || empty ($this->secondFormName) ||
			empty ($this->firstFieldName) || empty ($this->secondFieldName))
		{ return false; }

		return $this->get_function_name () . "('" . $this->firstFormName . "', '" . $this->secondFormName . "', '" . $this->firstFieldName . "', '" . $this->secondFieldName . "', '" .  $this->firstAlert . "')";
	}

	function get_second2first_js ()
	{
		if (empty ($this->firstFormName) || empty ($this->secondFormName) ||
			empty ($this->firstFieldName) || empty ($this->secondFieldName))
		{ return false; }
		
		return $this->get_function_name () . "('" . $this->secondFormName . "', '" . $this->firstFormName . "', '" . $this->secondFieldName . "', '" . $this->firstFieldName . "', '" .  $this->secondAlert . "')";
	}
}
?>