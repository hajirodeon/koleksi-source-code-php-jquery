<?php include ("CMovingList.php"); ?>
<?php
$movinglist = new CMovingList ();
$movinglist->firstFormName = "demo";
$movinglist->secondFormName = "demo";
$movinglist->firstFieldName = "leftItems";
$movinglist->secondFieldName = "rightItems";
$movinglist->firstAlert = "Please select one or more items from the left side list!";
$movinglist->secondAlert = "Please select one or more items from the right side list!";
?>
<form name="demo" method="post">
  <?php print ($movinglist->get_function_js ()); ?> 
  <table border="0" cellspacing="5" cellpadding="0">
  <tr align="center">
      <td colspan="3">Simple moving list</td>
    </tr>
    <tr> 
      <td> <select multiple size=10 name=leftItems[]>
          <option value=8>os - freebsd</option>
          <option value=5>os - linux</option>
          <option value=7>os - mac os x</option>
          <option value=9>os - unix</option>
          <option value=6>os - windows</option>
          <option value=10>sgbd - mysql</option>
          <option value=12>sgbd - oracle</option>
          <option value=11>sgbd - postgresql</option>
        </select></td>
      <td> &nbsp; &nbsp; <input onclick="return <?php print ($movinglist->get_second2first_js ()); ?>" type="submit" value="&lt;&lt;"> 
        &nbsp; &nbsp; <input onclick="return <?php print ($movinglist->get_first2second_js ()); ?>" type="submit" value="&gt;&gt;"> 
        &nbsp; &nbsp;</td>
      <td> <select multiple size="10" name="rightItems[]">
          <option value="2">langage - asp</option>
          <option value="4">langage - c++</option>
          <option value="3">langage - javascript</option>
          <option value="1">langage - php</option>
        </select> </td>
    </tr>
  </table>
</form>
<?php
$movinglist = new CMovingList ();
$movinglist->firstFormName = "demo2";
$movinglist->secondFormName = "demo2";
$movinglist->firstFieldName = "leftItems";
$movinglist->secondFieldName = "centerItems";
$movinglist->firstAlert = "Please select one or more items from the left side list!";
$movinglist->secondAlert = "Please select one or more items from the right side list!";

$movinglist2 = new CMovingList ();
$movinglist2->firstFormName = "demo2";
$movinglist2->secondFormName = "demo2";
$movinglist2->firstFieldName = "centerItems";
$movinglist2->secondFieldName = "rightItems";
$movinglist2->firstAlert = "Please select one or more items from the left side list!";
$movinglist2->secondAlert = "Please select one or more items from the right side list!";

?>
<form name="demo2" method="post">
  <?php print ($movinglist->get_function_js ()); ?>
  <?php print ($movinglist2->get_function_js ()); ?> 
  <table border="0" cellspacing="5" cellpadding="0">
  <tr align="center">
      <td colspan="3">Multiple moving list</td>
    </tr>
    <tr> 
      <td> <select multiple size="10" name="leftItems[]">
          <option value="8">os - freebsd</option>
          <option value="5">os - linux</option>
          <option value="7">os - mac os x</option>
          <option value="9">os - unix</option>
          <option value="6">os - windows</option>
          <option value="10">sgbd - mysql</option>
          <option value="12">sgbd - oracle</option>
          <option value="11">sgbd - postgresql</option>
        </select></td>
      <td> &nbsp; &nbsp; <input onclick="return <?php print ($movinglist->get_second2first_js ()); ?>" type="submit" value="&lt;&lt;"> 
        &nbsp; &nbsp; <input onclick="return <?php print ($movinglist->get_first2second_js ()); ?>" type="submit" value="&gt;&gt;"> 
        &nbsp; &nbsp;</td>
      <td> <select multiple size="10" name="centerItems[]">
          <option value="2">langage - asp</option>
          <option value="4">langage - c++</option>
          <option value="3">langage - javascript</option>
          <option value="1">langage - php</option>
        </select> </td>
      <td> &nbsp; &nbsp; <input onclick="return <?php print ($movinglist2->get_second2first_js ()); ?>" type="submit" value="&lt;&lt;"> 
        &nbsp; &nbsp; <input onclick="return <?php print ($movinglist2->get_first2second_js ()); ?>" type="submit" value="&gt;&gt;"> 
        &nbsp; &nbsp;</td>
      <td> <select multiple size="10" name="rightItems[]">
          <option value="2">features - parallel computing</option>
          <option value="4">features - cluster</option>
          <option value="3">features - enterprice</option>
          <option value="1">features - storabe</option>
        </select> </td>
    </tr>
  </table>
</form>