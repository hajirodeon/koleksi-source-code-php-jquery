
<?php


/* ***************************************** */
function getmicrotime(){
/* ***************************************** */
    list($usec, $sec) = explode(" ",microtime());
    return ((float)$usec + (float)$sec);
    }

// record processing time
$start=getmicrotime();

function fehler() {
/* *************************** */
global $HTTP_SERVER_VARS, $db_mailto_error;

    if (mysql_errno()>0) {
            $error1=mysql_errno();
            $error2=mysql_error();
            echo "<font size=+2 color=red><b>Datenbankfehler!</b> $error1: $error2<BR>";
            $err_msg = "WARNING: Check log file if suspected recurrent error!\n\n";
            $err_msg .= "Error Occured @:\n";
            $err_msg .= date ("D M j, Y h:i:s A") . "\n\n";
            $err_msg .= "MySQL ErrNo: $error1\n";
            $err_msg .= "MySQL ErrMsg: $error2\n\n";
            $err_msg .= "Website: ".$HTTP_SERVER_VARS['HTTP_HOST']."\n";
            $err_msg .= "Query-String: ".$HTTP_SERVER_VARS['REQUEST_URI']."\n";
            $err_msg .= "Remote IP Access from: ".$HTTP_SERVER_VARS['REMOTE_ADDR']."\n";

            mail($db_mailto_error,"mySQL Error on ".$HTTP_SERVER_VARS['HTTP_HOST'],$err_msg);

            exit; break; stop;
    };

} /* end of function fehler() */



/* ---------------------------------- */
/* Change the following settings !    */
/* ---------------------------------- */

// database-server ...
$db_host = "base.isb.net";

// database username
$db_user = "zeit4zeit";

// Database name
$db = "zeit4zeit";

// password to connect with to the database-server
$db_pwd = "1azeit";

// database table name we are working on ... if you don't have it setup already, doit now!
// definition of the table is shown in the documentation of the php_tree.class itself
$table = "php_tree";		/* database table working on */

// where to mail errors
$db_mailto_error= "phpclasses@zeitfenster.de";

// display mode: 3=almost everything, 2=less, 1=crutial
$mode = "3";

// show parent, ident, haschild values in tree-views: 1=yes, 0=no
$show_db_identifier="1";

// show sql-statements, 1=true, 0=false
$debug="0";


// define client / mandant
if (!isset($gui)) { $gui = "999"; }

// set starting point to root node, if none given
if (!isset($node)) { $node="-1"; };

/* ********************************** */


/*

	header for html page

*/
echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">';
echo '<html><head><title>PHP Tree - demo of php_tree class</title>';
include("style_win.css");		/* load some style */
echo '</head><body>';

/*

	Javascript ... don't know where to store this right now! todo!
*/

?>
<script language="JavaScript" type="text/javascript" src="php_tree.js"></script>
<?php



/*

	Some information to lead into demo

*/
echo '<table><tr><td>';
echo '<h2><a href="example.php">php_tree demo</a></h2>';

if ( isset($node) && $node=="-1" )
{
    echo '<p>You must have a database and store data in a table with ident, parent, haschild rows holding information about your products, your database, your repository, your menuesystem, your ';
    echo '... what ever you can imagine, than php_tree gives you handy, raw-functions to retrieve, inject and safely destroy information without having to bother about anything else than layout ';
    echo 'and your idea itself.</p>';
    echo 'php_tree may be used to display the path from root to node and visaversa, display a branch of a tree and draw the full tree in static manor or interactive javascript style. ';
    echo 'Almost nothing is stored in memory, ';
    echo 'so what you might need when working on large trees is a fast database-server and a fast application-server.';
	echo 'Please be encouraged to drop me a mail (phptree\'at\'zeitfenster.de), in case of any problems or questions or errors or missing functionality.';
	echo 'I would be very happy to answer your e-mail.';
}
echo '</td></tr></table>';


/*

	connect to database

*/
if ( ( $db_host=="base.isb.net" && $_SERVER['SERVER_NAME']!="www.zeitfenster.de" ) || $_GET['action']=="showsource")
{
	echo '<h2>Here comes the source-code</h2><br>';
	echo '<br>';
	echo '*******************************************<br><p>';
	echo '<h2>qad (quick and dirty) Examples how to use php_tree ... hope it helps you</h2><br>';
	echo '*******************************************<br>';
	echo ' example.php<br>';
	echo '*******************************************<br>';
	show_source('example.php');
	echo '*******************************************<br>';
	echo ' php_tree.class<br>';
	echo '*******************************************<br>';
	show_source('php_tree.class');
	echo '*******************************************<br><p>';
	exit;
}
mysql_connect($db_host,$db_user,$db_pwd);
mysql_select_db($db);




/*

	get class ready for working 

*/
require_once("php_tree.class");

// initialize class
$mytree = new php_tree();

// set the parameters from source-code into scope of class
$mytree->set_parameters($gui,$mode,$db,$table,$show_db_identifier,$debug);


/**
* +----------------------------------------------+
* | Demonstration of functions of php_tree.class |
* +----------------------------------------------+
*/

/*

   delete a node

*/

if ($_POST['action']=="delete") {
	$mytree->delete_from_db($_POST['node']);
	$node=$_POST['parent_node'];
}

// evaluate actions coming from form or url
if (isset($_GET['action'])) {

    switch ($_GET['action']) {
    case "delete_from_db":
        /*

            example of how to delete a whole tree

        */
        if (isset($_GET['node'])) { $node=$_GET['node']; }
        $mytree->delete_from_db( $node );
        echo 'node #'.$node.' removed and '.$mytree->number_of_nodes.' childs have been moved to parent<br>';
        break;

    case "delete_from_db_wholetree":
        /*

            example of how to delete a whole tree

        */
        if (isset($_GET['node'])) { $node=$_GET['node']; }
        $mytree->delete_from_db_wholetree($node);

        echo "done. ".$mytree->number_of_nodes." nodes removed.";
        break;

    case "move_up":
        /*

            example of how to delete a whole tree

        */
        if (isset($_GET['node'])) { $node=$_GET['node']; }
        $mytree->move_up($node);
        if ($mytree->father !="") {
            echo "node #".$node." moved to ".$mytree->father.".";
            $node=$mytree->father;
        } else {
            echo 'father object empty ... could not move node-object beyond absolute root<br>';
        }
        break;

    case "fulltree":
        /*

        display the full tree

        */
        $mytree->display_full_tree($node,1);
        break;

    case "displaybranch":
        echo '<table><tr><td>';
        echo "<br><p>display_branch(\$node)</p>";
        $mytree->display_branch($node);
        echo $mytree->number_of_nodes.'</td></tr></table>';
        break;

    case "populatetree":
        // create a root node
        $mytree->insert_into_db(-1,"1000 nodes below this node", time() );

        // generate 1000 nodes below root-node #1
        srand ((double)microtime()*1000000);

        for ($i=0;$i<1000;$i++) {
            $node=rand(1,1+$i);
            $mytree->uid=1+$i;
            $mytree->insert_into_db($node,"test".$i, 1+$i );
        } /* end of for */
        
        echo "<p>".$i." nodes generated</p>";

        // set starting point to root-node
        $node="-1"; 
	} /* end of switch */
}

/*

    display some form for assistance of database injection

*/

echo '<table><tr><td>';
echo '<form method="post">';
echo 'Child <input type="text" name="child">';
echo '<input type=hidden name=node value="'.$node.'">';
echo '<input type=submit class="button" name=submit value="save">';
echo '</form>';
echo '</td></tr></table>';


/*

    store a new object

*/
if (isset($_POST['child'])) {
    $mytree->insert_into_db($_POST['node'],$_POST['child'], time() );
    echo "ok";
}


/*

    display a branch of a $node

*/
echo '<table><tr><td>';
echo "<br><p>display_branch(\$node)</p>";
$mytree->display_branch($node);
        
// check if database is empty ... 
if ( !isset($mytree->number_of_nodes) || $mytree->number_of_nodes=="0" ) {

    // database is empty ... offer help to populate database
    echo '<b>database is empty</b> ... <a href="?action=populatetree">click here to create a root-node and populate the database with dummy entries</a><br><br>';
    echo '</td></tr></table>';

} else {
    
    // database hasnodes ... offer links to tree_displays
    echo '<ul>';
    echo '<li> <a href="?action=fulltree&node='.$node.'">display_full_tree('.$node.')</a><br>';
    echo '<li> <a href="example_with_lots_of_javascript.php?action=fulltree&node='.$node.'">display full tree javascript version</a>';
    echo '</ul>';
    echo '</td></tr></table>';

    /*
    
        delete nodes links
    
    */
    echo '<table><tr><td>';
    echo 'functions to delete nodes are: <a href="?action=delete_from_db&node='.$node.'">delete_from_db('.$node.')</a> and <a href="?action=delete_from_db_wholetree&node='.$node.'">delete_from_db_wholetree('.$node.')</a><br>';
    echo '</td></tr></table>';

    /*
    
        display path to a $node
    
    */
    echo "<table><tr><td><br><p>display_path ( \$node, \$reverse_path )</p>";
    $branches=$mytree->display_path($node,$mytree->reverse_path,"1");
    echo '\\<a href="?node=-1">root</a><br>'; echo "branch no. ".$branches." in tree";
    echo '</td>';
    
    /*
    
        display reverse path to a node
    
    */
    echo '<td>';
    echo "<br><p>display_reverse_path ( \$node )</p> ";
    $mytree->display_reverse_path( $node );
    echo '</td>';
    echo '</tr></table>';


} // end of if 


// just some calculation of execution time
$diff=round(getmicrotime()-$start,3); echo "<br>exec ".$diff." sec - execution time changes as result of processing time is scheduled from shared webserver ;-) - <a href=\"?action=showsource\">show source-code</a><br>";


?>
</body>
</html>
