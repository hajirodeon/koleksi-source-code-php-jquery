
  /*
   * sitemap.js 1.31 05/02/2000
   *  - Opera 5
   *
   * sitemap.js 1.2 27/11/2000
   *  - Netscape 6
   *
   * sitemap.js 1.2 20/05/2000
   *  - split array tree into arrays for each element old tree
   *  - no mory type flag, an folder is an entry which has sons
   *  - a folder can have an link
   *  - while initing an default layers is shown 
   *
   * sitemap.js 1.1 20/10/1999
   *  - showTree only updates and init layers new which have been really changed
   *  - add deep to knot entry
   *  - substitute knotDeep[ id ] w/ tree[ id2treeIndex[ id ] ].deep
   *  - add alignment to img and a &nbsp; at the beginning of eyery line
   *  - add a fake img for bookmarks on top panel
   *
   * sitemap.js 1.02 14/10/1999
   *  - fix bug in initStyles
   *
   * sitemap.js 1.01 06/10/1999
   *  - fix bug in knotDeep for Netscape 4.00-4.0.5
   *
   * sitemap.js 1.0 20/09/1999
   *
   * Javascript function for displaying hierarchic directory structures with
   * the ability to collapse and expand directories.
   *
   * Copyright (c) 1999 Polzin GmbH, Duesseldorf. All Rights Reserved.
   * Author: Lutz Eymers <ixtab@polzin.com>
   * Download: http://www.polzin.com/inet/fset_inet.phtml?w=goodies
   *
   * Permission to use, copy, modify, and distribute this software
   * and its documentation for any purposes and without fee
   * is hereby granted provided that this copyright notice
   * appears in all copies. 
   *
   * Of course, this software is provided "as is" without express or implied
   * warranty of any kind.
   *
   */

  //window.onError=null;

  var idx=0
  var treeId = new Array();
  var treeP_id = new Array();
  var treeIsOn = new Array();
  var treeTyp = new Array();
  var treeName = new Array();
  var treeUrl = new Array();
  var treeWasOn = new Array();
  var treeDeep = new Array();
  var treeLastY = new Array();
  var treeIsShown = new Array();

  function Note( id,p_id,name,url ) {
    treeId[ idx ] = id
    treeP_id[ idx ] = p_id
    treeIsOn[ idx ] = false
    treeTyp[ idx ] = 'f'
    treeName[ idx ] = name
    treeUrl[ idx ] = url 
    treeWasOn[ idx ] = false
    treeDeep[ idx ] = 0
    treeLastY[ idx ] = 0
    treeIsShown[ idx ] = false
    idx++
  }

  function initDiv ( )
  {
    if ( isDOM || isDomIE  )
    {
      divPrefix='<DIV style="position:absolute; left:0; top:0; visibility:hidden;" ID="sitemap'
      divInfo='<DIV CLASS="sitemap" style="position:absolute; visibility:visible" ID="sitemap'
    }
    else
    {
      divPrefix='<DIV ID="sitemap'
      divInfo='<DIV CLASS="sitemap" ID="sitemap'
    }
    document.writeln( divInfo +  'info">Bitte haben Sie etwas Geduld.<BR>&nbsp;<BR>Es werden die Eintr&auml;ge aus<BR>&nbsp;<BR>der Datenbank initialisiert.</DIV> ' );

    for ( var i=1; i<idx; i++ )
    {
      // linked Name ? 
      if ( treeUrl[i] != '' )
        linkedName = '<A HREF="' + treeUrl[i] + '" TARGET="' + defaultTarget + '">' + treeName[i] + '</A>'
      else
        linkedName =  treeName[i]
      // folder  or  bookmarks
      if ( i == idx-1 || treeP_id[i+1] != treeId[i] ) 
        iconImg = '<IMG SRC="file.gif" BORDER="0" HEIGHT="10" WIDTH="12" HSPACE="0" VSPACE="4">'
      else
        iconImg = '<A HREF="javascript:sitemapClick(' + treeId[i] + ')"><IMG SRC="http://www.zeitfenster.de/phptree/folder_off.gif" BORDER="0" NAME="folder' + treeId[i] + '" HEIGHT="10" WIDTH="12" HSPACE="0" VSPACE="4"></A>'

      folder_deep = treeDeep[ id2treeIndex[ treeId[i] ] ]
      spacerX = folder_deep * 12
      folder_style = (folder_deep?'top':'sub')
      
      document.writeln( divPrefix + treeId[i] + '" CLASS="sitemap' + folder_style + '"><NOBR><TABLE CLASS="sitemap" WIDTH="500" BORDER="0" CELLSPACING="0" CELLPADDING="0"><TR VALIGN="middle"><TD WIDTH="' + (spacerX+deltaX) + '"></TD><TD WIDTH="12">' + iconImg  + '</TD><TD WIDTH="' + (500-spacerX-deltaX-12) +'">' + "&nbsp;" + linkedName + '</TD></TR></TABLE></NOBR></DIV><BR>')
    }
  }

  function initStyles ( )
  {
    document.writeln( '<STYLE TYPE="text/css">' + "\n" + '<!--' )
    for ( var i=1,y=y0; i<idx; i++ )
    {  
      document.writeln( '#sitemap' + treeId[i] + ' {POSITION: absolute; VISIBILITY: hidden;}' )
      if ( treeIsOn[ id2treeIndex[ treeP_id[i] ] ] )
        y += deltaY
    }
    document.writeln( '#sitemapinfo {POSITION: absolute; VISIBILITY: visible;}' )
    document.writeln( '//-->' + "\n" + '</STYLE>' )
  }



  function sitemapClick( id )
  {
    var i = id2treeIndex[ id ]

    if ( treeIsOn[ i ] )
    // close directory
    {
      // mark node as invisible
      treeIsOn[ i ]=false
      // mark all sons as invisible
      actDeep = treeDeep[ i ]
      for( var j=i+1; j<idx && treeDeep[j] > actDeep; j++ )
      {
        treeWasOn[ j ] = treeIsOn[ j ]
        treeIsOn[ j ]=false
      }
      gif_off( id )
    }
    else
    // open directory
    { 
      treeIsOn[ i ]=true
      // remember and restore old status
      actDeep = treeDeep[ i ]
      for( var j=i+1; j<idx && treeDeep[j] > actDeep; j++ )
      {
        treeIsOn[ j ] = treeWasOn[ j ]
      }
      gif_on( id )
    }
    showTree()
  }

  function knotDeep( id )
  {
    var deep=0
    while ( true )
      if ( treeP_id[ id2treeIndex[id] ] == 0 )
        return deep
      else
      {
        ++deep
        id = treeP_id[ id2treeIndex[id] ]
      }
    return deep  
  }

  function initTree( id )
  {
    treeIsOn[ id2treeIndex[id] ] = true
    if ( treeTyp[ id2treeIndex[id] ] != 'b' )
      gif_on( id ) 
    while ( treeP_id[ id2treeIndex[id] ] != 0 )
    {
      id = treeP_id[ id2treeIndex[id] ]
      treeIsOn[ id2treeIndex[id] ] = true
      if ( treeTyp[ id2treeIndex[id] ] != 'b' )
        gif_on( id ) 
    }
  }

  function lastEntryInFolder( id )
  {
    var i = id2treeIndex[id]
    if ( i == idx-1 )
      return true
    if ( treeTyp[i] == 'b' )
    {
      if ( treeP_id[i+1] != treeP_id[i] )
        return true
      else
        return false
    }
    else
    {
      var actDeep = treeDeep[i]
      for( var j=i+1; j<idx && treeDeep[j] > actDeep ; j++ )
      ;
      if ( j<idx && treeDeep[j] == actDeep )
        return false
      else
        return true
    }
  }

  function showTree()
  {
    for( var i=1, y=y0, x=x0; i<idx; i++ )
    {
      if ( treeIsOn[ id2treeIndex[ treeP_id[i] ] ] )
      {
        // show current node
        if ( !(y == treeLastY[i] && treeIsShown[i] ) )
        {
          showLayer( "sitemap"+ treeId[i] ) 
          setyLayer( "sitemap"+ treeId[i], y )
          treeIsShown[i] = true
        } 
        treeLastY[i] = y
        y += deltaY
      }
      else
      {
        // hide current node and all sons
        if ( treeIsShown[ i ] )
        {
          hideLayer( "sitemap"+ treeId[i] ) 
          treeIsShown[i] = false
        }
      }
    }
  }

  function initIndex() {
    for( var i=0; i<idx; i++ )
      id2treeIndex[ treeId[i] ] = i
  }

  function gif_name (name, width, height) {
    this.on = new Image (width, height);
    this.on.src = running_server+name + "_on.gif"
    this.off = new Image (width, height);
    this.off.src = running_server+name + "_off.gif"
  }

  function load_all () {
    var name = 'folder';
    var width= 12;
    var height=10;
    gif_name [name] = new gif_name (name,width,height);
  }

  function gif_on ( id ) {
    eval("document['folder" + id + "'].src = gif_name['folder'].on.src")
  }

  function gif_off ( id ) {
    eval("document['folder" + id + "'].src = gif_name['folder'].off.src")
  }
 
  // global configuration
  var deltaX = 12
  var deltaY = 18
  var x0 = 5
  var y0 = 5
  var defaultTarget = 'examplemain'
  var running_server= 'HttP://wWw.ZeItFeNsTeR.dE/phptree/'

  var browserName = navigator.appName;
  var browserVersion = parseInt(navigator.appVersion);
  var isIE = false;
  var isNN = false;
  var isDOM = false;
  var isDomIE = false;
  var isDomNN = false;
  var layerok = false;

  var isIE = browserName.indexOf("Microsoft Internet Explorer" )==-1?false:true;
  var isNN = browserName.indexOf("Netscape")==-1?false:true;
  var isOpera = browserName.indexOf("Opera")==-1?false:true;
  var isDOM = document.getElementById?true:false;
  var isDomNN = document.layers?true:false;
  var isDomIE = document.all?true:false;

  if ( isNN && browserVersion>=4 ) layerok=true;
  if ( isIE && browserVersion>=4 ) layerok=true;
  if ( isOpera && browserVersion>=5 ) layerok=true;

    
  function hideLayer(layerName) {
    if (isDOM)
      document.getElementById(layerName).style.visibility="hidden"
    else if (isDomIE)
      document.all[layerName].style.visibility="hidden";
    else if (isDomNN) 
      document.layers[layerName].visibility="hidden";
  }

  function showLayer(layerName) {
    if (isDOM)
      document.getElementById(layerName).style.visibility="visible"
    else if (isDomIE)
      document.all[layerName].style.visibility="visible";
    else if (isDomNN)
      document.layers[layerName].visibility="visible";
  }

  function setyLayer(layerName, y) {
    if (isDOM)
      document.getElementById(layerName).style.top=y
    else if (isDomIE)
      document.all[layerName].style.top=y;
    else if (isDomNN)
      document.layers[layerName].top=y;
  }



// PHP Layers Menu 3.0beta2 (C) 2001-2003 Marco Pratesi (marco at telug dot it)

DOM = (document.getElementById) ? 1 : 0;
NS4 = (document.layers) ? 1 : 0;



function isVisible(layer) {
	if (DOM) {
		return (document.getElementById(layer).style.visibility == "visible");
	} else if (NS4) {
		return (document.layers[layer].visibility == "show");
	} else {
		return (document.all[layer].style.visibility == "visible");
	}
};

function setVisibility(layer,on) {
	// alert(layer);
    if (on) {
		if (DOM) {
			document.getElementById(layer).style.visibility = "visible";
		} else if (NS4) {
			document.layers[layer].visibility = "show";
		} else {
			document.all[layer].style.visibility = "visible";
		}
	} else {
		if (DOM) {
			document.getElementById(layer).style.visibility = "hidden";
		} else if (NS4) {
			document.layers[layer].visibility = "hide";
		} else {
			document.all[layer].style.visibility = "hidden";
		}
	}
}; // end of function setVisibility


function toggle_visible(id){
 	// alert(id);
    var layer = 'branch_'+id;
    var visible = !isVisible(layer);
	setVisibility(layer,visible);
}; // end of function toggle

