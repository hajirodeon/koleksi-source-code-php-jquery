<?php


/* ***************************************** */
function getmicrotime(){
/* ***************************************** */
    list($usec, $sec) = explode(" ",microtime());
    return ((float)$usec + (float)$sec);
    }

// record processing time
$start=getmicrotime();

function fehler() {
/* *************************** */
global $HTTP_SERVER_VARS, $db_mailto_error;

    if (mysql_errno()>0) {
            $error1=mysql_errno();
            $error2=mysql_error();
            echo "<font size=+2 color=red><b>Datenbankfehler!</b> $error1: $error2<BR>";
            $err_msg = "WARNING: Check log file if suspected recurrent error!\n\n";
            $err_msg .= "Error Occured @:\n";
            $err_msg .= date ("D M j, Y h:i:s A") . "\n\n";
            $err_msg .= "MySQL ErrNo: $error1\n";
            $err_msg .= "MySQL ErrMsg: $error2\n\n";
            $err_msg .= "Website: ".$HTTP_SERVER_VARS['HTTP_HOST']."\n";
            $err_msg .= "Query-String: ".$HTTP_SERVER_VARS['REQUEST_URI']."\n";
            $err_msg .= "Remote IP Access from: ".$HTTP_SERVER_VARS['REMOTE_ADDR']."\n";

            mail($db_mailto_error,"mySQL Error on ".$HTTP_SERVER_VARS['HTTP_HOST'],$err_msg);

            exit; break; stop;
    };

} /* end of function fehler() */



/* ---------------------------------- */
/* Change the following settings !    */
/* ---------------------------------- */

// database-server ...
$db_host = "base.isb.net";

// database username
$db_user = "zeit4zeit";

// Database name
$db = "zeit4zeit";

// password to connect with to the database-server
$db_pwd = "1azeit";

// database table name we are working on ... if you don't have it setup already, doit now!
// definition of the table is shown in the documentation of the php_tree.class itself
$table = "php_tree";

// where to mail errors
$db_mailto_error= "phpclasses@zeitfenster.de";

// display mode: 3=almost everything, 2=less, 1=crutial
$mode = "3";

// show parent, ident, haschild values in tree-views: 1=yes, 0=no
$show_db_identifier="1";

// show sql-statements, 1=true, 0=false
$debug="0";


// define client / mandant
if (!isset($gui)) { $gui = "999"; }

// set starting point to root node, if none given
if (!isset($node)) { $node="-1"; };

/* ********************************** */
mysql_connect($db_host,$db_user,$db_pwd);
mysql_select_db($db);
require_once("php_tree.class");
$mytree=new php_tree();
$mytree->set_parameters($gui,$mode,$db,$table,$show_db_identifier,$debug);
/* ********************************** */

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 3.2//EN">
<HTML>
<HEAD>
  <META NAME="Generator" CONTENT="Cosmo Create 1.0.3">
  <TITLE>PHP Tree Demo</TITLE>
    <STYLE TYPE="text/css">
    <!--

    body          {font-family: helvetica, arial, geneva, sans-serif; font-size: 10pt; color: #000000; background-color: #FFFFFF}

    .sitemap, TD {
	    font-family:Arial,Helvetica;
	    font-size:10pt;
	    line-height:10pt;
    }

    .sitemaptop {
      layer-background-color: #F0F0F0;
      background-color: #F0F0F0;
    }

    .sitemapsub {
      layer-background-color: #E0E0EF;
      background-color: #E0E0EF;
    }

    body { margin-top:0px;
           margin-left:0px;
    }
    a:link { text-decoration: none; color:#AA0000; }
    a:visited { text-decoration: none; color:#0000AA; }
    a:active { text-decoration: none; color:#00AA00; }
    a:hover { text-decoration: underline; color:#AA0000;}
    // -->
    </STYLE>

  <script language="JavaScript1.2" type="text/javascript" src="php_tree.js"></script>
  <SCRIPT language="JavaScript">

  var id2treeIndex = new Array()

  function initArray()
  {
    Note(0,-1,'','')
<?php

        /* -------------------------------------------------- */
        /* example of populate_polzin_tree($node)             */
        /* -------------------------------------------------- */
        
		if (!isset($node)) {$node="1003"; }
        // echo "Note(".$node.",0,'test','')\n";
        $mytree->populate_polzin_tree($node,'0');

        /* -------------------------------------------------- */
        /* -------------------------------------------------- */
        /* -------------------------------------------------- */

 ?>


    treeTyp[0] = 'f'
    treeIsOn[0] = true
    treeWasOn[0] = true
  }

  var idx=0
  initArray()
  initIndex()
  load_all()
  for( i=1; i<idx; i++ )
  {
    treeDeep[i] = knotDeep( treeId[i] )
    if ( treeDeep[i] == 0 )
      treeIsShown[i] = true
  }
  if ( isDomNN )
    initStyles();

  </SCRIPT>
</HEAD>
<BODY VLINK="#000000" ALINK="#000000" LINK="#000000" BGCOLOR="#ffffff" TEXT="#000000"
 onLoad="if (layerok) showTree();"
 MARGINHEIGHT="0" MARGINWIDTH="0" LEFTMARGIN="0" TOPMARGIN="0">
<!--
<body>
-->
<SCRIPT language="JavaScript1.2">
<!--
  initDiv()
  hideLayer("sitemapinfo")
//-->
</SCRIPT>

<div style="position:absolute; top:50px; left:450px; width:350px; border:2px solid #ce3A04; padding:2px;">
<?php
	echo "PHP Tree Demo :: number of nodes in tree: ".$mytree->number_of_nodes."";
    // just some calculation of execution time
    $diff=round(getmicrotime()-$start,3); 
    echo "<br>exec ".$diff." sec <br><a href='example.php'>&gt;&gt; go back to example.php</a>";

	/*
	if (!isset($node)) {$node="1003"; }
    echo "<pre>Note(".$node.",0,'test','')\n";
    $mytree->populate_polzin_tree($node,'0');
    echo '</pre>';
    */
?>
</div>

</BODY>
</HTML>
