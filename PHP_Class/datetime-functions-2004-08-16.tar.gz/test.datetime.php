<?php

    require_once('class.datetime.php');
    $time = time() - rand(0, 172800);
    $timeStr = DateTime::timeStampToString($time);
    
    echo "Compare $time to ", time(), ': ', DateTime::compareDates($time, time()), "<br /><br />\n\n";
    echo "$time to string: $timeStr<br /><br />\n\n";
    echo "$timeStr to time stamp: ", DateTime::timeStringToStamp($timeStr), "<br /><br />\n\n";
    echo "$timeStr as 'Y-m-D': ", DateTime::timeFormat($timeStr, 'Y-m-d'), "<br /><br />\n\n";
    echo "$time as 'Y-m-D': ", DateTime::timeFormat($time, 'Y-m-d'), "<br /><br />\n\n";
    echo "From $time to ", time(), ' as human readable: ', DateTime::timeToHumanReadable(time() - $time), "<br /><br />\n\n";
    echo "$time as 'fuzzy' time string: ", DateTime::fuzzyTimeString($time), "<br /><br />\n\n";

?>