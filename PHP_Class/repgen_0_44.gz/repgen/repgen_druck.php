<?php session_start();
require_once("repgen_const.inc");
require_once("repgen_def.inc");

$url_druck = "repgen_druck1.php";


?>
<!doctype html public "-//W3C//DTD HTML 4.0 //EN">
<html>
<head>
       <title>Title here!</title>
</head>
<body>
<?php  page_header();
?>
  <form action="<?php echo $url_druck; ?>" method="post" target="_top">
  <input type=hidden name="reportnr" value = "<? echo $id; ?>" >
  <BR><BR>
  <input type=submit value="<? echo DRUCKEN; ?>" >
</form>
<?php page_footer();
?>
</body>
</html>

