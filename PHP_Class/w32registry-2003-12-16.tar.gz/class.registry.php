<?php
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// MODULE: Classe Registry
// -----------------------
// Note: A n'utiliser que sur une plateforme windows
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// Auteur: PascalZ (www.pascalz.com)
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-


// D�claration des constantes
if (!defined("HKCR"))
{
	define("HKCR","HKEY_CLASSES_ROOT",	TRUE);
	define("HKCU","HKEY_CURRENT_USER",	TRUE);
	define("HKLM","HKEY_LOCAL_MACHINE",	TRUE);
	define("HKU", "HKEY_USERS",			TRUE);
	define("HKCC","HKEY_CURRENT_CONFIG",TRUE);
}

class Registry 
{
	// Variable priv� du Shell
	var $_Shell;

	// Constructeur
	function Registry()
	{
		$this->_Shell= &new COM('WScript.Shell');
	}

	// Gestion des erreurs
	function RegError($error)
	{
		print($error);
		error_reporting(E_ALL);
	}
	
	// Lecture d'une cl�
	function Read($key)
	{
		if (!$this->KeyExists($key))
			$this->RegError("La cl� n'existe pas !");
		else return $this->_Shell->RegRead($key);
	}

	// Ecriture dans une cl�
	function Write($key,$value)
	{
		if (!$this->KeyExists($key))
			$this->RegError("La cl� n'existe pas !");
		else return $this->_Shell->RegWrite($key,$value);
	}

	// Supprimer la cl�
	function Delete($key)
	{
		if (!$this->KeyExists($key))
			$this->RegError("La cl� n'existe pas !");
		else return $this->_Shell->RegDelete($key);
	}

	// V�rifier que la cl� existe
	function KeyExists($key)
	{
		return (@$this->_Shell->RegRead($key) != null);
	}

}
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
?>