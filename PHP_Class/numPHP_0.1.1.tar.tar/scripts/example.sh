#! /bin/sh
#
# To test the function and documentation scripts
# Jesus M. Castagnetto.
#
# $Id: example.sh,v 1.1 2000/02/28 09:58:52 jmcastagnetto Exp $
#

echo " Example 1: extract the sign function from pkg.arith.php"
echo "            which is only one that has the appropriate tags"
echo ""
./getfunc sign ../pkg.arith.php
echo ""
echo "----------------------------------------"
echo ""
echo " Example 2: extract the documentation of function is_odd"
echo ""
./getdoc is_odd ../pkg.arith.php
