<?php
require ("../pkg.arith.php");

/* 
 * To test pkg.arith
 * $Id: testarith.php,v 1.1 2000/02/27 09:30:40 jmcastagnetto Exp $
 */

echo "sign(-23) is ".sign(-23)."\n";
echo "is_odd(-23) is ".is_odd(-23)."\n";
echo "is_odd(40) is ".is_odd(40)."\n";

?>
