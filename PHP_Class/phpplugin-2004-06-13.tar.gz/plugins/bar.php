

<?php

function bar($str){
	$this->display("----" . $str . "-----");
}

?>

