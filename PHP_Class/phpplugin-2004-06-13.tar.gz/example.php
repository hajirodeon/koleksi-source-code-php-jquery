<?php

// Example file for phpPlugin

require "plugin.class.php";

// Class that will be extended with new plugins
class foo
{
	var $good;
	function foo($str='')
	{
		$this->good = $str;
	}

}

// Plugin object that will manage all the plugin requests in this script
// The path to the plugins is set 'plugins/'
$plugin = new phpPlugin('plugins/');

// Class that will be extended with new plugins
$foo = new foo();

// Sets the filename format for the plugins 'foo'
// The plugin name will replace the character '?'
// The filename will be modified with the function 'strtolower' passed as parameter
$plugin->set_filename("?.func.php", "foo", "strtolower");

// Loads the plugin 
// The filename must be 'plugins/func.bar.php'
$class = $plugin->load("bar", $foo, "foo");

// Try to load again
$newclass = $plugin->load("bar", $foo, "foo");

if($newclass==$class){
	print "Already loaded."; // this will show up
}

// But you can force the script to reload the plugin and replace it 
$newclass = $plugin->load("bar", $foo, "foo", true); 

?>