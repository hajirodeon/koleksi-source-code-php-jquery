<?php

// Test file for phpPlugin

require "plugin.class.php";

// Class that will be extended with plugins.

class foo
{

	var $text;
	
	function foo($str='')
	{
		$this->text = $str;
	}
	
	function display($str)
	{
		echo $str . "<br><br>";
	}

}

echo "<h1>phpPlugin EXAMPLES</h1><hr>";
echo "Filename's standard format is: 'name_of_the_plugin.func.php' = \$plugin->set_filename('?.func.php')<br>";
echo "You can change it at the phpPlugin's code or set your own filename format using set_filename()";

/*****************************
 * 	EXAMPLE 1
 ****************************/

// plugin object that will manage all the plugin requests in this script
$plugin = new phpPlugin('plugins/');

$foo = new foo("baaaaad");

echo "<h3>Starting EXAMPLE 1...</h3>";
echo "Current classname (1): " . get_class($foo) . "<br><br>";
echo "Variable 'text': " . $foo->text . "<br><br>";

echo "Loading plugin 'bar'<br><br>";
$plugin->load("bar", $foo);

echo "Current classname (2): " . get_class($foo) . "<br><br>";

echo "Using plugin 'bar': ";
$foo->bar("example 1");

echo "Using plugin 'bar' with the variable 'text' from the old instance: ";
$foo->bar($foo->text);

echo "Loading plugin 'bar' again<br><br>";
$plugin->load("bar", $foo);

echo "Current classname (3): " . get_class($foo) . "<br>";
echo "If this classname (3) isn't equal than (2), then the ClassName parameter wasn't passed and the plugin was loaded again and replaced.<br>See example 2.<br><br>";

echo "<hr><br>";


/*****************************
 * 	EXAMPLE 2
 ****************************/

$plugin = new phpPlugin('plugins/');

$foo = new foo("goooood");

echo "<h3>Starting EXAMPLE 2...</h3>";
echo "Current classname (1): " . get_class($foo) . "<br><br>";
echo "Variable 'text': " . $foo->text . "<br><br>";

echo "Loading plugin 'bar' passing 'foo' as the classname<br><br>";
$plugin->load("bar", $foo, "foo");

echo "Current classname (2): " . get_class($foo) . "<br><br>";

echo "Using plugin 'bar': ";
$foo->bar("example 2");

echo "Using plugin 'bar' with the variable 'text' from the old instance: ";
$foo->bar($foo->text);

echo "Loading plugin 'bar' again with 'foo' as the classname<br><br>";
$plugin->load("bar", $foo, "foo");

echo "Current classname (3): " . get_class($foo) . "<br>";
echo "Now the plugin wasn't loaded and replaced -> (2) = (3)<br><br>";

echo "<hr><br>";


/*****************************
 * 	EXAMPLE 3
 ****************************/

$plugin = new phpPlugin('plugins/');

$foo = new foo("let's go");

echo "<h3>Starting EXAMPLE 3...</h3>";
echo "Current classname (1): " . get_class($foo) . "<br><br>";
echo "Variable 'text': " . $foo->text . "<br><br>";

echo "Setting the filename to call 'bar.php' instead of 'bar.func.php'<br><br>";
$plugin->set_filename("?.php", "foo", "strtolower");

echo "Loading plugin 'bar' from 'bar.php' passing 'foo' as the classname<br><br>";
$plugin->load("bar", $foo, "foo");

echo "Current classname (2): " . get_class($foo) . "<br><br>";

echo "Using plugin 'bar' from 'bar.php': ";
$foo->bar("example 3");

echo "Forcing the reload of the plugin<br><br>";
$plugin->load("bar", $foo, "foo", true);

echo "Current classname (3): " . get_class($foo) . "<br><br>";

echo "Using plugin 'bar' reloaded from 'bar.php': ";
$foo->bar("example 3 - part 2");

echo "<hr><br>";


/*****************************
 * 	EXAMPLE 4
 ****************************/

// Function that will modify the filename.
// The first parameter has to be the filename.
// All other parameters can be passed as an array starting at the second parameter.

function change_filename($str, $boo){

	if($boo){
		return strtolower($str);
	}

}

$plugin = new phpPlugin('plugins/');

$foo = new foo("let's do it again");

echo "<h3>Starting EXAMPLE 4...</h3>";
echo "Current classname (1): " . get_class($foo) . "<br><br>";
echo "Variable 'text': " . $foo->text . "<br><br>";

echo "Loading plugin 'bar' from 'bar.func.php' passing 'foo' as the classname<br><br>";
$plugin->load("bar", $foo, "foo");

echo "Current classname (2): " . get_class($foo) . "<br><br>";

echo "Using plugin 'bar' from 'bar.func.php': ";
$foo->bar("example 4");

echo "Setting the filename to call 'bar.php' instead of 'bar.func.php', passing 'change_filename' as the modifier function and 'array(true)' as parameter<br><br>";
$plugin->set_filename("?.PHP", "", "change_filename", array(true));

echo "Loading plugin 'bar' from 'bar.php' and forcing a reload because they have the same name<br><br>";
$plugin->load("bar", $foo, "foo", true);

echo "Current classname (3): " . get_class($foo) . "<br><br>";

echo "Using plugin 'bar' from where? ";
$foo->bar("example 4");
echo "From 'bar.php' because the function was replaced.<br><br>";

echo "<hr><br>";


?>