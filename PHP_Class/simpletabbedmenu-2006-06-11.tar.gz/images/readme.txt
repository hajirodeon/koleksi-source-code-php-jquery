Here are the images for tabMenu,
these are transparent images which are given the required color using CSS. 
<vedanta.barooah at gmail dot com>