<?php

/**
 * @author Dick Munroe <munroe@csworks.com>
 * @copyright copyright @ 2006 by Dick Munroe, Cottage Software Works, Inc.
 * @license http://www.csworks.com/publications/ModifiedNetBSD.html
 * @version 1.3.0
 * @package Simple Tab Menu
 * @example ./example.php
 *
 *  A set of classes to build the input data structure for creating a tabbed menu interface.
 *
 * Edit History:
 *
 *  Dick Munroe (munroe@csworks.com) 26-Apr-2006
 *      Initial Version Created.
 *
 *  Dick Munroe (munroe@csworks.com) 01-May-2006
 *      Add mechanism for adding attributes.
 */

/**
 * Each row in the menu consists of one or more items.
 *
 * Each item consists of (at least):
 *
 *  An URL for the anchor
 *  Text displayed for that url
 *  [optional] attributes to be added to the anchor.
 *      Attributes must be a well formatted HTML fragment or an array
 *      of such fragments suitable for inclusion in an HTML anchor
 *      tag.
 *
 *  Parent menu items may optionally have a child menu which is displayed
 *  ONLY when the parent menu is active.
 */

class tabMenuDescription
{
    /**
     * @var mixed The menu data structure to be fed into tabMenuBase.
     * @access private.
     */
    
    var $m_menu ;

    /**
     * @var mixed A data structure for a single item.
     * @access private
     */
    
    var $m_nextMenuItem ;
    
    /**
     * @var string the visible name of the menu item.
     * @access private.
     */
    
    var $m_nextMenuItemIndex ;

    /**
     * @desc Constructor
     * @access public
     */
    
    function tabMenuDescription()
    {
        $this->m_menu = array() ;
        $this->m_nextMenuItem = NULL ;
    }

    /**
     * There is a side effect of closing any currently open row
     * thus flushing it to the menu.
     * 
     * @desc Start a row in a menu
     * @param boolean [OPTIONAL] True to flush any open row contents to the menu, false otherwise, default = TRUE.
     * @access public
     */
    
    function openRow($theCloseIfOpen = TRUE)
    {
        if ($theCloseIfOpen && ($this->m_nextMenuItem !== NULL))
        {
            $this->closeRow() ;
        }

        $this->m_nextMenuItem = array() ;
        $this->m_nextMenuItemIndex = NULL ;
    }

    /**
     * @desc add a new menu item to the currently open menu.
     * @param string the visible anchor for the URL.
     * @param string the URL.
     * @param mixed [OPTIONAL] the child menu associated with this menu item.  May be either a tabMenuDescription object or an array.
     * @access public
     */
    
    function addItem($theAnchor, $theParentLink, $theChildMenu = NULL)
    {
        if ($theChildMenu !== NULL)
        {
            if (is_object($theChildMenu))
            {
                $theChildMenu = $theChildMenu->getMenu() ;
                $theChildMenu = $theChildMenu[0] ;
            }
            else
            {
                $theChildMenu = NULL ;
            }
        }

        $this->m_nextMenuItemIndex = $theAnchor ;
        $this->m_nextMenuItem[$theAnchor][0] = $theParentLink ;
        $this->m_nextMenuItem[$theAnchor][$theAnchor][0] = $theChildMenu ;
    }
    
    /**
     * @desc Add attributes to the individual menu item HTML.
     * @param mixed string or array containing valid html attributes for the anchor.
     * @return void
     * @access public
     */
    
    function addAttributes($theAttributes)
    {
        $this->m_nextMenuItem[$this->m_nextMenuItemIndex][$this->m_nextMenuItemIndex][1] = $theAttributes ;
    }

    /**
     * @desc Flush the current menu row to the accumlated menu data structure.
     * @return void
     * @access public
     */
    
    function closeRow()
    {
        if ($this->m_nextMenuItem !== NULL)
        {
            $this->m_menu[] = $this->m_nextMenuItem ;
            $this->m_nextMenuItem = NULL ;
        }
    }

    /**
     * @desc reset the internal state of the object.
     * @return void
     * @access public
     */
    
    function reset()
    {
        $this->m_menu = array() ;
        $this->m_nextMenuItem = NULL ;
    }

    /**
     * @desc return the contents of the menu data structure.
     * @return mixed
     * @access public
     */
    
    function &getMenu()
    {
        return $this->m_menu ;
    }
}

?>
