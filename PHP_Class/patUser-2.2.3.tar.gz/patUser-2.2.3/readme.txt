patUser - powerful user management class

Copyright (c) 2001,2002,2003 by Stephan Schmidt <schst@php-tools.de> and gERD Schaufelberger <gerd@php-tools.de>
download at http://www.php-tools.net

This program and all associated files are released under the GNU Lesser Public License,
see lgpl.txt for details!