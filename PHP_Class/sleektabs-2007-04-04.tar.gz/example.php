<?php

if (!empty($_GET['page'])) {

	switch ($_GET['page']) {

		case 'tab1':
		?>This is the first tab.<?php
		die();
		break;

		case 'tab2':
		?>This is the second tab.<?php
		die();
		break;


	}

}

require_once('sleektabs.php');
?>
<div id="sleektabs-wrapper"><?php
$tabs[0]['name'] = 'tab1';
$tabs[0]['friendlyname'] = 'Tab 1';
$tabs[0]['ajaxurl'] = './?page=tab1';
$tabs[0]['fallbackurl'] = '#';
$tabs[1]['name'] = 'tab2';
$tabs[1]['friendlyname'] = 'Tab 2';
$tabs[1]['ajaxurl'] = './?page=tab2';
$tabs[1]['fallbackurl'] = '#';

$sltabs = new SleekTabs($tabs, 'tabcontent');
$sltabs->contentDiv = 'sleektabs-content';
$sltabs->makeJavaScript();
$sltabs->makeCSS();
$sltabs->drawTabs('tab1');

?><div id="sleektabs-content">
</div>
</div>