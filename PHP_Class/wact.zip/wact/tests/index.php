<?php
/**
* @version $Id: index.php,v 1.21 2003/12/10 12:43:09 jon-bangoid Exp $
*/

/* wact common */
require_once '../framework/common.inc.php';

require_once 'lib/testmanager.php';
TestManager::setTestPathsFromIniFile('tests.ini');

if ( !defined('SIMPLE_TEST') ) {
    define('SIMPLE_TEST', getConfigOption('tests', 'simpletest', 'library_path'));
}
if (!@include_once SIMPLE_TEST . 'reporter.php') {
    RaiseError('runtime', 'LIBRARY_REQUIRED', array(
        'library' => 'Simple Test',
        'path' => SIMPLE_TEST));
}

if (isset($_GET['group'])) {
    if ('all' == $_GET['group']) {
        TestManager::runAllTests(new HTMLReporter);
    } else {
        TestManager::runGroupTest(ucfirst($_GET['group']),
                                  TEST_GROUPS,
                                  new HTMLReporter());
    }
    echo "<p><a href='" . $_SERVER['PHP_SELF'] . "'>Run more tests</a></p>";
    exit(0);
}

if (isset($_GET['case'])) {
    TestManager::runTestCase($_GET['case'], new HTMLReporter());
    echo "<p><a href='" . $_SERVER['PHP_SELF'] . "?show=cases'>Run more tests</a></p>";
    exit(0);
}

echo "<h1>WACT Unit Test Suite</h1>\n";
echo "<p><a href='" . $_SERVER['PHP_SELF'] . "'>Test groups</a>";
echo " || <a href='" . $_SERVER['PHP_SELF'] . "?show=cases'>Test cases</a></p>";

if (isset($_GET['show']) && $_GET['show'] == 'cases') {
    /* doesn't currently deal with special case adodb.test.ext.php */
    echo HTMLTestManager::getTestCaseList(TEST_CASES);
} else {
    /* no group specified, so list them all */
    echo HTMLTestManager::getGroupTestList(TEST_GROUPS);
} 
?>