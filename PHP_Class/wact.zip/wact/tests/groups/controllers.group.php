<?php
/**
* @package WACT_TESTS
* @version $Id: controllers.group.php,v 1.1 2003/12/08 12:01:32 jon-bangoid Exp $
*/
/**
 * @package WACT_TESTS
 */
class CONTROLLERS_TESTS extends GroupTest {
    function CONTROLLERS_TESTS() {
        $this->GroupTest('Controllers test cases');
        TestManager::addTestCasesFromDirectory($this,
                                               TEST_CASES . '/controllers');
    }
}
?>