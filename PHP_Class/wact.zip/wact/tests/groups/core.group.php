<?php
/**
* @package WACT_TESTS
* @version $Id: core.group.php,v 1.1 2003/12/08 12:01:32 jon-bangoid Exp $
*/
/**
 * @package WACT_TESTS
 */
class CORE_TESTS extends GroupTest {
    function CORE_TESTS() {
        $this->GroupTest('Core test cases');
        $this->addTestFile(TEST_CASES . '/core.test.php');
    }
}
?>