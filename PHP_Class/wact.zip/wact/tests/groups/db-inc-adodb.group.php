<?php
/**
* @package WACT_TESTS
* @version $Id: db-inc-adodb.group.php,v 1.1 2003/12/08 12:01:32 jon-bangoid Exp $
*/
/**
 * @package WACT_TESTS
 */
class DB_TESTS extends GroupTest {
    function DB_TESTS() {
        $this->GroupTest('DB test cases');
        TestManager::addTestCasesFromDirectory($this,
                                               TEST_CASES . '/db');
        $this->addTestFile(TEST_CASES . '/db/drivers/adodb.test.ext.php');
    }
}
?>