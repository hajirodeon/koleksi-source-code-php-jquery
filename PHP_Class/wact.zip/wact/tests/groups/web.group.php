<?php
/**
* @package WACT_TESTS
* @version $Id: web.group.php,v 1.1 2003/12/08 12:01:32 jon-bangoid Exp $
*/
require_once 'cases/web_tests/web.inc.php';
/**
 * @package WACT_TESTS
 */
class WEB_TESTS extends GroupTest {
    function WEB_TESTS() {
        $this->GroupTest('Web Tests');
        TestManager::addTestCasesFromDirectory($this,
                                               TEST_CASES . '/web_tests');
    }
}
?>