<?php
/**
* @package WACT_TESTS
* @version $Id: compiler-inc-web.group.php,v 1.1 2003/12/08 12:01:32 jon-bangoid Exp $
*/
/**
 * @package WACT_TESTS
 */
class COMPILER_INCWEB_TESTS extends GroupTest {
    function COMPILER_INCWEB_TESTS() {
        $this->GroupTest('Compiler test cases');
        TestManager::addTestCasesFromDirectory($this,
                                               TEST_CASES . '/template/compiler');
        $this->addTestFile('cases/web_tests/wacttags.test.php');
        $this->addTestFile('cases/web_tests/badhtml.test.php');
        $this->addTestFile('cases/web_tests/goodhtml.test.php');
    }
}
?>