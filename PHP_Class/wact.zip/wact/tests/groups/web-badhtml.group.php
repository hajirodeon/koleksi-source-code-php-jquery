<?php
/**
* @package WACT_TESTS
* @version $Id: web-badhtml.group.php,v 1.1 2003/12/08 12:01:32 jon-bangoid Exp $
*/
/**
 * @package WACT_TESTS
 */
class WEB_BADHTML_TESTS extends GroupTest {
    function WEB_BADHTML_TESTS() {
        $this->GroupTest('Web (badhtml) tests');
        $this->addTestFile(TEST_CASES . '/web_tests/badhtml.test.php');
    }
}
?>