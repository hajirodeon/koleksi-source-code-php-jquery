<?php
/**
* @package WACT_TESTS
* @version $Id: all-but-web.group.php,v 1.1 2003/12/08 12:01:32 jon-bangoid Exp $
*/
/**
 * @package WACT_TESTS
 */
class ALL_BUT_WEB_TESTS extends GroupTest {
    function ALL_BUT_WEB_TESTS() {
        $this->GroupTest('All but web test cases');
        TestManager::addTestCasesFromDirectory($this,
                                               TEST_CASES . '/controllers');
        TestManager::addTestCasesFromDirectory($this,
                                               TEST_CASES . '/db');
        TestManager::addTestCasesFromDirectory($this,
                                               TEST_CASES . '/request');
        TestManager::addTestCasesFromDirectory($this,
                                               TEST_CASES . '/template/compiler');
        TestManager::addTestCasesFromDirectory($this,
                                               TEST_CASES . '/util');
        TestManager::addTestCasesFromDirectory($this,
                                               TEST_CASES . '/validation');
    }
}
?>