<?php
/**
* @package WACT_TESTS
* @version $Id: all-but-breakage.group.php,v 1.1 2003/12/08 12:01:32 jon-bangoid Exp $
*/
/**
 * @package WACT_TESTS
 */
class ALL_BUT_WEB_TESTS extends GroupTest {
    function ALL_BUT_WEB_TESTS() {
        $this->GroupTest('All but majorly broken/missing lib test cases');
        TestManager::addTestCasesFromDirectory($this,
                                               TEST_CASES . '/controllers');
        $this->addTestFile(TEST_CASES . '/db/drivers/mysql.test.php');
        $this->addTestFile(TEST_CASES . '/db/drivers/peardb.test.php');
        
        TestManager::addTestCasesFromDirectory($this,
                                               TEST_CASES . '/request');
        TestManager::addTestCasesFromDirectory($this,
                                               TEST_CASES . '/template/compiler');
        TestManager::addTestCasesFromDirectory($this,
                                               TEST_CASES . '/util');
        TestManager::addTestCasesFromDirectory($this,
                                               TEST_CASES . '/validation');

        $this->addTestFile(TEST_CASES . '/web_tests/badhtml.test.php');
        $this->addTestFile(TEST_CASES . '/web_tests/errors.test.php');
        $this->addTestFile(TEST_CASES . '/web_tests/goodhtml.test.php');
        $this->addTestFile(TEST_CASES . '/web_tests/wacttags.test.php');
  }
}
?>