<?php
/**
* @package WACT_TESTS
* @version $Id: web-errors.group.php,v 1.1 2003/12/08 12:01:32 jon-bangoid Exp $
*/
/**
 * @package WACT_TESTS
 */
class WEB_ERRORS_TESTS extends GroupTest {
    function WEB_ERRORS_TESTS() {
        $this->GroupTest('Web (errors) tests');
        $this->addTestFile(TEST_CASES . '/web_tests/errors.test.php');
    }
}
?>