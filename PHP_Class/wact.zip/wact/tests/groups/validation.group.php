<?php
/**
* @package WACT_TESTS
* @version $Id: validation.group.php,v 1.1 2003/12/08 12:01:32 jon-bangoid Exp $
*/
/**
 * @package WACT_TESTS
 */
class VALIDATION_TESTS extends GroupTest {
    function VALIDATION_TESTS() {
        $this->GroupTest('Validation Tests');
        TestManager::addTestCasesFromDirectory($this,
                                               TEST_CASES . '/validation/rules');
    }
}
?>