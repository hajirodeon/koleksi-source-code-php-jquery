<?php
/**
* @package WACT_TESTS
* @version $Id: request.group.php,v 1.1 2003/12/08 12:01:32 jon-bangoid Exp $
*/
/**
 * @package WACT_TESTS
 */
class REQUEST_TESTS extends GroupTest {
    function REQUEST_TESTS() {
        $this->GroupTest('Request test cases');
        TestManager::addTestCasesFromDirectory($this,
                                               TEST_CASES . '/request');
    }
}
?>