<?php
/**
* Shared by all db tests
* @package WACT_TESTS
* @version $Id: db.inc.php,v 1.1 2003/12/08 12:11:04 jon-bangoid Exp $
*/
require_once WACT_ROOT.'/common.inc.php';

if (!defined('DATASPACE_LOADED')) {
    require WACT_ROOT . '/util/dataspace.inc.php';
}

require_once WACT_ROOT.'/template/template.inc.php';
require_once WACT_ROOT.'/template/components/pager.inc.php';

require_once TEST_CASES . '/dataspace.inc.php';

define('DBC_HOST', 'localhost');
define('DBC_USER', 'wact');
define('DBC_PASSWORD', 'wacky');
define('DBC_DATABASE', 'wactexamples');

Mock::generate('DataSpace', 'MockDataSpace');
Mock::generate('PageNavigatorComponent', 'MockPager');

if ( !function_exists('MySQL_Setup') ) {
	function MySQL_Setup () {
		// Not pretty but how else?
		if ( !mysql_connect(DBC_HOST,DBC_USER,DBC_PASSWORD) )
			die ('Could not connect: '.mysql_errno().' - '.mysql_error() );
		if ( !mysql_select_db(DBC_DATABASE) )
			die ('Could not connect: '.mysql_errno().' - '.mysql_error() );

		$sql = "CREATE TABLE IF NOT EXISTS founding_fathers (
		  id int(11) NOT NULL auto_increment,
		  first varchar(50) NOT NULL default '',
		  last varchar(50) NOT NULL default '',
		  PRIMARY KEY  (id)
		);";
		if ( !mysql_query($sql) )
			die ('Error creating table: '.mysql_errno().' - '.mysql_error() );

		if ( !mysql_query('TRUNCATE founding_fathers') )
			die ('Error creating table: '.mysql_errno().' - '.mysql_error() );

		$inserts = array(
			"INSERT INTO founding_fathers VALUES (1, 'George', 'Washington');",
			"INSERT INTO founding_fathers VALUES (2, 'Alexander', 'Hamilton');",
			"INSERT INTO founding_fathers VALUES (3, 'Benjamin', 'Franklin');"
		);

		foreach ( $inserts as $insert ) {
			if ( !mysql_query($insert) )
				die ('Error inserting '.mysql_errno().' - '.mysql_error() );
		}
	}
}
?>