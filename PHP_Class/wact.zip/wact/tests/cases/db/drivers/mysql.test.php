<?php
/**
* @package WACT_TESTS
* @version $Id: mysql.test.php,v 1.1 2003/12/08 12:11:04 jon-bangoid Exp $
*/
require_once 'db.inc.php';
require_once WACT_ROOT.'/db/drivers/mysql.inc.php';

/**
* @package WACT_TESTS
*/
class MySQLConnectionTestCase extends UnitTestCase {
	var $connection;
	function MySQLConnectionTestCase($name = 'MySQLConnection test cases') {
		$this->UnitTestCase($name);
	}
	function setUp() {
		MySQL_Setup();
		$this->connection = & new MySQLConnection(DBC_DATABASE,DBC_USER,DBC_PASSWORD,DBC_HOST);
	}
	function testGetConnectionId() {
		$this->assertTrue(is_resource($this->connection->getConnectionId()));
	}
	function testMakeLiteral() {
		$var = "Hello 'World!'";
		$this->assertEqual($this->connection->makeLiteral($var),"'".mysql_escape_string($var)."'");
		$var = 1;
		$this->assertEqual($this->connection->makeLiteral($var),'1');
		$var = NULL;
		$this->assertEqual($this->connection->makeLiteral($var),'NULL');
		$var = false; // strval() converts to upper case
		$this->assertEqual($this->connection->makeLiteral($var),'FALSE');
		$var = "Hello 'World!'";
		$type = 'string';
		$this->assertEqual($this->connection->makeLiteral($var,$type),"'".mysql_escape_string($var)."'");
		$var = 1;
		$type = 'int';
		$this->assertEqual($this->connection->makeLiteral($var,$type),'1');
		$var = NULL;
		$type = 'NULL';
		$this->assertEqual($this->connection->makeLiteral($var,$type),'NULL');
		$var = false; // strval() converts to upper case
		$type = 'boolean';
		$this->assertEqual($this->connection->makeLiteral($var,$type),'FALSE');
	}
	function testFindRecord() {
		$sql = "SELECT * FROM founding_fathers";
		$this->assertIsA($this->connection->findRecord($sql),'MySQLRecord');
	}
	function testGetOneValue() {
		$sql = "SELECT first FROM founding_fathers";
		$this->assertEqual($this->connection->getOneValue($sql),'George');
	}
	function testGetOneColumnArray() {
		$sql = "SELECT first FROM founding_fathers";
		$testarray = array('George','Alexander','Benjamin');
		$this->assertEqual($this->connection->getOneColumnArray($sql),$testarray);
	}
	function testGetTwoColumnArray() {
		$sql = "SELECT id, first FROM founding_fathers";
		$testarray = array(1=>'George',2=>'Alexander',3=>'Benjamin');
		$this->assertEqual($this->connection->getTwoColumnArray($sql),$testarray);
	}
	function testExecute() {
		$sql = "SELECT * FROM founding_fathers";
		$this->assertTrue(is_resource($this->connection->execute($sql)));
	}
}

/**
* @package WACT_TESTS
*/
class MySQLRecordTestCase extends SharedDataSpaceTestCase {
	function MySQLRecordTestCase($name = 'MySQLRecord test cases') {
		$this->SharedDataSpaceTestCase($name);
	}
	function setUp() {
		MySQL_Setup();
		$connection = & new MySQLConnection(DBC_DATABASE,DBC_USER,DBC_PASSWORD,DBC_HOST);
		$this->dataspace = new MySQLRecord($connection);
	}
	function testExecute() {
		$sql = "SELECT * FROM founding_fathers";
		$this->assertTrue(is_resource($this->dataspace->execute($sql)));
	}
	function testInsert() {
		if ( !mysql_query('TRUNCATE founding_fathers') )
			die ('Error creating table: '.mysql_errno().' - '.mysql_error() );
		$record = array ('id'=>4,'first'=>'Richard','last'=>'Nixon');
		$this->dataspace->import($record);
		$fields = array ('id','first','last');
		$this->assertTrue($this->dataspace->insert('founding_fathers',$fields));
	}
	function testInsertId() {
		if ( !mysql_query('TRUNCATE founding_fathers') )
			die ('Error creating table: '.mysql_errno().' - '.mysql_error() );
		$record = array ('id'=>4,'first'=>'Richard','last'=>'Nixon');
		$this->dataspace->import($record);
		$fields = array ('id','first','last');
		$this->assertEqual($this->dataspace->insert('founding_fathers',$fields,true),4);
	}
	function testInsertSelectBack() {
		if ( !mysql_query('TRUNCATE founding_fathers') )
			die ('Error creating table: '.mysql_errno().' - '.mysql_error() );
		$record = array ('id'=>4,'first'=>'Richard','last'=>'Nixon');
		$this->dataspace->import($record);
		$fields = array ('id','first','last');
		$this->dataspace->insert('founding_fathers',$fields);
		$this->assertTrue(is_resource($this->dataspace->execute('SELECT * FROM founding_fathers WHERE id=\'4\'')));
	}
	function testUpdate() {
		$record = array ('first'=>'Richard','last'=>'Nixon');
		$this->dataspace->import($record);
		$fields = array ('first','last');
		$this->assertTrue($this->dataspace->update('founding_fathers',$fields,"id='3'"));
	}
	function testUpdateSelectBack() {
		$record = array ('first'=>'Richard','last'=>'Nixon');
		$this->dataspace->import($record);
		$fields = array ('first','last');
		$this->dataspace->update('founding_fathers',$fields,"id='3'");
		$this->assertTrue(is_resource($this->dataspace->execute('SELECT * FROM founding_fathers WHERE id=\'3\' and first=\'Richard\'')));
	}
	function testAffectedRowCout() {
		$record = array ('first'=>'Richard','last'=>'Nixon');
		$this->dataspace->import($record);
		$fields = array ('first','last');
		$this->dataspace->update('founding_fathers',$fields);
		$this->assertEqual($this->dataspace->getAffectedRowCount(),3);
	}
}

/**
* @package WACT_TESTS
*/
class MySQLRecordSetTestCase extends SharedDataSpaceTestCase {
	function MySQLRecordSetTestCase($name = 'MySQLRecordSet test cases') {
		$this->SharedDataSpaceTestCase($name);
	}
	function setUp() {
		MySQL_Setup();
		$connection = & new MySQLConnection(DBC_DATABASE,DBC_USER,DBC_PASSWORD,DBC_HOST);
		$sql = "SELECT id, first FROM founding_fathers";
		$this->dataspace = new MySQLRecordSet($connection,$sql);
	}
	/**
	* Override parent test as method not implemented in MySQL driver
	*/
	function testfilter() {}

	function testPaginate() {
		$mockPager = & new MockPager($this);
		$mockPager->expectCallCount('setPagedDataSet',1);
		$this->dataspace->paginate($mockPager);
	}

	function testReset() {
		$this->assertTrue($this->dataspace->reset());
	}

	function testIteration() {
		$this->dataspace->reset();
		$i = 0;
		do {
			$i++;
		} while ( $this->dataspace->next() );
		$this->assertEqual(4,$i);
	}

	function testPagerIteration() {
		$mockPager = & new MockPager($this);
		$mockPager->expectCallCount('getStartingItem',1);
		$mockPager->expectCallCount('getItemsPerPage',1);
		$mockPager->setReturnValue('getStartingItem',0);
		$mockPager->setReturnValue('getItemsPerPage',2);
		$this->dataspace->paginate($mockPager);
		$this->dataspace->reset();
		$i = 0;
		do {
			$i++;
		} while ( $this->dataspace->next() );
		$this->assertEqual(3,$i);
	}

	function testGetRowCount() {
		$this->dataspace->prepare();
		$this->assertEqual($this->dataspace->getRowCount(),3);
	}

	function testGetTotalRowCount() {
		$this->assertEqual($this->dataspace->getTotalRowCount(),3);
	}
}
?>