<?php
/**
* @package WACT_TESTS
* @version $Id: emptydataset.test.php,v 1.1 2003/12/08 12:11:05 jon-bangoid Exp $
*/
require_once WACT_ROOT.'/util/arraydataset.inc.php';
require_once WACT_ROOT.'/util/emptydataset.inc.php';

require_once TEST_CASES.'/dataspace.inc.php';

/**
* @package WACT_TESTS
*/
class EmptyDataSetTestCase extends UnitTestCase {
	function EmptyDataSetTestCase($name = 'EmptyDataSetTestCase') {
		$this->UnitTestCase($name);
	}
	function setUp() {
		$this->dataspace = new EmptyDataSet();
	}
	function tearDown() {
		unset ( $this->dataspace );
	}
	function testListRecordSetIteration() {
		$this->dataspace->reset();
		if ( $this->dataspace->next() ) {
			do {
				$out_array[] = $this->dataspace->get('a');
			} while ( $this->dataspace->next() );
		}
		$test_array=array();
		$this->assertIdentical($this->dataspace->next(),false);
	}
	function testGetUnsetVariable() {
		$this->assertIdentical($this->dataspace->get('foo'),'');
	}
	function testGetSetVariable() {
		$this->dataspace->set('foo','bar');
		$this->assertIdentical($this->dataspace->get('foo'),'');
	}
	function testGetSetArray() {
		$array = array('red','blue','green' );
		$this->dataspace->set('foo',$array);
		$this->assertIdentical($this->dataspace->get('foo'),'');
	}
	function testGetSetObject() {
		$foo = new NullClass();
		$foo->colors = array('red','blue','green' );
		$this->dataspace->set('foo',$foo);
		$this->assertIdentical($this->dataspace->get('foo'),'');
	}
	function testGetSetAppend() {
		$first = 'Hello';
		$second = 'World!';
		$this->dataspace->set('foo',$first);
		$this->dataspace->append('foo',$second);
		$this->assertIdentical($this->dataspace->get('foo'),'');
	}
	function testGetSetAppendMixedType() {
		$first = 'Hello';
		$second = 2;
		$this->dataspace->set('foo',$first);
		$this->dataspace->append('foo',$second);
		$this->assertIdentical($this->dataspace->get('foo'),'');
	}
	function testExportEmpty() {
		$foo = array();
		$this->assertIdentical($this->dataspace->export(),$foo);
	}
}
?>