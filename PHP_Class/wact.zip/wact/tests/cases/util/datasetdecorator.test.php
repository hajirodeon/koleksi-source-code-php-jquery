<?php
/**
* @package WACT_TESTS
* @version $Id: datasetdecorator.test.php,v 1.1 2003/12/08 12:11:05 jon-bangoid Exp $
*/
require_once WACT_ROOT.'/util/emptydataset.inc.php';
require_once WACT_ROOT.'/util/datasetdecorator.inc.php';

Mock::generate('EmptyDataSet','MockDataSet');

/**
* @package WACT_TESTS
*/
class DataSetDecoratorTestCase extends UnitTestCase {
	function DataSetDecoratorTestCase($name = 'DataSetDecoratorTestCase') {
		$this->UnitTestCase($name);
	}
	function setUp() {
	}
	function tearDown() {
	}
	function testReset() {
		$mockDataSet = & new MockDataSet($this);
		$mockDataSet->setReturnValue('reset',NULL);
		$mockDataSet->expectOnce('reset');
		$dataSetDecorator= & new DataSetDecorator($mockDataSet);
		$this->assertNull($dataSetDecorator->reset());
		$mockDataSet->tally();
	}

	function testNext() {
		$mockDataSet = & new MockDataSet($this);
		$mockDataSet->setReturnValue('next',false);
		$mockDataSet->expectOnce('next');
		$dataSetDecorator= & new DataSetDecorator($mockDataSet);
		$this->assertFalse($dataSetDecorator->next());
		$mockDataSet->tally();
	}
	function testGet() {
		$mockDataSet = & new MockDataSet($this);
		$mockDataSet->setReturnValue('get','testing');
		$mockDataSet->expectOnce('get',array('test'));
		$dataSetDecorator= & new DataSetDecorator($mockDataSet);
		$this->assertEqual($dataSetDecorator->get('test'),'testing');
		$mockDataSet->tally();
	}
	function testSet() {
		$mockDataSet = & new MockDataSet($this);
		$mockDataSet->setReturnValue('set',NULL);
		$mockDataSet->expectOnce('set',array('test','testing'));
		$dataSetDecorator= & new DataSetDecorator($mockDataSet);
		$this->assertNull($dataSetDecorator->set('test','testing'));
		$mockDataSet->tally();
	}
	function testAppend() {
		$mockDataSet = & new MockDataSet($this);
		$mockDataSet->setReturnValue('append',NULL);
		$mockDataSet->expectOnce('append',array('test','testing'));
		$dataSetDecorator= & new DataSetDecorator($mockDataSet);
		$this->assertNull($dataSetDecorator->append('test','testing'));
		$mockDataSet->tally();
	}
	function testImport() {
		$mockDataSet = & new MockDataSet($this);
		$mockDataSet->setReturnValue('import',NULL);
		$mockDataSet->expectOnce('import',array(array(1,2,3)));
		$dataSetDecorator= & new DataSetDecorator($mockDataSet);
		$array = array(1,2,3);
		$this->assertNull($dataSetDecorator->import($array));
		$mockDataSet->tally();
	}
	function testImportAppend() {
		$mockDataSet = & new MockDataSet($this);
		$mockDataSet->setReturnValue('importAppend',NULL);
		$mockDataSet->expectOnce('importAppend',array(array(1,2,3)));
		$dataSetDecorator= & new DataSetDecorator($mockDataSet);
		$array = array(1,2,3);
		$this->assertNull($dataSetDecorator->importAppend($array));
		$mockDataSet->tally();
	}
	function testExport() {
		$mockDataSet = & new MockDataSet($this);
		$mockDataSet->setReturnValue('export',array(1,2,3));
		$mockDataSet->expectCallCount('export',1);
		$dataSetDecorator= & new DataSetDecorator($mockDataSet);
		$array = array(1,2,3);
		$this->assertEqual($dataSetDecorator->export(),$array);
		$mockDataSet->tally();
	}
	function testRegisterFilter() {
		$mockDataSet = & new MockDataSet($this);
		$mockDataSet->setReturnValue('registerFilter',NULL);
		$mockDataSet->expectOnce('registerFilter',array('test'));
		$dataSetDecorator= & new DataSetDecorator($mockDataSet);
		$test = 'test'; // This should really be an object but will suffice
		$this->assertNull($dataSetDecorator->registerFilter($test));
		$mockDataSet->tally();
	}
	function testPrepare() {
		$mockDataSet = & new MockDataSet($this);
		$mockDataSet->setReturnValue('prepare',NULL);
		$mockDataSet->expectOnce('prepare');
		$dataSetDecorator= & new DataSetDecorator($mockDataSet);
		$this->assertNull($dataSetDecorator->prepare());
		$mockDataSet->tally();
	}
}
?>