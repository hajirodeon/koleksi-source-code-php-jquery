<?php
/**
* @package WACT_TESTS
* @version $Id: dataspace.test.php,v 1.1 2003/12/08 12:11:05 jon-bangoid Exp $
*/
require_once TEST_CASES . '/dataspace.inc.php';

/**
* Cases for dataspace are defined in shared cases/dataspace.inc.php
* @package WACT_TESTS
*/
class DataSpaceTestCase extends SharedDataSpaceTestCase {
    function DataSpaceTestCase($name = 'DataSpace test cases') {
        $this->SharedDataSpaceTestCase($name);
    }
}
?>