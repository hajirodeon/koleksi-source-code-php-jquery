<?php
/**
* @package WACT_TESTS
* @version $Id: arraydataset.test.php,v 1.1 2003/12/08 12:11:05 jon-bangoid Exp $
*/
require_once WACT_ROOT.'/util/arraydataset.inc.php';
require_once WACT_ROOT.'/util/emptydataset.inc.php';

require_once TEST_CASES . '/dataspace.inc.php';

/**
* @package WACT_TESTS
*/
class ArrayDataSetTestCase extends SharedDataSpaceTestCase {
    function ArrayDataSetTestCase($name = 'ArrayDataSetTestCase') {
        $this->UnitTestCase($name);
    }
    function setUp() {
        $array = array(
            array('a'=>'small','b'=>'medium','c'=>'large'),
            array('a'=>'red','b'=>'green','c'=>'blue'));
        $this->dataspace = new ArrayDataSet($array);
    }
    function tearDown() {
        unset ( $this->dataspace );
    }
    function testListDataSetIteration() {
        $out_array = array();
        $this->dataspace->prepare();
        while ($this->dataspace->next()) {
            $out_array[] = $this->dataspace->get('a');
        }
        $test_array=array('small','red');
        $this->assertIdentical($test_array,$out_array);
    }
    function testSet() {
        $this->dataspace->set('a', 'tiny');
        $this->assertIdentical($this->dataspace->get('a'), 'tiny');
    }
    function testImport() {
        $array = array('a' => 'fast', 'b' => 'slow');
        $this->dataspace->import($array);
        $this->assertIdentical($this->dataspace->get('a'), 'fast');
        $this->assertIdentical($this->dataspace->get('b'), 'slow');
        $this->assertNull($this->dataspace->get('c'));
        $array = array('cow' => 'not a dog');
        $this->dataspace->import($array);
        $this->assertIdentical($this->dataspace->row, $array);
    }
    function testImportAppend() {
        $array = array('a' => 'fast', 'd' => 'faster');
        $this->dataspace->importAppend($array);
        $this->assertIdentical($this->dataspace->get('a'), 'fast');
        $this->assertIdentical($this->dataspace->get('b'), 'medium');
        $this->assertIdentical($this->dataspace->get('c'), 'large');
        $this->assertIdentical($this->dataspace->get('d'), 'faster');
    }        
    function testAppend() {
        $this->dataspace->append('a', ' car');
        $this->assertIdentical($this->dataspace->get('a'), 'small car');
    }
    function testAddRow() {
        $row = array('a'=>'1','b'=>'2','c'=>'3');
        $this->dataspace->addRow($row);
        $this->dataspace->reset();
        $i = 0;
        if ( $this->dataspace->next() ) {
            do {
                if ( $i == 2 ) {
                    $this->assertIdentical($row, $this->dataspace->export());
                }
                $i++;
            } while ( $this->dataspace->next() );
        }
    }
    function testSetDataSet() {
        $dataset = array (
            array('x'=>1,'y'=>2),
            array('x'=>3,'y'=>4),
            array('x'=>5,'y'=>6),
            );

        $row = array('x'=>1,'y'=>2);
        $this->dataspace->setDataSet($dataset);
        $this->assertIdentical($row, $this->dataspace->export());
        $this->assertIdentical($dataset, $this->dataspace->getDataSet());
    }
    function testIsEmpty() {
        $this->assertFalse($this->dataspace->isEmpty());
    }
    function testExportEmpty() {
        $foo = array();
        $this->dataspace->import($foo);
        $this->assertIdentical($this->dataspace->export(), $foo);
    }
    function testExport() {
        $this->dataspace->import(array());
        $this->dataspace->set('foo','bar');
        $expected = array('foo'=>'bar');
        $this->assertIdentical($this->dataspace->export(),$expected);
    }
    function testFilter() {
        $out_array = array();
        $filter =& new MockFilter($this);
        $filter->expectArgumentsAt(0, 'doFilter',
                                   array(array('a'=>'small','b'=>'medium','c'=>'large')));
        $filter->expectArgumentsAt(1, 'doFilter',
                                   array(array('a'=>'red','b'=>'green','c'=>'blue')));
        $filter->expectCallCount('doFilter', 2);
        $this->dataspace->registerFilter($filter);
        while ($this->dataspace->next()) {
        }
        $filter->tally();
    }
}
?>