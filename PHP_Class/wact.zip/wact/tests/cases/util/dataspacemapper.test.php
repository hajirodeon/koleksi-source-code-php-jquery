<?php
/**
* @package WACT_TESTS
* @version $Id: dataspacemapper.test.php,v 1.1 2003/12/08 12:11:05 jon-bangoid Exp $
*/
require_once WACT_ROOT.'/util/dataspacemapper.inc.php';

if ( !class_exists('TestDataSpaceMapper') ) {
    // Not the best practice but solves issues where getConfigOption is redeclared
    /**
    * @package WACT_TESTS
    */
    class TestDataSpaceMapper extends DataSpaceMapper {
        function TestDataSpaceMapper () {
            $this->map = array('one'=>'red','two'=>'blue');
        }
    }
}

/**
* @package WACT_TESTS
*/
class DataSpaceMapperTestCase extends UnitTestCase {
	function DataSpaceMapperTestCase($name = 'DataSpaceMapperTestCase') {
		$this->UnitTestCase($name);
	}
	function setUp() {
	}
	function tearDown() {
	}
	function testDoFilter() {
        $vars = array('red'=>1,'blue'=>2,'green'=>3 );
        $testvars = array('one'=>1,'two'=>2,'green'=>3,'red'=>NULL,'blue'=>NULL);
        $tdsm = new TestDataSpaceMapper();
        $tdsm->doFilter($vars);
        $this->assertEqual($vars,$testvars);
	}

}
?>