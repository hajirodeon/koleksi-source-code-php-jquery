<?php
/**
 * @package WACT_TESTS
 * @version $Id: formcontroller.test.php,v 1.1 2003/12/08 12:11:04 jon-bangoid Exp $
 */
require_once WACT_ROOT.'/controllers/formcontroller.inc.php';

require_once WACT_ROOT . '/template/template.inc.php';
Mock::generate('Template', 'BasicMockTemplate');
class MockTemplate extends BasicMockTemplate {
    function &findChildByClass($string) {
        return $this;
    }
    function setErrors($errorlist) {}
}

require_once WACT_ROOT . '/validation/validator.inc.php';
Mock::generate('Validator', 'BasicMockValidator');
class MockValidator extends BasicMockValidator {
    var $returnValue = TRUE;
    var $rules = array();

    function validate(&$DataSpace) {}
    function IsValid() {
        return $this->returnValue;
    }
    function getErrorList() {
        return 'foo';
    }
}

class MockFormController extends FormController {
    var $DataSpace;
    var $IsFirstTimeReturnValue = TRUE;

    var $runInitializeController = FALSE;
    var $runInitializeActions = FALSE;
    var $runInitializeValidator = FALSE;
    var $runIsFirstTime = FALSE;
    var $runInitializeDataSpace = FALSE;
    var $runSetDataSpace = FALSE;
    /* int so we can check how many times validate() is called */
    var $runValidate = 0;
    var $runPerformAction = FALSE;
    var $runOnPreview = FALSE;
    var $runDisplayFormView = FALSE;

    function resetRunVars() {
        $this->runInitializeController = FALSE;
        $this->runInitializeActions = FALSE;
        $this->runInitializeValidator = FALSE;
        $this->runIsFirstTime = FALSE;
        $this->runInitializeDataSpace = FALSE;
        $this->runSetDataSpace = FALSE;
        $this->runValidate = 0;
        $this->runPerformAction = FALSE;
        $this->runOnPreview = FALSE;
        $this->runDisplayFormView = FALSE;
    }

    function MockFormController() {
        $this->DataSpace =& new DataSpace();
        $this->Validator =& new MockValidator($this);
        $this->CurrentAction =& new MockAction($this);
        $this->CurrentActionCondition = PRE_VALID;
    }

    function setDataSpace() { $this->runSetDataSpace = TRUE; }
    function IsFirstTime() {
        $this->runIsFirstTime = TRUE;
        return $this->IsFirstTimeReturnValue;
    }
    function initializeController() { $this->runInitializeController = TRUE; }
    function initializeActions() { $this->runInitializeActions = TRUE; }
    function initializeDataSpace() { $this->runInitializeDataSpace = TRUE; }
    function initializeView() {
        $this->View =& new MockTemplate($this);
        $this->runInitializeView = TRUE;
    }
    function initializeValidator() { $this->runInitializeValidator = TRUE; }
    function onPreview() { $this->runOnPreview = TRUE; }
    function validate() {
        parent::validate();
        $this->runValidate++;
    }
    function performAction() {
        parent::performAction();
        $this->runPerformAction = TRUE;
    }
    function displayFormView() {
        parent::displayFormView();
        $this->runDisplayFormView = TRUE;
    }
}

Mock::generate('NoAction', 'BasicNoAction');
class MockAction extends BasicNoAction {
    function MockAction() {}
 	function performAction(&$context) {
        return FORM_COMPLETE;
	}
}

/**
 * @package WACT_TESTS
 */
class FormControllerTestCase extends UnitTestCase {

    var $formcontroller;

    function FormControllerTestCase($name = 'FormControllerTestCase') {
        $this->UnitTestCase($name);
    }

    function setUp() {
        $this->formcontroller =& new MockFormController();
    }

    function testComplete() {
        $this->assertIdentical($this->formcontroller->FormState, FORM_ACTIVE);
        $this->formcontroller->complete();
        $this->assertIdentical($this->formcontroller->FormState, FORM_COMPLETE);
    }

    function testGetDataSpace() {
        $this->assertIsA($this->formcontroller->getDataSpace(), 'DataSpace');
    }

    function testGetView() {
        $this->assertIsA($this->formcontroller->getView(), 'MockTemplate');
    }

    function testValidate() {
        $this->formcontroller->validate();
        $this->assertTrue($this->formcontroller->Valid);

        $this->Validated = FALSE;
        $this->formcontroller->Validator->returnValue = FALSE;
        $this->formcontroller->validate();
        $this->assertFalse($this->formcontroller->Valid);
    }

    function testIsValid() {
        $this->assertFalse($this->formcontroller->IsValid());
    }

    function testPerformAction() {
        $this->formcontroller->performAction();
        $this->assertIdentical($this->formcontroller->FormState, FORM_ACTIVE);

        $this->formcontroller->CurrentActionCondition = PRE_NONE;
        $this->Validated = FALSE;
        $this->formcontroller->performAction();
        $this->assertIdentical($this->formcontroller->FormState, FORM_COMPLETE);
    }

    function testDisplayFormView() {
        /* no clue how to test this */
        $this->assertNull($this->formcontroller->displayFormView());
    }

    function runCommonTests() {
        $this->assertTrue($this->formcontroller->runInitializeController);
        $this->assertTrue($this->formcontroller->runInitializeActions);
        $this->assertTrue($this->formcontroller->runInitializeValidator);
    }

    function testRun() {
        $this->formcontroller->run();
        $this->runCommonTests();
        $this->assertTrue($this->formcontroller->runInitializeDataSpace);
        $this->assertTrue($this->formcontroller->runDisplayFormView);

        $this->formcontroller->resetRunVars();
        $this->formcontroller->IsFirstTimeReturnValue = FALSE;
        $this->Validated = FALSE;
        $this->formcontroller->Validator->returnValue = FALSE;
        $this->assertFalse($this->formcontroller->IsValid());
        $this->formcontroller->run();
        $this->runCommonTests();
        $this->assertTrue($this->formcontroller->runSetDataSpace);
        /* check that validate() only gets called once */
        $this->assertIdentical($this->formcontroller->runValidate, 1);
        $this->assertTrue($this->formcontroller->runPerformAction);
        $this->assertTrue($this->formcontroller->runOnPreview);
        $this->assertTrue($this->formcontroller->runDisplayFormView);
    }
}

class PostFormControllerTestCase extends UnitTestCase {
    function PostFormControllerTestCase($name = 'PostFormControllerTestCase') {
        $this->UnitTestCase($name);
    }
    function setUp() {
        $this->formcontroller =& new PostFormController();
    }
    
    function testRegisterSubmitAction() {
        $_POST['foo'] = 'bar';
        $this->formcontroller->registerSubmitAction('foo', 'NoAction');
        $this->assertIsA($this->formcontroller->CurrentAction, 'NoAction');
        $this->assertIdentical($this->formcontroller->CurrentActionCondition, PRE_NONE);
        $_POST['bar'] = 'foo';
        $this->formcontroller->registerSubmitAction('foo', 'NoAction', PRE_VALID);
        $this->assertIsA($this->formcontroller->CurrentAction, 'NoAction');
        $this->assertIdentical($this->formcontroller->CurrentActionCondition, PRE_VALID);
    }

    function testRegisterDefaultSubmitAction() {
        $this->formcontroller->registerDefaultSubmitAction('NoAction');
        $this->assertIdentical($this->formcontroller->DefaultAction, 'NoAction');
        $this->assertIdentical($this->formcontroller->DefaultActionCondition, PRE_NONE);
        $this->formcontroller->registerDefaultSubmitAction('NoAction', PRE_VALID);
        $this->assertIdentical($this->formcontroller->DefaultAction, 'NoAction');
        $this->assertIdentical($this->formcontroller->DefaultActionCondition, PRE_VALID);
    }

    function testSetDataSpace() {
        $_POST['foo'] = 'bar';
        $_FILES['bar'] = 'foo';
        $this->formcontroller->setDataSpace();
        $this->assertIsA($this->formcontroller->DataSpace, 'PostDataSpace');
        $this->assertIdentical($this->formcontroller->DataSpace->get('foo'), 'bar');
        $this->assertIdentical($this->formcontroller->DataSpace->get('bar'), 'foo');
    }

    function testIsFirstTime() {
        $_SERVER['REQUEST_METHOD'] = 'GET';
        $this->assertTrue($this->formcontroller->IsFirstTime());
        $_SERVER['REQUEST_METHOD'] = 'POST';
        $this->assertFalse($this->formcontroller->IsFirstTime());
    }

    function testPerformAction() {
       $this->formcontroller->registerDefaultSubmitAction('MockAction');
       $this->formcontroller->performAction();
       $this->assertIsA($this->formcontroller->CurrentAction, 'MockAction');
       $this->assertIdentical($this->formcontroller->CurrentActionCondition, PRE_NONE);
       $this->assertIdentical($this->formcontroller->FormState, FORM_COMPLETE);
    }
}
?>