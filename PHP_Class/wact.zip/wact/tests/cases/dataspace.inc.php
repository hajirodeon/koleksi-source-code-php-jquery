<?php
/**
* @package WACT_TESTS
* @version $Id: dataspace.inc.php,v 1.1 2003/12/08 12:06:52 jon-bangoid Exp $
*/

if (!defined('DATASPACE_LOADED')) {
    require WACT_ROOT . '/util/dataspace.inc.php';
}

/**
* @package WACT_TESTS
*/
class Filter {
    function doFilter($vars){
    }
}
/**
* @package WACT_TESTS
*/
class NullClass {}
Mock::generate('Filter', 'MockFilter');

SimpleTestOptions::ignore('SharedDataSpaceTestCase');
/**
* Shared tests for all classes implementing the DataSpace interface.
* @package WACT_TESTS
*/
class SharedDataSpaceTestCase extends UnitTestCase {
    var $dataspace;
    var $filter;
    function DataSpaceTestCase($name = 'DataSpaceTestCase') {
        $this->UnitTestCase($name);
    }
    function setUp() {
        $this->dataspace = new DataSpace();
    }
    function tearDown() {
        unset ( $this->dataspace );
    }
    function testGetUnsetVariable() {
        $this->assertNull($this->dataspace->get('foo'));
    }
    function testGetSetVariable() {
        $this->dataspace->set('foo','bar');
        $this->assertIdentical($this->dataspace->get('foo'),'bar');
    }
    function testGetSetArray() {
        $array = array('red','blue','green' );
        $this->dataspace->set('foo',$array);
        $this->assertIdentical($this->dataspace->get('foo'),$array);
    }
    function testGetSetObject() {
        $foo = new NullClass();
        $foo->colors = array('red','blue','green' );
        $this->dataspace->set('foo',$foo);
        $this->assertIdentical($this->dataspace->get('foo'),$foo);
    }
    function testGetSetAppend() {
        $first = 'Hello';
        $second = 'World!';
        $this->dataspace->set('foo',$first);
        $this->dataspace->append('foo',$second);
        $this->assertIdentical($this->dataspace->get('foo'),$first.$second);
    }
    function testGetSetAppendMixedType() {
        $first = 'Hello';
        $second = 2;
        $this->dataspace->set('foo',$first);
        $this->dataspace->append('foo',$second);
        $this->assertIdentical($this->dataspace->get('foo'),$first.$second);
    }
    function testExportEmpty() {
        $foo = array();
        $this->assertIdentical($this->dataspace->export(),$foo);
    }
    function testExport() {
        $this->dataspace->set('foo','bar');
        $expected = array('foo'=>'bar');
        $this->assertIdentical($this->dataspace->export(),$expected);
    }
    function testExportImport() {
        $numbers = array(1,2,3);
        $foo = array('size' => 'big','color'=>'red','numbers'=> $numbers);
        $this->dataspace->import($foo);
        $exported = $this->dataspace->export();
        $this->assertIdentical($exported['size'], 'big');
        $this->assertIdentical($exported['color'], 'red');
        $this->assertIdentical($exported['numbers'], $numbers);
    }
    function testExportImportAppend() {
        $numbers = array(1,2,3);
        $foo = array('numbers'=> $numbers);
        $bar = array('size' => 'big','color'=>'red');
        $this->dataspace->import($foo);
        $this->dataspace->importAppend($bar);
        $exported = $this->dataspace->export();
        $this->assertIdentical($exported['size'], 'big');
        $this->assertIdentical($exported['color'], 'red');
        $this->assertIdentical($exported['numbers'], $numbers);
    }
    function testDuplicateImportAppend() {
        // experimental test case.  Should this be the proper behavior of importAppend
        // instead of what it does now?
        // I think so, why would you want to keep the original value rather than
        // using the new one? (Jon)
        $foo = array('foo' => 'kung');
        $this->dataspace->set('foo','bar');
        $this->dataspace->importAppend($foo);
        $expected = $this->dataspace->export();
        $this->assertIdentical($expected['foo'], 'kung');
    }
    function testFilter() {
        $array = array('color' => 'red');
        $filter = &new MockFilter($this);
        $filter->expectArguments('doFilter', array($array));
        $filter->expectCallCount('doFilter',1);
        $this->dataspace->import($array);
        $this->dataspace->registerFilter($filter);
        $this->dataspace->prepare();
        $filter->tally();
    }
}
?>