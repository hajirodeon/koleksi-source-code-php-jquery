<?php
require_once 'common.inc.php';
$Page =& new Template('/xmlescapes.html');
$Page->display();
?>
