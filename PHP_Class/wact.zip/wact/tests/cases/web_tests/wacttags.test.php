<?php
/**
 * @package WACT_TESTS
 * @version $Id: wacttags.test.php,v 1.1 2003/12/08 12:12:49 jon-bangoid Exp $
 */
require_once 'web.inc.php';

/**
 * @package WACT_TESTS
 */
class TagsTestCase extends WACTWebTestCase {
    function TagsTestCase($name = 'TagsTestCase') {
        $this->WACTWebTestCase($name);
    }

    function testCompileAll() {
        $this->get(WACT_EXAMPLES_HTTP_PATH . '/tags/compileall.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/tags/expected_output/compileall.html'));
    }
    function testNoTags() {
        $this->get(WACT_EXAMPLES_HTTP_PATH . '/tags/notags.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/tags/expected_output/notags.html'));
    }
    function testVarRef() {
        $this->get(WACT_EXAMPLES_HTTP_PATH . '/tags/varref.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/tags/expected_output/varref.html'));
    }
    function testBlock() {
        $this->get(WACT_EXAMPLES_HTTP_PATH . '/tags/block.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/tags/expected_output/block.html'));
    }
    function testDataSpace() {
        $this->get(WACT_EXAMPLES_HTTP_PATH . '/tags/dataspace.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/tags/expected_output/dataspace.html'));
    }
    function testImport() {
        $this->get(WACT_EXAMPLES_HTTP_PATH . '/tags/import.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/tags/expected_output/import.html'));
    }
    function testInclude() {
        $this->get(WACT_EXAMPLES_HTTP_PATH . '/tags/include.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/tags/expected_output/include.html'));
    }
    function testLiteral() {
        $this->get(WACT_EXAMPLES_HTTP_PATH . '/tags/literal.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/tags/expected_output/literal.html'));
    }

    function testSet() {
        $this->get(WACT_EXAMPLES_HTTP_PATH . '/tags/set.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/tags/expected_output/set.html'));
    }
    function testWrap() {
        $this->get(WACT_EXAMPLES_HTTP_PATH . '/tags/wrap.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/tags/expected_output/wrap.html'));
    }
    function testList() {
        $this->get(WACT_EXAMPLES_HTTP_PATH . '/tags/list.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/tags/expected_output/list.html'));
    }

    /* form tags */
    function testButton() {
        $this->get(WACT_EXAMPLES_HTTP_PATH . '/tags/button.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/tags/expected_output/button.1.html'));
        $post = array('Text' => 'test',
                      'upper' => 'arbitrary?');
        $this->post(WACT_EXAMPLES_HTTP_PATH . '/tags/button.php', $post);
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/tags/expected_output/button.2.html'));
        $post = array('Text' => 'TEST',
                      'lower' => 'arbitrary?');
        $this->post(WACT_EXAMPLES_HTTP_PATH . '/tags/button.php', $post);
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/tags/expected_output/button.3.html'));
    }
    function testErrorSummary() {
        $this->get(WACT_EXAMPLES_HTTP_PATH . '/tags/errorsummary.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/tags/expected_output/errorsummary.1.html'));
        $post = array('FirstName' => '',
                      'LastName' => '',
                      'submit' => 'Add Contact');
        $this->post(WACT_EXAMPLES_HTTP_PATH . '/tags/errorsummary.php', $post);
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/tags/expected_output/errorsummary.2.html'));
        $post['FirstName'] = 'Jon';
        $this->post(WACT_EXAMPLES_HTTP_PATH . '/tags/errorsummary.php', $post);
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/tags/expected_output/errorsummary.3.html'));
        $post['LastName'] = 'Ramsey';
        $this->post(WACT_EXAMPLES_HTTP_PATH . '/tags/errorsummary.php', $post);
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/tags/expected_output/errorsummary.4.html'));
    }
    function testInput() {
        $this->get(WACT_EXAMPLES_HTTP_PATH . '/tags/input.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/tags/expected_output/input.1.html'));
/*         $post = array('username' => '', */
/*                       'password' => '', */
/*                       'passwordconfirm' => '', */
/*                       'terms' => '', */
/*                       'frequency' => 'occasionally', */
/*                       'submit' => 'register'); */
/*         $this->post(WACT_EXAMPLES_HTTP_PATH . '/tags/input.php', $post); */
/*         $this->assertWantedPattern( */
/*             $this->_fileToPattern(TEST_HTTP_PATH . '/tags/expected_output/input.2.html')); */
/*         $post['username'] = 'blah'; */
/*         $post['frequency'] = 'regularly'; */
/*         $this->post(WACT_EXAMPLES_HTTP_PATH . '/tags/input.php', $post); */
/*         $this->assertWantedPattern( */
/*             $this->_fileToPattern(TEST_HTTP_PATH . '/tags/expected_output/input.3.html')); */
/*         $post['terms'] = 'checkbox'; */
/*         $post['password'] = 'password'; */
/*         $post['passwordconfirm'] = 'passwrod'; */
/*         $this->post(WACT_EXAMPLES_HTTP_PATH . '/tags/input.php', $post); */
/*         $this->assertWantedPattern( */
/*             $this->_fileToPattern(TEST_HTTP_PATH . '/tags/expected_output/input.4.html')); */
/*         $post['passwordconfirm'] = 'password'; */
/*         $this->post(WACT_EXAMPLES_HTTP_PATH . '/tags/input.php', $post); */
/*         $this->assertWantedPattern( */
/*             $this->_fileToPattern(TEST_HTTP_PATH . '/tags/expected_output/input.5.html')); */
    }
    function testSelect() {
        $this->get(WACT_EXAMPLES_HTTP_PATH . '/tags/select.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/tags/expected_output/select.1.html'));
        $post = array('Country' => 'Dahomey',
                      'submit' => 'select');
        $this->post(WACT_EXAMPLES_HTTP_PATH . '/tags/select.php', $post);
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/tags/expected_output/select.2.html'));
    }

    function testAnyTag() {
        $this->get(WACT_EXAMPLES_HTTP_PATH . '/tags/anytag.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/tags/expected_output/anytag.html'));
    }
}
?>