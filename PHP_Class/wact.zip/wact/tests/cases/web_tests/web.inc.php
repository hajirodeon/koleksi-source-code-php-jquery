<?php
/**
 * @package WACT_TESTS
 * @version $Id: web.inc.php,v 1.1 2003/12/08 12:12:49 jon-bangoid Exp $
 */
SimpleTestOptions::ignore('WACTWebTestCase');
/**
 * @package WACT_TESTS
 */
class WACTWebTestCase extends WebTestCase {
    function &_fileToPattern($file) {
        $file_as_array = file($file);
        $pattern = '#^';
        foreach ($file_as_array as $line) {
            /* strip trailing newline */
            if ($line[strlen($line) - 1] == "\n") {
                $line = substr($line, 0, strlen($line) - 1);
            }
            $line = preg_quote($line, '#');

            /* replace paths with wildcard */
            $line = preg_replace("#'/[^']*#", "'.*", $line);
            
            $pattern .= $line . '\n';        
        }
        /* strip final newline */
        $pattern = substr($pattern, 0, strlen($pattern) - 2);
        $pattern .= '$#i';
        return $pattern;
    }

    function WACTWebTestCase($name = 'WACTWebTestCase') {
        $this->WebTestCase($name);
    }
}
?>