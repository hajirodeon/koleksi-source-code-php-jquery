<?php
/**
 * @package WACT_TESTS
 * @version $Id: goodhtml.test.php,v 1.1 2003/12/08 12:12:49 jon-bangoid Exp $
 */
require_once 'web.inc.php';

/**
 * @package WACT_TESTS
 */
class GoodHtmlTestCase extends WACTWebTestCase {
    function GoodHtmlTestCase($name = 'GoodHtmlTestCase') {
        $this->WACTWebTestCase($name);
    }

    function testSelfClose() {
        $this->get(TEST_HTTP_PATH . '/goodhtml/selfclose.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/goodhtml/expected_output/selfclose.html'));
    }

    function testMinimizedAttribute() {
        $this->get(TEST_HTTP_PATH . '/goodhtml/minimizedattribute.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/goodhtml/expected_output/minimizedattribute.html'));
    }

    function testEscapeWhitespace() {
        $this->get(TEST_HTTP_PATH . '/goodhtml/escapewhitespace.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/goodhtml/expected_output/escapewhitespace.html'));
    }

    function testXMLEscapes() {
        $this->get(TEST_HTTP_PATH . '/goodhtml/xmlescapes.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/goodhtml/expected_output/xmlescapes.html'));
    }
}
?>