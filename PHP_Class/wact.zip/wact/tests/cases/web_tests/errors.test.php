<?php
/**
 * @package WACT_TESTS
 * @version $Id: errors.test.php,v 1.1 2003/12/08 12:12:49 jon-bangoid Exp $
 */

require_once 'web.inc.php';

/**
 * @package WACT_TESTS
 */
class ErrorsTestCase extends WACTWebTestCase {
    function ErrorsTestCase($name = 'ErrorsTestCase') {
        $this->WACTWebTestCase($name);
    }

/*     function testCompileAll() { */
/*         $this->get(TEST_HTTP_PATH . '/errors/compileall.php'); */
/*         $this->assertWantedPattern( */
/*             $this->_fileToPattern(TEST_HTTP_PATH . '/errors/expected_output/compileall.html')); */
/*     } */

    function testBadSelfNestingTag() {
        $this->get(TEST_HTTP_PATH . '/errors/badselfnestingtag.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/errors/expected_output/badselfnestingtag.html'));
    }
    function testComponentNotFound() {
        $this->get(TEST_HTTP_PATH . '/errors/componentnotfound.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/errors/expected_output/componentnotfound.html'));
    }
    function testControlArrayRequired() {
        $this->get(TEST_HTTP_PATH . '/errors/controlarrayrequired.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/errors/expected_output/controlarrayrequired.html'));
    }
    function testDoubleWrap() {
        $this->get(TEST_HTTP_PATH . '/errors/doublewrap.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/errors/expected_output/doublewrap.html'));
    }
    function testDuplicateID() {
        $this->get(TEST_HTTP_PATH . '/errors/duplicateid.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/errors/expected_output/duplicateid.html'));
    }
    /* carries on parsing till end of file */
    function testExpectingGT() {
        $this->get(TEST_HTTP_PATH . '/errors/expectinggt.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/errors/expected_output/expectinggt.html'));
    }
    function testExtraClosingTag() {
        $this->get(TEST_HTTP_PATH . '/errors/extraclosingtag.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/errors/expected_output/extraclosingtag.html'));
    }
    function testInvalidFileName() {
        $this->get(TEST_HTTP_PATH . '/errors/invalidfilename.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/errors/expected_output/invalidfilename.html'));
    }
    /* not sure what the correct line number report should be for this one...,
     * same line as opening tag, next tag line number?, end of doc (current output)? */
    function testMissingClose() {
        $this->get(TEST_HTTP_PATH . '/errors/missingclose.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/errors/expected_output/missingclose.html'));
    }
    function testMissingEnclosure() {
        $this->get(TEST_HTTP_PATH . '/errors/missingenclosure.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/errors/expected_output/missingenclosure.html'));
    }
    function testMissingFile() {
        $this->get(TEST_HTTP_PATH . '/errors/missingfile.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/errors/expected_output/missingfile.html'));
    }
    function testMissingFile2() {
        $this->get(TEST_HTTP_PATH . '/errors/missingfile2.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/errors/expected_output/missingfile2.html'));
    }
    function testMissingRequiredAttribute() {
        $this->get(TEST_HTTP_PATH . '/errors/missingrequiredattribute.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/errors/expected_output/missingrequiredattribute.html'));
    }
    function testRelativePath() {
        $this->get(TEST_HTTP_PATH . '/errors/relativepath.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/errors/expected_output/relativepath.html'));
    }
    function testUnexpectedClose() {
        $this->get(TEST_HTTP_PATH . '/errors/unexpectedclose.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/errors/expected_output/unexpectedclose.html'));
    }
    function testUnexpectedClose2() {
        $this->get(TEST_HTTP_PATH . '/errors/unexpectedclose2.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/errors/expected_output/unexpectedclose2.html'));
    }
    function testUnknownInputType() {
        $this->get(TEST_HTTP_PATH . '/errors/unknowninputtype.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/errors/expected_output/unknowninputtype.html'));
    }
    function testValueNotFound() {
        $this->get(TEST_HTTP_PATH . '/errors/valuenotfound.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/errors/expected_output/valuenotfound.html'));
    }
}
?>