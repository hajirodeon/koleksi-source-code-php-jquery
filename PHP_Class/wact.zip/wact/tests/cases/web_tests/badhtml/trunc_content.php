<?php
require_once 'common.inc.php';
$Page =& new Template('/trunc_content.html');
$Page->display();
?>
