<?php
require_once 'common.inc.php';
$Page =& new Template('/emptyclose.html');
$Page->display();
?>
