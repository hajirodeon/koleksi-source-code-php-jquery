<?php
require_once 'common.inc';
$Page =& new Template('/attributeentity_amp.html');
$Page->display();
?>
