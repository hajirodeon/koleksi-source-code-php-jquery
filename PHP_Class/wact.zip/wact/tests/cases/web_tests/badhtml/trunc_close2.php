<?php
require_once 'common.inc.php';
$Page =& new Template('/trunc_close2.html');
$Page->display();
?>
