<?php
require_once 'common.inc.php';
$Page =& new Template('/contententity_lt.html');
$Page->display();
?>
