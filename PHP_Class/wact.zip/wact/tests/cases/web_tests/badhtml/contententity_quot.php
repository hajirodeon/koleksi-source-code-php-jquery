<?php
require_once 'common.inc.php';
$Page =& new Template('/contententity_quot.html');
$Page->display();
?>
