<?php
require_once 'common.inc.php';
$Page =& new Template('/trunc_tag1.html');
$Page->display();
?>
