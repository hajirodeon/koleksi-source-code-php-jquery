<?php
require_once 'common.inc.php';
$Page =& new Template('/closeattribute.html');
$Page->display();
?>
