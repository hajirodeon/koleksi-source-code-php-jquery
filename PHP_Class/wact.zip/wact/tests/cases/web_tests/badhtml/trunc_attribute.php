<?php
require_once 'common.inc.php';
$Page =& new Template('/trunc_attribute.html');
$Page->display();
?>
