<?php
require_once 'common.inc.php';
$Page =& new Template('/wact_trunc_value.html');
$Page->display();
?>
