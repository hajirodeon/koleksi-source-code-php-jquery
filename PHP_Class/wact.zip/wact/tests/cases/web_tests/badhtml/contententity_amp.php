<?php
require_once 'common.inc.php';
$Page =& new Template('/contententity_amp.html');
$Page->display();
?>
