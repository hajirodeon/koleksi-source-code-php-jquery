<?php
require_once 'common.inc.php';
$Page =& new Template('/wact_trunc_attribute.html');
$Page->display();
?>
