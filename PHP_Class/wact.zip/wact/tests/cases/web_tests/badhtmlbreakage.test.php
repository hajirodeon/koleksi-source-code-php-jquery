<?php
/**
 * @package WACT_TESTS
 * @version $Id: badhtmlbreakage.test.php,v 1.1 2003/12/08 12:12:49 jon-bangoid Exp $
 */

require_once 'web.inc.php';

/**
 * @package WACT_TESTS
 */
class BadHtmlBreakageTestCase extends WACTWebTestCase {
    function BadHtmlBreakageTestCase($name = 'BadHtmlTestCase') {
        $this->WACTWebTestCase($name);
    }

    function testTruncatedAttribute() {
        $this->get(TEST_HTTP_PATH . '/badhtml/trunc_attribute.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/badhtml/expected_output/trunc_attribute.html'));
    }

    function testWactTruncatedAttribute() {
        $this->get(TEST_HTTP_PATH . '/badhtml/wact_trunc_attribute.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/badhtml/expected_output/wact_trunc_attribute.html'));
    }

}
?>