<?php
require_once 'common.inc.php';
$Page =& new Template('/extraclosingtag.html');
$Page->display();
?>
