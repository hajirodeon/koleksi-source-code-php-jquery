<?php
require_once 'common.inc.php';
$Page =& new Template('relativepath/relativepath.html');
$Page->display();
?>
