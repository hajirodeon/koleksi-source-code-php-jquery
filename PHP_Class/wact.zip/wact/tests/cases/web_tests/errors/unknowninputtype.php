<?php
require_once 'common.inc.php';
$Page =& new Template('/unknowninputtype.html');
$Page->display();
?>
