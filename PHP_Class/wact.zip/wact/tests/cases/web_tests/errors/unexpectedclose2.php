<?php
require_once 'common.inc.php';
$Page =& new Template('/unexpectedclose2.html');
$Page->display();
?>
