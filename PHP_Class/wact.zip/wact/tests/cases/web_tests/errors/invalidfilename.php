<?php
require_once 'common.inc.php';
$Page =& new Template('../invalidfilename.html');
$Page->display();
?>
