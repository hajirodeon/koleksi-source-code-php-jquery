<?php
require_once 'common.inc.php';
require WACT_ROOT . '/template/compiler/compileall.inc.php';
CompileAll();
?>
