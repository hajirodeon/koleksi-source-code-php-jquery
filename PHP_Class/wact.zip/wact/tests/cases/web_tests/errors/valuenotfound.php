<?php
require_once 'common.inc.php';
$test =& getConfigOption('invalidfilename.php', 'test', 'test');
?>
