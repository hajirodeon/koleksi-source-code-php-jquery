<?php
require_once 'common.inc.php';
$Page =& new Template('/componentnotfound.html');
$List =& $Page->getChild('nonexistent');
$Page->display();
?>
