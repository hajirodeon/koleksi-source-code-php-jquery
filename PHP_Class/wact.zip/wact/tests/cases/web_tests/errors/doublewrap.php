<?php
require_once 'common.inc.php';
$Page =& new Template('/doublewrap.html');
$Page->display();
?>
