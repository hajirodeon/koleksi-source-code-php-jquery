<?php
require_once 'common.inc.php';
$Page =& new Template('/missingclose.html');
$Page->display();
?>
