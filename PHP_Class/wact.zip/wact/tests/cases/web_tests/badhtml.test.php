<?php
/**
 * @package WACT_TESTS
 * @version $Id: badhtml.test.php,v 1.1 2003/12/08 12:12:49 jon-bangoid Exp $
 */

require_once 'web.inc.php';

/**
 * @package WACT_TESTS
 */
class BadHtmlTestCase extends WACTWebTestCase {
    function BadHtmlTestCase($name = 'BadHtmlTestCase') {
        $this->WACTWebTestCase($name);
    }

    function testAttributeEntity_lt() {
        $this->get(TEST_HTTP_PATH . '/badhtml/attributeentity_lt.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/badhtml/expected_output/attributeentity_lt.html'));
    }

    function testAttributeEntity_gt() {
        $this->get(TEST_HTTP_PATH . '/badhtml/attributeentity_gt.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/badhtml/expected_output/attributeentity_gt.html'));
    }

    function testAttributeEntity_quot() {
        $this->get(TEST_HTTP_PATH . '/badhtml/attributeentity_quot.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/badhtml/expected_output/attributeentity_quot.html'));
    }

    function testAttributeEntity_amp() {
        $this->get(TEST_HTTP_PATH . '/badhtml/attributeentity_amp.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/badhtml/expected_output/attributeentity_amp.html'));
    }

    function testContentEntity_lt() {
        $this->get(TEST_HTTP_PATH . '/badhtml/contententity_lt.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/badhtml/expected_output/contententity_lt.html'));
    }

    function testContentEntity_gt() {
        $this->get(TEST_HTTP_PATH . '/badhtml/contententity_gt.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/badhtml/expected_output/contententity_gt.html'));
    }

    function testContentEntity_quot() {
        $this->get(TEST_HTTP_PATH . '/badhtml/contententity_quot.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/badhtml/expected_output/contententity_quot.html'));
    }

    function testContentEntity_amp() {
        $this->get(TEST_HTTP_PATH . '/badhtml/contententity_amp.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/badhtml/expected_output/contententity_amp.html'));
    }

    function testEmptyClose() {
        $this->get(TEST_HTTP_PATH . '/badhtml/emptyclose.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/badhtml/expected_output/emptyclose.html'));
    }

    function testEmptyOpen() {
        $this->get(TEST_HTTP_PATH . '/badhtml/emptyopen.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/badhtml/expected_output/emptyopen.html'));
    }

    function testDoubleClose() {
        $this->get(TEST_HTTP_PATH . '/badhtml/doubleclose.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/badhtml/expected_output/doubleclose.html'));
    }

    function testCloseAttribute() {
        $this->get(TEST_HTTP_PATH . '/badhtml/closeattribute.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/badhtml/expected_output/closeattribute.html'));
    }

    function testTruncatedTag1() {
        $this->get(TEST_HTTP_PATH . '/badhtml/trunc_tag1.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/badhtml/expected_output/trunc_tag1.html'));
    }

    function testTruncatedTag2() {
        $this->get(TEST_HTTP_PATH . '/badhtml/trunc_tag2.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/badhtml/expected_output/trunc_tag2.html'));
    }

    function testTruncatedClose1() {
        $this->get(TEST_HTTP_PATH . '/badhtml/trunc_close1.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/badhtml/expected_output/trunc_close1.html'));
    }

    function testTruncatedClose2() {
        $this->get(TEST_HTTP_PATH . '/badhtml/trunc_close2.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/badhtml/expected_output/trunc_close2.html'));
    }

    function testTruncatedValue() {
        $this->get(TEST_HTTP_PATH . '/badhtml/trunc_value.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/badhtml/expected_output/trunc_value.html'));
    }

    function testTruncatedContent() {
        $this->get(TEST_HTTP_PATH . '/badhtml/trunc_content.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/badhtml/expected_output/trunc_content.html'));
    }

    function testWactAttributeEntity_lt() {
        $this->get(TEST_HTTP_PATH . '/badhtml/wact_attributeentity_lt.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/badhtml/expected_output/wact_attributeentity_lt.html'));
    }

    function testWactAttributeEntity_gt() {
        $this->get(TEST_HTTP_PATH . '/badhtml/wact_attributeentity_gt.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/badhtml/expected_output/wact_attributeentity_gt.html'));
    }

    function testWactAttributeEntity_quot() {
        $this->get(TEST_HTTP_PATH . '/badhtml/wact_attributeentity_quot.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/badhtml/expected_output/wact_attributeentity_quot.html'));
    }

    function testWactAttributeEntity_amp() {
        $this->get(TEST_HTTP_PATH . '/badhtml/wact_attributeentity_amp.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/badhtml/expected_output/wact_attributeentity_amp.html'));
    }

    function testWactContentEntity_lt() {
        $this->get(TEST_HTTP_PATH . '/badhtml/wact_contententity_lt.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/badhtml/expected_output/wact_contententity_lt.html'));
    }

    function testWactContentEntity_gt() {
        $this->get(TEST_HTTP_PATH . '/badhtml/wact_contententity_gt.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/badhtml/expected_output/wact_contententity_gt.html'));
    }

    function testWactContentEntity_quot() {
        $this->get(TEST_HTTP_PATH . '/badhtml/wact_contententity_quot.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/badhtml/expected_output/wact_contententity_quot.html'));
    }

    function testWactContentEntity_amp() {
        $this->get(TEST_HTTP_PATH . '/badhtml/wact_contententity_amp.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/badhtml/expected_output/wact_contententity_amp.html'));
    }

    function testWactTruncatedClose1() {
        $this->get(TEST_HTTP_PATH . '/badhtml/wact_trunc_close1.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/badhtml/expected_output/wact_trunc_close1.html'));
    }

    function testWactTruncatedClose2() {
        $this->get(TEST_HTTP_PATH . '/badhtml/wact_trunc_close2.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/badhtml/expected_output/wact_trunc_close2.html'));
    }

    function testWactTruncatedValue() {
        $this->get(TEST_HTTP_PATH . '/badhtml/wact_trunc_value.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/badhtml/expected_output/wact_trunc_value.html'));
    }

    function testWactTruncatedContent() {
        $this->get(TEST_HTTP_PATH . '/badhtml/wact_trunc_content.php');
        $this->assertWantedPattern(
            $this->_fileToPattern(TEST_HTTP_PATH . '/badhtml/expected_output/wact_trunc_content.html'));
    }
}
?>