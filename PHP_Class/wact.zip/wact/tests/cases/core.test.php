<?php
/**
* @package WACT_TESTS
* @version $Id: core.test.php,v 1.1 2003/12/08 12:06:52 jon-bangoid Exp $
*/

require_once 'dataspace.inc.php';

if (!defined('DATASPACE_LOADED')) {
    require WACT_ROOT . '/util/dataspace.inc.php';
}

/**
* Shared tests for all classes implementing the DataSpace interface.
* @package WACT_TESTS
*/
class CoreTestCase extends SharedDataSpaceTestCase {
    var $dataspace;
    var $filter;
    function CoreTestCase($name = 'Core test cases') {
        $this->SharedDataSpaceTestCase($name);
    }
}
?>