<?php
/**
* @package WACT_TESTS
* @version $Id: pattern.test.php,v 1.1 2003/12/08 12:11:06 jon-bangoid Exp $
*/

require_once 'singlefield.inc.php';
require_once WACT_ROOT . '/validation/rules/pattern.inc.php';

class PatternRuleTestCase extends SingleFieldRuleTestCase {
    function PatternRuleTestCase($name = 'PatternRuleTestCase') {
        $this->UnitTestCase($name);
    }
    function testPatternRule() {
        $this->validator->addRule(new PatternRule('testfield', '/^\w+$/'));
        
        $Data =& new DataSpace();
        $Data->set('testfield', 'SimpletestisCool');

        $this->ErrorList->expectNever('addError');
        
        $this->validator->validate($Data);
        $this->assertTrue($this->validator->IsValid());
    }
    function testPatternRuleFailed() {
        $this->validator->addRule(new PatternRule('testfield', '/^\w+$/'));
        
        $Data =& new DataSpace();
        $Data->set('testfield', 'Simpletest is Cool!');

        $this->ErrorList->expectOnce('addError', array('validation', 'INVALID', array('Field'=>'testfield'), NULL));
        
        $this->validator->validate($Data);
        $this->assertFalse($this->validator->IsValid());
    }
}

class ExcludePatternRuleTestCase extends SingleFieldRuleTestCase {
    function ExcludePatternRuleTestCase($name = 'ExcludePatternRuleTestCase') {
        $this->UnitTestCase($name);
    }
    function testExcludePatternRule() {
        $this->validator->addRule(new ExcludePatternRule('testfield', '/\d/'));
        
        $Data =& new DataSpace();
        $Data->set('testfield', 'Error!');

        $this->ErrorList->expectNever('addError');
        
        $this->validator->validate($Data);
        $this->assertTrue($this->validator->IsValid());
    }
    function testExcludePatternRuleFailed() {
        $this->validator->addRule(new ExcludePatternRule('testfield', '/\d/'));
        
        $Data =& new DataSpace();
        $Data->set('testfield', '3rror!');

        $this->ErrorList->expectOnce('addError', array('validation', 'INVALID', array('Field'=>'testfield'), NULL));
        
        $this->validator->validate($Data);
        $this->assertFalse($this->validator->IsValid());
    }
}

?>