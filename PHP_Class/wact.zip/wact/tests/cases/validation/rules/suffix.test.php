<?php
/**
* @package WACT_TESTS
* @version $Id: suffix.test.php,v 1.1 2003/12/08 12:11:06 jon-bangoid Exp $
*/

require_once 'singlefield.inc.php';
require_once WACT_ROOT . '/validation/rules/suffix.inc.php';

class SuffixRuleTestCase extends SingleFieldRuleTestCase {
    function SuffixRuleTestCase($name = 'SuffixRuleTestCase') {
        $this->UnitTestCase($name);
    }
    function testSuffixRule() {
        $this->validator->addRule(new SuffixRule('testfield', 'com'));
        
        $Data =& new DataSpace();
        $Data->set('testfield', 'www.domain.com');

        $this->ErrorList->expectNever('addError');
        
        $this->validator->validate($Data);
        $this->assertTrue($this->validator->IsValid());
    }
    function testSuffixRuleMissing() {
        $this->validator->addRule(new SuffixRule('testfield', 'com'));
        
        $Data =& new DataSpace();
        $Data->set('testfield', 'domain.gov');

        $this->ErrorList->expectOnce('addError', array('validation', 'SUFFIX_MISSING', array('Field'=>'testfield'), array('suffix'=>'com')));
        
        $this->validator->validate($Data);
        $this->assertFalse($this->validator->IsValid());
    }
}

class ExcludeSuffixRuleTestCase extends SingleFieldRuleTestCase {
    function ExcludeSuffixRuleTestCase($name = 'ExcludeSuffixRuleTestCase') {
        $this->UnitTestCase($name);
    }
    function testExcludeSuffixRule() {
        $this->validator->addRule(new ExcludeSuffixRule('testfield', 'com'));
        
        $Data =& new DataSpace();
        $Data->set('testfield', 'domain.gov');

        $this->ErrorList->expectNever('addError');
        
        $this->validator->validate($Data);
        $this->assertTrue($this->validator->IsValid());
    }
    function testExcludeSuffixRuleMissing() {
        $this->validator->addRule(new ExcludeSuffixRule('testfield', 'com'));
        
        $Data =& new DataSpace();
        $Data->set('testfield', 'www.domain.com');

        $this->ErrorList->expectOnce('addError', array('validation', 'SUFFIX_NOT_ALLOWED', array('Field'=>'testfield'), array('suffix'=>'com')));
        
        $this->validator->validate($Data);
        $this->assertFalse($this->validator->IsValid());
    }
}

?>