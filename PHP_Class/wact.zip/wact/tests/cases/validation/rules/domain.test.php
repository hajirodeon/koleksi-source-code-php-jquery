<?php
/**
* @package WACT_TESTS
* @version $Id: domain.test.php,v 1.1 2003/12/08 12:11:06 jon-bangoid Exp $
*/

require_once 'singlefield.inc.php';
require_once WACT_ROOT . '/validation/rules/domain.inc.php';

class DomainRuleTestCase extends SingleFieldRuleTestCase {
    function DomainRuleTestCase($name = 'DomainRuleTestCase') {
        $this->UnitTestCase($name);
    }
    function testDomainRule() {
        $this->validator->addRule(new DomainRule('testfield'));
        
        $Data =& new DataSpace();
        $Data->set('testfield', 'sourceforge.net');

        $this->ErrorList->expectNever('addError');
        
        $this->validator->validate($Data);
        $this->assertTrue($this->validator->IsValid());
    }
    function testDomainRuleBlank() {
        $this->validator->addRule(new DomainRule('testfield'));
        
        $Data =& new DataSpace();
        $Data->set('testfield', '');

        $this->ErrorList->expectNever('addError');
        
        $this->validator->validate($Data);
        $this->assertTrue($this->validator->IsValid());
    }
    function testDomainRuleBadCharacters() {
        $this->validator->addRule(new DomainRule('testfield'));
        
        $Data =& new DataSpace();
        $Data->set('testfield', 'source#&%forge.net');

        $this->ErrorList->expectOnce('addError', array('validation', 'BAD_DOMAIN_CHARACTERS', array('Field'=>'testfield'), NULL));
        
        $this->validator->validate($Data);
        $this->assertFalse($this->validator->IsValid());
    }
    function testDomainRuleDoubleHyphens() {
        $this->validator->addRule(new DomainRule('testfield'));
        
        $Data =& new DataSpace();
        $Data->set('testfield', 'source--forge.net');

        $this->ErrorList->expectOnce('addError', array('validation', 'BAD_DOMAIN_DOUBLE_HYPHENS', array('Field'=>'testfield'), NULL));
        
        $this->validator->validate($Data);
        $this->assertFalse($this->validator->IsValid());
    }
    function testDomainRuleTooLarge() {
        $this->validator->addRule(new DomainRule('testfield'));
        
        $segment = "abcdefg-hijklmnop-qrs-tuv-wx-yz-ABCDEFG-HIJKLMNOP-QRS-TUV-WX-YZ-0123456789";
        
        $Data =& new DataSpace();
        $Data->set('testfield', $segment . '.net');

        $this->ErrorList->expectOnce('addError', array('validation', 'BAD_DOMAIN_SEGMENT_TOO_LARGE', array('Field'=>'testfield'), array('segment'=>$segment)));
        
        $this->validator->validate($Data);
        $this->assertFalse($this->validator->IsValid());
    }
    function testDomainHyphenBegin() {
        $this->validator->addRule(new DomainRule('testfield'));
        
        $segment = "-sourceforge";
        
        $Data =& new DataSpace();
        $Data->set('testfield', $segment . '.net');

        $this->ErrorList->expectOnce('addError', array('validation', 'BAD_DOMAIN_HYPHENS', array('Field'=>'testfield'), array('segment'=>$segment)));
        
        $this->validator->validate($Data);
        $this->assertFalse($this->validator->IsValid());
    }
    function testDomainRuleHyphenEnd() {
        $this->validator->addRule(new DomainRule('testfield'));
        
        $segment = "sourceforge-";
        
        $Data =& new DataSpace();
        $Data->set('testfield', $segment . '.net');

        $this->ErrorList->expectOnce('addError', array('validation', 'BAD_DOMAIN_HYPHENS', array('Field'=>'testfield'), array('segment'=>$segment)));
        
        $this->validator->validate($Data);
        $this->assertFalse($this->validator->IsValid());
    }
    function testDomainRuleCombination() {
        $this->validator->addRule(new DomainRule('testfield'));
        
        $Data =& new DataSpace();
        $Data->set('testfield', '.n..aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa.');

        $this->ErrorList->expectCallCount('addError', 4);

        $this->ErrorList->expectArgumentsAt(0,
                                            'addError',
                                            array('validation', 'BAD_DOMAIN_STARTING_PERIOD', array('Field'=>'testfield'), NULL));

        $this->ErrorList->expectArgumentsAt(1,
                                            'addError',
                                            array('validation', 'BAD_DOMAIN_ENDING_PERIOD', array('Field'=>'testfield'), NULL));

        $this->ErrorList->expectArgumentsAt(2,
                                            'addError',
                                            array('validation', 'BAD_DOMAIN_DOUBLE_DOTS', array('Field'=>'testfield'), NULL));

        $this->ErrorList->expectArgumentsAt(3,
                                            'addError',
                                            array('validation', 'BAD_DOMAIN_SEGMENT_TOO_LARGE', array('Field'=>'testfield'), array('segment' => 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa')));

        $this->validator->validate($Data);
        $this->assertFalse($this->validator->IsValid());
    }
}

?>