<?php
/**
* @package WACT_TESTS
* @version $Id: required.test.php,v 1.1 2003/12/08 12:11:06 jon-bangoid Exp $
*/

require_once 'singlefield.inc.php';

class RequiredRuleTestCase extends SingleFieldRuleTestCase {
    function RequiredRuleTestCase($name = 'RequiredRuleTestCase') {
        $this->UnitTestCase($name);
    }
    function testRequiredRule() {
        $this->validator->addRule(new RequiredRule('testfield'));
        
        $Data =& new DataSpace();
        $Data->set('testfield', TRUE);

        $this->ErrorList->expectNever('addError');
        
        $this->validator->validate($Data);
        $this->assertTrue($this->validator->IsValid());
    }
    function testRequiredRuleZero() {
        $this->validator->addRule(new RequiredRule('testfield'));
        
        $Data =& new DataSpace();
        $Data->set('testfield', 0);

        $this->ErrorList->expectNever('addError');
        
        $this->validator->validate($Data);
        $this->assertTrue($this->validator->IsValid());
    }
    function testRequiredRuleZero2() {
        $this->validator->addRule(new RequiredRule('testfield'));
        
        $Data =& new DataSpace();
        $Data->set('testfield', '0');

        $this->ErrorList->expectNever('addError');
        
        $this->validator->validate($Data);
        $this->assertTrue($this->validator->IsValid());
    }
    function testRequiredRuleFalse() {
        $this->validator->addRule(new RequiredRule('testfield'));
        
        $Data =& new DataSpace();
        $Data->set('testfield', FALSE);

        $this->ErrorList->expectNever('addError');
        
        $this->validator->validate($Data);
        $this->assertTrue($this->validator->IsValid());
    }
    function testRequiredRuleZeroLengthString() {
        $this->validator->addRule(new RequiredRule('testfield'));
        
        $Data =& new DataSpace();
        $Data->set('testfield', '');

        $this->ErrorList->expectOnce('addError', array('validation', 'MISSING', array('Field'=>'testfield')));
        
        $this->validator->validate($Data);
        $this->assertFalse($this->validator->IsValid());
    }
    function testRequiredRuleFailure() {
        $this->validator->addRule(new RequiredRule('testfield'));
        
        $Data =& new DataSpace();

        $this->ErrorList->expectOnce('addError', array('validation', 'MISSING', array('Field'=>'testfield')));
        
        $this->validator->validate($Data);
        $this->assertFalse($this->validator->IsValid());
    }
}    
    
?>