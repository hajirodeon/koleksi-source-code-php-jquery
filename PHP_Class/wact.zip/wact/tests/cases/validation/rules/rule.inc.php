<?php
/**
* @package WACT_TESTS
* @version $Id: rule.inc.php,v 1.4 2003/12/08 12:11:06 jon-bangoid Exp $
*/

require_once WACT_ROOT . '/validation/validator.inc.php';
require_once WACT_ROOT . '/util/dataspace.inc.php';

Mock::generate('ErrorList');

Mock::generatePartial(
    'Validator',
    'ValidatorTestVersion',
    array('createErrorList')); 

/**
* @package WACT_TESTS
*/

SimpleTestOptions::ignore('ValidationRuleTestCase');
class ValidationRuleTestCase extends UnitTestCase {
    var $validator;
    var $ErrorList;

    function setUp() {
        $this->ErrorList =& new MockErrorList($this);
        $this->validator =& new ValidatorTestVersion($this);
        $this->validator->setReturnReference('createErrorList', $this->ErrorList);
    }
    function tearDown() {
        $this->validator->tally();
        $this->ErrorList->tally();
        unset ( $this->validator );
        unset ( $this->ErrorList );
    }
}


?>