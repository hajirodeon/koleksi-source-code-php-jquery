<?php
/**
* @package WACT_TESTS
* @version $Id: singlefield.inc.php,v 1.3 2003/12/08 12:11:06 jon-bangoid Exp $
*/

require_once 'rule.inc.php';

SimpleTestOptions::ignore('SingleFieldRuleTestCase');
class SingleFieldRuleTestCase extends ValidationRuleTestCase {
}
?>