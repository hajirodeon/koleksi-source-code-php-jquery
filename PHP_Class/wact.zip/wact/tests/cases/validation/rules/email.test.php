<?php
/**
* @package WACT_TESTS
* @version $Id: email.test.php,v 1.1 2003/12/08 12:11:06 jon-bangoid Exp $
*/

require_once 'singlefield.inc.php';
require_once WACT_ROOT . '/validation/rules/email.inc.php';

class EmailRuleTestCase extends SingleFieldRuleTestCase {
    function EmailRuleTestCase($name = 'EmailRuleTestCase') {
        $this->UnitTestCase($name);
    }
    function testEmailRule() {
        $this->validator->addRule(new EmailRule('testfield'));
        
        $Data =& new DataSpace();
        $Data->set('testfield', 'billgates@microsoft.com');

        $this->ErrorList->expectNever('addError');
        
        $this->validator->validate($Data);
        $this->assertTrue($this->validator->IsValid());
    }
    function testEmailRuleNoAt() {
        $this->validator->addRule(new EmailRule('testfield'));
        
        $Data =& new DataSpace();
        $Data->set('testfield', 'billgatesmicrosoft.com');

        $this->ErrorList->expectOnce('addError', array('validation', 'EMAIL_INVALID', array('Field'=>'testfield'), NULL));
        
        $this->validator->validate($Data);
        $this->assertFalse($this->validator->IsValid());
    }
    function testEmailRuleInvalidUser() {
        $this->validator->addRule(new EmailRule('testfield'));
        
        $Data =& new DataSpace();
        $Data->set('testfield', 'bill(y!)gates@microsoft.com');

        $this->ErrorList->expectOnce('addError', array('validation', 'EMAIL_INVALID_USER', array('Field'=>'testfield'), NULL));
        
        $this->validator->validate($Data);
        $this->assertFalse($this->validator->IsValid());
    }
    function testEmailRuleInvalidDomain() {
        $this->validator->addRule(new EmailRule('testfield'));
        
        $Data =& new DataSpace();
        $Data->set('testfield', 'billgates@micro$oft.com');

        $this->ErrorList->expectOnce('addError', array('validation', 'BAD_DOMAIN_CHARACTERS', array('Field'=>'testfield'), NULL));
        
        $this->validator->validate($Data);
        $this->assertFalse($this->validator->IsValid());
    }
}


?>