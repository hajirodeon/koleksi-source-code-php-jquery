<?php
/**
* @package WACT_TESTS
* @version $Id: match.test.php,v 1.1 2003/12/08 12:11:06 jon-bangoid Exp $
*/

require_once 'rule.inc.php';
require_once WACT_ROOT . '/validation/rules/match.inc.php';

class MatchRuleTestCase extends ValidationRuleTestCase {
    function MatchRuleTestCase($name = 'MatchRuleTestCase') {
        $this->UnitTestCase($name);
    }
    function testMatchRule() {
        $this->validator->addRule(new matchRule('testfield', 'testmatch'));
        
        $Data =& new DataSpace();
        $Data->set('testfield', 'peaches');
        $Data->set('testmatch', 'peaches');

        $this->ErrorList->expectNever('addError');
        
        $this->validator->validate($Data);
        $this->assertTrue($this->validator->IsValid());
    }
    function testMatchRuleEmpty() {
        $this->validator->addRule(new matchRule('testfield', 'testmatch'));
        
        $Data =& new DataSpace();

        $this->ErrorList->expectNever('addError');
        
        $this->validator->validate($Data);
        $this->assertTrue($this->validator->IsValid());
    }
    function testMatchRuleEmpty2() {
        $this->validator->addRule(new matchRule('testfield', 'testmatch'));
        
        $Data =& new DataSpace();
        $Data->set('testfield', 'peaches');

        $this->ErrorList->expectNever('addError');
        
        $this->validator->validate($Data);
        $this->assertTrue($this->validator->IsValid());
    }
    function testMatchRuleEmpty3() {
        $this->validator->addRule(new matchRule('testfield', 'testmatch'));
        
        $Data =& new DataSpace();
        $Data->set('testmatch', 'peaches');

        $this->ErrorList->expectNever('addError');
        
        $this->validator->validate($Data);
        $this->assertTrue($this->validator->IsValid());
    }
    function testMatchRuleFailure() {
        $this->validator->addRule(new matchRule('testfield', 'testmatch'));
        
        $Data =& new DataSpace();
        $Data->set('testfield', 'peaches');
        $Data->set('testmatch', 'cream');

        $this->ErrorList->expectOnce('addError', array('validation', 'NO_MATCH', array('Field'=>'testfield', 'MatchField' => 'testmatch')));
        
        $this->validator->validate($Data);
        $this->assertFalse($this->validator->IsValid());
    }
 }
 
?>