<?php
/**
* @package WACT_TESTS
* @version $Id: sizerange.test.php,v 1.1 2003/12/08 12:11:06 jon-bangoid Exp $
*/

require_once 'singlefield.inc.php';
    
class SizeRangeRuleTestCase extends SingleFieldRuleTestCase {
    function SizeRangeRuleTestCase($name = 'SizeRangeRuleTestCase') {
        $this->UnitTestCase($name);
    }
    function testSizeRangeRuleEmpty() {
        $this->validator->addRule(new SizeRangeRule('testfield', 10));
        
        $Data =& new DataSpace();

        $this->ErrorList->expectNever('addError');
        
        $this->validator->validate($Data);
        $this->assertTrue($this->validator->IsValid());
    }
    function testSizeRangeRuleBlank() {
        $this->validator->addRule(new SizeRangeRule('testfield', 5, 10));
        
        $Data =& new DataSpace();
        $Data->set('testfield', '');

        $this->ErrorList->expectNever('addError');
        
        $this->validator->validate($Data);
        $this->assertTrue($this->validator->IsValid());
    }
    function testSizeRangeRuleZero() {
        $this->validator->addRule(new SizeRangeRule('testfield', 5, 10));
        
        $Data =& new DataSpace();
        $Data->set('testfield', '0');

        $this->ErrorList->expectOnce('addError', array('validation', 'SIZE_TOO_SMALL', array('Field'=>'testfield'), array('min'=>5)));
        
        $this->validator->validate($Data);
        $this->assertFalse($this->validator->IsValid());
    }
    function testSizeRangeRuleTooBig() {
        $this->validator->addRule(new SizeRangeRule('testfield', 10));
        
        $Data =& new DataSpace();
        $Data->set('testfield', '12345678901234567890');

        $this->ErrorList->expectOnce('addError', array('validation', 'SIZE_TOO_BIG', array('Field'=>'testfield'), array('max'=>10)));
        
        $this->validator->validate($Data);
        $this->assertFalse($this->validator->IsValid());
    }
    function testSizeRangeRuleTooBig2() {
        $this->validator->addRule(new SizeRangeRule('testfield', 5, 10));
        
        $Data =& new DataSpace();
        $Data->set('testfield', '12345678901234567890');

        $this->ErrorList->expectOnce('addError', array('validation', 'SIZE_TOO_BIG', array('Field'=>'testfield'), array('max'=>10)));
        
        $this->validator->validate($Data);
        $this->assertFalse($this->validator->IsValid());
    }
    function testSizeRangeRuleTooSmall() {
        $this->validator->addRule(new SizeRangeRule('testfield', 30, 100));
        
        $Data =& new DataSpace();
        $Data->set('testfield', '12345678901234567890');

        $this->ErrorList->expectOnce('addError', array('validation', 'SIZE_TOO_SMALL', array('Field'=>'testfield'), array('min'=>30)));
        
        $this->validator->validate($Data);
        $this->assertFalse($this->validator->IsValid());
    }
}

?>