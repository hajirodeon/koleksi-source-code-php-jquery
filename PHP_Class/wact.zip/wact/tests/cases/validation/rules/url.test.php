<?php
/**
* @package WACT_TESTS
* @version $Id: url.test.php,v 1.1 2003/12/08 12:11:06 jon-bangoid Exp $
*/

require_once 'singlefield.inc.php';
require_once WACT_ROOT . '/validation/rules/url.inc.php';

class UrlRuleTestCase extends SingleFieldRuleTestCase {
    function UrlRuleTestCase($name = 'UrlRuleTestCase') {
        $this->UnitTestCase($name);
    }
    function testUrlRule() {
        $this->validator->addRule(new UrlRule('testfield'));
        
        $Data =& new DataSpace();
        $Data->set('testfield', 'http://www.sourceforge.net/');

        $this->ErrorList->expectNever('addError');
        
        $this->validator->validate($Data);
        $this->assertTrue($this->validator->IsValid());
    }
    function testUrlRuleBadScheme() {
        $allowedSchemes = array('http');
        $this->validator->addRule(new UrlRule('testfield',$allowedSchemes));
        
        $Data =& new DataSpace();
        $Data->set('testfield', 'ftp://www.sourceforge.net/');

        $this->ErrorList->expectOnce('addError', array('validation', 'URL_BAD_SCHEME', array('Field'=>'testfield'), array('scheme'=>'ftp')));
        
        $this->validator->validate($Data);
        $this->assertFalse($this->validator->IsValid());
    }
    function testUrlRuleMissingScheme() {
        $allowedSchemes = array('http');
        $this->validator->addRule(new UrlRule('testfield',$allowedSchemes));
        
        $Data =& new DataSpace();
        $Data->set('testfield', 'www.sourceforge.net/');

        $this->ErrorList->expectOnce('addError', array('validation', 'URL_MISSING_SCHEME',array('Field'=>'testfield'), NULL));
        
        $this->validator->validate($Data);
        $this->assertFalse($this->validator->IsValid());
    }
    function testUrlRuleDomain() {
        $this->validator->addRule(new UrlRule('testfield'));
        
        $Data =& new DataSpace();
        $Data->set('testfield', 'http://www.source--forge.net/');

        $this->ErrorList->expectOnce('addError', array('validation', 'BAD_DOMAIN_DOUBLE_HYPHENS', array('Field'=>'testfield'), NULL));
        
        $this->validator->validate($Data);
        $this->assertFalse($this->validator->IsValid());
    }
}

?>