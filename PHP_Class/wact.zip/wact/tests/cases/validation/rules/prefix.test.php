<?php
/**
* @package WACT_TESTS
* @version $Id: prefix.test.php,v 1.1 2003/12/08 12:11:06 jon-bangoid Exp $
*/

require_once 'singlefield.inc.php';
require_once WACT_ROOT . '/validation/rules/prefix.inc.php';

class PrefixRuleTestCase extends SingleFieldRuleTestCase {
    function PrefixRuleTestCase($name = 'PrefixRuleTestCase') {
        $this->UnitTestCase($name);
    }
    function testPrefixRule() {
        $this->validator->addRule(new PrefixRule('testfield', 'www'));
        
        $Data =& new DataSpace();
        $Data->set('testfield', 'www.domain.com');

        $this->ErrorList->expectNever('addError');
        
        $this->validator->validate($Data);
        $this->assertTrue($this->validator->IsValid());
    }
    function testPrefixRuleMissing() {
        $this->validator->addRule(new PrefixRule('testfield', 'www'));
        
        $Data =& new DataSpace();
        $Data->set('testfield', 'domain.com');

        $this->ErrorList->expectOnce('addError', array('validation', 'PREFIX_MISSING', array('Field'=>'testfield'), array('prefix'=>'www')));
        
        $this->validator->validate($Data);
        $this->assertFalse($this->validator->IsValid());
    }
}

class ExcludePrefixRuleTestCase extends SingleFieldRuleTestCase {
    function ExcludePrefixRuleTestCase($name = 'ExcludePrefixRuleTestCase') {
        $this->UnitTestCase($name);
    }
    function testExcludePrefixRule() {
        $this->validator->addRule(new ExcludePrefixRule('testfield', 'www'));
        
        $Data =& new DataSpace();
        $Data->set('testfield', 'domain.com');

        $this->ErrorList->expectNever('addError');
        
        $this->validator->validate($Data);
        $this->assertTrue($this->validator->IsValid());
    }
    function testExcludePrefixRuleMissing() {
        $this->validator->addRule(new ExcludePrefixRule('testfield', 'www'));
        
        $Data =& new DataSpace();
        $Data->set('testfield', 'www.domain.com');

        $this->ErrorList->expectOnce('addError', array('validation', 'PREFIX_NOT_ALLOWED', array('Field'=>'testfield'), array('prefix'=>'www')));
        
        $this->validator->validate($Data);
        $this->assertFalse($this->validator->IsValid());
    }
}

?>