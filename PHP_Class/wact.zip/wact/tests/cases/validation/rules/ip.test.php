<?php
/**
* @package WACT_TESTS
* @version $Id: ip.test.php,v 1.1 2003/12/08 12:11:06 jon-bangoid Exp $
*/

require_once 'singlefield.inc.php';
require_once WACT_ROOT . '/validation/rules/ip.inc.php';

class IPAddressRuleTestCase extends SingleFieldRuleTestCase {
    function IPAddressRuleTestCase($name = 'IPAddressRuleTestCase') {
        $this->UnitTestCase($name);
    }
    function testIPAddressRule() {
        $this->validator->addRule(new IPAddressRule('testfield'));
        
        $Data =& new DataSpace();
        $Data->set('testfield', '127.0.0.1');

        $this->ErrorList->expectNever('addError');
        
        $this->validator->validate($Data);
        $this->assertTrue($this->validator->IsValid());
    }
    function testIPAddressRuleBadChars() {
        $this->validator->addRule(new IPAddressRule('testfield'));
        
        $Data =& new DataSpace();
        $Data->set('testfield', 'a.b.c.d');

        $this->ErrorList->expectOnce('addError', array('validation', 'IP_INVALID', array('Field'=>'testfield'), NULL));
        
        $this->validator->validate($Data);
        $this->assertFalse($this->validator->IsValid());
    }
    function testIPAddressRuleMissing() {
        $this->validator->addRule(new IPAddressRule('testfield'));
        
        $Data =& new DataSpace();
        $Data->set('testfield', '12.0..1');

        $this->ErrorList->expectOnce('addError', array('validation', 'IP_INVALID', array('Field'=>'testfield'), NULL));
        
        $this->validator->validate($Data);
        $this->assertFalse($this->validator->IsValid());
    }
    function testIPAddressRuleTooBig() {
        $this->validator->addRule(new IPAddressRule('testfield'));
        
        $Data =& new DataSpace();
        $Data->set('testfield', '256.0.0.1');

        $this->ErrorList->expectOnce('addError', array('validation', 'IP_INVALID', array('Field'=>'testfield'), NULL));
        
        $this->validator->validate($Data);
        $this->assertFalse($this->validator->IsValid());
    }
    function testIPAddressRuleTooMany() {
        $this->validator->addRule(new IPAddressRule('testfield'));
        
        $Data =& new DataSpace();
        $Data->set('testfield', '127.0.0.0.1');

        $this->ErrorList->expectOnce('addError', array('validation', 'IP_INVALID', array('Field'=>'testfield'), NULL));
        
        $this->validator->validate($Data);
        $this->assertFalse($this->validator->IsValid());
    }
    function testIPAddressRulePartial() {
        $this->validator->addRule(new IPAddressRule('testfield'));
        
        $Data =& new DataSpace();
        $Data->set('testfield', '127.0.0.');

        $this->ErrorList->expectOnce('addError', array('validation', 'IP_INVALID', array('Field'=>'testfield'), NULL));
        
        $this->validator->validate($Data);
        $this->assertFalse($this->validator->IsValid());
    }
}


class PartialIPAddressRuleTestCase extends SingleFieldRuleTestCase {
    function PartialIPAddressRuleTestCase($name = 'PartialIPAddressRuleTestCase') {
        $this->UnitTestCase($name);
    }
    function testIPAddressRule() {
        $this->validator->addRule(new PartialIPAddressRule('testfield'));
        
        $Data =& new DataSpace();
        $Data->set('testfield', '127.0.0.');

        $this->ErrorList->expectNever('addError');
        
        $this->validator->validate($Data);
        $this->assertTrue($this->validator->IsValid());
    }
    function testIPAddressRuleBadChars() {
        $this->validator->addRule(new PartialIPAddressRule('testfield'));
        
        $Data =& new DataSpace();
        $Data->set('testfield', '127.0.0');

        $this->ErrorList->expectOnce('addError', array('validation', 'IP_INVALID', array('Field'=>'testfield'), NULL));
        
        $this->validator->validate($Data);
        $this->assertFalse($this->validator->IsValid());
    }
}

?>