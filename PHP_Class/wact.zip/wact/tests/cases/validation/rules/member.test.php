<?php
/**
* @package WACT_TESTS
* @version $Id: member.test.php,v 1.1 2003/12/08 12:11:06 jon-bangoid Exp $
*/

require_once 'singlefield.inc.php';
require_once WACT_ROOT . '/validation/rules/member.inc.php';

class MemberRuleTestCase extends SingleFieldRuleTestCase {
    function MemberRuleTestCase($name = 'MemberRuleTestCase') {
        $this->UnitTestCase($name);
    }
    function testmemberRule() {
        $this->validator->addRule(new MemberRule('testfield', 
            array_flip(array('peaches', 'apples', 'oranges'))));
        
        $Data =& new DataSpace();
        $Data->set('testfield', 'peaches');

        $this->ErrorList->expectNever('addError');
        
        $this->validator->validate($Data);
        $this->assertTrue($this->validator->IsValid());
    }
    function testmemberRuleFailure() {
        $this->validator->addRule(new MemberRule('testfield', 
            array_flip(array('peaches', 'apples', 'oranges'))));
        
        $Data =& new DataSpace();
        $Data->set('testfield', 'bananas');

        $this->ErrorList->expectOnce('addError', array('validation', 'NON_MEMBER', array('Field'=>'testfield'), array('Value'=>'bananas')));
        
        $this->validator->validate($Data);
        $this->assertFalse($this->validator->IsValid());
    }
}

?>