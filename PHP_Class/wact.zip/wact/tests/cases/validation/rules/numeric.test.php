<?php
/**
* @package WACT_TESTS
* @version $Id: numeric.test.php,v 1.1 2003/12/08 12:11:06 jon-bangoid Exp $
*/

require_once 'singlefield.inc.php';
require_once WACT_ROOT . '/validation/rules/numeric.inc.php';
 
 class NumericRuleTestCase extends SingleFieldRuleTestCase {
    function NumericRuleTestCase($name = 'NumericRuleTestCase') {
        $this->UnitTestCase($name);
    }
    function testNumericRule() {
        $this->validator->addRule(new NumericPrecisionRule('testfield', 3, 2));
        
        $Data =& new DataSpace();
        $Data->set('testfield', '111.22');

        $this->ErrorList->expectNever('addError');
        
        $this->validator->validate($Data);
        $this->assertTrue($this->validator->IsValid());
    }
    function testNumericRuleZero() {
        $this->validator->addRule(new NumericPrecisionRule('testfield', 3, 2));
        
        $Data =& new DataSpace();
        $Data->set('testfield', '0');

        $this->ErrorList->expectNever('addError');
        
        $this->validator->validate($Data);
        $this->assertTrue($this->validator->IsValid());
    }
    function testNumericRuleZeroInt() {
        $this->validator->addRule(new NumericPrecisionRule('testfield', 3, 2));
        
        $Data =& new DataSpace();
        $Data->set('testfield', 0);

        $this->ErrorList->expectNever('addError');
        
        $this->validator->validate($Data);
        $this->assertTrue($this->validator->IsValid());
    }
    function testNumericRuleFailure() {
        // I don't know why this fails?
        $this->validator->addRule(new NumericPrecisionRule('testfield', 3, 2));
        
        $Data =& new DataSpace();
        $Data->set('testfield', 'not a number');

        $this->ErrorList->expectOnce('addError', array('validation', 'NOT_NUMERIC', array('Field'=>'testfield'), NULL));
      
        $this->validator->validate($Data);
        $this->assertFalse($this->validator->IsValid());
    }
    function testNumericRuleTooManyWholeDigits() {
        // I don't know why this fails?
        $this->validator->addRule(new NumericPrecisionRule('testfield', 3, 2));
        
        $Data =& new DataSpace();
        $Data->set('testfield', '1111');

        $this->ErrorList->expectOnce('addError', array('validation', 'TOO_MANY_WHOLE_DIGITS', array('Field'=>'testfield'), array('maxdigits'=>3, 'digits'=>4)));
      
        $this->validator->validate($Data);
        $this->assertFalse($this->validator->IsValid());
    }
    function testNumericRuleTooManyDecimalDigits() {
        // I don't know why this fails?
        $this->validator->addRule(new NumericPrecisionRule('testfield', 3, 2));
        
        $Data =& new DataSpace();
        $Data->set('testfield', '111.222');

        $this->ErrorList->expectOnce('addError', array('validation', 'TOO_MANY_DECIMAL_DIGITS', array('Field'=>'testfield'), array('maxdigits'=>2, 'digits'=>3)));
      
        $this->validator->validate($Data);
        $this->assertFalse($this->validator->IsValid());
    }
}

 class NumericRangeRuleTestCase extends SingleFieldRuleTestCase {
    function NumericRangeRuleTestCase($name = 'NumericRangeRuleTestCase') {
        $this->UnitTestCase($name);
    }
    function testNumericRangeRule() {
        $this->validator->addRule(new NumericRangeRule('testfield', 1, 100));
        
        $Data =& new DataSpace();
        $Data->set('testfield', '50');

        $this->ErrorList->expectNever('addError');
        
        $this->validator->validate($Data);
        $this->assertTrue($this->validator->IsValid());
    }
    function testNumericRangeRuleBlank() {
        $this->validator->addRule(new NumericRangeRule('testfield', 1, 100));
        
        $Data =& new DataSpace();
        $Data->set('testfield', '');

        $this->ErrorList->expectNever('addError');
        
        $this->validator->validate($Data);
        $this->assertTrue($this->validator->IsValid());
    }
    function testNumericRangeRuleTooBig() {
        $this->validator->addRule(new NumericRangeRule('testfield', 1, 100));
        
        $Data =& new DataSpace();
        $Data->set('testfield', '101');

        $this->ErrorList->expectOnce('addError', array('validation', 'RANGE_TOO_BIG', array('Field'=>'testfield'), array('max'=>100)));
        
        $this->validator->validate($Data);
        $this->assertFalse($this->validator->IsValid());
    }
    function testNumericRangeRuleTooSmall() {
        $this->validator->addRule(new NumericRangeRule('testfield', 1, 100));
        
        $Data =& new DataSpace();
        $Data->set('testfield', '0');

        $this->ErrorList->expectOnce('addError', array('validation', 'RANGE_TOO_SMALL', array('Field'=>'testfield'), array('min'=>1)));
        
        $this->validator->validate($Data);
        $this->assertFalse($this->validator->IsValid());
    }
    function testNumericRangeRuleTooSmallZero() {
        $this->validator->addRule(new NumericRangeRule('testfield', 1, 100));
        
        $Data =& new DataSpace();
        $Data->set('testfield', 0);

        $this->ErrorList->expectOnce('addError', array('validation', 'RANGE_TOO_SMALL', array('Field'=>'testfield'), array('min'=>1)));
        
        $this->validator->validate($Data);
        $this->assertFalse($this->validator->IsValid());
    }
    function testNumericRangeRuleFloat() {
        $this->validator->addRule(new NumericRangeRule('testfield', .25, .75));
        
        $Data =& new DataSpace();
        $Data->set('testfield', '.50');

        $this->ErrorList->expectNever('addError');
        
        $this->validator->validate($Data);
        $this->assertTrue($this->validator->IsValid());
    }
    function testNumericRangeRuleTooBigFloat() {
        $this->validator->addRule(new NumericRangeRule('testfield', .25, .75));
        
        $Data =& new DataSpace();
        $Data->set('testfield', '.90');

        $this->ErrorList->expectOnce('addError', array('validation', 'RANGE_TOO_BIG', array('Field'=>'testfield'), array('max'=>.75)));
        
        $this->validator->validate($Data);
        $this->assertFalse($this->validator->IsValid());
    }
    function testNumericRangeRuleTooSmallFloat() {
        $this->validator->addRule(new NumericRangeRule('testfield', .25, .75));
        
        $Data =& new DataSpace();
        $Data->set('testfield', '.10');

        $this->ErrorList->expectOnce('addError', array('validation', 'RANGE_TOO_SMALL', array('Field'=>'testfield'), array('min'=>.25)));
        
        $this->validator->validate($Data);
        $this->assertFalse($this->validator->IsValid());
    }
}


?>