<?php
/**
* @package WACT_TESTS
* @version $Id: componenttree.test.php,v 1.1 2003/12/08 12:11:05 jon-bangoid Exp $
*/
require_once TEST_CASES . '/template/compiler/compilerdirectivetag.test.php';

/**
* @package WACT_TESTS
*/
class ComponentTreeTestCase extends CompilerDirectiveTagTestCase {
	function ComponentTreeTestCase($name = 'ComponentTree test cases') {
		parent::CompilerDirectiveTagTestCase($name);
	}
	function setUp() {
		$this->component = & new ComponentTree();
	}
	function tearDown() {
		unset ( $this->component );
	}
	function testGetDataSpaceRefCode() {
		$this->assertEqual($this->component->getDataSpaceRefCode(),'$DataSpace');
	}
	function testGetComponentRefCode() {
		$this->assertEqual($this->component->getComponentRefCode(),'$DataSpace');
	}
	function testPreGenerate() {
		$Mock = & new MockCodeWriter($this);
		$Mock->expectAtLeastOnce('writePHP',array('$DataSpace->prepare();'));
		$this->component->preGenerate($Mock);
		$Mock->tally();
	}
	function testGetDataSpace() {
		$this->assertIsA($this->component->getDataSpace(),'ComponentTree');
	}
}
?>