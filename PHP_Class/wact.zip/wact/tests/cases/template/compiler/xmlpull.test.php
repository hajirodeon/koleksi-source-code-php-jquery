<?php
/**
* @package WACT_TESTS
* @version $Id: xmlpull.test.php,v 1.1 2003/12/08 12:11:05 jon-bangoid Exp $
*/
require_once WACT_ROOT.'/template/compiler/xmlpull.inc.php';

/**
* @package WACT_TESTS
*/
class XMLPullTestCase extends UnitTestCase {
    function XMLPullTestCase($name = 'XMLPullTestCase') {
        $this->UnitTestCase($name);
    }
    function setUp() {
    }
    function tearDown() {
    }
}
/**
* @package WACT_TESTS
* @todo Make tests much for extensive
* @todo perhaps use Mock version of PEAR::XML_HTMLSax
*/
class XMLPullParserTestCase extends UnitTestCase {
    function XMLPullParserTestCase($name = 'XMLPullParserTestCase') {
        $this->UnitTestCase($name);
    }
    function testParse () {
        $doc = 'Test';
        $parser = & new XMLPull($doc);
        $event = $parser->parse();
        $this->assertEqual($event->type(),XML_TEXT);
        $this->assertEqual($event->text(),'Test');
    }
}
/**
* @package WACT_TESTS
*/
class XMLEventTestCase extends UnitTestCase {
    function XMLEventTestCase($name = 'XMLEventTestCase') {
        $this->UnitTestCase($name);
    }
    function setUp() {
        $this->event = & new XMLEvent('test',100);
    }
    function tearDown() {
        unset ( $this->event );
    }
    function testType() {
        $this->assertEqual($this->event->type(),'test');
    }
    function testPosition() {
        $this->assertEqual($this->event->position(),100);
    }
}
/**
* @package WACT_TESTS
*/
class XMLOpenTestCase extends XMLEventTestCase {
    function XMLOpenTestCase() {
        parent::XMLEventTestCase('XMLOpenTestCase');
    }
    function setUp() {
        $this->event = & new XMLOpen('test',array('foo'=>'bar'),100,TRUE);
    }
    function tearDown() {
        unset ( $this->event );
    }
    function testTag() {
        $this->assertEqual($this->event->tag(),'test');
    }
    function testAttribs() {
        $this->assertEqual($this->event->attributes(),array('foo'=>'bar'));
    }
    function testType() {
        $this->assertEqual($this->event->type(),XML_OPEN);
    }
    function testIsEmpty() {
        $this->assertTrue($this->event->isEmpty());
    }
}
/**
* @package WACT_TESTS
*/
class XMLCloseTestCase extends XMLEventTestCase {
    function XMLCloseTestCase() {
        parent::XMLEventTestCase('XMLCloseTestCase');
    }
    function setUp() {
        $this->event = & new XMLClose('test',100,TRUE);
    }
    function tearDown() {
        unset ( $this->event );
    }
    function testTag() {
        $this->assertEqual($this->event->tag(),'test');
    }
    function testType() {
        $this->assertEqual($this->event->type(),XML_CLOSE);
    }
    function testIsEmpty() {
        $this->assertTrue($this->event->isEmpty());
    }
}
/**
* @package WACT_TESTS
*/
class XMLDataTestCase extends XMLEventTestCase {
    function XMLDataTestCase() {
        parent::XMLEventTestCase('XMLDataTestCase');
    }
    function setUp() {
        $this->event = & new XMLData('test',100);
    }
    function tearDown() {
        unset ( $this->event );
    }
    function testText() {
        $this->assertEqual($this->event->text(),'test');
    }
    function testType() {
        $this->assertEqual($this->event->type(),XML_TEXT);
    }
}
/**
* @package WACT_TESTS
*/
class XMLPITestCase extends XMLEventTestCase {
    function XMLPITestCase() {
        parent::XMLEventTestCase('XMLPITestCase');
    }
    function setUp() {
        $this->event = & new XMLPI('php','test',100);
    }
    function tearDown() {
        unset ( $this->event );
    }
    function testTarget() {
        $this->assertEqual($this->event->target(),'php');
    }
    function testInstruction() {
        $this->assertEqual($this->event->instruction(),'test');
    }
    function testType() {
        $this->assertEqual($this->event->type(),XML_PI);
    }
}
/**
* @package WACT_TESTS
*/
class XMLEscapeTestCase extends XMLEventTestCase {
    function XMLEscapeTestCase() {
        parent::XMLEventTestCase('XMLEscapeTestCase');
    }
    function setUp() {
        $this->event = & new XMLEscape('test',100);
    }
    function tearDown() {
        unset ( $this->event );
    }
    function testText() {
        $this->assertEqual($this->event->text(),'test');
    }
    function testType() {
        $this->assertEqual($this->event->type(),XML_ESCAPE);
    }
}
/**
* @package WACT_TESTS
*/
class XMLJaspTestCase extends XMLEventTestCase {
    function XMLJaspTestCase() {
        parent::XMLEventTestCase('XMLJaspTestCase');
    }
    function setUp() {
        $this->event = & new XMLJasp('test',100);
    }
    function tearDown() {
        unset ( $this->event );
    }
    function testText() {
        $this->assertEqual($this->event->text(),'test');
    }
    function testType() {
        $this->assertEqual($this->event->type(),XML_JASP);
    }
}
?>