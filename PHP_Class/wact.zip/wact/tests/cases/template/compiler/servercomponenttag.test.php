<?php
/**
* @package WACT_TESTS
* @version $Id: servercomponenttag.test.php,v 1.2 2004/01/20 12:44:22 harryf Exp $
*/
/**
* Includes
*/
require_once TEST_CASES . '/template/compiler/compilercomponent.test.php';
require_once WACT_ROOT.'/template/compiler/servercomponent.inc.php';

/**
* Make partial mock to control behaviour of getServerId which has static counter
*/
Mock::generatePartial('ServerComponentTag','ServerComponentTagTestVersion',array('getServerId'));

/**
* @package WACT_TESTS
*/
class ServerComponentTagTestCase extends CompilerComponentTestCase {
	function ServerComponentTagTestCase($name = 'ServerComponentTag test cases') {
		parent::CompilerComponentTestCase($name);
	}
	function setUp() {
		$this->component = & new ServerComponentTagTestVersion($this);
		$this->component->setReturnValue('getServerId','id001');
	}
	function tearDown() {
		unset ( $this->component );
	}
	function testGetServerId() {
		$this->assertEqual($this->component->getServerId(),'id001');
	}
	function testGetServerIdAttribute() {
		$this->assertEqual($this->component->getServerId(),'id001');
	}
	function testGetComponentRefCode() {
		$Mock = & new MockCompilerComponent($this);
		$Mock->setReturnValue('getComponentRefCode','$DataSpace');
		$this->component->parent = & $Mock;
		$this->assertEqual($this->component->getComponentRefCode(),'$DataSpace->children[\'id001\']');
	}
	function testGenerateConstructor() {
		$this->component->runtimeIncludeFile = 'testinclude.inc.php';
		$this->component->runtimeComponentName = 'testname';
		$MockCode = & new MockCodeWriter($this);
		$MockCode->expectOnce('registerInclude',array(WACT_ROOT.'testinclude.inc.php'));
		$MockCode->expectOnce('writePHP',array('$DataSpace->addChild(new testname(), \'id001\');'));
		$MockParent = & new MockCompilerComponent($this);
		$MockParent->setReturnValue('getComponentRefCode','$DataSpace');
		$this->component->parent = & $MockParent;
		$this->component->generateConstructor($MockCode);
	}
	function testGetServerIdNew() {}
	function testGetServerIdNewAgain() {}
}
?>
