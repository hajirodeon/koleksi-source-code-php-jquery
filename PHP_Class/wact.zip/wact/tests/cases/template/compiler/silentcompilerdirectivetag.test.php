<?php
/**
* @package WACT_TESTS
* @version $Id: silentcompilerdirectivetag.test.php,v 1.2 2004/01/20 12:44:22 harryf Exp $
*/
/**
* Includes
*/
require_once TEST_CASES . '/template/compiler/compilercomponent.test.php';
require_once WACT_ROOT.'/template/compiler/compilerdirective.inc.php';

/**
* Make partial mock
*/
Mock::generatePartial('SilentCompilerDirectiveTag','SilentCompilerDirectiveTagTestVersion',
	array('preGenerate','generateContents','postGenerate'));
/**
* @package WACT_TESTS
*/
class SilentCompilerDirectiveTagTestCase extends CompilerComponentTestCase {
	function SilentCompilerDirectiveTagTestCase($name = 'SilentCompilerDirectiveTag test cases') {
		$this->CompilerComponentTestCase($name);
	}
	function setUp() {
		$this->component = & new SilentCompilerDirectiveTag();
	}
	function tearDown() {
		unset ( $this->component );
	}
	function testGenerate() {
		$MockCode = & new MockCodeWriter($this);
		$MockCode->expectCallCount('writeHTML',0);
		$MockCode->expectCallCount('writePHP',0);
		$this->component->generate($MockCode);
		$MockCode->tally();
	}
	function testGenerateNow() {
		$Component = & new SilentCompilerDirectiveTagTestVersion($this);
		$Component->expectCallCount('preGenerate',1);
		$Component->expectCallCount('generateContents',1);
		$Component->expectCallCount('postGenerate',1);
		$MockCode = & new MockCodeWriter($this);
		$Component->generateNow($MockCode);
		$Component->tally();
	}
	/* Avoid re-tests for time being, as static value in memory ... */
	function testGetServerIdNew() {}
	function testGetServerIdNewAgain() {}
}
?>
