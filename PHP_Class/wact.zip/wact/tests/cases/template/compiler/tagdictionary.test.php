<?php
/**
* @package WACT_TESTS
* @version $Id: tagdictionary.test.php,v 1.1 2003/12/08 12:11:05 jon-bangoid Exp $
*/
require_once WACT_ROOT . '/common.inc.php';
require_once WACT_ROOT.'/template/compiler/tagdictionary.inc.php';
/**
* @package WACT_TESTS
* TagInfo classes have no methods so use a simple class to test
*/
class TestTagInfo {
	var $Tag = 'testtag';
}
/**
* @package WACT_TESTS
*/
class TagDictionaryTestCase extends UnitTestCase {
	function TagDictionaryTestCase($name = 'TagDictionary test cases') {
		$this->UnitTestCase($name);
	}
	function setUp() {
		$this->dict = & new TagDictionary();
		$TagInfo = new TestTagInfo();
		$this->dict->registerTag($TagInfo);
	}
	function tearDown() {
		unset ( $this->dict );
	}
	function testGetTagInfo() {
		$this->assertIsA($this->dict->getTagInfo('TeStTag'),'TestTagInfo');
	}
	function testGetTagList() {
		$testTagList = array('testtag');
		$this->assertEqual($this->dict->getTagList(),$testTagList);
	}
	function testGetInstance() {
		$this->assertIsA($this->dict->getInstance(),'TagDictionary');
	}
}
?>