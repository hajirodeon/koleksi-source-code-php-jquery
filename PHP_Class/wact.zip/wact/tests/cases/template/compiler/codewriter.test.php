<?php
/**
* @package WACT_TESTS
* @version $Id: codewriter.test.php,v 1.1 2003/12/08 12:11:05 jon-bangoid Exp $
*/
require_once WACT_ROOT . '/common.inc.php';
require_once WACT_ROOT.'/template/template.inc.php';
require_once WACT_ROOT.'/template/compiler/templatecompiler.inc.php';

require_once TEST_CASES . '/dataspace.inc.php';

/**
* @package WACT_TESTS
*/
class CodeWriterTestCase extends UnitTestCase {
	function CodeWriterTestCase($name = 'CodeWriter test cases') {
		$this->UnitTestCase($name);
	}
	function setUp() {
		$this->writer = & new CodeWriter();
	}
	function tearDown() {
		unset ( $this->writer );
	}
	function testGetCode() {
		$this->assertEqual($this->writer->getCode(),'');
	}
	function testWritePHP() {
		$this->writer->writePHP('echo ("Hello World!");');
		$this->assertEqual($this->writer->getCode(),'<?php echo ("Hello World!"); ?>');
	}
	function testWriteHTML() {
		$this->writer->writeHTML('<p>Hello World!</p>');
		$this->assertEqual($this->writer->getCode(),'<p>Hello World!</p>');
	}
	function testRegisterInclude() {
		$this->writer->registerInclude('test.php');
		$this->assertEqual($this->writer->getCode(),'<?php '."require_once 'test.php';\n".'?>');
	}
	function testBeginFunction() {
		$params = '($a,$b,$c)';
		$this->writer->beginFunction($params);
		$this->assertEqual($this->writer->getCode(),'<?php function tpl1'.$params ." {\n ?>");
	}
	function testEndFunction() {
		$this->writer->endFunction();
		$this->assertEqual($this->writer->getCode(),'<?php '." }\n".' ?>');
	}
	function testSetFunctionPrefix() {
		$this->writer->setFunctionPrefix('Test');
		$params = '($a,$b,$c)';
		$this->writer->beginFunction($params);
		$this->assertEqual($this->writer->getCode(),'<?php function tplTest1'.$params ." {\n ?>");
	}
	function testGetTempVariable() {
	    $var = $this->writer->getTempVariable();
        $this->assertWantedPattern('/[a-z][a-z0-9]*/i', $var); 
	}
	function testGetSecondTempVariable() {
	    $A = $this->writer->getTempVariable();
	    $B = $this->writer->getTempVariable();
		$this->assertNotEqual($A, $B);
	}
	function testGetTempVariablesMany() {
	    for ($i = 1; $i <= 30; $i++) {
    	    $var = $this->writer->getTempVariable();
            $this->assertWantedPattern('/[a-z][a-z0-9]*/i', $var); 
        }
    }
}
?>