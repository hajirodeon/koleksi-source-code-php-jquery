<?php
/**
* @package WACT_TESTS
* @version $Id: compilerdirectivetag.test.php,v 1.2 2004/01/20 12:44:22 harryf Exp $
*/
/**
* Includes
*/
require_once TEST_CASES . '/template/compiler/compilercomponent.test.php';
require_once WACT_ROOT.'/template/compiler/compilerdirective.inc.php';

/**
* @package WACT_TESTS
*/
if ( !class_exists('CompilerDirectiveTagTestCase') ) {
        class CompilerDirectiveTagTestCase extends CompilerComponentTestCase {
                function CompilerDirectiveTagTestCase($name = 'CompilerDirectiveTag test cases') {
                        $this->CompilerComponentTestCase($name);
                }
                /* Avoid re-tests for time being, as static value in memory ... */
                function testGetServerIdNew() {}
                function testGetServerIdNewAgain() {}
        }
}
?>
