<?php
/**
* @package WACT_TESTS
* @version $Id: compilercomponent.test.php,v 1.2 2004/01/20 12:44:22 harryf Exp $
*/
require_once WACT_ROOT . '/common.inc.php';
require_once WACT_ROOT.'/template/template.inc.php';
require_once WACT_ROOT.'/template/compiler/templatecompiler.inc.php';

require_once TEST_CASES . '/dataspace.inc.php';

/**
* @package WACT_TESTS
*/
if ( !class_exists('NullWrappingComponent') ) {
	class NullWrappingComponent {
		function generateWrapperPrefix(){}
		function generateWrapperPostfix(){}
	}
}
/**
* Generate Mocks
*/
Mock::Generate('CompilerComponent','MockCompilerComponent');
Mock::Generate('DataSpace','MockDataSpace');
Mock::Generate('CodeWriter','MockCodeWriter');
Mock::Generate('NullWrappingComponent','MockNullWrappingComponent');
/**
* @package WACT_TESTS
*/
if ( !class_exists('CompilerComponentTestCase') ) {
        class CompilerComponentTestCase extends UnitTestCase {
                function CompilerComponentTestCase($name = 'CompilerComponent test cases') {
                        $this->UnitTestCase($name);
                }
                function setUp() {
                        $this->component = & new CompilerComponent();
                }
                function tearDown() {
                        unset ( $this->component );
                }
                function testGetClientId() {
                        $this->component->setAttributes(array('id'=>'TestId'));
                        $this->assertEqual($this->component->getClientId(),'TestId');
                }
                function testGetClientIdUnset() {
                        $this->assertNull($this->component->getClientId());
                }
                function testGetServerId() {
                        $this->component->setAttributes(array('id'=>'TestId'));
                        $this->assertEqual($this->component->getServerId(),'TestId');
                }
                function testGetServerIdAttribute() {
                        $this->component->ServerId = 'Test';
                        $this->assertEqual($this->component->getServerId(),'Test');
                }
                function testGetServerIdNew() {
                        $this->assertEqual($this->component->getServerId(),'id001');
                }
                function testGetServerIdNewAgain() {
                        $this->component->getServerId();
                        $this->assertEqual($this->component->getServerId(),'id002');
                }
                function testFindChild() {
                        $mock = & new MockCompilerComponent($this);
                        $mock->setReturnValue('getServerId','Test');
                        $this->component->addChild($mock);
                        $this->assertIsA($this->component->findChild('Test'),'MockCompilerComponent');
                }
                function testFindChildNotFound() {
                        $this->assertFalse($this->component->findChild('Test'));
                }
                function testFindChildByClass() {
                        $mock = & new MockCompilerComponent($this);
                        $this->component->addChild($mock);
                        $this->assertIsA($this->component->findChildByClass('MockCompilerComponent'),'MockCompilerComponent');
                }
                function testFindChildByClassNotFound() {
                        $this->assertFalse($this->component->findChildByClass('MockCompilerComponent'));
                }
                function testFindParentByChilld() {
                        $parent = & new CompilerComponent();
                        $parent->addChild($this->component);
                        $this->assertIsA($this->component->findParentByClass('CompilerComponent'),'CompilerComponent');
                }
                function testFindParentByClassNotFound() {
                        $this->assertFalse($this->component->findParentByClass('Test'));
                }
                function testRemoveChild() {
                        $mock = & new MockCompilerComponent($this);
                        $mock->setReturnValue('getServerId','Test');
                        $this->component->addChild($mock);
                        $this->assertIsA($this->component->removeChild('Test'),'MockCompilerComponent');
                }
                function testPrepare() {
                        $child = &new MockCompilerComponent($this);
                        $this->component->addChild($child);
                        $child->expectCallCount('prepare',1);
                        $this->component->prepare();
                        $child->tally();
                }
                function testPreParse() {
                        $this->assertEqual($this->component->preParse(),PARSER_REQUIRE_PARSING);
                }
                function testGetDataSpace() {
                        $parent = &new MockCompilerComponent($this);
                        $mockds = & new MockDataSpace($this);
                        $parent->setReturnValue('getDataSpace',$mockds);
                        $this->component->parent = & $parent;
                        $this->assertIsA($this->component->getDataSpace(),'MockDataSpace');
                }
                function testGetParentDataSpace() {
                        $parent = &new MockCompilerComponent($this);
                        $mockds = & new MockDataSpace($this);
                        $testparent = & new MockCompilerComponent($this);
                        $testparent->expectCallCount('getDataSpace',1);
                        $mockds->parent = & $testparent;
                        $parent->setReturnValue('getDataSpace',$mockds);
                        $this->component->parent = & $parent;
                }
                function testGetRootDataSpace() {
                        $parent  =&new MockCompilerComponent($this);
                        $parent->parent = NULL;
                        $this->component->parent = $parent;
                        $this->assertIsA($this->component->getRootDataSpace(),'MockCompilerComponent');
                }
                function testGetDataSpaceRefCode() {
                        $parent = &new MockCompilerComponent($this);
                        $parent->setReturnValue('getDataSpaceRefCode','Test');
                        $this->component->parent = & $parent;
                        $this->assertEqual($this->component->getDataSpaceRefCode(),'Test');
                }
                function testGenerateConstructor() {
                        $code = & new MockCodeWriter($this);
                        $child = & new MockCompilerComponent($this);
                        $child->expectCallCount('generateConstructor',1);
                        $this->component->addChild($child);
                        $this->component->generateConstructor($code);
                        $child->tally();
                }
                function testGenerateContents() {
                        $code = & new MockCodeWriter($this);
                        $child = & new MockCompilerComponent($this);
                        $child->expectCallCount('generate',1);
                        $this->component->addChild($child);
                        $this->component->generateContents($code);
                        $child->tally();
                }
                function testPreGenerate() {
                        $code = & new MockCodeWriter($this);
                        $wrapper = & new MockNullWrappingComponent($this);
                        $wrapper->expectCallCount('generateWrapperPrefix',1);
                        $this->component->WrappingComponent = & $wrapper;
                        $this->component->preGenerate($code);
                        $wrapper->tally();
                }
                function testPostGenerate() {
                        $code = & new MockCodeWriter($this);
                        $wrapper = & new MockNullWrappingComponent($this);
                        $wrapper->expectCallCount('generateWrapperPostfix',1);
                        $this->component->WrappingComponent = & $wrapper;
                        $this->component->postGenerate($code);
                        $wrapper->tally();
                }
                function testGenerate(){
                        $code = & new MockCodeWriter($this);
                        $child = & new MockCompilerComponent($this);
                        $child->expectCallCount('generate',1);
                        $this->component->addChild($child);
                        $wrapper = & new MockNullWrappingComponent($this);
                        $wrapper->expectCallCount('generateWrapperPrefix',1);
                        $wrapper->expectCallCount('generateWrapperPostfix',1);
                        $this->component->WrappingComponent = & $wrapper;
                        $this->component->generate($code);
                        $child->tally();
                }
                function testGetAttribute() {
                        $this->component->setAttributes(array('foo'=>'bar'));
                        $this->assertEqual($this->component->getAttribute('foo'),'bar');
                }
                function testGetAttributeUnset() {
                        $this->assertNull($this->component->getAttribute('foo'));
                }
        }
}
?>