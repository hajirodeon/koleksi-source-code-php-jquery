<?php
/**
* @package WACT_TESTS
* @version $Id: variablereference.test.php,v 1.2 2004/01/20 12:44:22 harryf Exp $
*/
/**
* Includes
*/
require_once TEST_CASES . '/template/compiler/compilercomponent.test.php';
require_once WACT_ROOT.'/template/compiler/textnode.inc.php';

/**
* @package WACT_TESTS
* @todo Needs more extensive tests of scoping
*/
class VariableReferenceTestCase extends CompilerComponentTestCase {
	function VariableReferenceTestCase($name = 'VariableReference test cases') {
		parent::CompilerComponentTestCase($name);
	}
	function setUp() {
		$this->component = & new VariableReference();
		$this->component->reference='test';
		$this->component->scope = '$';
	}
	function tearDown() {
		unset ( $this->component );
	}
	function testGenerate() {
		$MockCode = & new MockCodeWriter($this);
		$MockCode->expectOnce('writeHTML',array('test'));
	}
	/* Avoid re-tests for time being, as static value in memory ... */
	function testGetServerIdNew() {}
	function testGetServerIdNewAgain() {}
}
/**
* @package WACT_TESTS
*/
class AttributeVariableReferenceTestCase extends VariableReferenceTestCase {
	function AttributeVariableReferenceTestCase($name = 'AttributeVariableReference test cases') {
		parent::VariableReferenceTestCase($name);
	}
	function setUp() {
		$this->component = & new AttributeVariableReference('testAttr');
	}
	function tearDown() {
		unset ( $this->component );
	}
}
?>
