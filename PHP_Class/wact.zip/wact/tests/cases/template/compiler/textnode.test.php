<?php
/**
* @package WACT_TESTS
* @version $Id: textnode.test.php,v 1.2 2004/01/20 12:44:22 harryf Exp $
*/
/**
* Includes
*/
require_once TEST_CASES . '/template/compiler/compilerdirectivetag.test.php';
require_once WACT_ROOT.'/template/compiler/textnode.inc.php';

/**
* @package WACT_TESTS
*/
class TextNodeTestCase extends CompilerDirectiveTagTestCase {
	function TextNodeTestCase($name = 'TextNode test cases') {
		parent::CompilerDirectiveTagTestCase($name);
	}
	function setUp() {
		$this->component = & new TextNode('test');
	}
	function tearDown() {
		unset ( $this->component );
	}
	function testGenerate() {
		$MockCode = & new MockCodeWriter($this);
		$MockCode->expectOnce('writeHTML',array('test'));
	}
}
/**
* @package WACT_TESTS
*/
class AttributeNodeTestCase extends CompilerDirectiveTagTestCase {
	function AttributeNodeTestCase($name = 'AttributeNode test cases') {
		parent::CompilerDirectiveTagTestCase($name);
	}
	function setUp() {
		$this->component = & new AttributeNode();
	}
	function tearDown() {
		unset ( $this->component );
	}
}
?>
