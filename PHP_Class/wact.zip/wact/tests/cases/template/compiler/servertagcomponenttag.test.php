<?php
/**
* @package WACT_TESTS
* @version $Id: servertagcomponenttag.test.php,v 1.2 2004/01/20 12:44:22 harryf Exp $
*/
/**
* Includes
*/
require_once TEST_CASES . '/template/compiler/servercomponenttag.test.php';
require_once WACT_ROOT.'/template/compiler/servertagcomponent.inc.php';
require_once WACT_ROOT.'/template/compiler/variablereference.inc.php';

/**
* Make partial mock to control behaviour of getServerId which has static counter
*/
Mock::generatePartial('ServerTagComponentTag','ServerTagComponentTagTestVersion',
	array('getServerId'));
/**
* Generate Mock AttributeVariableReference
*/
Mock::generatePartial('AttributeVariableReference','AttributeVariableReferenceTestVersion',
	array('getComponentRefCode'));

/**
* @package WACT_TESTS
*/
class ServerTagComponentTagTestCase extends ServerComponentTagTestCase {
	function ServerTagComponentTagTestCase($name = 'ServerTagComponentTag test cases') {
		parent::ServerComponentTagTestCase($name);
	}
	function setUp() {
		$this->component = & new ServerTagComponentTagTestVersion($this);
		$this->component->setReturnValue('getServerId','id001');
		$MockParent = & new MockCompilerComponent($this);
		$MockParent->setReturnValue('getComponentRefCode','$DataSpace');
		$this->component->parent = & $MockParent;
	}
	function tearDown() {
		unset ( $this->component );
	}
	function testGetRenderedTag() {
		$this->component->tag = 'test';
		$this->assertEqual($this->component->getRenderedTag(),'test');
	}
	function testGenerateExtraAttributes() {
		$MockAttr = & new AttributeVariableReferenceTestVersion($this);
		$MockAttr->setReturnValue('getComponentRefCode','$DataSpace');
		$MockAttr->name = 'foo';
		$MockAttr->reference = 'bar';
		$this->component->addChild($MockAttr);
		$MockCode = & new MockCodeWriter($this);
		$MockCode->expectCallCount('writeHTML',2);
		$MockCode->expectOnce('writePHP',array('echo(htmlspecialchars($DataSpace->get(\'bar\'), ENT_QUOTES));'));
		$this->component->generateExtraAttributes($MockCode);
		$MockCode->tally();
	}
	function testPreGenerate() {
		$MockCode = & new MockCodeWriter($this);
		$MockCode->expectCallCount('writeHTML',2);
		$MockCode->expectOnce('writePHP',array('$DataSpace->children[\'id001\']->renderAttributes();'));
		$this->component->preGenerate($MockCode);
		$MockCode->tally();
	}
	function testPostGenerate() {
		$this->component->tag = 'test';
		$this->component->hasClosingTag = TRUE;
		$MockCode = & new MockCodeWriter($this);
		$MockCode->expectOnce('writeHTML',array('</test>'));
		$this->component->postGenerate($MockCode);
		$MockCode->tally();
	}
	/**
	* @todo This test could be improved to examine the written code. Currently only checks call count
	*/
	function testGenerateConstructor() {
		$this->component->runtimeIncludeFile = 'testinclude.inc.php';
		$this->component->runtimeComponentName = 'testcomponent';
		$MockCode = & new MockCodeWriter($this);
		$MockCode->expectCallCount('writePHP',2);
		$this->component->generateConstructor($MockCode);
		$MockCode->tally();
	}
}
?>
