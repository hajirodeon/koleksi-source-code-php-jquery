<?php
/**
* @package WACT_TESTS
* @version $Id: components.test.php,v 1.1 2003/12/08 12:11:05 jon-bangoid Exp $
* @todo tests for Template and importVarFile
*/

if (!defined('DATASPACE_LOADED')) {
    require WACT_ROOT . '/util/dataspace.inc.php';
}
require_once WACT_ROOT.'/template/template.inc.php';

require_once TEST_CASES.'/dataspace.inc.php';

Mock::generate('Component', 'MockComponent');
/**
* @package WACT_TESTS
*/
class ComponentTestCase extends SharedDataSpaceTestCase {
	function ComponentTestCase($name = 'Component test cases') {
		$this->SharedDataSpaceTestCase($name);
	}
	function setUp() {
		$this->dataspace = & new Component();
	}
	function tearDown() {
		unset ( $this->dataspace );
	}
	function testGetServerID() {
		$this->dataspace->id = 'TestId';
		$this->assertEqual($this->dataspace->getServerId(),'TestId');
	}
	function testFindChild() {
		$child = & new MockComponent($this);
		$child->id = 'TestChild';
		$this->dataspace->addChild($child,'TestChild');
		$this->assertIsA($this->dataspace->findChild('TestChild'),'MockComponent');
	}
	function testFindChildNotFound() {
		$this->assertFalse($this->dataspace->findChild('TestChild'));
	}
	function testFindChildByClass() {
		$child = & new MockComponent($this);
		$this->dataspace->addChild($child,'TestChild');
		$this->assertIsA($this->dataspace->findChildByClass('MockComponent'),'MockComponent');
	}
	function testFindChildByClassNotFound() {
		$this->assertFalse($this->dataspace->findChildByClass('TestComponent'));
	}
	function testFindParentByChilld() {
		$component = & new Component();
		$component->id = 'TestParent';
		$component->addChild($this->dataspace,'TestComponent');
		$this->assertIsA($this->dataspace->findParentByClass('Component'),'Component');
	}
	function testFindParentByClassNotFound() {
		$this->assertFalse($this->dataspace->findParentByClass('TestComponent'));
	}
}

class TagComponentTestCase extends ComponentTestCase {
	function TagComponentTestCase($name = 'TagComponentTestCase') {
		$this->UnitTestCase($name);
	}
	function setUp() {
		$this->dataspace = & new TagComponent();
	}
	function testGetClientId() {
		$this->dataspace->setAttribute('id','TestId');
		$this->assertEqual($this->dataspace->getClientId(),'TestId');
	}
	function testGetClientIdUnset() {
		$this->assertNull($this->dataspace->getClientId());
	}
	function testGetAttribute() {
		$this->dataspace->setAttribute('class','Test');
		$this->assertEqual($this->dataspace->getAttribute('class'),'Test');
	}
	function testGetUnsetAttribute() {
		$this->assertNull($this->dataspace->getAttribute('class'));
	}
	function testHasAttribute() {
		$this->dataspace->setAttribute('class','Test');
		$this->assertTrue($this->dataspace->hasAttribute('class'));
	}
	function testHasAttributeUnset() {
		$this->assertFalse($this->dataspace->hasAttribute('class'));
	}
	function testRenderAttributes() {
		$this->dataspace->setAttribute('a','red');
		$this->dataspace->setAttribute('b','blue');
		$this->dataspace->setAttribute('c','green');
		ob_start();
		$this->dataspace->renderAttributes();
		$output = ob_get_contents();
		ob_end_clean();
		$this->assertEqual(' a="red" b="blue" c="green"',$output);
	}
}
?>