<?php
/**
 * @package WACT_TESTS
 * @version $Id: request.test.php,v 1.1 2003/12/08 12:11:05 jon-bangoid Exp $
 */

if (!defined('DATASPACE_LOADED')) {
    require WACT_ROOT . '/util/dataspace.inc.php';
}

require_once WACT_ROOT.'/request/getdata.inc.php';
require_once WACT_ROOT.'/request/postdata.inc.php';
require_once WACT_ROOT.'/request/cookiedata.inc.php';
require_once WACT_ROOT.'/request/uridata.inc.php';

require_once TEST_CASES.'/dataspace.inc.php';

SimpleTestOptions::ignore('RequestDataTestCase');
/**
 * @package WACT_TESTS
 */
class RequestDataTestCase extends SharedDataSpaceTestCase {
    var $dataspace;
    var $request;
    function RequestDataTestCase($name = 'RequestData test cases') {
        $this->SharedDataSpaceTestCase($name);
    }
    function setUp() {
        if (get_magic_quotes_gpc()) {
            $bar = "\'bar\'";
            $green = "\'green\'";
            $blue = '\"blue\"';
        } else {
            $bar = "'bar'";
            $green = "'green'";
            $blue = '"blue"';
        }
        $this->request = array('foox' => $bar,
                               'barx' => array('green' => $green,
                                               'blue' => $blue),
                               );
    }

    function testStripped() {
        $array = array('foox' => "'bar'",
                       'barx' => array('green' => "'green'",
                                       'blue' => '"blue"'),
                       );
        $this->assertIdentical($this->dataspace->vars, $array);
    }

    function testExport() {
        $this->dataspace->set('foo','bar');
        $expected = $this->dataspace->export();
        $this->assertIdentical($expected['foo'], 'bar');
        $this->assertIdentical($expected['foox'], "'bar'");
        $this->assertIdentical($expected['barx'], array('green' => "'green'",
                                                        'blue' => '"blue"'));
    }
}

/**
 * @package WACT_TESTS
 */
class GetDataTestCase extends RequestDataTestCase {
    function GetDataTestCase($name = 'GetData test cases') {
        $this->RequestDataTestCase($name);
    }
    function setUp() {
        parent::setUp();
        $_GET = $this->request;
        $this->dataspace =& new GetDataSpace();
    }
    function testExportEmpty() {
        $_GET = array();
        $this->dataspace =& new GetDataSpace();
        parent::testExportEmpty();
    }
}

/**
 * @package WACT_TESTS
 */
class PostDataTestCase extends RequestDataTestCase {
    function PostDataTestCase($name = 'PostData test cases') {
        $this->RequestDataTestCase($name);
    }
    function setUp() {
        parent::setUp();
        $_POST = $this->request;
        $this->dataspace =& new PostDataSpace();
    }
    function testExportEmpty() {
        $_POST = array();
        $this->dataspace =& new PostDataSpace();
        parent::testExportEmpty();
    }
}

/**
 * @package WACT_TESTS
 */
class CookieDataTestCase extends RequestDataTestCase {
    function CookieDataTestCase($name = 'CookieData test cases') {
        $this->RequestDataTestCase($name);
    }
    function setUp() {
        parent::setUp();
        $_COOKIE = $this->request;
        $this->dataspace =& new CookieDataSpace();
    }
    function testExportEmpty() {
        $_COOKIE = array();
        $this->dataspace =& new CookieDataSpace();
        parent::testExportEmpty();
    }
}

/**
 * @package WACT_TESTS
 */
class UriDataTestCase extends RequestDataTestCase {
    function UriDataTestCase($name = 'UriData test cases') {
        $this->RequestDataTestCase($name);
    }
    function setUp() {
        parent::setUp();
        $_GET = $this->request;
        $_SERVER['REQUEST_URI'] = '';
        $this->dataspace =& new UriDataSpace();
    }
    function tearDown() {
        unset($this->dataSpace);
        unset($this->request);
    }
    function testExportEmpty() {
        $_GET = array();
        $this->dataspace =& new UriDataSpace();
        parent::testExportEmpty();
    }
/*     /\* Huh? - remove this and test fails... *\/ */
/*     function testStripped() { */
/*         parent::testStripped(); */
/*     } */
    function testUriParse() {
        $_SERVER['SCRIPT_NAME']='/test.php';
        $_SERVER['REQUEST_URI']='/test.php/foo';
        $this->dataspace =& new UriDataSpace();
        $this->assertEqual('foo',$this->dataspace->get(0));
    }
    function testUriParseSlash() {
        $_SERVER['SCRIPT_NAME']='/test.php';
        $_SERVER['REQUEST_URI']='/test.php/foo/';
        $this->dataspace =& new UriDataSpace();
        $this->assertEqual('foo',$this->dataspace->get(0));
    }
    function testUriParseSlashNoSecondIndex() {
        $_SERVER['SCRIPT_NAME']='/test.php';
        $_SERVER['REQUEST_URI']='/test.php/foo/';
        $this->dataspace =& new UriDataSpace();
        $this->assertNull($this->dataspace->get(1));
    }
    function testUriMixedGet() {
        $_SERVER['SCRIPT_NAME']='/test.php';
        $_SERVER['REQUEST_URI']='/test.php/foo/bar?one=red';
        $this->dataspace =& new UriDataSpace();
        $this->assertEqual('bar',$this->dataspace->get(1));
        $this->assertNull($this->dataspace->get(2));
    }
    function testUriNull() {
        $_SERVER['SCRIPT_NAME']='/test.php';
        $_SERVER['REQUEST_URI']='/test.php';
        $this->dataspace =& new UriDataSpace();
        $this->assertNull($this->dataspace->get(0));
    }
}
?>