<?php
define('TMPL_FORCE_COMPILE', FALSE);
require '../../framework/common.inc.php';
require_once WACT_ROOT . '/template/template.inc.php';
require_once WACT_ROOT . '/util/arraydataset.inc.php';

if ( !isset ($_GET['page']) )
	$_GET['page']=1;

$Page =& new Template("/presentation.html");
$Page->import(parse_ini_file('pages/presentation.ini'));

$pages = parse_ini_file('pages/pages.ini',true);

$Page->set('PageTitle',@$pages[$_GET['page']]['Title']);
$Nav =& $Page->findChild('nav');
$Nav->setTotalItems(count($pages));
$Nav->getStartingItem(1);

$file = @file_get_contents('pages/'.@$pages[$_GET['page']]['File']);
if ( empty ( $file ) ) {
	$file = file_get_contents('pages/error.page');
}
$Page->set('Body',$file);

$Page->display();
?>
