<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT_PETSTORE
* @version $Id: catalog.php,v 1.6 2003/11/29 23:02:56 jeffmoore Exp $
*/
/**
* Framework includes
*/
require 'framework/common.inc.php';
require_once WACT_ROOT . '/template/template.inc.php';
require_once WACT_ROOT . '/controllers/getcontroller.inc.php';
/**
* Application includes
*/
require_once 'datasets/item.ds.php';
require_once 'datasets/product_category.ds.php';
require_once 'model/product_category_cache.inc.php';
require_once 'model/alternate.dec.php';
require_once 'model/yousave.dec.php';
//--------------------------------------------------------------------------------
/**
* Action Class for dealing with display of a single product
* @package WACT_PETSTORE
*/
class ViewPet {
    function performAction(&$context) {
        $Page = & new Template('/product.html');
        $DataSpace = & $context->getDataSpace();
        if ( $DataSet = & ItemDS::findById($DataSpace->get('viewpet')) ) {
            $DataSet = & new YouSave($DataSet);
            $Page->import($DataSet->export());
        } else {
            $ProductBlock = & $Page->findChild('ProductBlock');
            $ProductBlock->hide();
            $NoProductBlock = & $Page->findChild('NoProductBlock');
            $NoProductBlock->show();
        }
        $Page->display();
        return GET_COMPLETE;
    }
}
//--------------------------------------------------------------------------------
/**
* Action Class for displaying all categories, if none is provided by user
* @package WACT_PETSTORE
*/
class Categories {
    var $View;
    var $DataSpace;
    var $DataSet;
    function FetchDataSet() {
        if ( $this->DataSpace->get('order') ) {
            $this->DataSet = & ItemDs::findAll($this->DataSpace->get('order'));
        } else {
            $this->DataSet = & ItemDs::findAll();
        }
    }
    function InitializeView() {
		$this->View =& new Template("/catalog.html");
        $this->View->set('category_name','Viewing All Categories');
        $this->View->set('category_description','Use the links above to view individual categories');
        $List = & $this->View->findChild('CatalogList');
        $this->DataSet->paginate($List->findChild('pagenav'));
        $DataSet = & new AlternateDecorator($this->DataSet);
        $List->registerDataSet($DataSet);
    }
    function performAction(&$context) {
        $this->DataSpace = & $context->getDataSpace();
        $this->FetchDataSet();
        $this->InitializeView();
        $this->View->display();
        return GET_COMPLETE;
    }
}
//--------------------------------------------------------------------------------
/**
* Action Class for displaying a category
* @package WACT_PETSTORE
*/
class ViewCategory extends Categories {
    function FetchDataSet() {
        if ( $this->DataSpace->get('order') ) {
            $this->DataSet = & ItemDs::findByCategory($this->DataSpace->get('category'),
                $this->DataSpace->get('order'));
        } else {
            $this->DataSet = & ItemDs::findByCategory($this->DataSpace->get('category'));
        }
    }
    function InitializeView() {
        parent::InitializeView();
        $Category = Product_Category_Cache::findById($this->DataSpace->get('category'));
        $this->View->set('category_name',$Category->get('name'));
        $this->View->set('category_description',$Category->get('description'));
    }
}

//--------------------------------------------------------------------------------
/**
* Petstore catalog controller
* @package WACT_PETSTORE
*/
class CatalogController extends QueryStringController {
	function InitializeView() {
		$this->View =& new Template("/catalog.html");
        if ( isset($_GET['order']) ) {
            $ds = & ItemDs::findAll($_GET['order']);
        } else {
            $ds = & ItemDs::findAll();
        }
        $List = & $this->View->findChild('CatalogList');
        $ds->paginate($List->findChild('pagenav'));
        $ds = & new AlternateDecorator($ds);
        $List->registerDataSet($ds);
	}

	function InitializeActions() {
		require_once WACT_ROOT . '/validation/rules/member.inc.php';
		$CategoryRule = & new MemberRule('category',array_flip(Product_Category_Cache::getList()));
		$this->registerAction($CategoryRule, 'ViewCategory','Categories');
		$ViewPetRule = & new RequiredRule('viewpet');
		$this->registerAction($ViewPetRule, 'ViewPet');
	}
}
//--------------------------------------------------------------------------------
$Controller = new CatalogController();
$Controller->Run();
?>