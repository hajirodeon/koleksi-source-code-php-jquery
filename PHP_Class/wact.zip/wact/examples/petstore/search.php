<?php
require 'framework/common.inc.php';
require_once WACT_ROOT . '/template/template.inc.php';
require_once WACT_ROOT . '/request/getdata.inc.php';

$Get = new GetDataSpace();

$Page = & new Template('/search.html');
$List = & $Page->getChild('SearchResults');

$Page->display();
?>