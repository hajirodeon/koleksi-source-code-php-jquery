<?php
require 'framework/common.inc.php';
require_once WACT_ROOT . '/template/template.inc.php';

$Page = & new Template('/login.html');

$Page->display();
?>