# phpMyAdmin MySQL-Dump
# version 2.3.0-rc3
# http://phpwizard.net/phpMyAdmin/
# http://www.phpmyadmin.net/ (download page)
#
# Host: localhost
# Generation Time: Oct 19, 2003 at 11:37 AM
# Server version: 4.00.00
# PHP Version: 4.3.2
# Database : `petstore`
# --------------------------------------------------------

#
# Table structure for table `account`
#

CREATE TABLE account (
  account_id int(11) NOT NULL auto_increment,
  username varchar(15) NOT NULL default '',
  password varchar(15) NOT NULL default '',
  email varchar(150) NOT NULL default '',
  firstname varchar(50) NOT NULL default '',
  lastname varchar(50) NOT NULL default '',
  status smallint(6) NOT NULL default '0',
  addr1 varchar(150) NOT NULL default '',
  addr2 varchar(150) NOT NULL default '',
  city varchar(50) NOT NULL default '',
  state varchar(50) NOT NULL default '',
  country_code char(2) default NULL,
  home_phone varchar(30) NOT NULL default '',
  work_phone varchar(30) NOT NULL default '',
  mobile_phone varchar(30) NOT NULL default '',
  lang_pref char(2) NOT NULL default 'EN',
  PRIMARY KEY  (account_id)
) TYPE=MyISAM COMMENT='Customer Accounts';

#
# Dumping data for table `account`
#

# --------------------------------------------------------

#
# Table structure for table `item`
#

CREATE TABLE item (
  item_id int(11) NOT NULL auto_increment,
  product_id int(11) NOT NULL default '0',
  quantity smallint(6) NOT NULL default '0',
  listprice decimal(10,0) NOT NULL default '0',
  unitprice decimal(10,0) NOT NULL default '0',
  supplier_id int(11) NOT NULL default '0',
  status smallint(6) NOT NULL default '0',
  attr1 varchar(150) NOT NULL default '',
  attr2 varchar(150) NOT NULL default '',
  attr3 varchar(150) NOT NULL default '',
  attr4 varchar(150) NOT NULL default '',
  attr5 varchar(150) NOT NULL default '',
  PRIMARY KEY  (item_id)
) TYPE=MyISAM COMMENT='Items for Sale';

#
# Dumping data for table `item`
#

INSERT INTO item VALUES (1, 1, 2, '300', '350', 1, 0, '', '', '', '', '');
INSERT INTO item VALUES (2, 2, 1, '600', '800', 1, 0, '', '', '', '', '');
# --------------------------------------------------------

#
# Table structure for table `order`
#

CREATE TABLE orders (
  order_id int(11) NOT NULL auto_increment,
  account_id int(11) NOT NULL default '0',
  order_date int(10) NOT NULL default '0',
  ship_addr1 varchar(150) NOT NULL default '',
  ship_addr2 varchar(150) NOT NULL default '',
  ship_city varchar(50) NOT NULL default '',
  ship_state varchar(50) NOT NULL default '',
  ship_country_code char(2) default NULL,
  bill_addr1 varchar(150) NOT NULL default '',
  bill_addr2 varchar(150) NOT NULL default '',
  bill_city varchar(50) NOT NULL default '',
  bill_state varchar(50) NOT NULL default '',
  bill_country_code char(2) default NULL,
  PRIMARY KEY  (order_id)
) TYPE=MyISAM COMMENT='Details of the Order Itself';

#
# Dumping data for table `order`
#

# --------------------------------------------------------

#
# Table structure for table `order_item`
#

CREATE TABLE order_item (
  order_item_id int(11) NOT NULL auto_increment,
  order_id int(11) NOT NULL default '0',
  item_id int(11) NOT NULL default '0',
  unit_price varchar(11) NOT NULL default '',
  quantity smallint(6) NOT NULL default '0',
  PRIMARY KEY  (order_item_id)
) TYPE=MyISAM COMMENT='Details of Items within an Order';

#
# Dumping data for table `order_item`
#

# --------------------------------------------------------

#
# Table structure for table `order_status`
#

CREATE TABLE order_status (
  order_status_id int(11) NOT NULL auto_increment,
  order_item_id int(11) NOT NULL default '0',
  status_date int(10) NOT NULL default '0',
  status text NOT NULL,
  PRIMARY KEY  (order_status_id)
) TYPE=MyISAM COMMENT='Current Status of an Order';

#
# Dumping data for table `order_status`
#

# --------------------------------------------------------

#
# Table structure for table `product`
#

CREATE TABLE product (
  product_id int(11) NOT NULL auto_increment,
  product_category_id varchar(10) NOT NULL default '0',
  name varchar(150) NOT NULL default '',
  description text,
  image_name varchar(100) NOT NULL default '',
  PRIMARY KEY  (product_id)
) TYPE=MyISAM COMMENT='Products in shop';

#
# Dumping data for table `product`
#

INSERT INTO product VALUES (1, 'birds', 'Kentucky Chicken', '...with a crispy coating', 'bird1.gif');
INSERT INTO product VALUES (2, 'birds', 'Tweeties', 'I tawt I taw a puddy cat', 'bird2.gif');
# --------------------------------------------------------

#
# Table structure for table `product_category`
#

CREATE TABLE product_category (
  product_category_id varchar(10) NOT NULL default '',
  name varchar(150) NOT NULL default '',
  description text,
  PRIMARY KEY  (product_category_id),
  UNIQUE KEY product_category_id (product_category_id)
) TYPE=MyISAM COMMENT='Product Categories';

#
# Dumping data for table `product_category`
#

INSERT INTO product_category VALUES ('fish', 'Fish', 'They stink');
INSERT INTO product_category VALUES ('dogs', 'Dogs', 'Mans best friend');
INSERT INTO product_category VALUES ('reptiles', 'Reptiles', 'You\'ll probably find your manager somewhere here...');
INSERT INTO product_category VALUES ('cats', 'Cats', 'Womans best friend...');
INSERT INTO product_category VALUES ('birds', 'Birds', 'What really happened to the dinosaurs...');
# --------------------------------------------------------

#
# Table structure for table `supplier`
#

CREATE TABLE supplier (
  supplier_id int(11) NOT NULL auto_increment,
  username varchar(15) NOT NULL default '',
  password varchar(15) NOT NULL default '',
  email varchar(150) NOT NULL default '',
  name varchar(50) NOT NULL default '',
  status smallint(6) NOT NULL default '0',
  addr1 varchar(150) NOT NULL default '',
  addr2 varchar(150) NOT NULL default '',
  city varchar(50) NOT NULL default '',
  state varchar(50) NOT NULL default '',
  country_code char(2) default NULL,
  contact_phone varchar(30) NOT NULL default '',
  PRIMARY KEY  (supplier_id)
) TYPE=MyISAM COMMENT='Supplier Information';

#
# Dumping data for table `supplier`
#


