<?php
require 'framework/common.inc.php';
require_once WACT_ROOT . '/template/template.inc.php';

if ( isset($_GET['action']) && $_GET['action'] == 'confirm' ) {
    $Page = & new Template('/confirm.html');
} else {
    $Page = & new Template('/checkout.html');
}

$Page->display();
?>