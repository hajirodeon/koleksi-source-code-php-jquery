<?php
require '../../framework/common.inc.php';
require WACT_ROOT . '/template/template.inc.php';

$Page =& new Template('/dataspace/dataspace.html');
$Page->display();

?>
