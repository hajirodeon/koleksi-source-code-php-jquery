<?php
require '../../framework/common.inc.php';

require_once WACT_ROOT . '/template/template.inc.php';

require_once WACT_ROOT . '/controllers/formcontroller.inc.php';

//--------------------------------------------------------------------------------
class AddAddress {

	function performAction(&$context) {
		$DataSpace =& $context->getDataSpace();
		$Page =& new Template('/errorsummary/thanks.html');
		$Page->import($DataSpace->export());
		$Page->display();
		return FORM_COMPLETE;
	}
	
}

//--------------------------------------------------------------------------------
class AddressForm extends PostFormController {

	function InitializeActions() {
		$this->registerSubmitAction('submit', 'AddAddress', PRE_VALID);
		$this->registerDefaultSubmitAction('AddAddress', PRE_VALID); 

        // The Default Submit Action will not work correctly unless all
        // buttons on the form have a corresponding action registered.
        // Even if that action does nothing.
	    $this->registerSubmitAction('preview', 'NoAction');
	}
     
    function InitializeValidator() {
		$this->Validator =& new Validator();
		$this->Validator->addRule(new RequiredRule('FirstName'));
		$this->Validator->addRule(new RequiredRule('LastName'));
		$this->Validator->addRule(new SizeRangeRule('FirstName', 2, 15));
		$this->Validator->addRule(new SizeRangeRule('LastName', 2, 20));
    }
    
    function InitializeView() {
 		$this->View =& new Template('/errorsummary/errorsummary.html');
     }

    function onPreview() {
		$View =& $this->getView();
		$block =& $View->getChild('Preview');
		$block->show();
    }
     
}

//--------------------------------------------------------------------------------
$Form = new AddressForm();
$Form->Run();

?>
