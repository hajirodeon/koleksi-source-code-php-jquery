<?php
require '../../framework/common.inc.php';
require_once WACT_ROOT . '/template/template.inc.php';

$Page =& new Template('/calendar.html');

switch (@$_GET['action']) {
	case 'hideCal':
		$Cal = & $Page->findChild('MyCal');
		$Cal->hide();
	break;
	case 'hideCalTitle':
		$CalTitle = & $Page->findChild('MyCalTitle');
		$CalTitle->hide();
	break;
	case 'hideCalHeader':
		$CalHeader = & $Page->findChild('MyCalHeader');
		$CalHeader->hide();
	break;
	case 'hideCalNextPrev':
		$CalNextPrev = & $Page->findChild('MyCalNextPrev');
		$CalNextPrev->hide();
	break;
}
$Page->display();
?>