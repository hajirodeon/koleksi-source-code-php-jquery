<?php
require '../../framework/common.inc.php';
require_once WACT_ROOT . '/template/template.inc.php';
require_once WACT_ROOT . '/controllers/formcontroller.inc.php';

//--------------------------------------------------------------------------------
class RegisterUser {

	function performAction(&$context) {
		$DataSpace =& $context->getDataSpace();
		$Page =& new Template('/input/thanks.html');
		$Page->import($DataSpace->export());
		$Page->display();
		return FORM_COMPLETE;
	}
	
}

//--------------------------------------------------------------------------------
class AddressForm extends PostFormController {

	function initializeDataSpace() {
		// We have to set an initial value for the radio buttons
		$this->DataSpace = new DataSpace();
		$this->DataSpace->set('frequency', 'occasionally'); 
	}

    function InitializeView() {
 		$this->View =& new Template("/input/input.html");
    }

	function InitializeActions() {
		$this->registerSubmitAction("register", "RegisterUser", PRE_VALID); 
		$this->registerDefaultSubmitAction("RegisterUser", PRE_VALID); 
	}

    function InitializeValidator() {
		$this->Validator =& new Validator();
    	require_once WACT_ROOT . '/validation/rules/match.inc.php';    	
    	require_once WACT_ROOT . '/validation/rules/member.inc.php';

		$this->Validator->addRule(new RequiredRule('username'));

		$this->Validator->addRule(new RequiredRule('password'));
		$this->Validator->addRule(new RequiredRule('passwordconfirm'));
		$this->Validator->addRule(new SizeRangeRule("password", 6, 15));
		$this->Validator->addRule(new SizeRangeRule("passwordconfirm", 6, 15));
		$this->Validator->addRule(new MatchRule('password', 'passwordconfirm'));

		// Set an internationalizable custom error message for this rule:
		$rule =& new RequiredRule('terms');
		$rule->setGroup('inputexample');
		$this->Validator->addRule($rule);

		// Double check our radio buttons to make sure that the value is valid.
		// They only time these rules should ever fail is due to one of the following:
		// a programming error
		// an error in the HTML template
		// garbled communications at the HTTP level
		// a browser that does not follow the HTML specifications
		// a hacking attempt.
		$this->Validator->addRule(new RequiredRule('frequency'));
		$this->Validator->addRule(
			new MemberRule('Frequency', 
				array_flip(array('occasionally', 'regularly', 'excessive'))));
    }
     
}

//--------------------------------------------------------------------------------
$Form = new AddressForm();
$Form->Run();

?>
