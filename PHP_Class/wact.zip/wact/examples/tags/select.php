<?php
require '../../framework/common.inc.php';
require_once WACT_ROOT . '/template/template.inc.php';
require_once WACT_ROOT . '/controllers/formcontroller.inc.php';

//--------------------------------------------------------------------------------
class AddressForm extends PostFormController {

    function InitializeView() {
 		$this->View =& new Template("/select/select.html");
 		$Country =& $this->View->getChild('Country');
 		$Country->setChoices(importVarFile('/select/countrylist.vars'));
     }
     
}

//--------------------------------------------------------------------------------
$Form = new AddressForm();
$Form->Run();

?>
