<?php
require '../../framework/common.inc.php';
require WACT_ROOT . '/template/template.inc.php';

$Page =& new Template('/varref.html');
$Page->set('Reference', "This is a variable reference");
$Page->display();
?>
