<?php
require '../../framework/common.inc.php';
require WACT_ROOT . '/template/template.inc.php';
require WACT_ROOT . '/util/arraydataset.inc.php';

class CapitalizeFilter {
	function doFilter(&$vars){
	    $vars['Last'] = strtoupper($vars['Last']);
	}
}

$FoundingFathers = 
    array(  array('First' => 'George', 'Last' => 'Washington'), 
            array('First' => 'Alexander', 'Last' => 'Hamilton'),
            array('First' => 'Benjamin', 'Last' => 'Franklin'));

$DataSet =& new ArrayDataSet($FoundingFathers);
$DataSet->registerFilter(new CapitalizeFilter());

$Page =& new Template('/list.html');

$List =& $Page->getChild('ListExample1');
$List->registerDataSet($DataSet);

$List =& $Page->getChild('ListExample2');
$List->registerDataSet($DataSet);

$Page->display();
?>
