<?php
require '../../framework/common.inc.php';
require WACT_ROOT . '/template/template.inc.php';

$Page =& new Template('/block.html');
$block =& $Page->getChild('Block3');
$block->show();
$Page->display();

?>
