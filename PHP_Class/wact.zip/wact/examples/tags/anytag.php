<?php
require '../../framework/common.inc.php';
require WACT_ROOT . '/template/template.inc.php';
require_once WACT_ROOT . '/template/compiler/templatecompiler.inc.php';
require WACT_ROOT . '/template/tags/any/anytag.tag.php';
require WACT_ROOT . '/template/tags/any/register/html.tag.php';

$Page =& new Template('/anytag.html');

if ( isset ($_GET['img']) ) {
	$Img = & $Page->getChild('MyImg');
	switch ( strtolower($_GET['img']) ) {
		case 'php':
			$Img->setAttribute('src','http://ch.php.net/images/php.gif');
		break;
		case 'mysql':
			$Img->setAttribute('src','http://www.mysql.com/images/poweredbymysql-125.png');
		break;
	}
}

$FoundingFathers = 
	array(	array( 'George',  'Washington'), 
			array( 'Alexander', 'Hamilton'), 
			array( 'Benjamin', 'Franklin'));

$Table = & $Page->getChild('MyTable');

foreach ( $FoundingFathers as $key => $FoundingFather ) {
	$Row = & new TagContainerWidget('tr');
	$size = count($FoundingFather);
	for ( $i = 0;$i<$size;$i++ ) {
		$Cell = & new TagContainerWidget('td');
		$Text = & new TextWidget($FoundingFather[$i]);
		$Cell->addChild($Text);
		$Row->addChild($Cell);
	}
	$Table->addChild($Row);
}
$Page->display();
?>