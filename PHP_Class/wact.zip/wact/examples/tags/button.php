<?php
require '../../framework/common.inc.php';
require_once WACT_ROOT . '/template/template.inc.php';

require_once WACT_ROOT . '/controllers/formcontroller.inc.php';

//--------------------------------------------------------------------------------
class ConvertToLower  {

	function performAction(&$context) {
		$DataSpace =& $context->getDataSpace();
		$DataSpace->set('Text', strtolower($DataSpace->get('Text')));
	}
}

//--------------------------------------------------------------------------------
class ConvertToUpper {

	function performAction(&$context) {
		$DataSpace =& $context->getDataSpace();
		$DataSpace->set('Text', strtoupper($DataSpace->get('Text')));
	}
	
}

//--------------------------------------------------------------------------------
class AddressForm extends PostFormController {

	function InitializeActions() {
		$this->registerSubmitAction("upper", "ConvertToUpper"); 
		$this->registerSubmitAction("lower", "ConvertToLower"); 
	}
     
    function InitializeView() {
 		$this->View =& new Template("/textarea.html");
     }
     
}

//--------------------------------------------------------------------------------
$Form = new AddressForm();
$Form->Run();

?>
