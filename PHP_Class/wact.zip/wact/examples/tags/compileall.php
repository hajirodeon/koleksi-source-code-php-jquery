<?php
require '../../framework/common.inc.php';
require WACT_ROOT . '/template/template.inc.php';
require WACT_ROOT . '/template/compiler/compileall.inc.php';

echo 'Compiling all templates...';
CompileAll();
echo 'Done.';
?>
