<?php
require '../../framework/common.inc.php';
require WACT_ROOT . '/template/template.inc.php';
require WACT_ROOT . '/request/getdata.inc.php';

// Initialize $_GET['page']
if ( !isset($_GET['page']) )
	$_GET['page']=1;
$GetDataSpace = new GetDataSpace();

$Page =& new Template('/outputcache.html');
$Page->set('Time',date('H:i:s'));
$Page->set('Page',$_GET['page']);

$Cache2 = & $Page->getChild('Cache2');
$Cache2->import($GetDataSpace->export());

if ( $GetDataSpace->get('flush') == 1 ) {
	$Cache2->flushGroup();
}

// Some HTTP client side caching, to save on bandwidth - this might eventually
// become a runtime component as well...

// Get the other two cache components
$caches = array();
$caches['Cache1'] = & $Page->getChild('Cache1');
$caches['Cache2'] = & $Cache2;
$caches['Cache3'] = & $Page->getChild('Cache3');

// Find the most recent modification time of all three caches
$lastModified = 1;
foreach ( array_keys($caches) as $key ) {
	if (($cacheModified=$caches[$key]->lastModified()) > $lastModified)
		$lastModified = $cacheModified;
}

// Issue an HTTP last modified header
header ( 'Last-Modified: '.
    gmdate('D, d M Y H:i:s',$lastModified).' GMT');

// Get client headers - Apache only
$request = getallheaders();

// Check to see if the client sent the If-Modified-Since header
if ( isset($request['If-Modified-Since']) ) {
	// Split the If-Modified-Since (Netscape < v6 sends this incorrectly)
	$modifiedSince = explode(';', $request['If-Modified-Since']);
	// Turn the client request If-Modified-Since into a timestamp
	$modifiedSince = strtotime($modifiedSince[0]);

    if ($lastModified <= $modifiedSince) {
        // Save on some bandwidth!
        header('HTTP/1.0 304 Not Modified');
        die();
    }
}

$Page->display();
?>