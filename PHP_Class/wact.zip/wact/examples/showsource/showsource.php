<?php

// Crude.

require '../../framework/common.inc.php';

require WACT_ROOT . '/template/template.inc.php';

function contains($str, $sub) {
    return gettype(strpos($str, $sub)) == "integer";
}

$file = $_GET['file'];

if (contains($file, "..") || contains($file, "//")) {
    exit;
}

if (substr($file, 0, 1) == '/') {
    exit;
}

if (substr_count($file, '.') > 1) {
    exit;
}

if (contains($file, "compiled")) {
    exit;
}

if (substr($file, -5) != '.html' && substr($file, -5) != '.vars' && substr($file, -4) != '.php') {
    exit;
}

if (contains($file, 'showsource')) {
    exit;
}


$filename = '../../examples/' . $file;
$filecontents = file_get_contents($filename,1);

$filecontents = str_replace('wacky', '******', $filecontents);

$Page =& new Template('/phpfile.html');
$Page->set('Filename', $file);

// Dodgy hack for older PHP versions
ob_start();
highlight_string( $filecontents );
$highlighted_string = ob_get_contents();
ob_end_clean();

$Page->set('SourceCode', $highlighted_string);
$Page->display();
?>
