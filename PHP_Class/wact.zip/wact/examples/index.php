<?php
require '../framework/common.inc.php';
require_once WACT_ROOT . '/template/template.inc.php';
require_once WACT_ROOT . '/util/arraydataset.inc.php';

/**
* HOW TO ADD EXAMPLES
*
* To add a new examples directory;
* 1. Modify the $dirs array below
* 2. Update the ini/exampledirs.ini file to provide details of the new
*    directory on the main index page
* 3. Create a ini file in the ./ini subdir, with the same name as the new
*    directory. See the other ini files to see what the file must contain
*
* To add a new example to a directory;
* 1. Find the ini file for that directory in ./ini
* 2. Create a new entry in the ini file for the example
* 3. Create a new ini file in ./ini/{$exampledir} e.g. ./ini/demoapp/ with
*    the name specified in the first ini file. This second ini file contains
*    the file names of all source files used in the example
*/

$dirs = array (
	'Basic Tags'=>'tags',
	'Simple App'=>'demoapp',
	'DB Adapters'=>'dbadapters',
	'Forms'=>'forms',
	'Internationalization'=>'i18n',
	'ASP.NET Compatibility'=>'dotnet',
	'Presentation System'=>'presentation',
);

if ( isset ( $_GET['dir'] ) && in_array($_GET['dir'],$dirs ) ) {
	$exampleset = new ArrayDataSet(getConfigOption('ini/'.$_GET['dir']));
	$Page =& new Template('/example.html');
	$examplesarray = getConfigOption('ini/'.$_GET['dir']);
	$keys = array_keys($examplesarray);
	foreach ( $keys as $key ) {
		$filenames = parse_ini_file('ini/'.$_GET['dir'].'/'.$examplesarray[$key]['ini']);
		$srcfiles = "<ul>\n";
		foreach ( $filenames as $filename ) {
			$srcfiles.="<li><a href=\"showsource/showsource.php?file={$_GET['dir']}/$filename\">$filename</a></li>\n";
		}
		$srcfiles .= "</ul>\n";
		$examplesarray[$key]['files'] = $srcfiles;
	}
	$examples =& new ArrayDataSet($examplesarray);

	$Examples = & $Page->getChild('Examples');
	$Examples->registerDataSet($examples);
	$flip_dirs = array_flip($dirs);
	$title = $flip_dirs[$_GET['dir']];
	$nav = array (
		array('title'=>$title,'url'=>'?dir='.$_GET['dir'])
	);
	$Crumbs = & $Page->getChild('Crumbs');
	$Crumbs->registerDataSet(new ArrayDataSet($nav));
	$Page->set('compileUrl',$_GET['dir'].'/compileall.php');
} else {
	$exampleset = new ArrayDataSet(getConfigOption('ini/exampledirs'));
	$Page =& new Template('/index.html');
	$Dirs = & $Page->getChild('ExampleDirs');
	$Dirs->registerDataSet($exampleset);
}
$Page->display();
?>
