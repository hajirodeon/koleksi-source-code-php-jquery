<?php
require_once '../../../framework/common.inc.php'; /* Your path to WACT may differ... */
require_once WACT_ROOT . '/template/template.inc.php'; /* Include the base WACT template system */

$feed =& new Template('/hello-world.3.html'); /* generate a template object from a template file */
$feed->display();               /* display the rendered template */
?>