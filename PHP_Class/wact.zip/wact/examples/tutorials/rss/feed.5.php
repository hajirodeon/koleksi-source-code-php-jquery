<?php
require_once '../../../framework/common.inc.php'; /* Your path to WACT may differ... */
require_once WACT_ROOT . '/template/template.inc.php'; /* Include the base WACT template system */
require_once WACT_ROOT . '/util/arraydataset.inc.php'; /* Include WACT ArrayDataSet */

$items_array = array(0 => array('itemlink' => 'http://www.example.com/item.1',
                                'itemtitle' => 'The first item in my feed.',
                                'itemdescription' => "This is the first item in my rilly cool feed. Don't you agree, it is very cool?"),
                     1 => array('itemlink' => 'http://www.example.com/item.2',
                                'itemtitle' => 'The second item in my feed.',
                                'itemdescription' => 'Like I say, this feed is just so cool.'),
                     2 => array('itemlink' => 'http://www.example.com/item.3',
                                'itemtitle' => 'The third item in my feed.',
                                'itemdescription' => 'I feel like I have a lot to offer. Oh by the way, Hello, World!'));
$items_recordset =& new ArrayDataSet($items_array);


$feed =& new Template('/rss1-0.2.rdf'); /* generate a template object from a template file */
$feed->set('xml', '<?xml version="1.0"?>'); /* set the xml header, to avoid php <? confusion */

/* set the feed publication date (i.e. now) */
putenv("TZ=UTC");
$tstamp = strftime("%Y-%m-%dT%H:%M:%SZ");
$feed->set('feedpublicationdate', $tstamp);

/* set up the items lists */
$items_menu =& $feed->getChild('itemsmenu');
$items_menu->registerDataSet($items_recordset);
$items =& $feed->getChild('items');
$items->registerDataSet($items_recordset);

header("Content-Type: application/xml"); /* set the content type to get nicer output in browsers */
$feed->display();               /* display the rendered template */
?>