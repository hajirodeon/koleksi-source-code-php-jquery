<?php
require_once '../../../framework/common.inc.php'; /* Your path to WACT may differ... */
require_once WACT_ROOT . '/template/template.inc.php'; /* Include the base WACT template system */

$feed =& new Template('/rss1-0.1.rdf'); /* generate a template object from a template file */
$feed->set('xml', '<?xml version="1.0"?>'); /* set the xml header, to avoid php <? confusion */

/* set the feed publication date (i.e. now) */
putenv("TZ=UTC");
$tstamp = strftime("%Y-%m-%dT%H:%M:%SZ");
$feed->set('feedpublicationdate', $tstamp);

header("Content-Type: application/xml"); /* set the content type to get nicer output in browsers */
$feed->display();               /* display the rendered template */
?>