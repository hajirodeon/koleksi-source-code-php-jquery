#!/bin/sh

# Create directories for storing compiled templates.

# Author: Jonathon Ramsey <jon@bangoid.com>
# This file is released under the LGPL license. See the file LICENSE in the root
# of the distribution for details.
# $Id: setup.sh,v 1.3 2003/12/11 19:53:34 jon-bangoid Exp $

cache_dir="cache";
templates_dir="templates";
compiled_dir="compiled";

writableDirSetup() {
    for i in *; do
        if [ -d "$i" ]; then
            cd "$i";
            if [[ "$i" == $templates_dir ]]; then
                compiledSetup;
            elif [[ "$i" == $cache_dir ]]; then
                chmod 777 .;
            fi
            writableDirSetup;
            cd ..
        fi
    done
    return 0;
}

compiledSetup() {
    if [ ! -e "`pwd`/$compiled_dir" ]; then
        mkdir $compiled_dir;
    fi
    chmod 0777 $compiled_dir;
    return 0;
}

cat <<EOF

The WACT templating system requires PHP writeable directories
(templates/compiled and cache) to store its compiled templates and output
caches.

This script sets up the required directories so that the examples and unit
tests will run correctly.  The required directories are set up as WORLD
writeable. You may prefer to change them to OWNER+GROUP writeable, with
their GROUP set to that of your webserver.

EOF
writableDirSetup;
if [ 0 -eq $? ]; then
    echo "The WACT examples are now all set up and ready to roll. Have fun.";
else
    cat <<EOF
Something has gone wrong. The end result was supposed to be a
'$compiled_dir' directory under every '$templates_dir' directory, and
several '$cache_dir', directories, all with permissions set to 777.

Sorry. Please patch the script and let us know.

EOF
fi
exit 0;
