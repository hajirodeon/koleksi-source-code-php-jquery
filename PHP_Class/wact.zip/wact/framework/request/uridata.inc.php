<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT_REQUEST
* @version $Id: uridata.inc.php,v 1.4 2003/12/07 01:09:51 harryf Exp $
*/
//--------------------------------------------------------------------------------
/**
* Include GetDataSpace
*/
require_once WACT_ROOT . '/request/getdata.inc.php';
//--------------------------------------------------------------------------------
/**
* Acts as a reader and filter for incoming URI variables which appear to the right
* of the script being executed and to the left of the first ? in the URL. Stores
* the values in the Dataspace by numeric index from left to right.<br>
* A Url like http://example.com/page.php/foo/bar?action=view/red/green will result
* in a DataSpace like;<br>
* <pre>
* Array
*  (
*     [action] => view/red/green
*     [0] => foo
*     [1] => bar
*  )
* </pre>
* Note that "parsing" on the URL into an indexed array stops after a URI is
* encountered that contains any of ?, & or =<br>
* Note this should produce the same behaviour with Apache re-writing or force type.
* The following Apache directory configurations have been tested;
* <pre>
* RewriteEngine On
* RewriteRule !(\.gif|\.jpe?g|\.css|\.php)$ index.php [NC,L]
* </pre>
* <pre>
* <Files index>
*    ForceType application/x-httpd-php
* </Files>
* DirectoryIndex index
* </pre>
* @see http://wact.sourceforge.net/index.php/UriDataSpace
* @access public
* @package WACT_REQUEST
*/
class UriDataSpace extends GetDataSpace {
	/**
	* This method intentionally does not retain references to $_GET elements.
	* @access public
	*/
	function UriDataSpace() {
		parent::GetDataSpace();
		$pathVars = $this->parseUrl();
		$strip = get_magic_quotes_gpc();
		foreach($pathVars as $value) {
			// This may not be necessary - will magic quotes quote that kind of URL?
			$value = ($strip) ? stripslashes($value) : $value;
			$this->vars[] = $value;
		}
	}
	/**
	* Parses the url
	* @return array
	* @access private
	*/
	function parseUrl () {
		$basePath = explode('/',$_SERVER['SCRIPT_NAME']);
		$script = array_pop($basePath);
		$basePath = implode('/',$basePath);
		if ( false !== strpos ( $_SERVER['REQUEST_URI'], $script ) ) {
			$uriPath = explode( $script,$_SERVER['REQUEST_URI'] );
			$uriPath = $uriPath[1];
		} else {
			$pattern = '/^'.str_replace('/','\/',$basePath).'/';
			$uriPath = preg_replace($pattern,'',$_SERVER['REQUEST_URI']);
		}
		$vars = explode('/',$uriPath);
		$pathVars = array();
		foreach ($vars as $var) {
			if ( $var == '' )
				continue;
			if ( strstr ($var,'?') ) {
				$var = explode('?',$var);
				if ( trim($var[0] != '' ) )
					$pathVars[] = $var[0];
				break;
			}
			if ( strstr ($var,'=') )
				break;
			if ( strstr ($var,'&') )
				break;
			$pathVars[]=$var;
		}
		return $pathVars;
	}
}
?>