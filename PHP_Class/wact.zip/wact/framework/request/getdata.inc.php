<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT_REQUEST
* @version $Id: getdata.inc.php,v 1.10 2003/12/07 01:09:51 harryf Exp $
*/
//--------------------------------------------------------------------------------
/**
* Load dataspace
*/
if (!defined('DATASPACE_LOADED')) {
    require WACT_ROOT . '/util/dataspace.inc.php';
}

/**
* Acts as filter for incoming HTTP GET variables, eliminating magic_quotes if found
* @see http://wact.sourceforge.net/index.php/GetDataSpace
* @access public
* @package WACT_REQUEST
*/
class GetDataSpace extends DataSpace {
	/**
	* Assumes that all GET variables are strings,
	* unless they are arrays of strings.  This assumption is unverified.
	* This method intentionally does not retain references to $_GET elements.
	* @access public
	*/
	function GetDataSpace() {
		$strip = get_magic_quotes_gpc();
		foreach($_GET as $name => $value) {
			if (is_array($value)) {
				foreach($value as $key => $data) {
					$value[$key] = ($strip) ? stripslashes($data) : $data;
				}
			} else {
        $value = ($strip) ? stripslashes($value) : $value;
      }
			$this->vars[$name] = $value;
		}
	}
}
?>