<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT
* @version $Id: common.inc.php,v 1.25 2003/12/09 10:04:11 jeffmoore Exp $
*/
/**
* Define WACT_ROOT, set error reporting and determine PHP version
*/
define('WACT_ROOT', dirname(__FILE__) . '/');

// we run best (fastest) in php 4.3, but we can run as far back as 4.1.0
/**
* Load PHP 4.2 support if necessary
*/
if (version_compare(phpversion(), '4.2', '<')) {
    require WACT_ROOT . '/util/php42.php';
}
/**
* Load PHP 4.3 support if necessary
*/
if (version_compare(phpversion(), '4.3', '<')) {
    require WACT_ROOT . '/util/php43.php';
}
/**
* Define global configuration settings array
*/
$ConfigurationSettings = array();

//--------------------------------------------------------------------------------
/**
* Represents a framework error
* @see http://wact.sourceforge.net/index.php/ErrorInfo
* @access protected
* @package WACT
*/
class ErrorInfo {
    var $group;
    var $id;
    var $info;
}

//--------------------------------------------------------------------------------
/**
* Raise an error message.  All framework error messages should be triggered using
* this function.  This allows for framework error messages to be internationalized.
*/
function RaiseError($group, $id, $info=NULL) {
    $errobj =& new ErrorInfo();
    $errobj->group = $group;
    $errobj->id = $id;
    $errobj->info = $info;
    trigger_error(serialize($errobj), E_USER_ERROR);
}

//--------------------------------------------------------------------------------
/** Standard error handler checks for error suppression and delegates actual error
** handling when a real error occurrs.
*/
function ErrorHandlerDispatch($ErrorNumber, $ErrorMessage, $FileName, $LineNumber) {

    if ( ( $ErrorNumber & error_reporting() ) != $ErrorNumber ) { 
        return; // Ignore this error because of error suppression
    }
    
    // If we are here, an error really did take place.  load an appropriate error
    // handler.  Future versions should allow configuration of which error handler
    // to load.
    require_once(WACT_ROOT . 'util/debugerrorhandler.inc.php');   
    HandleError($ErrorNumber, $ErrorMessage, $FileName, $LineNumber);
}
if (! defined('WACT_ERROR_HANDLER')) {
    define('WACT_ERROR_HANDLER', 'ErrorHandlerDispatch');
}
set_error_handler(WACT_ERROR_HANDLER);

//--------------------------------------------------------------------------------
/**
* Fetches a configuration option depending on supplied arguments.
* @see http://www.php.net/parse_ini_file
* @param string filename of ini file
* @param string section of ini
* @param string name of element in section
* @return string value of element
* @access public
*/
function getConfigOption($file, $section=false, $key=false) {
    global $ConfigurationSettings;
    if (!isset($ConfigurationSettings[$file])) {
        $configvalues = NULL;
        if (defined('WACT_CONFIG_DIRECTORY')) {
            $configvalues = @parse_ini_file(WACT_CONFIG_DIRECTORY . '/' .
                                            $file . '.ini', TRUE);
        }
        if (!is_array($configvalues)) {
            $configvalues = @parse_ini_file(dirname($_SERVER['SCRIPT_FILENAME']) .
                                            '/' . $file . '.ini', TRUE);
        }
        if (!is_array($configvalues)) {
            $configvalues = @parse_ini_file(dirname(__FILE__) . '/' .
                                            $file . '.ini', TRUE);
        }
        if (!is_array($configvalues)) {
            RaiseError('compiler', 'VALUENOTFOUND', array(
                'file' => $file,
                'section' => $section, 
                'key' => $key));
        }
        $ConfigurationSettings[$file] = $configvalues;
    }
    if ( $section && $key ) {
        return @$ConfigurationSettings[$file][$section][$key];
    } else if ( $section ) {
        return @$ConfigurationSettings[$file][$section];
    } else {
        return @$ConfigurationSettings[$file];
    }
}

?>