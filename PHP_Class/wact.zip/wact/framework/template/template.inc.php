<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT_TEMPLATE
* @version $Id: template.inc.php,v 1.23 2003/12/07 02:29:31 harryf Exp $
*/
//--------------------------------------------------------------------------------
/**
* Include dataspace as required
*/
if (!defined('DATASPACE_LOADED')) {
    require WACT_ROOT . '/util/dataspace.inc.php';
}

/**
* @see ResolveTemplateCompiledFileName
* @see ResolveTemplateSourceFileName
*/
define('TMPL_IMPORT', 'import');
/**
* @see ResolveTemplateCompiledFileName
* @see ResolveTemplateSourceFileName
*/
define('TMPL_INCLUDE', 'include');
//--------------------------------------------------------------------------------

/**
* @see http://wact.sourceforge.net/index.php/FileScheme
*/
if (!defined('TMPL_FILESCHEME_PATH')) {
	define('TMPL_FILESCHEME_PATH', WACT_ROOT . '/template/fileschemes/simpleroot/');
}
/**
* Include runtime support
*/
require_once TMPL_FILESCHEME_PATH . 'runtimesupport.inc.php';

//--------------------------------------------------------------------------------
/**
* Instantiate global variable $TemplateRender and $TemplateConstruct as arrays
*/
$TemplateRender = array();
$TemplateConstruct = array();
//--------------------------------------------------------------------------------
// This is a bit problematic, since not every Component is a DataSpace.
// every Template is a DataSpace, however.
// Bit of a refused bequest here.
/**
* Base class for runtime components.<br />
* Note that components that output XML tags should not inherit directly from
* Component but rather the child TagComponent<br />
* Note that in the comments for this class, the terms parent and child
* refer to the given components relative position in a template's
* hierarchy, not to the PHP class hierarchy
* @see http://wact.sourceforge.net/index.php/Component
* @access public
* @abstract
* @package WACT_COMPONENT
*/
class Component extends DataSpace {
	/**
	* Array of child components
	* @var array of component objects
	* @access private
	*/
	var $children = array();
	/**
	* Parent component - "parent" refers to nesting in template
	* not to class hierarchy.
	* @var object component object
	* @access private
	*/
	var $parent;
	/**
	* Root component in template
	* @var object component object
	* @access private
	*/
	var $root;
	/**
	* ID of component, corresponding to it's ID attribute in the template
	* @var string
	* @access private
	*/
	var $id;

	/**
	* Returns the ID of the component, as defined in the template tags
	* ID attribute
	* @return string
	* @access public
	*/
	function getServerId() {
		return $this->id;
	}

	/**
	* Returns a child component given it's ID.<br />
	* Note this is a potentially expensive operation if dealing with
	* many components, as it calls the findChild method of children
	* based on alphanumeric order: strcasecmp(). Attempt to call it via
	* the nearest known component to the required child.
	* @param string id
	* @return mixed refernce to child component object or FALSE if not found
	* @access public
	*/
	function &findChild($ServerId) {
		foreach( array_keys($this->children) as $key) {
			if (strcasecmp($key, $ServerId)) {
				$result =& $this->children[$key]->findChild($ServerId);
				if ($result) {
					return $result;
				}
			} else {
				return $this->children[$key];
			}
		}
		return FALSE;
	}

	/**
	* Returns the first child component matching the supplied WACT_TEMPLATE
	* Component PHP class name<br />
	* @param string component class name
	* @return mixed reference to child component object or FALSE if not found
	* @access public
	*/
	function &findChildByClass($class) {
		foreach( array_keys($this->children) as $key) {
		    if (is_a($this->children[$key], $class)) {
				return $this->children[$key];
			} else {
				$result =& $this->children[$key]->findChildByClass($class);
				if ($result) {
					return $result;
				}
			}
		}
		return FALSE;
	}

	/**
	* Recursively searches through parents of this component searching
	* for a given WACT_TEMPLATE component PHP class name
	* @param string component class name
	* @return mixed reference to parent component object or FALSE if not found
	* @access public
	*/
	function &findParentByClass($class) {
		$Parent =& $this->parent;
		while ($Parent && !is_a($Parent, $class)) {
			$Parent =& $Parent->parent;
		}
		return $Parent;
	}

	/**
	* Adds a reference to a child component to this component, using it's
	* ID attribute as the child array key
	* @param object child component
	* @param string value for ID attribute
	* @return void
	* @access public
	*/
	function addChild(&$Child, $ServerId) {
		$Child->parent =& $this;
		$Child->id = $ServerId;
		$this->children[$ServerId] =& $Child;
	}
	
}

//--------------------------------------------------------------------------------
/**
* Base class for runtime components that output XML tags
* @see http://wact.sourceforge.net/index.php/TagComponent
* @access public
* @abstract
* @package WACT_COMPONENT
*/
class TagComponent extends Component {
	/**
	* Array of XML attributes
	* @var array
	* @access private
	*/
	var $attributes = array();

	/**
	* Returns the value of the ID attribute
	* @param string component class name
	* @return string
	* @access public
	*/
	function getClientId() {
		if (isset($this->attributes['id'])) {
			return $this->attributes['id'];
		}
	}

	/**
	* Sets an attribute
	* @param string name of attribute
	* @param string value of attribute
	* @return void
	* @access public
	*/
	function setAttribute($attrib, $value) {
		$this->attributes[$attrib] = $value;
	}
	
	/**
	* Returns the value of an attribute, given it's name
	* @param string name of attribute
	* @return string value of attribute
	* @access public
	*/
	function getAttribute($attrib) {
		if (isset($this->attributes[$attrib])) {
			return $this->attributes[$attrib];
		}
	}
	
	/**
	* Check to see whether a named attribute exists
	* @param string name of attribute
	* @return boolean
	* @access public
	*/
	function hasAttribute($attrib) {
		return array_key_exists($attrib, $this->attributes);
	}

	/**
	* Writes the contents of the attributes to the screen, using
	* htmlspecialchars to convert entities in values. Called by
	* a compiled template
	* @return void
	* @access public
	*/
	function renderAttributes() {
		foreach ($this->attributes as $name => $value) {
			echo ' ';
			echo $name;
			if (!is_null($value)) {
				echo '="';
				echo htmlspecialchars($value, ENT_QUOTES);
				echo '"';
			}
		}
	}
}

//--------------------------------------------------------------------------------
/**
* Used to fetch data serialized in a var file
* @see http://wact.sourceforge.net/index.php/importVarFile
* @param filename of var file (relative or full path)
* @return mixed data stored in var file
* @access protected
*/
function importVarFile($file) {
    
	if (getConfigOption('config', 'templates', 'forcecompile')) {
		include_once WACT_ROOT . '/template/compiler/varfilecompiler.inc.php';
		CompileVarFile($file);
	}

	$CodeFile = ResolveTemplateCompiledFileName($file, TMPL_IMPORT);

	$data = @readTemplateFile($CodeFile);
	if (!$data) {
		include_once WACT_ROOT . '/template/compiler/varfilecompiler.inc.php';
		CompileVarFile($file);
		$data = readTemplateFile($CodeFile);
	}
	
	return unserialize($data);
	
}

//--------------------------------------------------------------------------------
/**
* Public facade for handling templates, dealing with loading, compiling and
* displaying
* @see http://wact.sourceforge.net/index.php/Template
* @access public
* @package WACT_COMPONENT
*/
class Template extends Component {
	/**
	* Stored the name of the compiled template file
	* @var string
	* @access private
	*/
	var $codefile;
	
	var $file;
	/**
	* Name of function in compiled template which outputs display to screen
	* @var string
	* @access private
	*/
	var $render_function;

	/**
	* Constructs Template
	* @param string name of (source) template file (relative or full path)
	* @access public
	*/
	function Template($file) {
        $this->file = $file;

		$this->codefile = ResolveTemplateCompiledFileName($file, TMPL_INCLUDE);
		if (!isset($GLOBALS['TemplateRender'][$this->codefile])) {

			if (getConfigOption('config', 'templates', 'forcecompile')) {
				include_once WACT_ROOT . '/template/compiler/templatecompiler.inc.php';
				CompileTemplateFile($file);
			}
			
			$errorlevel = error_reporting();
			error_reporting($errorlevel & ~E_WARNING);
			$found = include_once($this->codefile);
			error_reporting($errorlevel);
			if (!$found) {
				include_once WACT_ROOT . '/template/compiler/templatecompiler.inc.php';
				CompileTemplateFile($file);
				include_once($this->codefile);
			}
		}
		$this->render_function = $GLOBALS['TemplateRender'][$this->codefile];
		$func = $GLOBALS['TemplateConstruct'][$this->codefile];
		$func($this);
	}

    function &getChild($ServerId) {
        $result =& $this->findChild($ServerId);
        if (!is_object($result)) {
            RaiseError('compiler', 'COMPONENTNOTFOUND', array(
                'file' => $this->file,
                'ServerId' => $ServerId));
        }
        return $result;
    }

	/**
	* Outputs the template, calling the compiled templates render function
	* @return void
	* @access public
	*/
	function display() {
		$func = $this->render_function;
		$func($this);
	}
}
?>