<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT_TAG
* @version $Id: list.tag.php,v 1.13 2003/11/29 23:03:06 jeffmoore Exp $
*/
//--------------------------------------------------------------------------------
/**
* Register tag
*/
registerTag(new ListListTagInfo());
/**
* @see http://wact.sourceforge.net/index.php/TagInfoClasses
* @access protected
* @package WACT_TAG
*/
class ListListTagInfo {
	var $Tag = 'list:LIST';
	var $EndTag = ENDTAG_REQUIRED;
	var $TagClass = 'ListListTag';
}
/**
* The parent compile time component for lists
* @see http://wact.sourceforge.net/index.php/ListListTag
* @access protected
* @package WACT_TAG
*/
class ListListTag extends ServerComponentTag {
	/**
	* File to include at runtime
	* @var string path to runtime component relative to WACT_ROOT
	* @access private
	*/
	var $runtimeIncludeFile = '/template/components/list.inc.php';
	/**
	* Name of runtime component class
	* @var string
	* @access private
	*/
	var $runtimeComponentName = 'ListComponent';
	/**
	* Name of runtime DataSpace variable
	* @var string
	* @access private
	*/
	// var $dataSpaceVar;

	/**
	* @param CodeWriter
	* @return void
	* @access protected
	*/
	function preGenerate(&$code) {
		parent::preGenerate($code);
		$code->writePHP($this->getComponentRefCode() . '->prepare();');
		
		// $this->dataSpaceVar = $code->getTempVariable();
		// $code->writePHP('$' . $this->dataSpaceVar . ' =& ' . $this->getComponentRefCode() . '->DataSet;');
		
		$code->writePHP('if (' . $this->getComponentRefCode() . '->next()) {');
	}

	/**
	* @param CodeWriter
	* @return void
	* @access protected
	*/
	function postGenerate(&$code) {
		$code->writePHP('}');
		
		$emptyChild =& $this->findImmediateChildByClass('ListDefaultTag');
		if ($emptyChild) {
			$code->writePHP(' else { ');
			$emptyChild->generateNow($code);
			$code->writePHP('}');
		}
		parent::postGenerate($code);
	}

	/**
	* @return ListListTag this instance
	* @access protected
	*/
	function &getDataSpace() {
		return $this;
	}

	/**
	* @return string PHP runtime variable reference to component
	* @access protected
	*/
	function getDataSpaceRefCode() {
        return $this->getComponentRefCode() . '->DataSet';
	    // return '$' . $this->dataSpaceVar;
	}
}
?>