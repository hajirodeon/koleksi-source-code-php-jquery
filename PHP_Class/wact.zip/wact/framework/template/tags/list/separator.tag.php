<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT_TAG
* @version $Id: separator.tag.php,v 1.9 2004/01/27 01:01:02 jeffmoore Exp $
*/
//--------------------------------------------------------------------------------
/**
* Register tag
*/
registerTag(new ListSeparatorTagInfo());
/**
* @see http://wact.sourceforge.net/index.php/TagInfoClasses
* @access protected
* @package WACT_TAG
*/
class ListSeparatorTagInfo {
	var $Tag = 'list:SEPARATOR';
	var $EndTag = ENDTAG_REQUIRED;
	var $TagClass = 'ListSeparatorTag';
}
/**
* Compile time component for separators in a list
* @see http://wact.sourceforge.net/index.php/ListSeparatorTag
* @access protected
* @package WACT_TAG
*/
class ListSeparatorTag extends SilentCompilerDirectiveTag {
	/**
	* @return void
	* @access private
	*/
	function CheckNestingLevel() {
		if ($this->findParentByClass('ListSeparatorTag')) {
            RaiseError('compiler', 'BADSELFNESTING', array(
                'tag' => $this->tag,
                'file' => $this->SourceFile,
                'line' => $this->StartingLineNo));
		}
		if ( !is_a($this->parent, 'ListItemTag') && !is_a($this->parent, 'ErrorSummaryTag')) {
            RaiseError('compiler', 'MISSINGENCLOSURE', array(
                'tag' => $this->tag,
                'EnclosingTag' => 'list:ITEM or ERRORSUMMARY',
                'file' => $this->SourceFile,
                'line' => $this->StartingLineNo));
		}
	}
}
?>