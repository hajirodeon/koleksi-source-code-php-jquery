<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT_TAG
* @version $Id: item.tag.php,v 1.8 2003/10/15 12:34:52 harryf Exp $
*/
//--------------------------------------------------------------------------------
/**
* Register tag
*/
registerTag(new ListItemTagInfo());
/**
* @see http://wact.sourceforge.net/index.php/TagInfoClasses
* @access protected
* @package WACT_TAG
*/
class ListItemTagInfo {
	var $Tag = 'list:ITEM';
	var $EndTag = ENDTAG_REQUIRED;
	var $TagClass = 'ListItemTag';
}
/**
* Compile time component for items (rows) in the list
* @see http://wact.sourceforge.net/index.php/ListItemTag
* @access protected
* @package WACT_TAG
*/
class ListItemTag extends CompilerDirectiveTag {
	/**
	* @return void
	* @access protected
	*/
	function CheckNestingLevel() {
		if ( !is_a($this->parent, 'ListListTag') && !is_a($this->parent, 'ErrorSummaryTag')) {
            RaiseError('compiler', 'MISSINGENCLOSURE', array(
                'tag' => $this->tag,
                'EnclosingTag' => 'list:LIST or ERRORSUMMARY',
                'file' => $this->SourceFile,
                'line' => $this->StartingLineNo));
		}
	}

	/**
	* @param CodeWriter
	* @return void
	* @access protected
	*/
	function generateContents(&$code) {
		$SepChild =& $this->findImmediateChildByClass('ListSeparatorTag');

		$code->writePHP('do { ');

		if ($SepChild) {
			$code->writePHP('if (' . $this->getComponentRefCode() . '->ShowSeparator) {');
			$SepChild->generateNow($code);
			$code->writePHP('}');
			$code->writePHP($this->getComponentRefCode() . '->ShowSeparator = TRUE;');
		}
		parent::generateContents($code);
		$code->writePHP('} while (' . $this->getDataSpaceRefCode() . '->next());');
	}
}
?>