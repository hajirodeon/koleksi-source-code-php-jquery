<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT_TAG
* @version $Id: navigator.tag.php,v 1.4 2003/11/29 23:03:06 jeffmoore Exp $
*/
//--------------------------------------------------------------------------------
/**
* Register tag
*/
registerTag(new PageNavigatorTagInfo());
/**
* @see http://wact.sourceforge.net/index.php/TagInfoClasses
* @access protected
* @package WACT_TAG
*/
class PageNavigatorTagInfo {
	var $Tag = 'page:NAVIGATOR';
	var $EndTag = ENDTAG_REQUIRED;
	var $TagClass = 'PageNavigatorTag';
}
/**
* Compile time component for root of a pager tag
* @see http://wact.sourceforge.net/index.php/PageNavigatorTag
* @access protected
* @package WACT_TAG
*/
class PageNavigatorTag extends ServerComponentTag {
	/**
	* File to include at runtime
	* @var string path to runtime component relative to WACT_ROOT
	* @access private
	*/
	var $runtimeIncludeFile = 'template/components/pager.inc.php';
	/**
	* Name of runtime component class
	* @var string
	* @access private
	*/
	var $runtimeComponentName = 'PageNavigatorComponent';
	/**
	* @param CodeWriter
	* @return void
	* @access protected
	*/
	function preGenerate(&$code) {
		parent::preGenerate($code);
		$code->writePHP($this->getComponentRefCode() . '->prepare();');
	}
	/**
	* @param CodeWriter
	* @return void
	* @access protected
	*/
	function generateConstructor(&$code) {
		parent::generateConstructor($code);
		if (array_key_exists('items', $this->attributes)) {
			$code->writePHP($this->getComponentRefCode() . 
				'->Items = \'' . $this->attributes['items'] . '\';');
			unset($this->attributes['items']);
		}
		if (array_key_exists('anchorsize', $this->attributes)) {
			$code->writePHP($this->getComponentRefCode() . 
				'->AnchorSize = \'' . $this->attributes['anchorsize'] . '\';');
			unset($this->attributes['anchorsize']);
		}
		if (array_key_exists('windowsize', $this->attributes)) {
		    if (($this->attributes['windowsize'] % 2) != 1) {
		        // Window size must be an odd number
		    }
		
			$code->writePHP($this->getComponentRefCode() . 
				'->WindowSize = \'' . $this->attributes['windowsize'] . '\';');
			unset($this->attributes['windowsize']);
		}
	}

    /*
	function &getDataSpace() {
		return $this;
	}

	function getDataSpaceRefCode() {
		return $this->getComponentRefCode() . '->DataSet';
	}
	*/
	
}

?>