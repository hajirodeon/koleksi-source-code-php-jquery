<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT_TAG
* @version $Id: number.tag.php,v 1.3 2003/10/15 12:34:52 harryf Exp $
*/
//--------------------------------------------------------------------------------
/**
* Register tag
*/
registerTag(new PageNumberTagInfo());
/**
* @see http://wact.sourceforge.net/index.php/TagInfoClasses
* @access protected
* @package WACT_TAG
*/
class PageNumberTagInfo {
	var $Tag = 'page:NUMBER';
	var $EndTag = ENDTAG_FORBIDDEN;
	var $TagClass = 'PageNumberTag';
}
/**
* Compile time component for page numbers in pager
* @see http://wact.sourceforge.net/index.php/PageNumberTag
* @access protected
* @package WACT_TAG
*/
class PageNumberTag extends SilentCompilerDirectiveTag {
	/**
	* @return void
	* @access private
	*/
	function CheckNestingLevel() {
	    if ($this->findParentByClass('PageNumberTag')) {
            RaiseError('compiler', 'BADSELFNESTING', array(
                'tag' => $this->tag,
                'file' => $this->SourceFile,
                'line' => $this->StartingLineNo));
	    }
		if (!$this->findParentByClass('PageNavigatorTag')) {
            RaiseError('compiler', 'MISSINGENCLOSURE', array(
                'tag' => $this->tag,
                'EnclosingTag' => 'page:navigator',
                'file' => $this->SourceFile,
                'line' => $this->StartingLineNo));
		}
	}
	/**
	* @param CodeWriter
	* @return void
	* @access protected
	*/
	function generateContents(&$code) {

	    $parent =& $this->findParentByClass('PageNavigatorTag');
		$code->writePHP('if (!' . $parent->getComponentRefCode() . '->IsCurrentPage()) {');

        $code->writeHTML('<a ');
		unset($this->attributes['href']);
		foreach ($this->attributes as $name => $value) {
			$code->writeHTML(' ' . $name);
			if (!is_null($value)) {
				$code->writeHTML('="' . htmlspecialchars($value, ENT_QUOTES) . '"');
			}
		}
        $code->writeHTML(' href="');
        $code->writePHP('echo ' . $parent->getComponentRefCode() . '->getCurrentPageUri();');
        $code->writeHTML('">');

   		$code->writePHP('}');


        $code->writePHP('echo ' . $parent->getComponentRefCode() . '->getPageNumber();');

        $code->writePHP('if (!' . $parent->getComponentRefCode() . '->IsCurrentPage()) {');
        $code->writeHTML('</a>');
		$code->writePHP('}');

    }

}

?>