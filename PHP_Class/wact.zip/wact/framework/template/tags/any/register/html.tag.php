<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT_TAG
* @version $Id: html.tag.php,v 1.2 2003/10/15 12:34:52 harryf Exp $
* Definitions for some HTML tags using AnyTag
*/
//--------------------------------------------------------------------------------
/**
* Register the tag
*/
registerTag(new ImgTagInfo());
/**
* @see http://wact.sourceforge.net/index.php/TagInfoClasses
* @access protected
* @package WACT_TAG
*/
class ImgTagInfo {
	var $Tag = 'img';
	var $EndTag = ENDTAG_FORBIDDEN;
	var $TagClass = 'AnyTagTag';
}
/**
* Register the tag
*/
registerTag(new AnchorTagInfo());
/**
* @see http://wact.sourceforge.net/index.php/TagInfoClasses
* @access protected
* @package WACT_TAG
*/
class AnchorTagInfo {
	var $Tag = 'a';
	var $EndTag = ENDTAG_REQUIRED;
	var $TagClass = 'AnyContainerTagTag';
}
/**
* Register the tag
*/
registerTag(new TableTagInfo());
/**
* @see http://wact.sourceforge.net/index.php/TagInfoClasses
* @access protected
* @package WACT_TAG
*/
class TableTagInfo {
	var $Tag = 'table';
	var $EndTag = ENDTAG_REQUIRED;
	var $TagClass = 'AnyContainerTagTag';
}
/**
* Register the tag
*/
registerTag(new TableRowTagInfo());
/**
* @see http://wact.sourceforge.net/index.php/TagInfoClasses
* @access protected
* @package WACT_TAG
*/
class TableRowTagInfo {
	var $Tag = 'tr';
	var $EndTag = ENDTAG_REQUIRED;
	var $TagClass = 'AnyContainerTagTag';
}
/**
* Register the tag
*/
registerTag(new TableHeaderTagInfo());
/**
* @see http://wact.sourceforge.net/index.php/TagInfoClasses
* @access protected
* @package WACT_TAG
*/
class TableHeaderTagInfo {
	var $Tag = 'th';
	var $EndTag = ENDTAG_REQUIRED;
	var $TagClass = 'AnyContainerTagTag';
}
/**
* Register the tag
*/
registerTag(new TableCellTagInfo());
/**
* @see http://wact.sourceforge.net/index.php/TagInfoClasses
* @access protected
* @package WACT_TAG
*/
class TableCellTagInfo {
	var $Tag = 'td';
	var $EndTag = ENDTAG_REQUIRED;
	var $TagClass = 'AnyContainerTagTag';
}
?>