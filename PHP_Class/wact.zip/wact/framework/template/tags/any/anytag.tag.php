<?php 
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT_TAG
* @version $Id: anytag.tag.php,v 1.5 2003/11/29 23:03:03 jeffmoore Exp $
*/
//--------------------------------------------------------------------------------
/**
* Compile time component for building AnyTagComponents
* @see http://wact.sourceforge.net/index.php/AnyTagTag
* @access protected
* @package WACT_TAG
*/
class AnyTagTag extends ServerTagComponentTag {
	/**
	* File to include at runtime
	* @var string path to runtime component relative to WACT_ROOT
	* @access private
	*/
	var $runtimeIncludeFile = '/template/components/anytag.inc.php';
	/**
	* Name of runtime component class
	* @var string
	* @access private
	*/
	var $runtimeComponentName;
	/**
	* @return void
	* @access protected
	*/
	function prepare() {
		$this->runtimeComponentName = $this->tag.'Component';
		parent::prepare();
	}
	/**
	* @param CodeWriter
	* @return void
	* @access protected
	*/
	function generateConstructor(&$code) {
		$code->writePHP('if (!class_exists(\''.$this->tag.'Component\') ) {');
		$code->writePHP('class '.$this->tag.'Component extends AnyTagComponent {};');
		$code->writePHP('}');
		$code->registerInclude(WACT_ROOT . $this->runtimeIncludeFile);
		$code->writePHP($this->parent->getComponentRefCode() .
			'->addChild(new ' . $this->runtimeComponentName . 
			'(\''.$this->tag.'\'), \'' . $this->getServerId() . '\');');
		$code->writePHP($this->getComponentRefCode() .
			'->attributes = unserialize(\'' . serialize($this->attributes) . '\');');
	}
}
/**
* Compile time component for building AnyTagComponents
* @see http://wact.sourceforge.net/index.php/AnyTagTag
* @access protected
* @package WACT_TAG
*/
class AnyContainerTagTag extends ServerTagComponentTag {
	/**
	* File to include at runtime
	* @var string path to runtime component relative to WACT_ROOT
	* @access private
	*/
	var $runtimeIncludeFile = '/template/components/anytag.inc.php';
	/**
	* Name of runtime component class
	* @var string
	* @access private
	*/
	var $runtimeComponentName;
	/**
	* @return void
	* @access protected
	*/
	function prepare() {
		$this->runtimeComponentName = $this->tag.'Component';
		parent::prepare();
	}
	/**
	* @param CodeWriter
	* @return void
	* @access protected
	*/
	function generateConstructor(&$code) {
		$code->writePHP('if (!class_exists(\''.$this->tag.'Component\') ) {');
		$code->writePHP('class '.$this->tag.'Component extends AnyContainerTagComponent {};');
		$code->writePHP('}');
		$code->registerInclude(WACT_ROOT . $this->runtimeIncludeFile);
		$code->writePHP($this->parent->getComponentRefCode() .
			'->addChild(new ' . $this->runtimeComponentName . 
			'(\''.$this->tag.'\'), \'' . $this->getServerId() . '\');');
		$code->writePHP($this->getComponentRefCode() .
			'->attributes = unserialize(\'' . serialize($this->attributes) . '\');');
		CompilerComponent::generateConstructor($code);
	}
	/**
	* @param CodeWriter
	* @return void
	* @access protected
	*/
	function postGenerate(& $code) {
		$code->writePHP($this->getComponentRefCode() . '->render();');
		parent::postGenerate($code);
	}
	/**
	* @param CodeWriter
	* @return void
	* @access protected
	*/
	function generate(&$code) {
		parent::generate($code);
	}
}
?>