<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT_TAG
* @version $Id: literal.tag.php,v 1.7 2003/10/15 12:34:52 harryf Exp $
*/
//--------------------------------------------------------------------------------
/**
* Register the tag
*/
registerTag(new CoreLiteralTagInfo());
/**
* @see http://wact.sourceforge.net/index.php/TagInfoClasses
* @access protected
* @package WACT_TAG
*/
class CoreLiteralTagInfo {
	var $Tag = 'core:LITERAL';
	var $EndTag = ENDTAG_REQUIRED;
	var $TagClass = 'CoreLiteralTag';
}
/**
* Prevents a section of the template from being parsed, placing the contents
* directly into the compiled template
* @see http://wact.sourceforge.net/index.php/CoreLiteralTag
* @access protected
* @package WACT_TAG
*/
class CoreLiteralTag extends CompilerDirectiveTag {
	/**
	* @return void
	* @access protected
	*/
	function CheckNestingLevel() {
		if ($this->findParentByClass('CoreLiteralTag')) {
            RaiseError('compiler', 'BADSELFNESTING', array(
                'tag' => $this->tag,
                'file' => $this->SourceFile,
                'line' => $this->StartingLineNo));
		}
	}

	/**
	* @return int PARSER_FORBID_PARSING
	* @access protected
	*/
	function preParse() {
		return PARSER_FORBID_PARSING;
	}
}
?>