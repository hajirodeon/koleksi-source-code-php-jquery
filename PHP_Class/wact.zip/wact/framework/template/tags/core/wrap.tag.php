<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT_TAG
* @version $Id: wrap.tag.php,v 1.10 2003/12/04 22:42:37 harryf Exp $
*/
//--------------------------------------------------------------------------------
/**
* Register the tag
*/
registerTag(new CoreWrapTagInfo());
/**
* @see http://wact.sourceforge.net/index.php/TagInfoClasses
* @access protected
* @package WACT_TAG
*/
class CoreWrapTagInfo {
	var $Tag = 'core:WRAP';
	var $EndTag = ENDTAG_FORBIDDEN;
	var $TagClass = 'CoreWrapTag';
}
/**
* Merges the current template with a wrapper template, the current
* template being inserted into the wrapper at the point where the
* wrap tag exists.
* @see http://wact.sourceforge.net/index.php/CoreWrapTag
* @access protected
* @package WACT_TAG
*/
class CoreWrapTag extends CompilerDirectiveTag {
	/**
	* List of tag names of the children of the wrap tag
	* @var array
	* @access private
	*/
	var $keylist;

	/**
	* @return void
	* @access protected
	*/
	function CheckNestingLevel() {
		if ($this->findParentByClass('CoreWrapTag')) {
			RaiseError('compiler', 'BADSELFNESTING', array(
				'tag' => $this->tag,
				'file' => $this->SourceFile,
				'line' => $this->StartingLineNo));
		}
	}

	/**
	* @return int PARSER_FORBID_PARSING
	* @access protected
	*/
	function preParse() {
		global $TagDictionary;
		$file = $this->attributes['file']; 
		if (empty($file)) {
			RaiseError('compiler', 'MISSINGENCLOSURE', array(
				'tag' => $this->tag,
				'attribute' => 'file', 
				'EnclosingTag' => 'page:navigator',
				'file' => $this->SourceFile,
				'line' => $this->StartingLineNo));
		}

		$sourcefile = ResolveTemplateSourceFileName($file, TMPL_INCLUDE, $this->SourceFile);
		if (empty($sourcefile)) {
			RaiseError('compiler', 'MISSINGFILE', array(
				'tag' => $this->tag,
				'srcfile' => $file,
				'file' => $this->SourceFile,
				'line' => $this->StartingLineNo));
		}
		$sfp =& new SourceFileParser($sourcefile,$TagDictionary);
		$sfp->parse($this);

		return PARSER_FORBID_PARSING;
	}

	/**
	* @return void
	* @access protected
	*/
	function prepare() {
		if ( isset( $this->parent->WrappingComponent ) ) {
			$parent = empty($this->parent->tag) ? get_class($this->parent) : $this->parent->tag;
			RaiseError('compiler', 'WRAPPEREXISTS', array(
				'parent'=>$parent,
				'parent_id'=>$this->parent->getServerId(),
				'wrapper'=>$this->parent->WrappingComponent->tag,
				'wrapper_id'=>$this->parent->WrappingComponent->getServerId(),
				'file' => $this->SourceFile,
				'line' => $this->StartingLineNo));
		}
		$this->parent->WrappingComponent =& $this;
		parent::prepare();
	}

	/**
	* @return void
	* @access protected
	*/
	function generateWrapperPrefix(&$code) {
		$this->keylist = array_keys($this->children);
		$name = $this->attributes['placeholder'];
		
		reset($this->keylist);
		while (list(,$key) = each($this->keylist)) {
			$child =& $this->children[$key];
			if ($child->getServerId() == $name) {
				break;
			}
			$child->generate($code);
		}
	}

	/**
	* @param CodeWriter
	* @return void
	* @access protected
	*/
	function generateWrapperPostfix(&$code) {
		while (list(,$key) = each($this->keylist)) {
			$this->children[$key]->generate($code);
		}
	}

	/**
	* By the time this is called we have already called generate
	* on all of our children, so does nothing
	* @param CodeWriter
	* @return void
	* @access protected
	*/
	function generate(&$code) {
		// By the time this is called we have already called generate
		// on all of our children. 
	}
}
?>