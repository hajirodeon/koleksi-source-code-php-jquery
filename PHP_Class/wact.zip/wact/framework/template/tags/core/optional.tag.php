<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT_TAG
* @version $Id: optional.tag.php,v 1.5 2003/10/15 12:34:52 harryf Exp $
*/
//--------------------------------------------------------------------------------
/**
* Register the tag
*/
registerTag(new CoreOptionalTagInfo());
/**
* @see http://wact.sourceforge.net/index.php/TagInfoClasses
* @access protected
* @package WACT_TAG
*/
class CoreOptionalTagInfo {
	var $Tag = 'core:OPTIONAL';
	var $EndTag = ENDTAG_REQUIRED;
	var $TagClass = 'CoreOptionalTag';
}
/**
* Defines an action take, should a DataSpace variable have been set at runtime.
* The opposite of the CoreDefaultTag
* @see CoreDefaultTag
* @see http://wact.sourceforge.net/index.php/CoreOptionalTag
* @access protected
* @package WACT_TAG
*/
class CoreOptionalTag extends CompilerDirectiveTag {
	/**
	* The DataSpace variable name
	* @var string
	* @access private
	*/
	var $field;

	/**
	* @return int PARSER_REQUIRE_PARSING
	* @access protected
	*/
	function preParse() {
		$field = $this->attributes['for']; 
		if (empty($field)) {
            RaiseError('compiler', 'MISSINGREQUIREATTRIBUTE', array(
                'tag' => $this->tag,
                'attribute' => 'for', 
                'file' => $this->SourceFile,
                'line' => $this->StartingLineNo));
		}
		
		$this->field = $field;

		return PARSER_REQUIRE_PARSING;
	}

	/**
	* @param CodeWriter
	* @return void
	* @access protected
	*/
	function preGenerate(&$code) {
		parent::preGenerate($code);

		$tempvar = $code->getTempVariable();
		$code->writePHP('$' . $tempvar . ' = ' . $this->getDataSpaceRefCode() . '->get(\'' . $this->field . '\');');
		$code->writePHP('if (!empty($' . $tempvar . ')) {');
	}

	/**
	* @param CodeWriter
	* @return void
	* @access protected
	*/
	function postGenerate(&$code) {
		$code->writePHP('}');
		parent::postGenerate($code);
	}
}
?>