<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT_TAG
* @version $Id: outputcache.tag.php,v 1.8 2003/11/29 23:03:04 jeffmoore Exp $
*/
//--------------------------------------------------------------------------------
/**
* Register the tag
*/
registerTag(new CoreOutputCacheTagInfo());
/**
* @see http://wact.sourceforge.net/index.php/TagInfoClasses
* @access protected
* @package WACT_TAG
*/
class CoreOutputCacheTagInfo {
	var $Tag = 'core:OUTPUTCACHE';
	var $EndTag = ENDTAG_REQUIRED;
	var $TagClass = 'CoreOutputCacheTag';
}
/**
* Compile time component for instructing output to be cached in a file
* at runtime.
* @see http://wact.sourceforge.net/index.php/CoreBlockTag
* @access protected
* @package WACT_TAG
*/
class CoreOutputCacheTag extends ServerComponentTag {
	/**
	* File to include at runtime
	* @var string path to runtime component relative to WACT_ROOT
	* @access private
	*/
	var $runtimeIncludeFile = '/template/components/outputcache.inc.php';
	/**
	* Name of runtime component class
	* @var string
	* @access private
	*/
	var $runtimeComponentName = 'OutputCacheComponent';
	/**
	* Name of runtime variable reference where cached content is stored
	* @var string
	* @access private
	*/
	var $contentref;
	/**
	* @param CodeWriter
	* @return void
	* @access protected
	*/
	function generateConstructor(&$code) {
		$code->registerInclude(WACT_ROOT . $this->runtimeIncludeFile);
		$args = '__FILE__.\''.$this->getServerId().'\'';
		isset ( $this->attributes['expires'] ) ?
			$args .= ','.$this->attributes['expires'].'' : $args .= ',3600';
		isset ( $this->attributes['cacheby'] ) ?
			$args .= ',\''.$this->attributes['cacheby'].'\'' : $args .= ',\'\'';
		isset ( $this->attributes['cachegroup'] ) ?
			$args .= ',\''.$this->attributes['cachegroup'].'\'' : $args .= ',false';
		$code->writePHP($this->parent->getComponentRefCode() .
			'->addChild(new ' . $this->runtimeComponentName . 
			'('.$args.'), \'' . $this->getServerId() . '\');');
		CompilerComponent::generateConstructor($code);
	}
	/**
	* @param CodeWriter
	* @return void
	* @access protected
	*/
	function preGenerate(&$code) {
		$this->contentref = getNewServerId();
		parent::preGenerate($code);
		$code->writePHP('if (!'.$this->getComponentRefCode() . '->isCached()) {');
		$code->writePHP('ob_start();');
	}
	/**
	* @param CodeWriter
	* @return void
	* @access protected
	*/
	function postGenerate(&$code) {
		$code->writePHP($this->getComponentRefCode().'->cache(ob_get_contents());ob_end_clean();');
		$code->writePHP('}');
		$code->writePHP($this->getComponentRefCode().'->render();');
		parent::postGenerate($code);
	}
}
?>