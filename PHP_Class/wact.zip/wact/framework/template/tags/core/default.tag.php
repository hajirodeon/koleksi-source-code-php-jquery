<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT_TAG
* @version $Id: default.tag.php,v 1.5 2003/10/15 12:34:52 harryf Exp $
*/
//--------------------------------------------------------------------------------
/**
* Register the tag
*/
registerTag(new CoreDefaultTagInfo());
/**
* @see http://wact.sourceforge.net/index.php/TagInfoClasses
* @access protected
* @package WACT_TAG
*/
class CoreDefaultTagInfo {
	var $Tag = 'core:DEFAULT';
	var $EndTag = ENDTAG_REQUIRED;
	var $TagClass = 'CoreDefaultTag';
}
/**
* Allows a default action to take place at runtime, should a
* dataspace variable have failed to be populated
* @see http://wact.sourceforge.net/index.php/CoreDefaultTag
* @access protected
* @package WACT_TAG
*/
class CoreDefaultTag extends CompilerDirectiveTag {
	/**
	* The DataSpace variable name
	* @var string
	* @access private
	*/
	var $field;

	/**
	* @return int PARSER_REQUIRE_PARSING
	* @access protected
	*/
	function preParse() {
		$field = $this->attributes['for']; 
		if (empty($field)) {
            RaiseError('compiler', 'MISSINGREQUIREATTRIBUTE', array(
                'tag' => $this->tag,
                'attribute' => 'for',
                'file' => $this->SourceFile,
                'line' => $this->StartingLineNo));
		}
		
		$this->field = $field;
		return PARSER_REQUIRE_PARSING;
	}

	/**
	* @param CodeWriter
	* @return void
	* @access protected
	*/
	function preGenerate(&$code) {
		parent::preGenerate($code);
		$tempvar = $code->getTempVariable();
		$code->writePHP('$' . $tempvar . ' = ' . $this->getDataSpaceRefCode() . '->get(\'' . $this->field . '\');');
		$code->writePHP('if (empty($' . $tempvar . ')) {');
	}

	/**
	* @param CodeWriter
	* @return void
	* @access protected
	*/
	function postGenerate(&$code) {
		$code->writePHP('}');
		parent::postGenerate($code);
	}
}
?>