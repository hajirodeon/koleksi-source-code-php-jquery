<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT_TAG
* @version $Id: placeholder.tag.php,v 1.10 2003/11/29 23:03:05 jeffmoore Exp $
*/
//--------------------------------------------------------------------------------
/**
* Register the tag
*/
registerTag(new CorePlaceHolderTagInfo());
/**
* @see http://wact.sourceforge.net/index.php/TagInfoClasses
* @access protected
* @package WACT_TAG
*/
class CorePlaceHolderTagInfo {
	var $Tag = 'core:PLACEHOLDER';
	var $EndTag = ENDTAG_FORBIDDEN;
	var $TagClass = 'CorePlaceHolderTag';
}
/**
* Present a named location where content can be inserted at runtime
* @see http://wact.sourceforge.net/index.php/CorePlaceHolderTag
* @access protected
* @package WACT_TAG
*/
class CorePlaceHolderTag extends ServerComponentTag {
	/**
	* File to include at runtime
	* @var string path to runtime component relative to WACT_ROOT
	* @access private
	*/
	var $runtimeIncludeFile = '/template/components/placeholder.inc.php';
	/**
	* Name of runtime component class
	* @var string
	* @access private
	*/
	var $runtimeComponentName = 'PlaceHolderComponent';

	/**
	* @return void
	* @access protected
	*/
	function CheckNestingLevel() {
		if ($this->findParentByClass('CorePlaceHolderTag')) {
            RaiseError('compiler', 'BADSELFNESTING', array(
                'tag' => $this->tag,
                'file' => $this->SourceFile,
                'line' => $this->StartingLineNo));
		}
	}
}
?>