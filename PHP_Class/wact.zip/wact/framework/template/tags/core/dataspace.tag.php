<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT_TAG
* @version $Id: dataspace.tag.php,v 1.11 2003/11/29 23:03:04 jeffmoore Exp $
*/
//--------------------------------------------------------------------------------
/**
* Register the tag
*/
registerTag(new CoreDataSpaceTagInfo());
/**
* @see http://wact.sourceforge.net/index.php/TagInfoClasses
* @access protected
* @package WACT_TAG
*/
class CoreDataSpaceTagInfo {
	var $Tag = 'core:DATASPACE';
	var $EndTag = ENDTAG_REQUIRED;
	var $TagClass = 'CoreDataSpaceTag';
}
/**
* Dataspaces act is "namespaces" for a template.
* @see http://wact.sourceforge.net/index.php/CoreDataSpaceTag
* @access protected
* @package WACT_TAG
*/
class CoreDataSpaceTag extends ServerComponentTag {
	/**
	* File to include at runtime
	* @var string path to runtime component relative to WACT_ROOT
	* @access private
	*/
	var $runtimeIncludeFile = '/template/components/dataspace.inc.php';
	/**
	* Name of runtime component class
	* @var string
	* @access private
	*/
	var $runtimeComponentName = 'DataSpaceComponent';

	/**
	* @param CodeWriter
	* @return void
	* @access protected
	*/
	function preGenerate(&$code) {
		parent::preGenerate($code);
		$code->writePHP($this->getDataSpaceRefCode() . '->prepare();');
	}

	/**
	* Return this instance of the dataspace
	* @return object
	* @access protected
	*/
	function &getDataSpace() {
		return $this;
	}

	/**
	* Get the code (the PHP reference variable) for the dataspace
	* @return string
	* @access protected
	*/
	function getDataSpaceRefCode() {
		return $this->getComponentRefCode();
	}
}
?>