<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT_TAG
* @version $Id: block.tag.php,v 1.10 2003/11/29 23:03:04 jeffmoore Exp $
*/
//--------------------------------------------------------------------------------
/**
* Register the CoreBlockTag
*/
registerTag(new CoreBlockTagInfo());
/**
* @see http://wact.sourceforge.net/index.php/TagInfoClasses
* @access protected
* @package WACT_TAG
*/
class CoreBlockTagInfo {
	var $Tag = 'core:BLOCK';
	var $EndTag = ENDTAG_REQUIRED;
	var $TagClass = 'CoreBlockTag';
}

/**
* Compile time component for block tags
* http://wact.sourceforge.net/index.php/CoreBlockTag
* @access protected
* @package WACT_TAG
*/
class CoreBlockTag extends ServerComponentTag {
	/**
	* File to include at runtime
	* @var string path to runtime component relative to WACT_ROOT
	* @access private
	*/
	var $runtimeIncludeFile = '/template/components/block.inc.php';
	/**
	* Name of runtime component class
	* @var string
	* @access private
	*/
	var $runtimeComponentName = 'BlockComponent';
	/**
	* @param CodeWriter
	* @return void
	* @access protected
	*/
	function generateConstructor(&$code) {
		parent::generateConstructor($code);
		if (array_key_exists('hide', $this->attributes)) {
			$code->writePHP($this->getComponentRefCode() . '->visible = FALSE;');
		}
	}
	/**
	* @param CodeWriter
	* @return void
	* @access protected
	*/
	function preGenerate(&$code) {
		parent::preGenerate($code);
		$code->writePHP('if (' . $this->getComponentRefCode() . '->IsVisible()) {');
	}
	/**
	* @param CodeWriter
	* @return void
	* @access protected
	*/
	function postGenerate(&$code) {
		$code->writePHP('}');
		parent::postGenerate($code);
	}
		
}
?>