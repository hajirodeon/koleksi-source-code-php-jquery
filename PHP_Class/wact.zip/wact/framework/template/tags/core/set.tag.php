<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT_TAG
* @version $Id: set.tag.php,v 1.7 2003/10/15 12:34:52 harryf Exp $
*/
//--------------------------------------------------------------------------------
/**
* Register the tag
*/
registerTag(new CoreSetTagInfo());
/**
* @see http://wact.sourceforge.net/index.php/TagInfoClasses
* @access protected
* @package WACT_TAG
*/
class CoreSetTagInfo {
	var $Tag = 'core:SET';
	var $EndTag = ENDTAG_FORBIDDEN;
	var $TagClass = 'CoreSetTag';
}
/**
* Sets a variable in the runtime DataSpace, according the attributes of this
* tag at compile time.
* @see http://wact.sourceforge.net/index.php/CoreSetTag
* @access protected
* @package WACT_TAG
*/
class CoreSetTag extends SilentCompilerDirectiveTag {
	/**
	* @return void
	* @access protected
	*/
	function CheckNestingLevel() {
		if ($this->findParentByClass('CoreSetTag')) {
            RaiseError('compiler', 'BADSELFNESTING', array(
                'tag' => $this->tag,
                'file' => $this->SourceFile,
                'line' => $this->StartingLineNo));
		}
	}

	/**
	* @return int PARSER_FORBID_PARSING
	* @access protected
	*/
	function preParse() {

		$DataSpace =& $this->getDataSpace();
		$DataSpace->vars += $this->attributes;

		return PARSER_FORBID_PARSING;
	}
}
?>