<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT_TAG
* @version $Id: import.tag.php,v 1.13 2003/11/29 23:03:04 jeffmoore Exp $
*/
/**
* Include the VarFileCompiler
*/
require_once WACT_ROOT . '/template/compiler/varfilecompiler.inc.php';
//--------------------------------------------------------------------------------
/**
* Register tag
*/
registerTag(new CoreImportTagInfo());
/**
* @see http://wact.sourceforge.net/index.php/TagInfoClasses
* @access protected
* @package WACT_TAG
*/
class CoreImportTagInfo {
    var $Tag = 'core:IMPORT';
    var $EndTag = ENDTAG_FORBIDDEN;
    var $TagClass = 'CoreImportTag';
}
/**
* Imports a var file into the dataspace (e.g. a configuration file)
* @see http://wact.sourceforge.net/index.php/CoreImportTag
* @access protected
* @package WACT_TAG
*/
class CoreImportTag extends SilentCompilerDirectiveTag {
    /**
    * @return void
    * @access protected
    */
    function CheckNestingLevel() {
        if ($this->findParentByClass('CoreImportTag')) {
            RaiseError('compiler', 'BADSELFNESTING', array(
                'tag' => $this->tag,
                'file' => $this->SourceFile,
                'line' => $this->StartingLineNo));
        }
    }

    /**
    * @return int PARSER_FORBID_PARSING
    * @access protected
    */
    function preParse() {
        if (! array_key_exists('file', $this->attributes) ||
            empty($this->attributes['file'])) {
            RaiseError('compiler', 'MISSINGREQUIREATTRIBUTE', array(
                'tag' => $this->tag,
                'attribute' => 'file', 
                'file' => $this->SourceFile,
                'line' => $this->StartingLineNo));
        }
        $file = $this->attributes['file']; 

        $sourcefile = ResolveTemplateSourceFileName($file, TMPL_IMPORT, $this->SourceFile);
        if (empty($sourcefile)) {
            RaiseError('compiler', 'MISSINGFILE', array(
                'tag' => $this->tag,
                'srcfile' => $file, 
                'file' => $this->SourceFile,
                'line' => $this->StartingLineNo));
        }
        
        $DataSpace =& $this->getDataSpace();
        $DataSpace->vars += parseVarFile($sourcefile);

        return PARSER_FORBID_PARSING;
    }
}
?>