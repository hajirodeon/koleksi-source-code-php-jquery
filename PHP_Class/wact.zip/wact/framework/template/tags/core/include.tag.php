<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT_TAG
* @version $Id: include.tag.php,v 1.12 2003/10/16 21:16:06 jon-bangoid Exp $
*/
//--------------------------------------------------------------------------------
/**
* Register the tag
*/
registerTag(new CoreIncludeTagInfo());
/**
* @see http://wact.sourceforge.net/index.php/TagInfoClasses
* @access protected
* @package WACT_TAG
*/
class CoreIncludeTagInfo {
    var $Tag = 'core:INCLUDE';
    var $EndTag = ENDTAG_FORBIDDEN;
    var $TagClass = 'CoreIncludeTag';
}
/**
* Include another template into the current template
* @see http://wact.sourceforge.net/index.php/CoreIncludeTag
* @access protected
* @package WACT_TAG
*/
class CoreIncludeTag extends CompilerDirectiveTag {

    /**
    * @return int PARSER_FORBID_PARSING
    * @access protected
    */
    function preParse() {
        global $TagDictionary;
        if (! array_key_exists('file', $this->attributes) ||
            empty($this->attributes['file'])) {
            RaiseError('compiler', 'MISSINGREQUIREATTRIBUTE', array(
                'tag' => $this->tag,
                'attribute' => 'file',
                'file' => $this->SourceFile,
                'line' => $this->StartingLineNo));
        }
        $file = $this->attributes['file']; 
    
        $sourcefile = ResolveTemplateSourceFileName($file, TMPL_INCLUDE, $this->SourceFile);
        if (empty($sourcefile)) {
            RaiseError('compiler', 'MISSINGFILE', array(
                'tag' => $this->tag,
                'srcfile' => $file,
                'file' => $this->SourceFile,
                'line' => $this->StartingLineNo));
        }

        if (array_key_exists('literal', $this->attributes)) {
            $LiteralComponent =& new TextNode(readTemplateFile($sourcefile));
            $this->addChild($LiteralComponent);
        } else {
            $sfp =& new SourceFileParser($sourcefile,$TagDictionary);
            $sfp->parse($this);
        }
        return PARSER_FORBID_PARSING;
    }
}
?>