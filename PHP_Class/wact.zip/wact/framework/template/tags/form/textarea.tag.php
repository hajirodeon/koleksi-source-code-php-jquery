<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT_TAG
* @version $Id: textarea.tag.php,v 1.12 2003/11/29 23:03:05 jeffmoore Exp $
* @see http://www.w3.org/TR/html4/interact/forms.html
*/
//--------------------------------------------------------------------------------
/**
* Include control tag
*/
require_once 'control.inc.php';
/**
* Register the tag
*/
registerTag(new TextAreaTagInfo());
/**
* @see http://wact.sourceforge.net/index.php/TagInfoClasses
* @access protected
* @package WACT_TAG
*/
class TextAreaTagInfo {
	var $Tag = 'textarea';
	var $EndTag = ENDTAG_REQUIRED;
	var $TagClass = 'TextAreaTag';
}
/**
* Compile time component for building runtime textarea components
* @see http://wact.sourceforge.net/index.php/TextAreaTag
* @access protected
* @package WACT_TAG
*/
class TextAreaTag extends ControlTag {
	/**
	* File to include at runtime
	* @var string path to runtime component relative to WACT_ROOT
	* @access private
	*/
	var $runtimeIncludeFile = '/template/components/form.inc.php';
	/**
	* Name of runtime component class
	* @var string
	* @access private
	*/
	var $runtimeComponentName = 'TextAreaComponent';

	/**
	* Ignore the compiler time contents and generate the contents at run time.
	* @return void
	* @access protected
	*/
	// Ignore the compiler time contents and generate the contents at run time.
	function generateContents(&$code) {
		$code->writePHP($this->getComponentRefCode() . '->renderContents();');
	}

}

?>