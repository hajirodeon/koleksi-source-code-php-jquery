<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT_TAG
* @version $Id: errorsummary.tag.php,v 1.12 2003/11/29 23:03:05 jeffmoore Exp $
*/
//--------------------------------------------------------------------------------
/**
* Register the tag
*/
registerTag(new ErrorSummaryTagInfo());
/**
* @see http://wact.sourceforge.net/index.php/TagInfoClasses
* @access protected
* @package WACT_TAG
*/
class ErrorSummaryTagInfo {
	var $Tag = 'ERRORSUMMARY';
	var $EndTag = ENDTAG_REQUIRED;
	var $TagClass = 'ErrorSummaryTag';
}
/**
* Compile time component for errorsummary tags. Uses the ListComponent at
* runtime
* @see ListComponent
* @see http://wact.sourceforge.net/index.php/ErrorSummaryTag
* @access protected
* @package WACT_TAG
*/
class ErrorSummaryTag extends ServerComponentTag {
	/**
	* File to include at runtime
	* @var string path to runtime component relative to WACT_ROOT
	* @access private
	*/
	var $runtimeIncludeFile = '/template/components/list.inc.php';
	/**
	* Name of runtime component class
	* @var string
	* @access private
	*/
	var $runtimeComponentName = 'ListComponent';
	/**
	* ???
	* @var object
	* @access private
	*/
	var $itemChild;

	/**
	* @return void
	* @access protected
	*/
	function CheckNestingLevel() {
		if (!$this->findParentByClass('FormTag')) {
            RaiseError('compiler', 'MISSINGENCLOSURE', array(
                'tag' => $this->tag,
                'EnclosingTag' => 'form',
                'file' => $this->SourceFile,
                'line' => $this->StartingLineNo));
		}
	}

	/**
	* @param CodeWriter
	* @return void
	* @access protected
	*/
	function preGenerate(&$code) {
		parent::preGenerate($code);

		$ParentForm =& $this->findParentByClass('FormTag');
		$code->writePHP($this->getComponentRefCode() . '->registerDataSet(' .
			$ParentForm->getComponentRefCode() . '->getErrorDataSet());');

		if (isset($this->attributes['for'])) {
			$code->writePHP($this->getDataSpaceRefCode() . '->restrictFields(array(\'' . 
				$this->attributes['for'] . '\'));');
		}
	
		$code->writePHP($this->getComponentRefCode() . '->prepare();');
		$code->writePHP('if (' . $this->getDataSpaceRefCode() . '->next()) {');
	}

	/**
	* @param CodeWriter
	* @return void
	* @access protected
	*/
	function postGenerate(&$code) {
		$code->writePHP('}');
		
		$emptyChild =& $this->findChildByClass('ListListTag');
		if ($emptyChild) {
			$code->writePHP(' else { ');
			$emptyChild->generateNow($code);
			$code->writePHP('}');
		}
		parent::postGenerate($code);
	}

	/**
	* @return ErrorSummaryTag this instance
	* @access protected
	*/
	function &getDataSpace() {
		return $this;
	}

	/**
	* @return string PHP runtime reference to object
	* @access protected
	*/
	function getDataSpaceRefCode() {
		return $this->getComponentRefCode() . '->DataSet';
	}
}
?>