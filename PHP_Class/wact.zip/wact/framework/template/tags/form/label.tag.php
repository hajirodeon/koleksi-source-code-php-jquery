<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT_TAG
* @version $Id: label.tag.php,v 1.12 2003/11/29 23:03:05 jeffmoore Exp $
* @see http://www.w3.org/TR/html4/interact/forms.html
*/
// see http://www.w3.org/TR/html4/interact/forms.html
//--------------------------------------------------------------------------------
/**
* Register the tag
*/
registerTag(new LabelTagInfo());
/**
* @see http://wact.sourceforge.net/index.php/TagInfoClasses
* @access protected
* @package WACT_TAG
*/
class LabelTagInfo {
	var $Tag = 'label';
	var $EndTag = ENDTAG_REQUIRED;
	var $TagClass = 'LabelTag';
	var $HideAttrs = array('errorclass');
}
/**
* Compile time component for building runtime form labels
* @see http://wact.sourceforge.net/index.php/LabelTag
* @access protected
* @package WACT_TAG
*/
class LabelTag extends ServerTagComponentTag {
	/**
	* File to include at runtime
	* @var string path to runtime component relative to WACT_ROOT
	* @access private
	*/
	var $runtimeIncludeFile = '/template/components/form.inc.php';
	/**
	* Name of runtime component class
	* @var string
	* @access private
	*/
	var $runtimeComponentName = 'LabelComponent';

	/**
	* @return void
	* @access protected
	*/
	function CheckNestingLevel() {
		if ($this->findParentByClass('LabelTag')) {
            RaiseError('compiler', 'BADSELFNESTING', array(
                'tag' => $this->tag,
                'file' => $this->SourceFile,
                'line' => $this->StartingLineNo));
		}
		if (!$this->findParentByClass('FormTag')) {
            RaiseError('compiler', 'MISSINGENCLOSURE', array(
                'tag' => $this->tag,
                'EnclosingTag' => 'form',
                'file' => $this->SourceFile,
                'line' => $this->StartingLineNo));
		}
	}

	/**
	* @param CodeWriter
	* @return void
	* @access protected
	*/
	function generateConstructor(&$code) {
		parent::generateConstructor($code);
		if (array_key_exists('errorclass', $this->attributes)) {
			$code->writePHP($this->getComponentRefCode() . 
				'->errorclass = \'' . $this->attributes['errorclass'] . '\';');
			unset($this->attributes['errorclass']);
		}
		if (array_key_exists('errorstyle', $this->attributes)) {
			$code->writePHP($this->getComponentRefCode() . 
				'->errorstyle = \'' . $this->attributes['errorstyle'] . '\';');
			unset($this->attributes['errorstyle']);
		}
	}
}
?>