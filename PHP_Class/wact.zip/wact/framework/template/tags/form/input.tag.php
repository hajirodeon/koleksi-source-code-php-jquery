<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT_TAG
* @version $Id: input.tag.php,v 1.13 2003/11/29 23:03:05 jeffmoore Exp $
* @see http://www.w3.org/TR/html4/interact/forms.html
*/
//--------------------------------------------------------------------------------
/**
* Include control tag
*/
require_once 'control.inc.php';

/**
* Register the tag
*/
registerTag(new InputTagInfo());
/**
* @see http://wact.sourceforge.net/index.php/TagInfoClasses
* @access protected
* @package WACT_TAG
*/
class InputTagInfo {
	var $Tag = 'input';
	var $EndTag = ENDTAG_FORBIDDEN;
	var $TagClass = 'InputTag';
	var $HideAttrs = array('displayname');
}
/**
* Compile time component for building runtime InputComponents
* Creates all the components beginning with the name Input
* @see http://wact.sourceforge.net/index.php/InputTag
* @access protected
* @package WACT_TAG
*/
class InputTag extends ControlTag {
	/**
	* File to include at runtime
	* @var string path to runtime component relative to WACT_ROOT
	* @access private
	*/
	var $runtimeIncludeFile = '/template/components/form.inc.php';

	/**
	* Sets the runtimeComponentName property, depending on the type of
	* Input tag
	* @return void
	* @access protected
	*/
	function prepare() {
		$type = strtolower($this->attributes['type']);
		switch ($type) {
		case 'text':
			$this->runtimeComponentName = 'InputTextComponent';
			break;
		case 'password':
			$this->runtimeComponentName = 'InputPasswordComponent';
			break;
		case 'checkbox':
			$this->runtimeComponentName = 'InputCheckboxComponent';
			break;
		case 'submit':
			$this->runtimeComponentName = 'InputSubmitComponent';
			break;
		case 'radio':
			$this->runtimeComponentName = 'InputRadioComponent';
			break;
		case 'reset':
			$this->runtimeComponentName = 'InputResetComponent';
			break;
		case 'file':
			$this->runtimeComponentName = 'InputFileComponent';
			break;
		case 'hidden':
			$this->runtimeComponentName = 'InputHiddenComponent';
			break;
		case 'image':
			$this->runtimeComponentName = 'InputImageComponent';
			break;
		case 'button':
			$this->runtimeComponentName = 'InputButtonComponent';
			break;
		default:
            RaiseError('compiler', 'UNKNOWNINPUTYPE', array(
                'file' => $this->SourceFile,
                'line' => $this->StartingLineNo));
		}
		
		parent::prepare();
	}
}
?>