<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT_TAG
* @version $Id: button.tag.php,v 1.10 2003/11/29 23:03:05 jeffmoore Exp $
* @see http://www.w3.org/TR/html4/interact/forms.html
*/
// see http://www.w3.org/TR/html4/interact/forms.html
//--------------------------------------------------------------------------------
/**
* Include control tag
*/
require_once 'control.inc.php';
/**
* Register the tag
*/
registerTag(new ButtonTagInfo());
/**
* @see http://wact.sourceforge.net/index.php/TagInfoClasses
* @access protected
* @package WACT_TAG
*/
class ButtonTagInfo {
	var $Tag = 'button';
	var $EndTag = ENDTAG_REQUIRED;
	var $TagClass = 'ButtonTag';
}
/**
* Compile time component for button tags
* @see http://wact.sourceforge.net/index.php/ButtonTag
* @access protected
* @package WACT_TAG
*/
class ButtonTag extends ControlTag {
	/**
	* File to include at runtime
	* @var string path to runtime component relative to WACT_ROOT
	* @access private
	*/
	var $runtimeIncludeFile = '/template/components/form.inc.php';
	/**
	* Name of runtime component class
	* @var string
	* @access private
	*/
	var $runtimeComponentName = 'ButtonComponent';

}
?>