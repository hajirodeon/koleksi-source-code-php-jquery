<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT_TEMPLATE
* @version $Id: runtimesupport.inc.php,v 1.7 2003/10/08 05:29:40 jeffmoore Exp $
* Contains the multilang filescheme runtime side functions
* @see http://wact.sourceforge.net/index.php/FileScheme
*/

//--------------------------------------------------------------------------------
/**
* Determines the full path to a compiled template file.
* @see http://wact.sourceforge.net/index.php/ResolveTemplateCompiledFileName
* @param string template file name
* @param operation (TMPL_INCLUDE default) - deprecated?
* @return void
* @access protected
* @ignore
*/
function ResolveTemplateCompiledFileName($file, $operation = TMPL_INCLUDE) {

	if (gettype(strpos($file, "..")) == "integer" || gettype(strpos($file, "//")) == "integer") {
        RaiseError('compiler', 'INVALIDFILENAME', array(
            'file' => $file));
	}

	if (substr($file, 0, 1) == '/') {
	    $root = (getConfigOption('config', 'filescheme', 'templateroot'));
		if (isset($root)) {
			$FileRoot = $root . '/compiled';
		} else {
			$FileRoot = dirname($_SERVER['SCRIPT_FILENAME']) . '/templates/compiled';
		}
		return $FileRoot . '/' . $GLOBALS['CurrentLanguage'] . $file;
	} else {
        RaiseError('compiler', 'RELATIVEPATH', array(
            'file' => $file));
	}
}

/**
* Returns the contents of a compiled template file
* @see http://wact.sourceforge.net/index.php/readTemplateFile
* @param string template file name
* @return string
* @access protected
* @ignore
*/
function readTemplateFile($file) {
	return file_get_contents($file);
}
?>