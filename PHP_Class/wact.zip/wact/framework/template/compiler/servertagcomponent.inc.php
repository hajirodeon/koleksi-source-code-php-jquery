<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT_TEMPLATE
* @version $Id: servertagcomponent.inc.php,v 1.12 2003/12/05 01:01:05 harryf Exp $
*/
//--------------------------------------------------------------------------------
/**
* Server tag component tags are ServerComponentTags which also correspond to
* an HTML tag. Makes it easier to implement instead of extending from the
* ServerComponentTag class
* @see http://wact.sourceforge.net/index.php/ServerTagComponentTag
* @access public
* @abstract
* @package WACT_TEMPLATE
*/
class ServerTagComponentTag extends ServerComponentTag {
	/**
	* Whether the was empty and closed such as <br />
	* @var boolean
	* @access private
	*/
	var $emptyClosedTag = FALSE;

	/**
	* Returns the XML tag name
	* @return string
	* @access protected
	*/
	function getRenderedTag() {
		return $this->tag;
	}

	/**
	* Adds any additional XML attributes
	* @param CodeWriter
	* @return void
	* @abstract
	* @access protected
	*/
	function generateExtraAttributes(&$code) {
		foreach ( $this->children as $Component ) {
			if ( get_class($Component) == 'attributevariablereference' ||
					is_subclass_of($Component,'attributevariablereference') ) {
				$code->writeHTML(' '.$Component->name.'"');
				$code->writePHP('echo(htmlspecialchars('.
					$Component->getComponentRefCode().'->get(\''.
						$Component->reference.'\'), ENT_QUOTES));');
				$code->writeHTML('"');
			}
		}
	}

	/**
	* Calls the parent preGenerate() method then writes the XML tag name
	* plus a PHP string which renders the attributes from the runtime
	* component.
	* @param CodeWriter
	* @return void
	* @access protected
	* @todo compiler needs to detect XML to allow for empty tags
	*/
	function preGenerate(&$code) {
		parent::preGenerate($code);
		$code->writeHTML('<' . $this->getRenderedTag());
		$code->writePHP($this->getComponentRefCode() . '->renderAttributes();');
		if ( $this->emptyClosedTag ) {
			$code->writeHTML(' /');
		}
		$this->generateExtraAttributes($code);
		$code->writeHTML('>');
	}

	/**
	* Writes the closing tag string to the compiled template
	* @param CodeWriter
	* @return void
	* @access protected
	*/
	function postGenerate(&$code) {
		if ($this->hasClosingTag) {
			$code->writeHTML('</' . $this->getRenderedTag() .  '>');
		}
		parent::postGenerate($code);
	}

	/**
	* Writes the compiled template constructor from the runtime component,
	* assigning the attributes found at compile time to the runtime component
	* via a serialized string
	* @param CodeWriter
	* @return void
	* @access protected
	*/
	function generateConstructor(&$code) {
		parent::generateConstructor($code);
		$attrs = array();
		// Find the attribute nodes
		foreach ( $this->children as $key => $Component ) {
			if ( get_class($Component) == 'attributenode' ||
					is_subclass_of($Component,'attributenode')) {
				$attrs[$Component->name] = $Component->value;
			}
		}
		// Filters out attributes which should be hidden
		$attrs = $this->attributes;
		$TagDictionary = & TagDictionary::getInstance();
		$TagInfo = $TagDictionary->getTagInfo($this->tag);
		if ( !isset($TagInfo->HideAttrs) || !is_array($TagInfo->HideAttrs) ) {
			$TagInfo->HideAttrs = array();
		}
		foreach ( $attrs as $key => $value ) {
			foreach ( $TagInfo->HideAttrs as $hide ) {
				if ( strcasecmp($key,$hide) == 0 ) {
					unset($attrs[$key]);
				}
			}
		}
		$code->writePHP($this->getComponentRefCode() .
			'->attributes = unserialize(\'' . serialize($attrs) . '\');');
	}
}
?>