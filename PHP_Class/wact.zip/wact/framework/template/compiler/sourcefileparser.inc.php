<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT_TEMPLATE
* @version $Id: sourcefileparser.inc.php,v 1.33 2003/12/23 15:10:25 harryf Exp $
*/
/**
* Define compile component states which determine parse behaviour
*/
define('PARSER_REQUIRE_PARSING', TRUE);
define('PARSER_FORBID_PARSING', FALSE);
define('PARSER_ALLOW_PARSING', NULL);
/**
* Define the attribute which "triggers" components
*/
define('PARSER_TRIGGER_ATTR_NAME','runat');
define('PARSER_TRIGGER_ATTR_VALUE','server');
/**
* Include XMLPull
*/
require_once WACT_ROOT . '/template/compiler/xmlpull.inc.php';
//--------------------------------------------------------------------------------
/**
* The source template parser which uses the XMLPull parser
* @todo This is not in use yet. Planned to replace the existing regex based parser
* @see http://wact.sourceforge.net/index.php/SourceFileParser
* @access public
* @package WACT_TEMPLATE
* @ignore
*/
class SourceFileParser {
	/**
	* The contents of the source template as a string
	* @var string
	* @access private
	*/
	var $rawtext;
	/**
	* Instance of XMLPull
	* @var XMLPull
	* @access private
	*/
	var $parser;
	/**
	* Path and filename of source template
	* @var string
	* @access private
	*/
	var $SourceFile;
	/**
	* Reference to the global instance of the TagDictionary
	* @var TagDictionary
	* @access private
	*/
	var $TagDictionary;
	/**
	* Current line number of parser cursor within the raw text
	* @var int
	* @access private
	*/
	var $CurByteIndex;
	/**
	* Lists of tags obtained from TagDictionary
	* @var array
	* @access private
	*/
	var $TagList;
	/**
	* Regex pattern to match the contents of a tag.
	* @var string
	* @access private
	*/
	var $variableReferencePattern;
	
	//----------------------------------------------------------------------------
	/**
	* Constructs SourecFileParser. Uses readTemplateFile() to get the contents
	* of the template.
	* @see readTemplateFile
	* @param string path and filename of source template
	* @access protected
	*/
	function SourceFileParser($sourcefile,& $tagdictionary) {
		$this->SourceFile = $sourcefile;
		$this->TagDictionary = & $tagdictionary;
		$this->rawtext = $this->readTemplateFile($sourcefile);
		$this->parser = & new XMLPull($this->rawtext);
		$this->CurByteIndex = 0;
		$this->text = '';
		$this->getTags();
		$this->initializeVariableReferencePattern();
	}

	//----------------------------------------------------------------------------
	/**
	* Builds the TagList, converting tag names to lower case
	* @return void
	* @access private
	*/
	function getTags() {
		$this->TagList = array_map('strtolower',$this->TagDictionary->getTagList());
	}

	//----------------------------------------------------------------------------
	/**
	* Builds the regex for fetching contents of tags
    *
	* @return void
	* @access private
	*/
	function initializeVariableReferencePattern() {
        $this->variableReferencePattern = '/^((?Us)[^{]*){(' . preg_quote('$', '/') . '|' . preg_quote('#', '/') . '|' . preg_quote('^', '/') . ')(\w+)}((?s).*)$/';
	}

	//--------------------------------------------------------------------------------
	// This does not correctly determine the line number of the variable reference.
	// The preg_match in this method should be rolled up and included in the main
	// loop of the parse() method.
	// This will require a seriously nasty regular expression.
	/**
	* Used to parse the contents of a component
	* @param object compile time component
	* @param string contents of a component
	* @return void
	* @access private
	*/
	function parseText(&$ParentComponent, $text, $attribute = NULL) {
		while (preg_match($this->variableReferencePattern, $text, $match)) {
			if (strlen($match[1]) > 0) {
				$Component =& $this->getTextNode($match[1]);
				$ParentComponent->addChild($Component);
			}
			$Component =& $this->getVariableReference($attribute);
			$Component->reference = $match[3];
			$Component->scope = $match[2];

			// Set up the Sourcefile and line number for errors
			$Component->SourceFile = $this->SourceFile;
			$Component->StartingLineNo = $this->getLineNumber();

			$ParentComponent->addChild($Component);
			$text = $match[4];
		}
		if (strlen($text) > 0) {
			$Component =& $this->getTextNode($text,$attribute);
			$ParentComponent->addChild($Component);
		}
	}

	/**
	* Parse an attribute for a variable reference
	* @param object compile time component
	* @param string name of attribute
	* @param string value of attribute
	* @return void
	* @access private
	*/
	function parseAttribute(&$ParentComponent, $name, $value) {
		// Set up the Sourcefile and line number for errors
		$Component->SourceFile = $this->SourceFile;
		$Component->StartingLineNo = $this->getLineNumber();
		if ( preg_match($this->variableReferencePattern, $value, $match) ) {
			$Component =& $this->getVariableReference($value,$name);
			$Component->reference = $match[3];
			$Component->scope = $match[2];

			$ParentComponent->addChild($Component);
			$text = $match[4];
		} else {
			$Component =& $this->getAttributeNode($name,$value);
			$ParentComponent->addChild($Component);
		}
	}

	//----------------------------------------------------------------------------
	/**
	* Make sure we never have a duplicate Server Id in the component tree we build.
	* @param object parent component
	* @param object current component
	* @return void
	* @access private
	*/
	function CheckServerId(&$ParentComponent, &$Component) {
		// Move up to the root
		$root =& $ParentComponent;
		while (!is_null($root->parent)) {
			$root =& $root->parent;
		}
		
		$ServerId = $Component->getServerId();
		if ($root->findChild($ServerId)) {
			RaiseError('compiler', 'DUPLICATEID', array(
				'ServerId' => $ServerId,
				'tag' => $Component->tag,
				'file' => $Component->SourceFile, 
				'line' => $Component->StartingLineNo));
		}
		
	}

	//----------------------------------------------------------------------------
	/**
	* Used to parse the source template.
	* Initially invoked by the CompileTemplate function,
	* the first component argument being a ComponentTree.
	* Uses the TagDictionary to spot compiler components
	* @see CompileTemplate
	* @see ComponentTree
	* @see TagDictionary
	* @param object compile time component
	* @return void
	* @access protected
	*/
	function parse(&$ComponentRoot) {
		$TagInfo = NULL;
		$ParentComponent = NULL;
		$Component = & $ComponentRoot; // Set the starting component
		$Component->contents = '';

		// Monitor the state for literal components
		$LiteralTag = '';
		$ForbidParsing = false;

		while ( $event = $this->parser->parse() ) {
			$this->CurByteIndex = $event->position(); // Keep track of location

			switch ( $event->type() ) {
				//----------------------------------------------------------------
				case XML_OPEN: // XML opening tags
					$tag = $event->tag();
					$attrs = $event->attributes();

					// Unless parsing is forbidden, components are dealt with here
					if ( $this->isComponent($tag,$attrs) && !$ForbidParsing) {
						// Remap attributes as required
						$attrs = $this->remapAttributes($tag,$attrs);

						// Get tag info
						$TagInfo =& $this->TagDictionary->getTagInfo($tag);
						$tagClass = $TagInfo->TagClass;

						// Assign current component to parent reference
						$ParentComponent = & $Component;

						// Create the new component
						$Component =& new $tagClass();
						$Component->tag = $tag;

						// Create AttributeNodes or ArtributeVariableReferences
						foreach ( $attrs as $key => $value ) {
							$this->parseAttribute($Component,$key,$value);
						}

						// Set up the Sourcefile and line number for errors
						$Component->SourceFile = $this->SourceFile;
						$Component->StartingLineNo = $this->getLineNumber();

						// Pass on whether this in an empty and closed tag
						if ( $this->isServerTagComponentTag($tag) ) {
							$Component->emptyClosedTag = $event->isEmpty();
						}

						// Filter out runat attributes - HACK!
						if ( isset($attrs[PARSER_TRIGGER_ATTR_NAME]) ) {
							unset ($attrs[PARSER_TRIGGER_ATTR_NAME]);
						}

						// Assign attributes to new component
						$Component->setAttributes($attrs);

						// Check for duplicate IDs
						$this->CheckServerId($ParentComponent, $Component);

						// Add child to parent
						$ParentComponent->addChild($Component);

						// Call the component self validation check
						$Component->CheckNestingLevel();

						// Switch parser state to Forbid parsing if necessary
						if ( $Component->preParse() == PARSER_FORBID_PARSING ) {
							$LiteralTag = $tag;
							$ForbidParsing = true;
						}

						// Cleanup for components that have no closing tag
						if ( $TagInfo->EndTag == ENDTAG_FORBIDDEN ) {
							$Component->hasClosingTag = FALSE;
							$Component = & $ParentComponent;
							$ParentComponent = & $Component->parent;
							$LiteralTag = '';
							$ForbidParsing = false;
						}

					} else {
						// Deal with normal HTML here
						$Component->addChild($this->getTextNode('<'));
						$tagString = $tag;
						foreach ( $attrs as $key => $value ) {
							// Filter out runat attributes - HACK
							if ( strcasecmp($key,PARSER_TRIGGER_ATTR_NAME) == 0 ) {
								continue;
							}
							$tagString.= ' '.$key;
							if (!is_null($value)) {
								$tagString.= '="'.htmlspecialchars($value, ENT_QUOTES).'"';
							}
						}
						if ( !$ForbidParsing ) {
							$this->parseText($Component,$tagString);
						} else {
							$Component->addChild($this->getTextNode($tagString));
						}
						if ( $event->isEmpty() ) {
							$close = ' />';
						} else {
							$close = '>';
						}
						$Component->addChild($this->getTextNode($close));
					}

				break;
				//----------------------------------------------------------------
				case XML_CLOSE: // XML opening tags
					$tag = $event->tag();

					// Cleanup if this is the closing tag of a Literal
					if ( $ForbidParsing && $LiteralTag == $tag ) {
						$LiteralTag = '';
						$ForbidParsing = false;
						$Component->hasClosingTag = TRUE;
						$Component = & $ParentComponent;
						$ParentComponent = & $Component->parent;

					// Handle closing of components
					} else if ( in_array(strtolower($tag),$this->TagList) && !$ForbidParsing ) {
						// Check for unexpected closing tags
						if ( $Component->tag != $tag ) {
							if ( !$this->isServerTagComponentTag($tag) ) {
								// If there's a concrete parent, say what was expected
								if ( isset($Component->tag) ) {
									RaiseError('compiler', 'UNEXPECTEDCLOSE', array(
										'tag' => $tag,
										'ExpectTag' => $Component->tag,
										'file' => $this->SourceFile, 
										'line' => $this->getLineNumber()));
								// No concrete parent? (e.g. ComponentTree)
								} else {
									RaiseError('compiler', 'UNEXPECTEDCLOSE2', array(
										'tag' => $tag,
										'file' => $this->SourceFile, 
										'line' => $this->getLineNumber()));
								}
							} else {
								// Treat unexpected ServerTagComponentTag as normal HTML
								if ( !$event->isEmpty() ) {
									$Component->addChild($this->getTextNode('</'.$tag.'>'));
								}
							}
						} else {
							$TagInfo =& $this->TagDictionary->getTagInfo($tag);

							// Check for tags which shouldn't be closed
							if ($TagInfo->EndTag == ENDTAG_FORBIDDEN) {
								RaiseError('compiler', 'UNEXPECTEDCLOSE2', array(
									'tag' => $tag,
									'file' => $this->SourceFile, 
									'line' => $this->getLineNumber()));
							}
							$Component->hasClosingTag = TRUE;
							$Component = & $ParentComponent;
							$ParentComponent = & $Component->parent;
						}
					// Handle normal HTML
					} else {
						if ( !$event->isEmpty() ) {
							$Component->addChild($this->getTextNode('</'.$tag.'>'));
						}
					}
				break;
				//----------------------------------------------------------------
				case XML_TEXT: // Handle the body of a tag
					// If parsing not forbidden, allow literals
					if ( !$ForbidParsing ) {
						$this->parseText($Component,$event->text());
					} else {
						// Else dump the text straight through
						$Component->addChild($this->getTextNode($event->text()));
					}
				break;
				//----------------------------------------------------------------
				case XML_ESCAPE:
					// Pass through any doctype declarations / comments / CDATA sections
					$Component->addChild(
						$this->getTextNode('<!'.$event->text().'>'));
				break;
				//----------------------------------------------------------------
				case XML_PI:
					// Pass through any PI's except PHP PI's
					$invalid_targets = array('php','PHP','=','');
					if ( !in_array($event->target(),$invalid_targets) ) {
						$Component->addChild(
							$this->getTextNode(
								'<?'.$event->target().$event->instruction().'?>'
							)
						);
					}
				break;
			}
		}
		// Check for closing tag - the Component should be back to where we started
		if ( get_class($Component) != get_class($ComponentRoot) ) {
			RaiseError('compiler', 'MISSINGCLOSE', array(
				'tag' => $Component->tag,
				'file' => $this->SourceFile, 
				'line' => $this->getLineNumber()));
		}
	}

	//----------------------------------------------------------------------------
	/*
	* Determines whether a tag is a server component, examining attributes and class
	* @param string tag name
	* @param array tag attributes
	* @return boolean TRUE if it's a component
	* @access private
	*/
	function isComponent($tag,$attrs=array()) {
		if ( !in_array(strtolower($tag),$this->TagList) ) {
			return FALSE;
		}
		if ( isset ( $attrs[PARSER_TRIGGER_ATTR_NAME] ) ) {
			if ( strtolower($attrs[PARSER_TRIGGER_ATTR_NAME]) == PARSER_TRIGGER_ATTR_VALUE ) {
				return TRUE;
			} else {
				return FALSE;
			}
		}
/**
This is how it "should" be but will break alot of existing templates if changed
		if ( $this->isServerTagComponentTag($tag) ) {
			return FALSE;
		} else {
			return TRUE;
		}
**/
		if ( isset ( $attrs['id'] ) ) {
			return TRUE;
		} else if ( !$this->isServerTagComponentTag($tag)) {
			return TRUE;
		} else {
			return FALSE;
		}
	}

	//----------------------------------------------------------------------------
	/*
	* Checks the type of class of a tag, returning true if it's a subclass of
	* of ServerTagComponentTag
	* @param string tag name
	* @return boolean TRUE if it's a subclass of ServerTagComponentTag
	* @access private
	*/
	function isServerTagComponentTag($tag) {
		if ( in_array(strtolower($tag),$this->TagList) ) {
			$TagInfo =& $this->TagDictionary->getTagInfo($tag);
			$tagClass = $TagInfo->TagClass;
			// Hacking away ;) Watch this one cause trouble later...
			$Component =& new $tagClass();
			return is_subclass_of ($Component, 'ServerTagComponentTag' );
		} else {
			return FALSE;
		}
	}

	//----------------------------------------------------------------------------
	/*
	* Remaps attributes based on TagInfoClass
	* @param string tag name
	* @param array tag attributes
	* @return array of remapped attributes
	* @access private
	*/
	function remapAttributes($tag,$attrs=array()) {
		$TagInfo =& $this->TagDictionary->getTagInfo($tag);
		if ( isset($TagInfo->AttributeMap) && is_array($TagInfo->AttributeMap) ) {
			foreach ( $TagInfo->AttributeMap as $from => $to ) {
				if ( isset($attrs[$from]) && !isset($attrs[$to]) ) {
					$attrs[$to] = $attrs[$from];
					unset($attrs[$from]);
				}
			}
		}
		return $attrs;
	}

	//----------------------------------------------------------------------------
	/*
	* Calculates the line number from the byte index
	* @return int the current line number
	* @access private
	*/
	function getLineNumber() {
        $text_parsed_so_far = substr($this->rawtext, 0, $this->CurByteIndex);
        /* no. of \n so far is 1 less than current line no. */
        return 1 + substr_count($text_parsed_so_far, "\n");
	}

	//----------------------------------------------------------------------------
	/**
	* Provide local method of same name to help with Unit testing
	* @param string path and file of source template
	* @return string raw text from template file
	* @access private
	*/
	function readTemplateFile($sourcefile) {
		return readTemplateFile($sourcefile);
	}

	//----------------------------------------------------------------------------
	/**
	* Returns an instance of TextNode
	* @see TextNode
	* @param string text from template
	* @return TextNode
	* @access private
	*/
	function & getTextNode($text) {
		return new TextNode($text);
	}

	//----------------------------------------------------------------------------
	/*
	* Returns an instance of VariableReference
	* @see VariableReference
	* @see AttributeVariableReference
	* @param string (optional) name of attribute
	* @return object VariableReference or AttributeVariableReference
	* @access private
	*/
	function & getVariableReference($attribute = NULL) {
		if ( $attribute === NULL ) {
			return new VariableReference();
		} else {
			return new AttributeVariableReference($attribute);
		}
	}

	//----------------------------------------------------------------------------
	/*
	* Returns an instance of AttributeNode
	* @see AttributeNode
	* @param string name of attribute
	* @param string value of attribute
	* @return AttributeNode
	* @access private
	*/
	function getAttributeNode($name,$value) {
		$Component = new AttributeNode();
		$Component->name = $name;
		$Component->value = $value;
		return $Component;
	}
}
?>