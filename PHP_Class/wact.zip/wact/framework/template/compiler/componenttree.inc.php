<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT_TEMPLATE
* @version $Id: componenttree.inc.php,v 1.5 2003/09/23 14:37:44 harryf Exp $
*/
//--------------------------------------------------------------------------------
/**
* The root compile time component in the template hierarchy. Used to generate
* the correct reference PHP code like $DataSpace->...
* @see http://wact.sourceforge.net/index.php/ComponentTree
* @access public
* @package WACT_TEMPLATE
*/
class ComponentTree extends CompilerDirectiveTag {
	/**
	* Calls the parent preGenerate() method then writes
	* "$DataSpace->prepare();" to the compiled template.
	* @param CodeWriter
	* @return void
	* @access protected
	*/
	function preGenerate(&$code) {
		parent::preGenerate($code);
		$code->writePHP($this->getDataSpaceRefCode() . '->prepare();');
	}

	/**
	* Returns the base for building the PHP runtime component reference string
	* @param CodeWriter
	* @return string $DataSpace
	* @access protected
	*/
	function getComponentRefCode() {
		return '$DataSpace';
	}

	/**
	* Returns $DataSpace
	* @param CodeWriter
	* @return string $DataSpace
	* @access protected
	*/
	function getDataSpaceRefCode() {
		return '$DataSpace';
	}

	/**
	* Returns this instance of ComponentTree
	* @return ComponentTree this instance
	* @access protected
	*/
	function &getDataSpace() {
		return $this;
	}
}
?>