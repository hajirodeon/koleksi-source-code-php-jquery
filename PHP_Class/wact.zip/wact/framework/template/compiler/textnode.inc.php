<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT_TEMPLATE
* @version $Id: textnode.inc.php,v 1.5 2003/11/15 18:06:40 harryf Exp $
*/
//--------------------------------------------------------------------------------
// Literal Node
/**
* Used to write literal text from the source template to the compiled
* template
* @see http://wact.sourceforge.net/index.php/TextNode
* @access public
* @package WACT_TEMPLATE
*/
class TextNode extends CompilerDirectiveTag {
	/**
	* A text string to write
	* @var string
	* @access private
	*/
	var $contents;

	/**
	* Constructs TextNode
	* @param string contents of the text node
	* @access protected
	*/
	function TextNode($text) {
		$this->contents = $text;
	}

	/**
	* Writes the contents of the text node to the compiled template
	* using the writeHTML method
	* @param CodeWriter
	* @return void
	* @access protected
	*/
	function generate(&$code) {
		$code->writeHTML($this->contents);
	}
}
/**
* Used to store literal attributes found inside tag components
* @see http://wact.sourceforge.net/index.php/AttributeNode
* @access public
* @package WACT_TEMPLATE
*/
class AttributeNode extends CompilerDirectiveTag {
	var $name;
	var $value;
}
?>