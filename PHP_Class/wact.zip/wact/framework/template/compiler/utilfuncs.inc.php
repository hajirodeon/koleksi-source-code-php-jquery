<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT_TEMPLATE
* @version $Id: utilfuncs.inc.php,v 1.6 2003/10/13 22:09:56 jeffmoore Exp $
*/
//--------------------------------------------------------------------------------
/**
* Creates a new ID for a server component, if one wasn't found. Called from
* CompilerComponent::getServerId()
* @see http://wact.sourceforge.net/index.php/getNewServerId
* @see CompilerComponent
* @return string id for server component e.g. id000(x)
* @access protected
*/
function getNewServerId() {
	static $ServerIdCounter = 1;
	return 'id00' . $ServerIdCounter++;
}

//--------------------------------------------------------------------------------
/**
* Adds further quotes to a regex pattern
* @see http://wact.sourceforge.net/index.php/preg_replacement_quote
* @param string regular expression pattern
* @return string replacement
* @access protected
*/
function preg_replacement_quote($replacement) {
	$replacement = str_replace("\\", "\\\\", $replacement);
	$replacement = str_replace("$", "\\$", $replacement);
	return $replacement;
}

/*
	foreach( debug_backtrace() as $Line) {
		echo 'file: ' . $Line['file'] . ' line: ' . $Line['line'] . ' function: ' . $Line['function'] . " <BR>\n";
	}
	echo "<HR>\n";
*/

//--------------------------------------------------------------------------------
/**
* Debugging method to dump the component tree below the supplied component
* to screen
* @see http://wact.sourceforge.net/index.php/dump_component_tree
* @param object compile time component
* @return void
* @access public
*/
function dump_component_tree(&$Component) {
	if ($Component) {
		echo get_class($Component) . ' (' . $Component->getServerId() . ")<BR>\n";
		if (count($Component->children) > 0) {
			echo "<BLOCKQUOTE>\n";
			echo "<HR>\n";
			echo htmlspecialchars($Component->contents);
			echo "<HR>\n";
			foreach( array_keys($Component->children) as $key) {
				dump_component_tree($Component->children[$key]);
			}
			echo "</BLOCKQUOTE>\n";
		}
	}
}
?>