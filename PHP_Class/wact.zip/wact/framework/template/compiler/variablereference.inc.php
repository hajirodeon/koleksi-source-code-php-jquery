<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT_TEMPLATE
* @version $Id: variablereference.inc.php,v 1.5 2003/11/15 18:06:40 harryf Exp $
*/
//--------------------------------------------------------------------------------
/**
* Used to allow PHP variable references to be copied from straight from the source
* to the compiled template file.
* @see http://wact.sourceforge.net/index.php/VariableReference
* @access protected
* @package WACT_TEMPLATE
*/
class VariableReference extends CompilerComponent {
	/**
	* Reference of variable
	* @var string
	* @access private
	*/
	var $reference;
	/**
	* Scope of variable
	* @var string
	* @access private
	*/
	var $scope;

	/**
	* Generate the code
	* @param CodeWriter
	* @return void
	* @access protected
	*/
	function generate(&$code) {

		// This has to find parental namespaces, not parental components
		switch ($this->scope) {
			case '#':
				$Context =& $this->getRootDataSpace();
				break;
			case '^':
				$Context =& $this->getParentDataSpace();
				break;
			case '$':
				$Context =& $this->getDataSpace();
				break;
		}
		if ($Context != NULL) {
			if (array_key_exists($this->reference, $Context->vars)) {
				$code->writeHTML($Context->vars[$this->reference]);
			} else {
				$code->writePHP('echo ' . $Context->getDataSpaceRefCode() . '->get(\'' . $this->reference . '\');');
			}
		}
	}
}
/**
* Used for attributes in tag components who's values are variable references
* @see http://wact.sourceforge.net/index.php/AttributeVariableReference
* @access protected
* @package WACT_TEMPLATE
*/
class AttributeVariableReference extends VariableReference {
	/**
	* Attribute name
	* @var string
	* @access private
	*/
	var $name;
	/**
	* @param string attribute name
	* @access protected
	*/
	function AttributeVariableReference($name) {
		$this->name = $name;
	}
	/**
	* Generate the code
	* @param CodeWriter
	* @return void
	* @access protected
	*/
	function generate(&$code) {

		// This has to find parental namespaces, not parental components
		switch ($this->scope) {
			case '#':
				$Context =& $this->getRootDataSpace();
				break;
			case '^':
				$Context =& $this->getParentDataSpace();
				break;
			case '$':
				$Context =& $this->getDataSpace();
				break;
		}
		if ($Context != NULL) {
			if (array_key_exists($this->reference, $Context->vars)) {
				$code->writeHTML($this->name.'="'.$Context->vars[$this->reference].'"');
			} else {
				$code->writeHTML($this->name.'="');
				$code->writePHP('echo ' . $Context->getDataSpaceRefCode() . '->get(\'' . $this->reference . '\');');
				$code->writeHTML($this->name.'"');
			}
		}
	}
}
?>