<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT_TEMPLATE
* @version $Id: templatecompiler.inc.php,v 1.14 2003/11/29 23:03:01 jeffmoore Exp $
* This file is used to load the compile time component tags. Modify for new
* tag files, using the loadTags() function.
*/
//--------------------------------------------------------------------------------
/**
* Include all the compile time base components plus the compiler
*/
require_once WACT_ROOT . '/template/compiler/utilfuncs.inc.php';
require_once WACT_ROOT . '/template/compiler/tagdictionary.inc.php';

require_once WACT_ROOT . '/template/compiler/compilercomponent.inc.php';
require_once WACT_ROOT . '/template/compiler/compilerdirective.inc.php';
require_once WACT_ROOT . '/template/compiler/silentcompilerdirective.inc.php';
require_once WACT_ROOT . '/template/compiler/servercomponent.inc.php';
require_once WACT_ROOT . '/template/compiler/servertagcomponent.inc.php';
require_once WACT_ROOT . '/template/compiler/textnode.inc.php';
require_once WACT_ROOT . '/template/compiler/componenttree.inc.php';

require_once WACT_ROOT . '/template/compiler/sourcefileparser.inc.php';
require_once WACT_ROOT . '/template/compiler/codewriter.inc.php';
require_once WACT_ROOT . '/template/compiler/variablereference.inc.php';

require_once TMPL_FILESCHEME_PATH . '/compilersupport.inc.php';

//--------------------------------------------------------------------------------
/**
* Loads a concrete compile time tags file
* @param string name of tag file, to switch .tag.php will be appended
*/
function loadTags($TagDir) {

	if (is_dir($TagDir)) {
		if ($dir = opendir($TagDir)) {
			while (($TagFile = readdir($dir)) !== FALSE) {
				if (substr($TagFile, -8, 8) == '.tag.php') {
					include_once $TagDir . '/' . $TagFile;
				}
			}
		closedir($dir);
		}
	}

}
//--------------------------------------------------------------------------------
/**
* Create the TagDictionary global variable
*/
$GLOBALS['TagDictionary'] =& new TagDictionary();
/**
* Load some tag files
*/
$path = getConfigOption('compiler', 'tags', 'path');
foreach (explode(':', $path) as $tagpath) {
    if (substr($tagpath, 0, 1) != '/') {
        loadTags(WACT_ROOT . '/template/tags/' . $tagpath);
    } else {
        loadTags($tagpath);
    }
}

//--------------------------------------------------------------------------------
/**
* Compiles a template file. Uses the file scheme to location the source,
* instantiates the CodeWriter and ComponentTree (as the root) component then
* instantiates the SourceFileParser to parse the template.
* Creates the initialize and render functions in the compiled template.
* @see http://wact.sourceforge.net/CompileTemplateFile
* @see ComponentTree
* @see CodeWriter
* @see SourceFileParser
* @param string name of source template
* @return void
*/
function CompileTemplateFile($filename) {
	global $TagDictionary;
	$destfile = ResolveTemplateCompiledFileName($filename, TMPL_INCLUDE);
	$sourcefile = ResolveTemplateSourceFileName($filename, TMPL_INCLUDE);
	if (empty($sourcefile)) {
        RaiseError('compiler', 'MISSINGFILE2', array(
            'srcfile' => $filename));
	}

	$code =& new CodeWriter();
	$code->setFunctionPrefix(md5($destfile));

	$Tree =& new ComponentTree();
	$Tree->SourceFile = $sourcefile;
	
	$sfp =& new SourceFileParser($sourcefile,$TagDictionary);
	$sfp->parse($Tree);

	// DEBUG:
	// dump_component_tree($Tree);

	$Tree->prepare();
	
	$renderfunc = $code->beginFunction('(&$DataSpace)');
	$Tree->generate($code);
	$code->endFunction();
	
	$constructfunc = $code->beginFunction('(&$DataSpace)');
	$Tree->generateConstructor($code);
	$code->endFunction();

	$code->writePHP('$GLOBALS[\'TemplateRender\'][$this->codefile] = \'' . $renderfunc . '\';');
	$code->writePHP('$GLOBALS[\'TemplateConstruct\'][$this->codefile] = \'' . $constructfunc . '\';');

	writeTemplateFile($destfile, $code->getCode());
}
?>