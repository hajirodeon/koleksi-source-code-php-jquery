<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT_TEMPLATE
* @version $Id: xmlpull.inc.php,v 1.12 2004/01/14 09:39:01 harryf Exp $
*/
//--------------------------------------------------------------------------------
/**
* Include PEAR::XML_HTMLSax
*/
if ( !defined('PEAR_LIBRARY_PATH') ) {
    define('PEAR_LIBRARY_PATH', getConfigOption('config', 'pear', 'library_path'));
}
if (!@include_once PEAR_LIBRARY_PATH . 'XML/XML_HTMLSax.php') {
    if ( !defined('XML_HTMLSAX') ) {
        define('XML_HTMLSAX', WACT_ROOT . getConfigOption('compiler', 'XML_HTMLSAX', 'library_path'));
    }
    if (!@include_once XML_HTMLSAX . 'XML_HTMLSax.php') {
        RaiseError('runtime', 'LIBRARY_REQUIRED', array(
            'library' => 'PEAR::XML_HTMLSax',
            'path' => XML_HTMLSAX));
    }          
}


//--------------------------------------------------------------------------------
/**
* Define XML events
*/
define('XML_OPEN',1);
define('XML_CLOSE',2);
define('XML_TEXT',3);
define('XML_PI',4);
define('XML_ESCAPE',5); // HTMLSax only
define('XML_JASP',6); // HTMLSax only
//--------------------------------------------------------------------------------
/**
* Wraps SAX parser to provide an XML pull API
* @see http://wact.sourceforge.net/index.php/XMLPull
* @access public
* @package WACT_TEMPLATE
*/
class XMLPull {
	/**
	* Text to be parsed
	* @var string
	* @access private
	*/
	var $rawtext;
	/**
	* Instance of a SAX parser
	* @var string
	* @access private
	*/
	var $saxparser;
	/**
	* FIFO queue for XML events
	* @var array
	* @access private
	*/
	var $stack = array();
	/**
	* Switch for whether SAX parsing has begun
	* @var boolean (default = false)
	* @access private
	*/
	var $started = FALSE;
	/**
	* Constructs the XMLPull parser
	* @param string raw document to parse
	* @access protected
	*/
	function XMLPull ($rawtext) {
		$this->rawtext = $rawtext;
		$this->saxparser=& new XML_HTMLSax();
		$this->saxparser->set_option('XML_OPTION_FULL_ESCAPES');
		$this->saxparser->set_object($this);
		$this->saxparser->set_element_handler('open','close');
		$this->saxparser->set_data_handler('data');
		$this->saxparser->set_pi_handler('pi');
		$this->saxparser->set_escape_handler('escape');
		$this->saxparser->set_jasp_handler('jasp');
	}
	/**
	* Sax Open Handler
	* @param XML_HTMLSax instance of the parser
	* @param string tag name
	* @param array attributes
	* @return void
	* @access private
	*/
	function open($parser,$tag,$attrs,$empty) {
		$this->stack[]=new XMLOpen($tag,$attrs,$empty,$parser->get_current_position());
	}
	/**
	* Sax Close Handler
	* @param XML_HTMLSax instance of the parser
	* @param string tag name
	* @return void
	* @access private
	*/
	function close($parser,$tag,$empty) {
		$this->stack[]=new XMLClose($tag,$empty,$parser->get_current_position());
	}
	/**
	* Sax Data Handler
	* @param XML_HTMLSax instance of the parser
	* @param string text content in tag
	* @return void
	* @access private
	*/
	function data($parser,$data) {
		$this->stack[]=new XMLData($data,$parser->get_current_position());
	}
	/**
	* Sax Processing Instruction Handler
	* @param XML_HTMLSax instance of the parser
	* @param string target processor (e.g. php)
	* @param string text content in PI
	* @return void
	* @access private
	*/
	function pi($parser,$target,$data) {
		$this->stack[]=new XMLPI($target,$data,$parser->get_current_position());
	}
	/**
	* Sax XML Escape Handler
	* @param XML_HTMLSax instance of the parser
	* @param string text content in escape
	* @return void
	* @access private
	*/
	function escape($parser,$data) {
		$this->stack[]=new XMLEscape($data,$parser->get_current_position());
	}
	/**
	* Sax XML Jasp Handler
	* @param XML_HTMLSax instance of the parser
	* @param string text content in JASP block
	* @return void
	* @access private
	*/
	function jasp($parser,$data) {
		$this->stack[]=new XMLJasp($data,$parser->get_current_position());
	}
	/**
	* Returns an XML event from the stack
	* @return mixed NULL when finished or subclass of XMLEvent
	* @access private
	*/
	function parse() {
		if ( $this->started ) {
			return array_shift($this->stack);
		} else {
			$this->saxparser->parse($this->rawtext);
			$this->started = TRUE;
			return $this->parse();
		}
	}
}
//--------------------------------------------------------------------------------
/**
* Base class for representing SAX XML events
* @abstract
* @package WACT_TEMPLATE
*/
class XMLEvent {
	/**
	 * Type of event
	 * @var string
	 * @access private
	 */
	var $type;
	/**
	 * Strpos in XML document
	 * @var string
	 * @access private
	 */
	var $position;
	/**
	* Constructs XMLEvent
	* @param string type of event
	* @access protected
	*/
	function XMLEvent ($type,$position) {
		$this->type = $type;
		$this->position = $position;
	}
	/**
	* Returns the type of event
	* @return string type of event
	* @access public
	*/
	function type() {
		return $this->type;
	}
	function position() {
		return $this->position;
	}
}
//--------------------------------------------------------------------------------
/**
* Represents an XML start element
* @access public
* @package WACT_TEMPLATE
*/
class XMLOpen extends XMLEvent {
	/**
	 * Tag name
	 * @var string
	 * @access private
	 */
	var $tag;
	/**
	 * Tag attributes
	 * @var array
	 * @access private
	 */
	var $attribs;
	/**
	 * Whether the tag was empty
	 * @var boolean
	 * @access private
	 */
	var $empty = FALSE;
	/**
	 * Constructs StartElement
	 * @param string tag name
	 * @param array tag attributes
	 * @access public
	 */
	function XMLOpen ($tag,$attribs=array(),$empty,$position) {
		XMLEvent::XMLEvent(XML_OPEN,$position);
		$this->tag = $tag;
		$this->attribs = $attribs;
		$this->empty = $empty;
	}
	/**
	 * Returns the tag name
	 * @return string
	 * @access public
	 */
	function tag() {
		return $this->tag;
	}
	/**
	 * Returns the attributes
	 * Converts PEAR::XML_HTMLSax null attributes
	 * @return array
	 * @access public
	 */
	function attributes() {
		$attribs = array();
		foreach ( $this->attribs as $key => $value ) {
			if ( $value === true ) {
				$attribs[$key] = NULL;
			} else {
				$attribs[$key] = $value;
			}
		}
		return $attribs;
	}
	/**
	* Test to see if tag was empty
	* @return boolean
	* @access public
	*/
	function isEmpty() {
		return $this->empty;
	}
}
//--------------------------------------------------------------------------------
/**
* Represents an XML end element
* @access public
* @package WACT_TEMPLATE
*/
class XMLClose extends XMLEvent {
	/**
	 * Tag name
	 * @var string
	 * @access private
	 */
	var $tag;
	/**
	 * Whether the tag was empty
	 * @var boolean
	 * @access private
	 */
	var $empty = FALSE;
	/**
	 * Constructs EndElement
	 * @param string tag name
	 * @access public
	 */
	function XMLClose ($tag,$empty,$position) {
		XMLEvent::XMLEvent(XML_CLOSE,$position);
		$this->tag = $tag;
		$this->empty = $empty;
	}
	/**
	 * Returns the tag name
	 * @return string
	 * @access public
	 */
	function tag() {
		return $this->tag;
	}
	/**
	* Test to see if tag was empty
	* @return boolean
	* @access public
	*/
	function isEmpty() {
		return $this->empty;
	}
}
//--------------------------------------------------------------------------------
/**
* Represents data inside an element
* @access public
* @package WACT_TEMPLATE
*/
class XMLData extends XMLEvent {
	/**
	 * The data inside the element
	 * @var string
	 * @access private
	 */
	var $data;
	/**
	 * Constructs CharacterData
	 * @param string character data inside an element
	 * @access public
	 */
	function XMLData ($data,$position) {
		XMLEvent::XMLEvent(XML_TEXT,$position);
		$this->data = $data;
	}
	/**
	 * Returns the character data
	 * @return string
	 * @access public
	 */
	function text() {
		return $this->data;
	}
}
//--------------------------------------------------------------------------------
/**
* For XML processing instructions
* @access public
* @package WACT_TEMPLATE
*/
class XMLPI extends XMLEvent {
	/**
	 * Target processor
	 * @var string
	 * @access private
	 */
	 var $target;
	/**
	 * Contents of PI
	 * @var string
	 * @access private
	 */
	var $instruction;
	/**
	 * Constructs PI
	 * @param string target processor
	 * @param string processing instruction contents
	 * @access public
	 */
	function XMLPI ($target,$instruction,$position) {
		XMLEvent::XMLEvent(XML_PI,$position);
		$this->target = $target;
		$this->instruction = $instruction;
	}
	/**
	 * Returns the name of the target processor
	 * @return string
	 * @access public
	 */
	function target() {
		return $this->target;
	}
	/**
	 * Returns the processing instruction
	 * @return string
	 * @access public
	 */
	function instruction() {
		return $this->instruction;
	}
}
//--------------------------------------------------------------------------------
/**
* For XML escapes<br />
* Note: HTMLSax only
* @access public
* @package WACT_TEMPLATE
*/
class XMLEscape extends XMLEvent {
	/**
	 * Contents of escape
	 * @var string
	 * @access private
	 */
	var $data;
	/**
	 * Constructs Escape
	 * @param string character data inside an element
	 * @access public
	 */
	function XMLEscape ($data,$position) {
		XMLEvent::XMLEvent(XML_ESCAPE,$position);
		$this->data = $data;
	}
	/**
	 * Returns the contents of the escaped block
	 * @return string
	 * @access public
	 */
	function text() {
		return $this->data;
	}
}
//--------------------------------------------------------------------------------
/**
* For JSP / ASP markup<br />
* Note: HTMLSax only
* @access public
* @package WACT_TEMPLATE
*/
class XMLJasp extends XMLEvent {
	/**
	 * Contents of escape
	 * @var string
	 * @access private
	 */
	var $data;
	/**
	 * Constructs Jasp
	 * @param string character data inside an element
	 * @access public
	 */
	function XMLJasp ($data,$position) {
		XMLEvent::XMLEvent(XML_JASP,$position);
		$this->data = $data;
	}
	/**
	 * Returns the contents of the JASP block
	 * @return string
	 * @access public
	 */
	function text() {
		return $this->data;
	}
}
?>