<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT_TEMPLATE
* @version $Id: tagdictionary.inc.php,v 1.5 2003/11/14 00:46:41 harryf Exp $
*/
/**
* The tag must have a closing tag
*/
define('ENDTAG_REQUIRED', 1);
/**
* The tag may have a closing tag
*/
define('ENDTAG_OPTIONAL', 2);
/**
* The tag may not have a closing tag
*/
define('ENDTAG_FORBIDDEN', 3);

//--------------------------------------------------------------------------------
/**
* Registers information about a compile time tag in the global tag dictionary.
* This function is called from the respective compile time component class
* file.
* @see http://wact.sourceforge.net/index.php/registerTag
* @param object instance of a TagInfo class
* @return void
* @access protected
*/
function registerTag(&$taginfo) {
	$GLOBALS['TagDictionary']->registerTag($taginfo);
}

//--------------------------------------------------------------------------------
/**
* The TagDictionary, which exists as a global variable, acting as a registry
* of compile time components.
* @see http://wact.sourceforge.net/index.php/TagDictionary
* @access protected
* @package WACT_TEMPLATE
*/
class TagDictionary {
	/**
	* Associative array of TagInfo objects
	* @var array
	* @access private
	*/
	var $TagInformation = array();
	/**
	* Indexed array containing registered tag names
	* @var array
	* @access private
	*/
	var $TagList = array();

	/**
	* Registers a tag in the dictionary, called from the global registerTag()
	* function.
	* @param object TagInfo class
	* @return void
	* @access protected
	*/
	function registerTag($taginfo) {
		$tag = strtolower($taginfo->Tag);
		$this->TagList[] = $tag;
		$this->TagInformation[$tag] =& $taginfo;
	}

	/**
	* Gets the tag information about a given tag.
	* Called from the SourceFileParser
	* @see SourceFileParser
	* @param string name of a tag
	* @return object TagInfo class
	* @access protected
	*/
	function &getTagInfo($tag) {
		return $this->TagInformation[strtolower($tag)];
	}

	/**
	* Gets the list of a registered tags.
	* Called from the SourceFileParser
	* @see SourceFileParser
	* @param string name of a tag
	* @return array list of tags
	* @access protected
	*/
	function getTagList() {
		return $this->TagList;
	}

	/**
	* Returns the global instance of the tag dictionary
	* Used so less direct references scattered around to global location
	* @static
	* @return TagDictionary
	* @access protected
	*/
	function & getInstance() {
		return $GLOBALS['TagDictionary'];
	}
}
?>