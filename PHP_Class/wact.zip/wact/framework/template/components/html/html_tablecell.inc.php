<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT_COMPONENT
* @version $Id: html_tablecell.inc.php,v 1.2 2003/11/29 23:03:02 jeffmoore Exp $
*/
//--------------------------------------------------------------------------------
/**
* Load the parent block component
*/
require_once WACT_ROOT . '/template/components/html/html_base.inc.php';
/**
* @see http://wact.sourceforge.net/index.php/HtmlTableCellComponent
* @access public
* @package WACT_COMPONENT
*/
class HtmlTableCellComponent extends HtmlBaseComponent {

}
/**
* @see http://wact.sourceforge.net/index.php/HtmlTableHeaderComponent
* @access public
* @package WACT_COMPONENT
*/
class HtmlTableHeaderComponent extends HtmlTableCellComponent {

}
?>