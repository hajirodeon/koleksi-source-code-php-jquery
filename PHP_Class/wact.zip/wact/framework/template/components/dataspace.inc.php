<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT_COMPONENT
* @version $Id: dataspace.inc.php,v 1.4 2003/10/15 12:38:13 harryf Exp $
*/
//--------------------------------------------------------------------------------
/**
* The DataSpaceComponent does nothing other than extend Component but is
* required to build the runtime component heirarchy, being the root component
* @see http://wact.sourceforge.net/index.php/DataSpaceComponent
* @access public
* @package WACT_COMPONENT
*/
class DataSpaceComponent extends Component {
}
?>