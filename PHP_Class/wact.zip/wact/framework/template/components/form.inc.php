<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT_COMPONENT
* @version $Id: form.inc.php,v 1.22 2003/12/11 05:32:47 harryf Exp $
*/
/**
* Check Validator is loaded (required for Error classes)
*/
if (!defined('VALIDATION_LOADED')) {
    require WACT_ROOT . '/validation/validator.inc.php';
}
//--------------------------------------------------------------------------------
/**
* The FormComponent provide a runtime API for control the behavior of a form
* @see http://wact.sourceforge.net/index.php/FormComponent
* @access public
* @package WACT_COMPONENT
*/
class FormComponent extends TagComponent {
	/**
	* An ErrorList object
	* @var ErrorList
	* @access private
	*/
	var $ErrorList;
	/**
	* Switch to identify whether the form has errors or not
	* @var boolean TRUE means no errors
	* @access private
	*/
	var $IsValid = TRUE;
	/**
	* ErrorMessageDictionary which provides error messages for human
	* consumption
	* @var ErrorMessageDictionary
	* @access private
	*/
	var $Dictionary;
	/**
	* An indexed array of variable names used to build hidden form fields which
	* are passed on in the next POST request
	* @var array
	* @access private
	*/
	var $StateVars = array();

	/**
	* Finds the LabelComponent associated with a form field, allowing 
	* an error message to be displayed next to the field. Called by this
	* setErrors.
	* @param string server id of the form field where the error occurred
	* @param object component below which the LabelComponent can be found
	* @return mixed either a LabelComponent or false if not found
	* @access private
	*/
	function &findLabel($FieldId, &$Component) {
		foreach( array_keys($Component->children) as $key) {
			$Child =& $Component->children[$key];
			if (isset($Child->attributes['for']) && 
					$Child->attributes['for'] == $FieldId) {
				return $Child;
			} else {
				$result =& $this->findLabel($FieldId, $Child);
				if ($result) {
					return $result;
				}
			}
		}
		return FALSE;
	}

	/**
	* Sets the error message dictionary. Called from this setErrors
	* @param ErrorMessageDictionary
	* @return void
	* @access private
	*/
	function setErrorMessageDictionary(&$Dictionary) {
	    $this->Dictionary = $Dictionary;
	}

	/**
	* If errors occur, use this method to identify them to the FormComponent.
	* Normally this would be called by FormControllerValidate
	* @see FormController
	* @param ErrorList
	* @return void
	* @access public
	*/
	function setErrors(&$ErrorList) {
		
		if (!isset($this->Dictionary)) {
		    $this->setErrorMessageDictionary(new ErrorMessageDictionary());
		}
		
		$ErrorList->reset();
		while ($ErrorList->next()) {
			$this->IsValid = FALSE;
			
			$Error =& $ErrorList->getError();
			
			$Error->setErrorMessageDictionary($this->Dictionary);
		
			foreach ($Error->getFieldList() as $tokenName => $fieldName) {
				$Field =& $this->findChild($fieldName);
				if (is_object($Field)) {
					$Error->setDisplayName($tokenName, $Field->getDisplayName());
					$Field->setError();
					if (isset($Field->attributes['id'])) {
						$Label =& $this->findLabel($Field->attributes['id'], $this);
						if ($Label) {
							$Label->setError();
						}
					}
				}
			}
			
		}
		$this->ErrorList =& $ErrorList;
	}

	/**
	* Determined whether the form has errors.
	* @return boolean TRUE if the form has errros
	* @access public
	*/
	function hasErrors() {
		return !$this->IsValid;
	}

	/**
	* Returns the ErrorList if it exists or an EmptyErrorList if not
	* @return object
	* @access public
	*/
	function &getErrorDataSet() {
		if (empty($this->ErrorList)) {
			return new EmptyErrorList();
		} else {
			return $this->ErrorList;
		}
	}

	/**
	* Identify a variable stored in the DataSpace of the component, which
	* should be passed as a hidden form field in the form post.
	* @param string name of variable
	* @return void
	* @access public
	*/
	function preserveState($variable) {
	    $this->StateVars[] = $variable;
	}

	/**
	* Renders the hidden fields for variables which should be preserved
	* @return void
	* @access public
	*/
	function renderState() {
	    foreach ($this->StateVars as $var) {
	        echo '<INPUT type="hidden" name="';
	        echo $var;
	        echo '" value="';
	        echo htmlspecialchars($this->get($var), ENT_QUOTES);
	        echo '">';
	    }
	}
	
}
//--------------------------------------------------------------------------------
/**
* Base class for concrete form elements
* @see http://wact.sourceforge.net/index.php/FormElement
* @access public
* @abstract
* @package WACT_COMPONENT
*/
class FormElement extends TagComponent {

	/**
	* Whether the form element has validated successfully (default TRUE)
	* @var boolean
	* @access private
	*/
	var $IsValid = TRUE;

	/**
	* Name of the form element (for the name attribute)
	* @var string
	* @access protected
	*/
	var $displayname;

	/**
	* CSS class attribute the element should display if there is an error
	* @var string
	* @access private
	*/
	var $errorclass;

	/**
	* CSS style attribute the element should display if there is an error
	* @var string
	* @access private
	*/
	var $errorstyle;

	/**
	* Returns a value for the name attribute. If $this->displayname is not
	* set, returns either the title, alt or name attribute (in that order
	* of preference, defined for the tag
	* @return string
	* @access protected
	*/
	function getDisplayName() {
		if (isset($this->displayname)) {
			return $this->displayname;
		} else if (isset($this->attributes["title"])) {
			return $this->attributes["title"];
		} else if (isset($this->attributes["alt"])) {
			return $this->attributes["alt"];
		} else {
			return str_replace("_", " ", $this->attributes["name"]);
		}
	}

	/**
	* Returns true if the form element is in an error state
	* @return boolean
	* @access protected
	*/
	function hasErrors() {
		return !$this->IsValid;
	}

	/**
	* Puts the element into the error state and assigns the error class or
	* style attributes, if the corresponding member vars have a value
	* @return boolean
	* @access protected
	*/
	function setError() {
		$this->IsValid = FALSE;
		if (isset($this->errorclass)) {
			$this->attributes['class'] = $this->errorclass;
		}
		if (isset($this->errorstyle)) {
			$this->attributes['style'] = $this->errorstyle;
		}
	}

	/**
	* Returns the value of the form element
	* (the contents of the value attribute)
	* @return string
	* @access public
	*/
	function getValue() {
		$FormComponent =& $this->findParentByClass('FormComponent');
		return $FormComponent->get($this->attributes['name']);
	}
}

//--------------------------------------------------------------------------------
/**
* Base class for concrete input elements
* @see http://wact.sourceforge.net/index.php/InputFormElement
* @access public
* @abstract
* @package WACT_COMPONENT
*/
class InputFormElement extends FormElement {

	/**
	* Overrides then calls with the parent renderAttributes() method. Makes
	* sure there is always a value attribute, even if it's empty.
	* Called from within a compiled template render function.
	* @return void
	* @access protected
	*/
	function renderAttributes() {
		$value = $this->getValue();
		if (!is_null($value)) {
			$this->attributes['value'] = $value;
		} else {
			$this->attributes['value'] = '';
		}
		parent::renderAttributes();
	}
	
}

//--------------------------------------------------------------------------------
/**
* Base class for concrete form elements that comprise multiple HTML tags
* @see http://wact.sourceforge.net/index.php/ContainerFormElement
* @access public
* @abstract
* @package WACT_COMPONENT
*/
class ContainerFormElement extends FormElement {

	function renderContents() {
	}
	
}

//--------------------------------------------------------------------------------
// Strongly related to the list component; may need to inherit from it or a common ancestor.
/*
class ErrorSummaryComponent extends Component {

	var $DataSpace;
	var $ShowSeparator;

	function prepare() {
		$FormComponent =& $this->parent;
		while ($FormComponent->tag <> 'FORM') {
			$FormComponent =& $FormComponent->parent;
		}
		$this->DataSpace =& $FormComponent->getErrorDataSet();
		$this->DataSpace->reset();
		$this->ShowSeparator = FALSE;
	}

}
*/
//--------------------------------------------------------------------------------
/**
* Represents an HTML label tag
* @see http://wact.sourceforge.net/index.php/LabelComponent
* @access public
* @package WACT_COMPONENT
*/
class LabelComponent extends TagComponent {
	/**
	* CSS class attribute to display on error
	* @var string
	* @access private
	*/
	var $errorclass;
	/**
	* CSS style attribute to display on error
	* @var string
	* @access private
	*/
	var $errorstyle;

	/**
	* If either are set, assigns the attributes for error class or style
	* @return void
	* @access protected
	*/
	function setError() {
		if (isset($this->errorclass)) {
			$this->attributes['class'] = $this->errorclass;
		}
		if (isset($this->errorstyle)) {
			$this->attributes['style'] = $this->errorstyle;
		}
	}

}

//--------------------------------------------------------------------------------
/**
* Represents an HTML button tag
* @see http://wact.sourceforge.net/index.php/ButtonComponent
* @access public
* @package WACT_COMPONENT
*/
class ButtonComponent extends FormElement {
}

//--------------------------------------------------------------------------------
/**
* Represents an HTML input type="submit" tag
* @see http://wact.sourceforge.net/index.php/InputSubmitComponent
* @access public
* @package WACT_COMPONENT
*/
class InputSubmitComponent extends FormElement {
}

//--------------------------------------------------------------------------------
/**
* Represents an HTML input type="reset" tag
* @see http://wact.sourceforge.net/index.php/InputResetComponent
* @access public
* @package WACT_COMPONENT
*/
class InputResetComponent extends FormElement {
}

//--------------------------------------------------------------------------------
/**
* Represents an HTML input type="text" tag
* @see http://wact.sourceforge.net/index.php/InputTextComponent
* @access public
* @package WACT_COMPONENT
*/
class InputTextComponent extends InputFormElement {
}

//--------------------------------------------------------------------------------
/**
* Represents an HTML input type="password" tag
* @see http://wact.sourceforge.net/index.php/InputPasswordComponent
* @access public
* @package WACT_COMPONENT
*/
class InputPasswordComponent extends FormElement {
}

//--------------------------------------------------------------------------------
/**
* Represents an HTML input type="checkbox" tag
* @see http://wact.sourceforge.net/index.php/InputCheckBoxComponent
* @access public
* @package WACT_COMPONENT
*/
class InputCheckboxComponent extends FormElement {
	/**
	* Overrides then calls with the parent renderAttributes() method dealing
	* with the special case of the checked attribute
	* @return void
	* @access protected
	*/
	function renderAttributes() {
		$value = $this->getValue();
		if ($value == $this->attributes['value']) {
			$this->attributes['checked'] = NULL;
		} else {
			unset($this->attributes['checked']);
		}
		parent::renderAttributes();
	}
}

//--------------------------------------------------------------------------------
/**
* Represents an HTML input type="radio" tag
* @see http://wact.sourceforge.net/index.php/InputRadioComponent
* @access public
* @package WACT_COMPONENT
*/
class InputRadioComponent extends FormElement {
	/**
	* Overrides then calls with the parent renderAttributes() method dealing
	* with the special case of the checked attribute
	* @return void
	* @access protected
	*/
	function renderAttributes() {
		$value = $this->getValue();
		if ($value == $this->attributes['value']) {
			$this->attributes['checked'] = NULL;
		} else {
			unset($this->attributes['checked']);
		}
		parent::renderAttributes();
	}
}

//--------------------------------------------------------------------------------
/**
* Represents an HTML input type="file" tag
* @see http://wact.sourceforge.net/index.php/InputFileComponent
* @access public
* @package WACT_COMPONENT
*/
class InputFileComponent extends InputFormElement {
    /**
     * We can't get a meaningful 'value' attribute for file upload controls
     * after form submission - the value would need to be the full path to the
     * file on the client machine and we don't have a handle on that
     * information. The component's 'value' is instead set to the relevant
     * portion of the $_FILES array, allowing initial validation of uploaded
     * files w/ WACT.
     */
    function getValue() {
        return;
    }
}

//--------------------------------------------------------------------------------
/**
* Represents an HTML input type="hidden" tag
* @see http://wact.sourceforge.net/index.php/InputHiddenComponent
* @todo implement
* @access public
* @package WACT_COMPONENT
*/
class InputHiddenComponent extends InputFormElement {
	//  unimplemented
}

//--------------------------------------------------------------------------------
/**
* Represents an HTML input type="image" tag
* @see http://wact.sourceforge.net/index.php/InputImageComponent
* @todo implement
* @access public
* @package WACT_COMPONENT
*/
class InputImageComponent extends InputFormElement {
	// unimplemented
}

//--------------------------------------------------------------------------------
/**
* Represents an HTML input type="button" tag
* @see http://wact.sourceforge.net/index.php/InputButtonComponent
* @todo implement
* @access public
* @package WACT_COMPONENT
*/
class InputButtonComponent extends InputFormElement {
	// unimplemented
}

//--------------------------------------------------------------------------------
/**
* Represents an HTML select multiple tag
* @see http://wact.sourceforge.net/index.php/SelectMultipleComponent
* @access public
* @package WACT_COMPONENT
*/
class SelectMultipleComponent extends ContainerFormElement {
	/**
	* A associative array of choices to build the option list with
	* @var array
	* @access private
	*/
	var $choiceList = array();
	/**
	* The object responsible for rendering the option tags
	* @var object
	* @access private
	*/
	var $optionHandler;

	/**
	* Override FormElement method to deal with variable names containing
	* HTML array syntax.
	* @return array the contents of the value
	* @access private
	*/
	function getValue() {
		$FormComponent =& $this->findParentByClass('FormComponent');
		$name = $this->attributes['name'];
		return $FormComponent->get($name);
	}

	/**
	* Sets the choice list. Passed an associative array, the keys become the
	* contents of the option value attributes and the values in the array
	* become the text contents of the option tag
	* @param array
	* @return void
	* @access protected
	*/
	function setChoices($choiceList) {
		$this->choiceList = $choiceList;
	}

	/**
	* Sets a list of values to be displayed as selected
	* @param array indexed array of selected values
	* @return void
	* @access public
	*/
	function setSelection($selection) {
		$FormComponent =& $this->findParentByClass('FormComponent');
		$FormComponent->set($this->attributes['name'],$selection);
	}

	/**
	* Sets object responsible for rendering the options
	* @param object e.g. OptionRenderer
	* @return void
	* @access protected
	*/
	function setOptionRenderer($optionHandler) {
		$this->optionHandler = $optionHandler;
	}

	/**
	* Renders the contents of the the select tag, option tags being built by
	* the option handler. Called from with a compiled template render function.
	* @return void
	* @access protected
	*/
	function renderContents() {
		$values = $this->getValue();

		if ( !is_array($values) ) {
			$values = array(reset($this->choiceList));
		} else {
			$found = false;
			foreach ( $values as $value ) {
				if ( array_key_exists($value,$this->choiceList) ) {
					$found = true;
					break;
				}
			}
			if ( !$found )
				$values = array(reset($this->choiceList));
		}

		if (empty($this->optionHandler)) {
			$this->optionHandler = new OptionRenderer();
		}

		foreach($this->choiceList as $key => $contents) {
			$this->optionHandler->renderOption($key, $contents, in_array($key,$values));
		}
	}
}

//--------------------------------------------------------------------------------
// Simple renderer for OPTIONs.  Does not support disabled and label attributes.
// Does not support OPTGROUP tags.
/**
* Deals with rendering option elements for HTML select tags
* @see http://wact.sourceforge.net/index.php/OptionRenderer
* @access public
* @package WACT_COMPONENT
*/
class OptionRenderer {
	/**
	* Renders an option, sending directly to display. Called from a compiled
	* template render function.
	* @param string value to place within the option value attribute
	* @param string contents of the option tag
	* @param boolean whether the option is selected or not
	* @return void
	* @access protected
	*/
	function renderOption($key, $contents, $selected) {
		echo '<option value="';
		echo htmlspecialchars($key, ENT_QUOTES);
		echo '"';
		if ($selected) {
			echo " selected";
		}
		echo '>';
		if (empty($contents)) {
			echo htmlspecialchars($key, ENT_QUOTES);
		} else {
			echo htmlspecialchars($contents, ENT_QUOTES);
		}
		echo '</option>';
	}
}

//--------------------------------------------------------------------------------
/**
* Represents an HTML select tag
* @see http://wact.sourceforge.net/index.php/SelectSingleComponent
* @access public
* @package WACT_COMPONENT
*/
class SelectSingleComponent extends ContainerFormElement {
	/**
	* A associative array of choices to build the option list with
	* @var array
	* @access private
	*/
	var $choiceList = array();
	/**
	* The object responsible for rendering the option tags
	* @var object
	* @access private
	*/
	var $optionHandler;

	/**
	* Sets the choice list. Passed an associative array, the keys become the
	* contents of the option value attributes and the values in the array
	* become the text contents of the option tag
	* @param array
	* @return void
	* @access protected
	*/
	function setChoices($choiceList) {
		$this->choiceList = $choiceList;
	}

	/**
	* Sets a single option to be displayed as selected
	* @param string value which is selected
	* @return void
	* @access public
	*/
	function setSelection($selection) {
		$FormComponent =& $this->findParentByClass('FormComponent');
		$FormComponent->set($this->attributes['name'],$selection);
	}

	/**
	* Sets object responsible for rendering the options
	* @param object e.g. OptionRenderer
	* @return void
	* @access protected
	*/
	function setOptionRenderer($optionHandler) {
		$this->optionHandler = $optionHandler;
	}

	/**
	* Renders the contents of the the select tag, option tags being built by
	* the option handler. Called from with a compiled template render function.
	* @return void
	* @access protected
	*/
	function renderContents() {
		$value = $this->getValue();
		
		if (empty($value) || !array_key_exists($value, $this->choiceList)) {
			$value = reset($this->choiceList);
		}

		if (empty($this->optionHandler)) {
			$this->optionHandler = new OptionRenderer();
		}

		foreach($this->choiceList as $key => $contents) {
			$this->optionHandler->renderOption($key, $contents, $key == $value);
		}
	}
}

//--------------------------------------------------------------------------------
/**
* Represents an HTML textarea tag
* @see http://wact.sourceforge.net/index.php/TextAreaComponent
* @access public
* @package WACT_COMPONENT
*/
class TextAreaComponent extends ContainerFormElement {
	/**
	* Output the contents of the textarea, passing through htmlspecialchars().
	* Called from within a compiled template's render function
	* @return void
	* @access protected
	*/
	function renderContents() {
		echo htmlspecialchars($this->getValue(), ENT_QUOTES);
	}
}
?>