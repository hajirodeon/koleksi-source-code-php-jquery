<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT_COMPONENT
* @version $Id: placeholder.inc.php,v 1.4 2003/10/15 12:38:13 harryf Exp $
*/
//--------------------------------------------------------------------------------
/**
* Presents the component API for placeholder tags
* @see http://wact.sourceforge.net/index.php/PlaceHolderComponent
* @access public
* @package WACT_COMPONENT
*/
class PlaceHolderComponent extends Component {
}
?>