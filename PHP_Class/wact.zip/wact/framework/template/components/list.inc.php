<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT_COMPONENT
* @version $Id: list.inc.php,v 1.16 2004/01/27 01:01:01 jeffmoore Exp $
*/
//--------------------------------------------------------------------------------
/**
* Represents list tags at runtime, providing an API for preparing the data set
* @see http://wact.sourceforge.net/index.php/ListComponent
* @access public
* @package WACT_COMPONENT
*/
class ListComponent extends Component {
	/**
	* Data set to iterate over when rendering the list
	* @var object
	* @access private
	*/
	var $DataSet;
	/**
	* Whether to show the list separator
	* @var boolean
	* @access private
	*/
	var $ShowSeparator;

	/**
	* Registers a dataset with the list component. The dataset must
	* implement the iterator methods defined in DataSpace
	* @see DataSpace
	* @param object implementing the DataSpace iterator methods
	* @return void
	* @access public
	*/
	function registerDataSet(&$DataSet) {
		$this->DataSet =& $DataSet;
	}
	
	// Temporary delegation until better solution can be found
	function get($name) {
	    return $this->DataSet->get($name);
	}
	
	function reset() {
	    return $this->DataSet->reset();
	}
	
	function next() {
	    return $this->DataSet->next();
	}
	
	function registerFilter(&$filter) {
        $this->DataSet->registerFilter($filter);
    }
    
	/**
	* Prepares the list for iteration, creating an EmptyDataSet if no
	* data set has been registered then calling the dataset reset
	* method.
	* @see EmptyDataSet
	* @return void
	* @access protected
	*/
	function prepare() {
		if (empty($this->DataSet)) {
			require_once WACT_ROOT . '/util/emptydataset.inc.php';
			$this->registerDataSet(new EmptyDataSet());
		}
        /* temporary measure... */
        $this->DataSet->reset();
//		$this->DataSet->prepare();
		$this->ShowSeparator = FALSE;
	}
}
?>