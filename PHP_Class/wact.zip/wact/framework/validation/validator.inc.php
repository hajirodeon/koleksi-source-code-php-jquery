<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT_VALIDATION
* @version $Id: validator.inc.php,v 1.25 2003/12/07 01:45:21 harryf Exp $
*/
//--------------------------------------------------------------------------------
/**
* Load DataSpace if required
*/
if (!defined('DATASPACE_LOADED')) {
    require WACT_ROOT . '/util/dataspace.inc.php';
}
/**
* Define for components needing validation (e.g. FormComponent)
* This is a bad dependency.  FormComponent should not have a direct
* dependency on this file.
*/
define('VALIDATION_LOADED', TRUE);

/**
* Class representing a validation error, used to populate runtime
* components. Handles a single error type but can apply to many
* fields being validated
* @see http://wact.sourceforge.net/index.php/ValidationError
* @access public
* @package WACT_VALIDATION
*/
class ValidationError extends DataSpace {
    /**
    * The error group - related to error var files
    * @var string
    * @access private
    */
    var $Group;
    /**
    * The error id - related to error var files
    * @var string
    * @access private
    */
    var $Id;
    /**
    * Index array of runtime component ServerIds
    * @var array
    * @access private
    */
    var $FieldList;
    /**
    * Instance of ErrorMessage
    * @see ErrorMessage
    * @var ErrorMessage
    * @access private
    */
    var $ErrorMessage;
    /**
    * Instance of ErrorMessageDictionary
    * @see ErrorMessageDictionary
    * @var ErrorMessageDictionary
    * @access private
    */
    var $Dictionary;
    /**
    * Constructs ValidationError
    * @param string error message group (related to errors var file)
    * @param string error id (related to errors var file)
    * @param array list of fields the error applies to
    * @access public
    */
    function ValidationError($Group, $Id, $FieldList) {
        $this->Group = $Group;
        $this->Id = $Id;
        $this->FieldList = $FieldList;
    }
    /**
    * Set the ErrorMessageDictionary
    * @see ErrorMessageDictionary
    * @param ErrorMessageDictionary
    * @return void
    * @access public
    */
    function setErrorMessageDictionary(&$Dictionary) {
        $this->Dictionary =& $Dictionary;
    }
    /**
    * Sets the display name ???
    * @param string token
    * @param string token
    * @return void
    * @access public
    */
    function setDisplayName($token, $name) {
        $this->set($token, $name);
    }
    /**
    * Returns the field list
    * @return array index of fields
    * @access public
    */
    function getFieldList() {
        return $this->FieldList;
    }
    /**
    * Returns the ErrorMessageDictionary
    * @see ErrorMessageDictionary
    * @return ErrorMessageDictionary
    * @access public
    */
    function getErrorMessage() {
        $text = $this->Dictionary->getMessage($this->Group, $this->Id);
        
        foreach($this->vars as $key => $replacement) {
            $text = str_replace('{' . $key . '}', $replacement, $text);
        }

        return $text;
    }
}

/**
* Container for errors implementing the Iterator iterface
* @todo documention - check that ErrObj is ValidationError
* @see http://wact.sourceforge.net/index.php/ErrorList
* @see http://wact.sourceforge.net/index.php/Iterator
* @access public
* @package WACT_VALIDATION
*/
class ErrorList {
    /**
    * Indexed array of ValidationError objects
    * @var array
    * @access private
    */
    var $errors = array();
    /**
    * Switch for when at start of iteration
    * @var boolean
    * @access private
    */
    var $first = TRUE;
    /**
    * The current ValidationError from the array
    * @var ValidationError
    * @access private
    */
    var $currentError;
    /**
    * The fields that should be returned by the ErrorList
    * @var array
    * @access private
    */
    var $fieldlist;    

    /**
    * Add a ValidationError object
    * @return void
    * @access public
    */
    function addError($Group, $Id, $FieldList, $Values = NULL) {
        $ErrObj =& new ValidationError($Group, $Id, $FieldList);
        if (!is_null($Values)) {
            $ErrObj->import($Values);
        }
        $this->errors[] =& $ErrObj;
    }

    /**
    * @return void
    * @access public
    */
    function prepare() {
        $this->reset();
    }

    /**
    * Iterator method
    * @return void
    * @access public
    */
    function reset() {
        $this->first = TRUE;
    }

    /**
    * Iterator method
    * @return boolean TRUE is more errors
    * @access public
    */
    function next() {
        if ($this->first) {
            $result = reset($this->errors);
            $this->first = FALSE;
        } else {
            $result = next($this->errors);
        }
        if ($result === FALSE) {
            return FALSE;
        } else {
            $this->currentError =& $this->errors[key($this->errors)];
            if (!empty($this->fieldlist)) {
                if (!in_array($this->currentError->get('Field'), $this->fieldlist)) {
                    return $this->next();
                }
            }
            return TRUE;
        }
    }

    /**
    * Returns the current ValidationError
    * @return ValidationError
    * @access public
    */
    function &getError() {
        return $this->currentError;
    }

    /**
    * Gets an error message from the current ValidationError object
    * @param string name of error
    * @return string error message
    * @access public
    */
    
    function get($name) {
        return $this->currentError->getErrorMessage($name);
        // return $this->currentError->get($name);
    }
    /**
    * Fields which errors should be applied to ???
    * @param array list of fields
    * @return void
    * @access public
    */
    function restrictFields($fieldlist) {
        $this->fieldlist = $fieldlist;
    }
}

/**
* Returned by FormComponent::getErrorList() if not errors have been defined.
* Provides an "dummy" implementation of the DataSpace iterator and the
* ErrorList
* @see ErrorList
* @see FormComponent
* @see http://wact.sourceforge.net/index.php/EmptyErrorList
* @see http://wact.sourceforge.net/index.php/Iterator
* @access public
* @package WACT_VALIDATION
*/
class EmptyErrorList {
	/**
	* Dummy prepare method does nothing
	* @return void
	* @access protected
	*/
	function prepare() {
	}

	/**
	* Dummy reset method does nothing
	* @return void
	* @access protected
	*/
	function reset() {
	}

	/**
	* Dummy next method
	* @return boolean always returns FALSE
	* @access protected
	*/
	function next() {
		return FALSE;
	}

	/**
	* Dummy restrictFields method
	* @return void
	* @access protected
	*/
	function restrictFields($fieldlist) {
	}
}

/**
* The ErrorMessage dictionary contains a map of error messages to be displayed
* to the end user, if they fail any of the validation rules assigned to a controller
* @see http://wact.sourceforge.net/index.php/ErrorMessageDictionary
* @access public
* @package WACT_VALIDATION
*/
class ErrorMessageDictionary {
	/**
	* Associative array of errors, key being the error id and the value the
	* message for the end user.
	* @var array
	* @access private
	*/
	var $ErrorMessages = array();

	/**
	* Gets a message, given it's group and id. This method loads the var file
	* not already loaded, using the importVarFile() function.
	* @param string group identifies var file name: /errormessages/$Group.vars
	* @param string id of error message e.g. "MISSING"
	* @return string error message to display to user
	* @access protected
	*/
	function getMessage($Group, $Id) {
		if (!isset($this->ErrorMessages[$Group])) {
			$this->ErrorMessages[$Group] = importVarFile("/errormessages/$Group.vars");
		}
	
		return $this->ErrorMessages[$Group][$Id];
	}
}

/**
* Performs the validation checks against the Rules
* @see http://wact.sourceforge.net/index.php/Validator
* @see http://wact.sourceforge.net/index.php/Rule
* @access public
* @package WACT_VALIDATION
*/
class Validator {
    /**
    * Indexed array of Rule objects
    * @see Rule
    * @var array
    * @access private
    */
    var $rules = array();
    /**
    * Instance of ErrorList
    * @see ErrorList
    * @var ErrorList
    * @access private
    */
    var $ErrorList;
    /**
    * Whether the validation process was valid
    * @var boolean
    * @access private
    */
    var $IsValid = TRUE;

    /**
    * Initalize Error List
    * @param Rule
    * @return void
    * @access protected
    */
    function &createErrorList() {
        return new ErrorList();
    }

    /**
    * Registers a Rule
    * @param Rule
    * @return void
    * @access public
    */
    function addRule(&$Rule) {
        $this->rules[] = $Rule;
    }

    /**
    * Returns the ErrorList
    * @return ErrorList
    * @access public
    */
    function &getErrorList() {
        return $this->ErrorList;
    }

    /**
    * Whether the validation process was valid
    * @param string fieldname (default=NULL) unused
    * @return boolean TRUE if valid
    * @access public
    */
    function IsValid($FieldName = NULL) {
        return $this->IsValid;
    }

    /**
    * Perform the validation
    * @param DataSpace subclass of DataSpace to validate
    * @return void
    * @access public
    */
    function validate(&$DataSource) {
        $ErrorList =& $this->createErrorList();
        foreach( array_keys($this->rules) as $key) {
            if (! $this->rules[$key]->validate($DataSource, $ErrorList)) {
                $this->IsValid = FALSE;
            }
        }

        $this->ErrorList =& $ErrorList;
    }
}

/**
* Base class for defining Rules to validate against
* @see http://wact.sourceforge.net/index.php/Rule
* @access public
* @package WACT_VALIDATION
* @abstract
*/
class Rule {
    /**
    * Identifies error message group in vars file
    * @var string (default='validation')
    * @access private
    */
    var $Group = 'validation';
    
    /**
    * Sets the error message group (related to the vars file)
    * @param string group
    * @return void
    * @access public
    */
    function setGroup($Group) {
        $this->Group = $Group;
    }

    /**
    * Perform validation
    * @param DataSource - subclass to validate
    * @param ErrorList
    * @return boolean (always TRUE is base class)
    * @access protected
    * @abstract
    */
    function validate(&$DataSource, &$ErrorList) {
        RaiseError('compiler', 'ABSTRACTMETHOD',
                   array('method' => __FUNCTION__ .'()', 'class' => __CLASS__));
    }
}

/**
* Rules responsbile for validating a single field descend from this class.
* @see http://wact.sourceforge.net/index.php/SingleFieldRule
* @access public
* @package WACT_VALIDATION
* @abstract
*/
class SingleFieldRule extends Rule {
    /**
    * Field name to validate
    * @var string
    * @access private
    */
    var $fieldname;
    /**
    * Is this field valid?
    * @var boolean
    * @access private
    */
    var $IsValid = TRUE;
    /**
    * Error Collection Object
    * @var ErrorList
    * @access private
    */
    var $ErrorList;

    /**
    * Constructs Rule
    * @param string fieldname to validate
    * @access public
    */
    function SingleFieldRule($fieldname) {
        $this->fieldname = $fieldname;
    }

    /**
    * Returns the fieldname the rule applies to
    * @return string name of field
    * @access public
    */
    function getField() {
        return $this->fieldname;
    }

    /**
    * Signal that an error has occurred.
    * @param string id of the error
    * @param optional data regarding the error
    * @access protected
    */
    function Error($id, $values = NULL) {
        $this->IsValid = FALSE;
        $this->ErrorList->addError($this->Group, $id, 
            array('Field' => $this->fieldname), $values);
    }

    /**
    * Have we already determined this error to be invalid?
    * @param string id of the error
    * @param optional data regarding the error
    * @access protected
    */
    function IsValid() {
        return $this->IsValid;
    }
    
    /**
    * Perform validation
    * @param DataSource - Data to validate
    * @param ErrorList
    * @return boolean (always TRUE is base class)
    * @access public
    */
    function validate(&$DataSource, &$ErrorList) {
        $this->IsValid = TRUE;
        $this->ErrorList =& $ErrorList;
        $value = $DataSource->get($this->fieldname);
        if (isset($value) && $value !== '') {
            $this->Check($value);
        }
        return $this->IsValid;
    }

    /**
    * Check a Single Value to see if its valid
    * @param value - to check
    * @access protected
    * @abstract
    */
    function Check($value) {
        RaiseError('compiler', 'ABSTRACTMETHOD',
                   array('method' => __FUNCTION__ .'()', 'class' => __CLASS__));
    }
}

/**
* For fields which must be supplied a value by the user
* @see http://wact.sourceforge.net/index.php/RequiredRule
* @access public
* @package WACT_VALIDATION
*/
class RequiredRule extends SingleFieldRule {
    /**
    * Constructs RequiredRule
    * @param string fieldname to validate
    * @access public
    */
    function RequiredRule($fieldname) {
        parent :: SingleFieldRule($fieldname);
    }

	/**
	* Performs validation
	* @param DataSource - data to validate
	* @param ErrorList
	* @return boolean TRUE if validation passed
	* @access public
	*/
    function validate(&$DataSource, &$ErrorList) {
        $value = $DataSource->get($this->fieldname);
        if (!isset($value) || $value === '') {
            $ErrorList->addError($this->Group, 'MISSING', 
                array('Field' => $this->fieldname));
            return FALSE;
        }
        return TRUE;
    }
}

/**
* For fields have a minimum and maximum length
* @see http://wact.sourceforge.net/index.php/SizeRangeRule
* @access public
* @package WACT_VALIDATION
*/
class SizeRangeRule extends SingleFieldRule {
    /**
    * Minumum length
    * @var int
    * @access private
    */
    var $minLength;
    /**
    * Maximum length
    * @var int
    * @access private
    */
    var $maxLength;

    /**
    * Constructs SizeRangeRule
    * @param string fieldname to validate
    * @param int Minumum length
    * @param int Maximum length (optional)
    * @access public
    */
    function SizeRangeRule($fieldname, $minLength, $maxLength = NULL) {
        parent :: SingleFieldRule($fieldname);
        if (is_null($maxLength)) {
            $this->minLength = NULL;
            $this->maxLength = $minLength;
        } else {
            $this->minLength = $minLength;
            $this->maxLength = $maxLength;
        }
    }

	/**
	* Performs validation of a single value
	* @access protected
	*/
    function Check($value) {
        if (!is_null($this->minLength) && (strlen($value) < $this->minLength)) {
            $this->Error('SIZE_TOO_SMALL', array('min' => $this->minLength));
        } else if (strlen($value) > $this->maxLength) {
            $this->Error('SIZE_TOO_BIG', array('max' => $this->maxLength));
        }
    }
}
?>