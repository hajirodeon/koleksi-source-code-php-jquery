<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT_CONTROLLERS
* @version $Id: noaction.inc.php,v 1.1 2003/10/18 20:57:44 harryf Exp $
*/
//--------------------------------------------------------------------------------
/**
* A "NULL" ActionClass in case the user fails to define one.
* @access protected
* @package WACT_CONTROLLERS
*/
class NoAction {
	/**
	* Do nothing
	* @return void
	* @access protected
	*/
	function performAction(&$context) {
	}
}
?>