<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT_CONTROLLERS
* @version $Id: getcontroller.inc.php,v 1.8 2003/11/29 23:02:58 jeffmoore Exp $
*/
//--------------------------------------------------------------------------------
/**
* Include Validator and NoAction
*/
require_once WACT_ROOT . '/validation/validator.inc.php';
require_once WACT_ROOT . '/controllers/noaction.inc.php';
/**
* Define get states
*/
define('GET_COMPLETE', 1);
define('GET_ACTIVE', 2);
/**
* Page Controller for handling GET requests
* @see http://wact.sourceforge.net/index.php/GetController
* @access public
* @package WACT_CONTROLLERS
* @abstract
*/
class GetController {
	/**
	* @var DataSpace
	* @access protected
	*/
	var $DataSpace;
	/**
	* @var Validator
	* @access protected
	*/
	var $Validator;
	/**
	* @var Template
	* @access protected
	*/
	var $View;
	/**
	* Instance of current action Class to perform
	* @var object
	* @access private
	*/
	var $CurrentAction;
	/**
	* Instance of ErrorList
	* @var ErrorList
	* @access private
	*/
	var $ErrorList;
	/**
	* State of the controller
	* <ul>
	* <li>GET_ACTIVE - The view will be displayed to the user.</li>
	* <li>GET_COMPLETE - A final action has been performed.</li>
	* </ul>
	* @var int (default = GET_ACTIVE)
	* @access private
	*/
	var $GetState = GET_ACTIVE;
	/**
	* Switch to control whether a registered action has been spotted
	* @var boolean (default = TRUE)
	* @access private
	*/
	var $IsFirstTime = TRUE;
	/**
	* After validation, whether the request was valid
	* @var boolean (default = FALSE)
	* @access private
	*/
	var $Valid = FALSE;
	/**
	* Returns the DataSpace associated with the get controller
	* This can be called via the context parameter of actions.
	* @see DataSpace
	* @return DataSpace
	* @access public
	*/
	function &getDataSpace() {
		return $this->DataSpace;
	}
	/**
	* Returns the Template view.  This can be called via the context
	* parameter of actions.
	* called.
	* @see Template
	* @return Template
	* @access public
	*/
	function &getView() {
		if (!isset($this->View)) {
			$this->initializeView();
		}
		return $this->View;
	}
	/**
	* Template method to set the DataSpace
    * @return void
    * @access protected
    * @abstract
    */
	function setDataSpace() {
    }
	/**
	* Template method to initialize the controller
	* @return void
	* @access protected
	* @abstract
	*/
	function initializeController() {
	}
	/**
	* Template method to set the available actions in the controller
	* @return void
	* @access protected
	* @abstract
	*/
	function initializeActions() {
	}
	/**
	* Template method to set the DataSpace
	* @see DataSpace
	* @return void
	* @access protected
	* @abstract
	*/
	function initializeDataSpace() {
	}
	/**
	* Template method to set the Validator
	* @see Validator
	* @return void
	* @access protected
	* @abstract
	*/
	function initializeValidator() {
	}
	/**
	* Template method to set the Template
	* @see Template
	* @return void
	* @access protected
	* @abstract
	*/
	function initializeView() {
	}
	/**
	* Sets the controller state to GET_COMPLETE
	* @return void
	* @access private
	*/
	function complete() {
		$this->GetState = GET_COMPLETE;
	}
	/**
	* Returns the ErrorList
	* @return ErrorList
	* @access public
	*/
	function & getErrorList() {
		return $this->ErrorList;
	}
	/**
	* Executes the validation of fields other than the control field
	* @return void
	* @access private
	*/
	function validate() {
		if (!$this->Validated && isset($this->Validator)) {
			$this->Validator->validate($this->DataSpace);
			$IsValid = $this->Validator->IsValid();
			if (!$IsValid) {
                // Would be nice to use ErrorSummary here but currently tied to Form
				$this->ErrorList = $this->Validator->getErrorList();
			}
			$this->Valid = $IsValid;
		}
	}
	/**
	* Checks the valid state
	* @return boolean TRUE is form is valid
	* @access public
	*/
	function IsValid() {
		return $this->Valid;
	}
	/**
	* If an Action class is defined in CurrentAction,
	* runs the performAction() method of that class
	* @see http://wact.sourceforge.net/index.php/ActionClass
	* @return void
	* @access private
	*/
	function performAction() {
        if ( isset($this->CurrentAction) ) {
            if ( $this->CurrentAction->performAction($this) == GET_COMPLETE ) {
                $this->complete();
            }
        }
	}
	/**
	* @return void
	* @access private
	*/
	function DisplayView() {
		$View =& $this->getView();
		if (! is_null($View)) {
			$View->display();
		}
	}
	/**
	* @return void
	* @access public
	*/
	function Run() {
		$this->ErrorList = new ErrorList();
		$this->initializeController();
        // Init Validator before actions to allow Rule adding in registerAction
		$this->InitializeValidator();
		$this->InitializeActions();
		if ( $this->IsFirstTime ) {
			$this->InitializeDataSpace();
			$this->DisplayView();
		} else {
			$this->performAction();
			if ( $this->GetState == GET_ACTIVE ) {
				$this->DisplayView();
			}
		}
	}
}
//--------------------------------------------------------------------------------
/**
* Concrete Controller for GET query strings like page.php?action=view
* @access public
* @package WACT_CONTROLLERS
* @abstract
*/
class QueryStringController extends GetController {
	/**
	* Registers a GET variable to "watch" and the ActionClass to instantiate
	* if it is found and valid
	* @param string GET query string field to watch (e.g. 'action' for ?action=)
	* @param Rule subclass of Rule
	* @param string name of action class in invoke
	* @return void
	* @access protected
	*/
	function registerAction($rule, $action, $erroraction=NULL) {
		// Moved from parent::run() - could cause problems - not sure
		if ( !is_a($this->DataSpace,'GetDataSpace') )
			$this->setDataSpace();
		if ($this->IsFirstTime && $this->DataSpace->get($rule->getField()) ) {
            if ( $rule->validate($this->DataSpace,$this->ErrorList) ) {
                $this->CurrentAction =& new $action();
            } else {
                // Add Rule to validator to allow error message display
                if ( isset($this->Validator) ) {
                    $this->Validator->addRule($rule);
                }
                if ( !is_null($erroraction) ) {
                    $this->CurrentAction =& new $erroraction();
                } else {
                    $this->CurrentAction =& new NoAction();
                }
            }
            $this->IsFirstTime = FALSE;
		}
	}
	/**
	* Sets the DataSpace to the current contents of the $_GET variable
	* @see PostDataSpace
	* @return void
	* @access protected
	*/
	function setDataSpace() { 
		require_once WACT_ROOT . '/request/getdata.inc.php';
		$this->DataSpace = new GetDataSpace();
	}
}
//--------------------------------------------------------------------------------
/**
* Concrete Controller for URIs like http://example.com/index.php/news/
* @access public
* @package WACT_CONTROLLERS
* @abstract
*/
class UriController extends GetController {
	/**
	* Registers a URI index GET variable to "watch" and the ActionClass
	* to instantiate if it is found and valid
	* @param int URI index (e.g. 0 [=news] for index.php/news/)
	* @param Rule subclass of Rule
	* @param string name of action class in invoke
	* @param string name of action class in invoke if Rule fails
	* @return void
	* @access protected
	*/
	function registerAction($rule, $action, $erroraction=NULL) {
		// Moved from parent::run() - could cause problems - not sure
		if ( !is_a($this->DataSpace,'UriDataSpace') )
			$this->setDataSpace();
		if ($this->IsFirstTime && $this->DataSpace->get($rule->getField()) ) {
            if ( $rule->validate($this->DataSpace,$this->ErrorList) ) {
                $this->CurrentAction =& new $action();
            } else {
                // Add Rule to validator to allow error message display
                if ( isset($this->Validator) ) {
                    $this->Validator->addRule($rule);
                }
                if ( !is_null($erroraction) ) {
                    $this->CurrentAction =& new $erroraction();
                } else {
                    $this->CurrentAction =& new NoAction();
                }
            }
            $this->IsFirstTime = FALSE;
		}
	}
	/**
	* Sets the DataSpace to the current contents of the $_GET variable
	* @see PostDataSpace
	* @return void
	* @access protected
	*/
	function setDataSpace() { 
		require_once WACT_ROOT . '/request/uridata.inc.php';
		$this->DataSpace = new UriDataSpace();
	}
}
?>