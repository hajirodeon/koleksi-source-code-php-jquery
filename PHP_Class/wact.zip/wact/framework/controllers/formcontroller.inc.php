<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT_CONTROLLERS
* @version $Id: formcontroller.inc.php,v 1.20 2003/11/29 23:02:58 jeffmoore Exp $
*/
//--------------------------------------------------------------------------------
/**
* Include Validator and NoAction
*/
require_once WACT_ROOT . '/validation/validator.inc.php';
require_once WACT_ROOT . '/controllers/noaction.inc.php';

define('FORM_COMPLETE', 1);
define('FORM_ACTIVE', 2);

define('PRE_NONE', NULL);
define('PRE_VALID', 1);
/**
* Page Controller for handling forms
* @see http://wact.sourceforge.net/index.php/FormController
* @access public
* @package WACT_CONTROLLERS
* @abstract
*/
class FormController {
    /**
    * @var DataSpace
    * @access protected
    */
    var $DataSpace;
    /**
    * @var Validator
    * @access protected
    */
    var $Validator;
    /**
    * @var Template
    * @access protected
    */
    var $View;
    /**
    * Whether the form has been validated
    * @var boolean (default = FALSE)
    * @access private
    */
    var $Validated = FALSE;
    /**
    * After validation, whether the form submission was valid
    * @var boolean (default = FALSE)
    * @access private
    */
    var $Valid = FALSE;
    /**
    * The current action class set to respond to form actions
    * @var string (default = NULL)
    * @access private
    */
    var $CurrentAction = NULL;
    /**
    * Condition for when an ActionClass should be performed either;
    * <ul>
    * <li>PRE_NONE - The action will be performed even if the form has invalid values</li>
    * <li>PRE_VALID - The action will only be performed when all form values are valid</li>
    * </ul>
    * @var int (default = NULL)
    * @access private
    */
    var $CurrentActionCondition = NULL;
    /**
    * State of the form either;
    * <ul>
    * <li>FORM_ACTIVE - The form will be displayed to the user.</li>
    * <li>FORM_COMPLETE - Processing of the form page has been completed</li>
    * </ul>
    * @var int (default = FORM_ACTIVE)
    * @access private
    */
    var $FormState = FORM_ACTIVE;

    /**
    * Sets the FormState to FORM_COMPLETE
    * @see FormState
    * @return void
    * @access private
    */
    function complete() {
        $this->FormState = FORM_COMPLETE;
    }

    /**
    * Returns the DataSpace associated with the form.
    * This can be called via the context parameter of actions.
    * @see DataSpace
    * @return DataSpace
    * @access public
    */
    function &getDataSpace() {
        return $this->DataSpace;
    }

    /**
    * Returns the Template view.  This can be called via the context
    * parameter of actions.
    * called.
    * @see Template
    * @return Template
    * @access public
    */
    function &getView() {
        if (!isset($this->View)) {
            $this->initializeView();
        }
        return $this->View;
    }

    // function attachAction(); ABSTRACT;

    /**
    * Set up the form's DataSpace. Called by run().
    * @see run
    * @return void
    * @access protected
    * @abstract
    */
    function setDataSpace() {
        RaiseError('compiler', 'ABSTRACTMETHOD',
                   array('method' => __FUNCTION__ .'()', 'class' => __CLASS__));
    }

    /**
    * Template method to determine if this is the first time that the form has
    * been run().
    *
    * @return void
    * @access protected
    * @abstract
    */
    function IsFirstTime() {
        RaiseError('compiler', 'ABSTRACTMETHOD',
                   array('method' => __FUNCTION__ .'()', 'class' => __CLASS__));
    }

    /**
    * Template method to initialize the controller
    * @return void
    * @access protected
    * @abstract
    */
    function initializeController() {
    }

    /**
    * Template method to set the available actions in the form
    * @return void
    * @access protected
    * @abstract
    */
    function initializeActions() {
    }

    /**
    * Template method to set up the form's DataSpace
    * @see DataSpace
    * @return void
    * @access protected
    * @abstract
    */
    function initializeDataSpace() {
    }

    /**
    * Template method to set the Template
    * @see Template
    * @return void
    * @access protected
    * @abstract
    */
    function initializeView() {
    }

    /**
    * Template method to set up the form's Validator
    * @see Validator
    * @return void
    * @access protected
    * @abstract
    */
    function initializeValidator() {
    }

    /**
    * Template method to perform in case of a form with a "preview" state
    * @return void
    * @access protected
    * @abstract
    */
    function onPreview() {
    }

    /**
    * Executes the validation of the form
    * @return void
    * @access private
    */
    function validate() {
        if (PRE_VALID == $this->CurrentActionCondition &&
	!$this->Validated && isset($this->Validator)) {
            $this->Validator->validate($this->DataSpace);
            $IsValid = $this->Validator->IsValid();
            if (!$IsValid) {
                $View =& $this->getView();
                $form =& $View->findChildByClass('FormComponent');
                $form->setErrors($this->Validator->getErrorList());
            }
            $this->Valid = $IsValid;
        }
    }

    /**
    * Checks the valid state
    * @return boolean TRUE is form is valid
    * @access private
    */
    function IsValid() {
        return $this->Valid;
    }

    /**
    * If an Action class is defined in CurrentAction and the form is valid,
    * runs the performAction() method of that class
    * @see http://wact.sourceforge.net/index.php/ActionClass
    * @return void
    * @access private
    */
    function performAction() {
        $ConditionsMet = FALSE;
        if (!is_null($this->CurrentAction)) {
            if ($this->CurrentActionCondition == PRE_VALID) {
                if ($this->IsValid()) {
                    $ConditionsMet = TRUE;
                }
            } else {
                $ConditionsMet = TRUE;
            }
            if ($ConditionsMet) {
                if ($this->CurrentAction->performAction($this) == FORM_COMPLETE) {
                    $this->complete();
                }
            }
        }
    }

    /**
    * Displays the form, sending it directly to output. Called via the run()
    * method
    * @return void
    * @access private
    */
    function displayFormView() {
        $View =& $this->getView();

        if (isset($this->DataSpace)) {
            $Form =& $View->findChildByClass('FormComponent');
            $Form->import($this->DataSpace->export());
        }
        
        if (isset($this->Validator)) {
            foreach( array_keys($this->Validator->rules) as $key) {
                $Rule =& $this->Validator->rules[$key];
                if (is_a($Rule, 'SizeRangeRule')) {
                    $Field =& $View->findChild($Rule->fieldname);
                    if ($Field && is_a($Field, 'InputTextComponent')) {
                        $Field->attributes['maxlength'] = $Rule->maxLength;
                    }
                }
            }
        }

        if (! is_null($View)) {
            $View->display();
        }
    }

    /**
    * Executes the form.
    * @return void
    * @access public
    */
    function Run() {
        $this->initializeController();
        $this->InitializeActions();
        $this->InitializeValidator();
        if ($this->IsFirstTime()) {
            $this->InitializeDataSpace();
            $this->DisplayFormView();
        } else {
            $this->setDataSpace();
            $this->validate();
            $this->performAction();
            if ($this->FormState == FORM_ACTIVE) {
                $this->onPreview();
                $this->DisplayFormView();
            }
        }
    }
}

//--------------------------------------------------------------------------------
/**
* Form controller intended specifically for dealing with the HTTP POST method
* @see http://wact.sourceforge.net/index.php/PostFormController
* @access public
* @package WACT_CONTROLLERS
* @abstract
*/
class PostFormController extends FormController {
    /**
    * Default ActionClass name
    * @var string (default = NULL)
    * @access private
    */
    var $DefaultAction = NULL;
    /**
    * Default Condition for when an ActionClass should be performed either;
    * <ul>
    * <li>PRE_NONE - The action will be performed even if the form has invalid values</li>
    * <li>PRE_VALID - The action will only be performed when all form values are valid</li>
    * </ul>
    * @var int (default = NULL)
    * @access private
    */
    var $DefaultActionCondition = NULL;

    /**
    * Registers the form field to "watch" and the ActionClass to instantiate
    * if the form is submitted
    * @param string form field to watch (usually name of input submit tag)
    * @param string name of action class
    * @param int condition when ActionClass should register: PRE_NONE or PRE_VALID
    * @return void
    * @access protected
    */
    function registerSubmitAction($field, $action, $condition = PRE_NONE) {
        if (isset($_POST[$field])) {
            $this->CurrentAction =& new $action();
            $this->CurrentActionCondition = $condition;
        }
    }
    /**
    * Registers the default ActionClass to perform on any submit. Overridden
    * by ActionClass registered with registerSubmitAction
    * Default submit actions are usually triggered when the user hits the enter
    * key to submit a form and does not click on a specific submit button.
    * @param string name of action class
    * @param int condition when ActionClass should register: PRE_NONE or PRE_VALID
    * @return void
    * @access protected
    */
    function registerDefaultSubmitAction($action, $condition = PRE_NONE) {
        $this->DefaultAction =& $action;
        $this->DefaultActionCondition = $condition;
    }
    /**
    * Sets the DataSpace to the current contents of the $_POST variable
    * @see PostDataSpace
    * @return void
    * @access protected
    */
    function setDataSpace() { 
        require_once WACT_ROOT . '/request/postdata.inc.php';
        $this->DataSpace =& new PostDataSpace();
        /* add the $_FILES collection if apt */
        if (! empty($_FILES)) {
            $this->DataSpace->importAppend($_FILES);
        }
    }

    /**
    * Determines if this is the first time that the form will be shown.
    * No values have been submitted yet.
    * @return boolean (false if the user has submitted data to the form)
    * @access protected
    */
    function IsFirstTime() {
        return (strtoupper($_SERVER['REQUEST_METHOD']) != 'POST');
    }

    /**
    * Decides which ActionClass should be assigned to the parent CurrentAction
    * as well as passing on the ActionCondition, then calls the parent
    * performAction() method.
    * @return void
    * @access protected
    */
    function performAction() {
        if (    is_null($this->CurrentAction) && 
                !is_null($this->DefaultAction) &&
                !$this->IsfirstTime()) {
                
            $ActionClass = $this->DefaultAction;
            $this->CurrentAction =& new $ActionClass();
            $this->CurrentActionCondition = $this->DefaultActionCondition;
            
        }
        parent :: performAction();
    }
    
}
?>
