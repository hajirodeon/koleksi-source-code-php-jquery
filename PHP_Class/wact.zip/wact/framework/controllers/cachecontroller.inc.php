<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT_CONTROLLERS
* @version $Id: cachecontroller.inc.php,v 1.6 2003/12/09 10:16:35 jeffmoore Exp $
*/
//--------------------------------------------------------------------------------
/**
* Page Controller for file caching output
* @see http://wact.sourceforge.net/index.php/ServerCachedPageController
* @access public
* @package WACT_CONTROLLERS
* @abstract
*/
class ServerCachedPageController {
    /***
    * @var string
    * @access private
    */
    var $CachePath;
    /***
    * @var string
    * @access private
    */
    var $FileName;
    /***
    * Last file modification time (Unix Timestamp)
    * @var int
    * @access private
    */
    var $Age;
    /**
    * Determine whether page is cached
    * @return boolean
    * @access public
    */
    function IsCached() {
        $this->FileName = getConfigOption('config', 'cache', 'path') . $this->getFileName();
        if (!file_exists($this->FileName)) {
            return FALSE;
        }
        $this->Age = filemtime($this->FileName);
        return TRUE;
    }
    /**
    * Determine whether cache page has expired
    * @param int timestamp - the age of the cache
    * @return boolean
    * @access public
    */
    function IsExpired($Age) {
        return $Age < (time() - 60*5);
    }
    /**
    * Echoes the page stored in the cache to the output buffer,
    * sending the corresponding content length HTTP header as well
    * @return void
    * @access private
    */
    function DisplayCachedPage() {
        ob_start();
        $fp = fopen($this->FileName, "rb");
        flock($fp, LOCK_SH);
        $size = filesize($this->FileName);
        echo fread($fp, $size);
        flock($fp, LOCK_UN);
        fclose($fp);
        header("Content-Length: $size"); 
    }
    /**
    * Run the controller, displaying the page
    * @return void
    * @access public
    */
    function run() {
        if ($this->IsCached() && !$this->IsExpired($this->Age)) {
            $this->DisplayCachedPage();
        } else {
            ignore_user_abort(TRUE);
            require_once WACT_ROOT . '/util/filewrite.inc.php';
            EnsureDirectoryExists(dirname($this->FileName));
            $fp = fopen($this->FileName, "wb");
            if (flock($fp, LOCK_EX)) {
                ob_start();
                $this->DisplayPage();
                $size = ob_get_length();
                header("Content-Length: $size"); 
                fwrite($fp, ob_get_contents(), $size);
                flock($fp, LOCK_EX);
                ob_end_flush();
            } else {
                $this->DisplayCachedPage();
            }
            fclose($fp);
        }
    }
}
?>