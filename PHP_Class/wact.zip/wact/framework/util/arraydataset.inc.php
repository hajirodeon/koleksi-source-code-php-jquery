<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT_UTIL
* @version $Id: arraydataset.inc.php,v 1.16 2003/11/24 23:52:26 harryf Exp $
*/
//--------------------------------------------------------------------------------
/**
* Provides DataSpace combatible Iterator an array of associative arrays
* - a row set e.g.
* <code>
* $dataset = array (
*     array ('username'=>'jdoe','email'=>'jdoe@hotmail.com'),
*     array ('username'=>'rsmith','email'=>'rsmith@cure.org'),
*     array ('username'=>'nclark','email'=>'nclark@yahoo.com'),
* );
* $ds = new ArrayDataSet($dataset);
* </code>
* @see http://wact.sourceforge.net/index.php/ArrayDataSet
* @todo Does not yet fully implement DataSpace Interface
* @access public
* @package WACT_UTIL
*/
class ArrayDataSet /* implements DataSpaceInterface, Iterator */ {
    /**
    * Array to iterate over
    * @var array of arrays
    * @access private
    */
    var $dataset = array();
    /**
    * Current row (row) from the array
    * @var mixed
    * @access private
    */
    var $row = array();
    /**
    * TRUE if at start of the array
    * @var boolean (default=true)
    * @access private
    */
    var $first = TRUE;
    /**
    * Constructs ArrayDataSet
    * @param array (an array of arrays)
    * @access public
    */
    function ArrayDataSet($dataset = NULL) {
        if ( is_array($dataset) ) {
            $this->setDataSet($dataset);
        }
    }
    /**
    * Returns to start of ArrayDataSet
    * @return void
    * @access public
    */
    function reset() {
        $this->first = TRUE;
    }
    /**
    * Iterates through the ArrayDataSet, setting $this->row to the current
    * row.
    * Returns TRUE if there was another row to iterator over
    * Returns false if it's reached the end of the array
    * @return boolean
    * @access public
    */
    function next() {
        $key = key($this->dataset);
        if ( isset ( $key ) ) {
            $this->dataset[$key] = $this->row;
        }
        if ($this->first) {
            $row = reset($this->dataset);
            $this->first = FALSE;
        } else {
            $row = next($this->dataset);
        }
        if (is_array($row)) {
            $this->row = $row;
            $this->prepare();
            return TRUE;
        } else {
            $this->reset();
            return FALSE;
        }
    }
    /**
    * Gets a cell from the current row, given its column name
    * @return mixed
    * @access public
    */
    function get($name) {
        if (isset($this->row[$name])) {
            return $this->row[$name];
        }
    }
    /**
    * Assigns a value to a cell in the current row, given it's column name
    * @param string name of element
    * @param mixed value of element
    * @return void
    * @access public
    */
    function set($name,$value) {
        $this->row[$name] = $value;
    }
    /**
    * Appends some data to an existing cell in the current row
    * @param string name of element
    * @param mixed value of element
    * @return void
    * @access public
    */
    function append($name,$value) {
        $this->row[$name] .= $value;
    }
    /**
    * Replaces the current row with a new row
    * @param array
    * @return void
    * @access public
    */
    function import($valuelist) {
        if (is_array($valuelist)) {
            $this->row = NULL;
            $this->row = $valuelist;
        }
    }
    /**
    * Appends further columns to the current row (only). Existing columns of
    * the same name will be overwritten
    * @param array
    * @return void
    * @access public
    */
    function importAppend($valuelist) {
        if (is_array($valuelist)) {
            foreach ($valuelist as $name => $value) {
                $this->set($name, $value);
            }
        }
    }
    /**
    * Returns the current row from the dataset
    * @return array
    * @access public
    */
    function &export() {
        return $this->row;
    }
    /**
    * Registers a filter. Filters are used to transform rows
    * @param object instance of filter class containing a doFilter() method
    * @return void
    * @access public
    */
    function registerFilter(&$filter) {
        $this->filter =& $filter;
    }
    /**
    * Executes the doFilter() method of the registered filter, if one exists
    * @return void
    * @access protected
    */
    function prepare() {
        if (isset($this->filter)) {
            $this->filter->doFilter($this->row);
        }
    }
    /**
    * Set a complete dataset to be iterated over. Replaces any existing dataset
    * Works with a copy of the data set not a reference.
    * @return void
    * @access public
    * @param array a complete dataset
    */
    function setDataSet($dataset) {
        $this->dataset = $dataset;
        $this->row = reset($this->dataset);
    }
    /**
    * Returns the current dataset
    * @return array the complete dataset
    * @access public
    */
    function getDataSet() {
        return $this->dataset;
    }
    /**
    * Add a row to the current dataset.
    * @return void
    * @access public
    * @param array representing a row in the dataset
    */
    function addRow($row) {
        $this->dataset[] = $row;
    }
    /**
    * Check whether the DataSet is empty.
    * @return boolean
    * @access public
    */
    function isEmpty() {
        return empty($this->dataset);
    }
}
?>