<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT_UTIL
* @version $Id: dataspace.inc.php,v 1.2 2003/12/07 01:10:52 harryf Exp $
*/
//--------------------------------------------------------------------------------
/**
* Define dataspace as loaded
*/
define('DATASPACE_LOADED', TRUE);

//--------------------------------------------------------------------------------
/**
* The DataSpace is a container for a set of named data values (variables).
* @see http://wact.sourceforge.net/index.php/DataSpace
* @access public
* @abstract
* @package WACT
*/
class DataSpace {
    /**
    * Variables stored in the DataSpace are contained here
    * @var array
    * @access private
    */
    var $vars = array();
    /**
    * Filter object for transforming stored data
    * @var object
    * @access private
    */
    var $filter;

    // setFrom?
    // importFrom?

    /**
    * Gets a copy of a stored variable by name
    * @param string name of variable
    * @return mixed value of variable or VOID if not found
    * @access public
    */
    function get($name) {
        // isset check is faster than error suppression operator (@)
        if (isset($this->vars[$name])) {
            return $this->vars[$name];
        }
    }

    /**
    * Stores a copy of a variable
    * @param string name of variable
    * @param mixed value of variable
    * @return void
    * @access public
    */
    function set($name, $value) {
        $this->vars[$name] = $value;
    }

    /**
    * Concatenates a value to the end of an existing variable
    * @param string name of variable
    * @param mixed value to append
    * @deprecated append is probably superflous now.  Remove?
    * @return void
    * @access public
    */
    function append($name, $value) {
        $this->vars[$name] .= $value;
    }

    /**
    * Places a copy of an array in the data store, using the 1st dimension
    * array keys as the variable names.
    * @param array
    * @return void
    * @access public
    */
    // Rename to replace?
    function import($valuelist) {
        $this->vars = $valuelist;
    }

    // Reference counting?  huh?
    /**
    * Append a new list of values to the DataSpace. Existing key values will be
    * overwritten if duplicated in the new value list.
    *
    * @param array
    * @return void
    * @access public
    */
    // rename to import?
    function importAppend($valuelist) {
        foreach ($valuelist as $key => $value) {
            $this->set($key, $value);
        }
    }

    /**
    * Returns a reference to the complete array of variables stored
    * @return array
    * @access public
    */
    function &export() {
        return $this->vars;
    }

    /**
    * Registers a filter with the dataspace. Filters are used to transform
    * stored variables.
    * @param object instance of filter class containing a doFilter() method
    * @return void
    * @access public
    */
    function registerFilter(&$filter) {
        $this->filter =& $filter;
    }

    /**
    * Prepares the dataspace, executing the doFilter() method of the
    * registered filter, if one exists
    * @return void
    * @access protected
    */
    function prepare() {
        if (isset($this->filter)) {
            $this->filter->doFilter($this->vars);
        }
    }
}
?>