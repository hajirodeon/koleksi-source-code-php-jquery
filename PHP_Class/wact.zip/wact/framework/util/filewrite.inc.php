<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT_UTIL
* @version $Id: filewrite.inc.php,v 1.1 2003/10/17 18:02:44 jeffmoore Exp $
*/
//--------------------------------------------------------------------------------

/**
* If a directory does not exist in the correct scheme location, create one
* @param string directory name
* @return void
* @access protected
*/
function EnsureDirectoryExists($dirname) {
	$path = '';
	foreach (explode('/', $dirname) as $dir) {
		$path  .= $dir . '/';
		if (!file_exists($path)) {
			if (!@mkdir($path, 0777)) {
                RaiseError('compiler', 'CANNOTCREATEDIRECTORY', array(
                    'path' => $path));
			}
		}
	}
}

/**
* Writes a compiled template file
* @see http://wact.sourceforge.net/index.php/writeTemplateFile
* @param string filename
* @param string content to write to the file
* @return void
* @access protected
*/
function WriteFile($file, $data) {
	EnsureDirectoryExists(dirname($file));
	$fp=fopen($file, "wb");
	if (fwrite($fp, $data, strlen($data))){
		  fclose($fp);
	}
}

?>