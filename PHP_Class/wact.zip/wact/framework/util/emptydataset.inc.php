<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT_UTIL
* @version $Id: emptydataset.inc.php,v 1.5 2003/09/27 01:30:39 harryf Exp $
*/
//--------------------------------------------------------------------------------
/**
* A null implementation of the DataSpace and Iterator
* @see http://wact.sourceforge.net/index.php/EmptyDataSet
* @access public
* @package WACT_UTIL
*/
class EmptyDataSet /* implements DataSpace, Iterator */ {
	//--------------------------------------------------------------------------------
	// Iterator implementation
	/**
	* Iterator Method
	* @return void
	* @access public
	*/
	function reset() {
	}
	/**
	* Iterator Method
	* @return boolean FALSE
	* @access public
	*/
	function next() {
		return FALSE;
	}
	//--------------------------------------------------------------------------------
	// DataStore implementation
	/**
	* DataSpace Method
	* @param string name of variable
	* @return string empty string
	* @access public
	*/
	function &get($name) {
		return '';
	}
	/**
	* DataSpace Method
	* @param string name of variable
	* @param string value of variable
	* @return void
	* @access public
	*/
	function set($name, $value) {
	}
	/**
	* DataSpace Method
	* @param string name of variable
	* @param string value of variable
	* @return void
	* @access public
	*/
	function append($name, $value) {
	}
	/**
	* DataSpace Method
	* @param string name of variable
	* @return void
	* @access public
	*/
	function clear($name) {
	}
	/**
	* DataSpace Method
	* @param array associative array
	* @return void
	* @access public
	*/
	function import($valuelist) {
	}
	/**
	* DataSpace Method
	* @param array associative array
	* @return void
	* @access public
	*/
	function importAppend($valuelist) {
	}
	/**
	* DataSpace Method
	* @return array empty array
	* @access public
	*/
	function &export() {
		return array();
	}
	/**
	* DataSpace Method
	* @param object instance of filter class containing a doFilter() method
	* @return void
	* @access public
	*/
	function registerFilter(&$filter) {
	}
	/**
	* DataSpace Method
	* @return void
	* @access protected
	*/
	function prepare() {
	}
}
?>