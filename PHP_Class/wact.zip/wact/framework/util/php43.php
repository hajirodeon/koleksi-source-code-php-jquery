<?php
/**
* @package WACT_UTIL
* @version $Id: php43.php,v 1.4 2003/09/26 23:43:31 harryf Exp $
* Provides PHP implementations of functions only available since PHP 4.3.x
* allowing older versions to use them. Automatically included when the
* common framework include is loaded, after examining the PHP version
* @see http://wact.sourceforge.net/index.php/PHPCompatibility
*/
/**
* @see http://www.php.net/file_get_contents
* @see http://wact.sourceforge.net/index.php/PHPCompatibility
* @param string filename
* @return string contents of file
* @access public
*/
function file_get_contents($filename) {
	$fd = fopen("$filename", "rb");
	$content = fread($fd, filesize($filename));
	fclose($fd);
	return $content;
}
/**
* @see http://www.php.net/html_entity_decode
* @see http://wact.sourceforge.net/index.php/PHPCompatibility
* @todo Implement quote styles (?)
* @param string to encode HTML entities for
* @param string (default=NULL) - unused
* @return string contents of file
* @access public
*/
function html_entity_decode($str, $style=NULL) {
	return strtr($str, array_flip(get_html_translation_table(HTML_ENTITIES)));
}
?>