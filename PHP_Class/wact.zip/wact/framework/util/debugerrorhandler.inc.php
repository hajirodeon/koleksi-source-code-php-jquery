<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
require_once WACT_ROOT . 'template/template.inc.php';
/**
* @package WACT_UTIL
* @version $Id: debugerrorhandler.inc.php,v 1.4 2003/12/09 10:04:13 jeffmoore Exp $
*/
$GLOBALS['CurrentErrorObject'] = NULL;
/** 
* @TODO Change to use a template
* Putting high-level operations in an error handler leads to the dreaded
* recursive error problem that is the bane of non exception based error handling.
* Yet its nice to allow error message pages to have the look and feel of the rest
* of the site.
* that said, this function directly outputs HTML, and instead should probably
* format its output using a template.  That way, the template can be customized
* to match the look at feel of the site using the framework.
* The price of this is by using a template, there is an increased risk of a new
* error occurring while handling an error.  A bad situation.
*/
function HandleError($ErrorNumber, $ErrorMessage, $FileName, $LineNumber) {


    // Handle framework errors
    if ($ErrorNumber & E_USER_ERROR) {
        $Error = @unserialize($ErrorMessage);
        if (is_object($Error)) {
            $GLOBALS['CurrentErrorObject'] =& $Error;
            $OldHandler = set_error_handler('BareBonesErrorHandler');

            $Group = $Error->group;
            $MessageList = importVarFile("/errormessages/$Group.vars");
            $ErrorMessage = $MessageList[$Error->id];

            foreach($Error->info as $key => $replacement) {
                $ErrorMessage = str_replace('{' . $key . '}', $replacement, $ErrorMessage);
            }
    
            echo "<br><hr>\n";
            echo "<h3>Error:</h3>$ErrorMessage\n";
            exit;
        }
    }

    $ErrorTime = date("Y-m-d H:i:s (T)");

    // define an assoc array of error string
    // in reality the only entries we should
    // consider are 2,8,256,512 and 1024
    $ErrorType = array (
                1   =>  "Error",
                2   =>  "Warning",
                4   =>  "Parsing Error",
                8   =>  "Notice",
                16  =>  "Core Error",
                32  =>  "Core Warning",
                64  =>  "Compile Error",
                128 =>  "Compile Warning",
                256 =>  "User Error",
                512 =>  "User Warning",
                1024=>  "User Notice"
                );

	if ($ErrorNumber & (E_NOTICE | E_USER_NOTICE)) {
		$Level = 'NOTICE';
	} else if ($ErrorNumber & (E_WARNING | E_USER_WARNING | E_CORE_WARNING | E_COMPILE_WARNING)) {
		$Level = 'WARNING';
	} else if ($ErrorNumber & (E_ERROR | E_PARSE | E_CORE_ERROR | E_COMPILE_ERROR | E_USER_ERROR)) {
		$Level = 'ERROR';
	} else {
		$Level = 'Unknown';
	}
    
	echo "<br><hr>\n";
	echo "<h3>$Level:</h3>$ErrorMessage\n";
	echo "<ul><li>";
	echo '<font face="Courier New,Courier">';
	echo "$FileName line $LineNumber\n";

	// based on PHP manual page for debug_backtrace()
	if (PHPVERSION() >= 4.3) {
		$Trace = debug_backtrace();
		array_shift($Trace);
		foreach ($Trace as $line) {
			echo '<li>';
			echo '<font face="Courier New,Courier"><B>';
			if (isset($line['class'])) {
				echo $line['class'];
				echo ".";
			}
			echo $line['function'];
			echo "(";
			if (isset($line['args'])) {
				$sep = '';
				foreach ($line['args'] as $arg) {
					echo $sep;
					$sep = ', ';
					if (is_null($arg)) {
						echo 'NULL';
					} else if (is_array($arg)) {
						echo 'ARRAY[' . sizeof($v) . ']';
					} else if (is_object($arg)) {
						echo 'OBJECT:' . get_class($arg);
					} else if (is_bool($arg)) {
						echo $arg ? 'TRUE' : 'FALSE';
					} else { 
						echo '"';
						echo htmlspecialchars(substr((string) @$arg, 0, 32));
						if (strlen($arg) > 32) {
							echo '...';
						}
						echo '"';
					}
				}
			}
			echo ")";
			echo "</b><br>\n";
			echo $line['file'];
			echo " line <b>";
			echo $line['line'];
			echo '</b></font>';
		}
	}
		
	echo "</ul>";
	echo "<hr>\n";
  	exit;

}

/** 
* This function is called only when an error has occured in the error handler.
* Usually this is because there is a problem accessing the template system.
* Here we heroicly attempt to print out something intelligable for the original error.
* 
* @todo What happens if the error message is not found in the default error messages?
*/
function BareBonesErrorHandler($ErrorNumber, $ErrorMessage, $FileName, $LineNumber) {
    $Error =& $GLOBALS['CurrentErrorObject'];

    $filename = WACT_ROOT . 'default/errormessages/' . $Error->group . '.vars';

    $MessageList = array();

	$RawLines = file($filename);
	
	while (list(,$Line) = each($RawLines)) {
		$EqualPos = strpos($Line, '=');
		if ($EqualPos === FALSE) {
			$MessageList[trim($Line)] = NULL;
		} else {
			$Key = trim(substr($Line, 0, $EqualPos));
			if (strlen($Key) > 0) {
				$MessageList[$Key] = trim(substr($Line, $EqualPos+1));
			}
		}
	}

    $ErrorMessage = $MessageList[$Error->id];

    foreach($Error->info as $key => $replacement) {
        $ErrorMessage = str_replace('{' . $key . '}', $replacement, $ErrorMessage);
    }

    echo "<br><hr>\n";
    echo "<h3>Error:</h3>$ErrorMessage\n";
    exit;
}

?>
