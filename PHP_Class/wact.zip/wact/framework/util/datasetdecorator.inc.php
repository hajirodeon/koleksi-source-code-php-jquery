<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT_UTIL
* @version $Id: datasetdecorator.inc.php,v 1.2 2003/10/02 12:49:45 harryf Exp $
*/
//--------------------------------------------------------------------------------
/**
* Provides a base class to use for decorating datasets
* @see http://wact.sourceforge.net/index.php/DataSetDecorator
* @access public
* @package WACT_UTIL
*/
class DataSetDecorator /* implements DataSpaceInterface, Iterator */ {
	/**
	* The data set being decorated
	* @var object
	* @access private
	*/
	var $dataset;
	/**
	* Constructs DataSetDecorator
	* @param object data set to decorate
	* @access public
	*/
	function DataSetDecorator(& $dataset) {
		$this->dataset = & $dataset;
	}
	/**
	* @return void
	* @access public
	*/
	function reset() {
		$this->dataset->reset();
	}
	/**
	* @return boolean
	* @access public
	*/
	function next() {
		return $this->dataset->next();
	}
	/**
	* @return mixed
	* @access public
	*/
	function get($name) {
		return $this->dataset->get($name);
	}
	/**
	* @param string name of element
	* @param mixed value of element
	* @return void
	* @access public
	*/
	function set($name,$value) {
		$this->dataset->set($name,$value);
	}
	/**
	* @param string name of element
	* @param mixed value of element
	* @return void
	* @access public
	*/
	function append($name,$value) {
		$this->dataset->append($name,$value);
	}
	/**
	* @param array
	* @return void
	* @access public
	*/
	function import($valuelist) {
		$this->dataset->import($valuelist);
	}
	/**
	* @param array
	* @return void
	* @access public
	*/
	function importAppend($valuelist) {
		$this->dataset->importAppend($valuelist);
	}
	/**
	* @return array
	* @access public
	*/
	function &export() {
		return $this->dataset->export();
	}
	/**
	* @param object instance of filter class containing a doFilter() method
	* @return void
	* @access public
	*/
	function registerFilter(&$filter) {
		$this->dataset->registerFilter($filter);
	}
	/**
	* @return void
	* @access protected
	*/
	function prepare() {
		$this->dataset->prepare();
	}
}
?>