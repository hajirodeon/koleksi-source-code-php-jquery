<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT_DB
* @version $Id: mysql.inc.php,v 1.17 2003/12/07 01:14:33 harryf Exp $
*/
//--------------------------------------------------------------------------------

/**
* Check dataspace is loaded
*/
if (!defined('DATASPACE_LOADED')) {
	require WACT_ROOT . '/util/dataspace.inc.php';
}

/**
* Define globals
*/
// Can't really figure out a better way to do this as of yet.
$GLOBALS['DatabaseConnectionClass'] = 'MySQLConnection';
$GLOBALS['DatabaseRecordClass'] = 'MySQLRecord';
$GLOBALS['DatabaseRecordSetClass'] = 'MySQLRecordSet';

/**
* Encapsulates a database connection.  Allows for lazy connections.
* @see http://wact.sourceforge.net/index.php/MySQLConnection
* @access public
* @package WACT_DB
*/
class MySQLConnection {

	/**
	* Resource representing connection to MySQL database
	* @var resource
	* @access private
	*/
	var $ConnectionId;

	/**
	* Database to connect to
	* @var string
	* @access private
	*/
	var $database = NULL;

	/**
	* User to connect as
	* @var string
	* @access private
	*/
	var $user;

	/**
	* password to connect with
	* @var string
	* @access private
	*/
	var $password;
	
	/**
	* host to connect to
	* @var string
	* @access private
	*/
	var $host;
	
	/**
	* Create a MySQL database connection.  If the database isn't specified, all parameters
	* will be read from the configuration file parameters:
	*  mysql.database
	*  mysql.user
	*  mysql.password
	*  mysql.host
	* @param string Database to connect to
	* @param string User to connect as
	* @param string Password to connect with
	* @param string Host to connect to
	* @access private
	*/
	function MySQLConnection($database = '', $user = '', $password = '', $host = 'localhost') {
		if (func_num_args() == 0) {
			$this->database = getConfigOption('config', 'database', 'mysql.database');
			$this->user = getConfigOption('config', 'database', 'mysql.user');
			$this->password = getConfigOption('config', 'database', 'mysql.password');
			$this->host = getConfigOption('config', 'database', 'mysql.host');
		} else {
			$this->database = $database;
			$this->user = $user;
			$this->password = $password;
			$this->host = $host;
		}
	}

	/**
	* Return connectionId for a mysql database.  Allow a lazy connection.
	* @return resource
	* @access protected
	*/
	function getConnectionId() {
		if (!isset($this->ConnectionId)) {
			$this->connect();
		}
		return $this->ConnectionId;
	}

	/**
	* Connect to the the database
	* @return void
	* @access protected
	*/
	function connect() {
		$this->ConnectionId = mysql_connect($this->host, $this->user, $this->password);
		if ($this->ConnectionId === FALSE) {
			$this->RaiseError();
		}
	
		if (mysql_select_db($this->database, $this->ConnectionId) === FALSE) {
			$this->RaiseError();
		}
	}

	/**
	* Raises an error, passing it on to the framework level error mechanisms
	* @param string (optional) SQL statement
	* @return void
	* @access private
	*/
	function RaiseError($sql = NULL) {
		$errno = mysql_errno($this->getConnectionId());
		$id = 'DB_ERROR';
		$info = array('driver' => 'MySQL');
		if ($errno != 0) {
			$info['errorno'] = $errno;
			$info['error'] = mysql_error($this->getConnectionId());
			$id .= '_MESSAGE';
		}
		if (!is_null($sql)) {
			$info['sql'] = $sql;
			$id .= '_SQL';
		}
		RaiseError('db', $id, $info);
	}
	
	/**
	* EXPERIMENTAL:
	* Convert a PHP value into an SQL literal.
	* @param mixed value to convert
	* @param string (optional) type to convert to
	* @return string literal SQL value
	* @access public
	*/
	function makeLiteral($value, $type = NULL) {
		if (is_null($type)) {
			$type = gettype($value);
		}
		switch (strtolower($type)) {
		case 'string':
			return "'" . mysql_escape_string($value) . "'";
			break;
		case 'boolean':
			return ($value) ? 1 : 0;
			break;
		case 'null':
			return 'NULL';
			break;
		default:
			return strval($value);
		}
	}

	/**
	* Retreive a single record from the database based on a query.
	* @param string SQL Query
	* @return Record object or NULL if not found
	* @access public
	*/
	function &FindRecord($query) {
		$Record =& new MySqlRecord($this);
		$QueryId = $this->execute($query);
		$Record->vars =& mysql_fetch_assoc($QueryId);
		mysql_free_result($QueryId);
		if (is_array($Record->vars)) {
			return $Record;
		}
	}
	
	/**
	* Get a single value from the first column of a single record from
	* a database query.
	* @param string SQL Query
	* @return Value or NULL if not found
	* @access public
	*/
	function getOneValue($query) {
		$QueryId = $this->execute($query);
		$row = mysql_fetch_row($QueryId);
		mysql_free_result($QueryId);
		if (is_array($row)) {
			return $row[0];
		}
	}
	
	/**
	* Retreive an array where each element of the array is the value from the
	* first column of a database query.
	* @param string SQL Query
	* @access public
	*/
	function getOneColumnArray($query) {
		$Column = array();
		$QueryId = $this->execute($query);
		while (is_array($row = mysql_fetch_row($QueryId))) {
			$Column[] = $row[0];
		}
		mysql_free_result($QueryId);
		return $Column;
	}

	/**
	* Retreive an associative array where each element of the array is based
	* on the first column as a key and the second column as data.
	* @param string SQL Query
	* @access public
	*/
	function getTwoColumnArray($query) {
		$Column = array();
		$QueryId = $this->execute($query);
		while (is_array($row = mysql_fetch_row($QueryId))) {
			$Column[$row[0]] = $row[1];
		}
		mysql_free_result($QueryId);
		return $Column;
	}

	/**
	* Performs any query that does not return a cursor.
	* @param string SQL query
	* @return resource MySQL result resource
	* @access public
	*/
	function execute($sql) {
		$result = mysql_query($sql, $this->getConnectionId());
		if ($result === FALSE) {
			$this->RaiseError($sql);
		}
		return $result;
	}

	/**
	* Disconnect from database
	* @return void
	* @access public
	*/
	function disconnect() {
		mysql_close($this->getConnectionId);
		$this->ConnectionId = NULL;
	}
	
}

/**
* Encapsulates INSERT, UPDATE, or DELETE operations on a MySQL database.
* @see NewRecord
* @see http://wact.sourceforge.net/index.php/MySQLRecord
* @access public
* @package WACT_DB
*/
class MySqlRecord extends DataSpace {
	/**
	* Connection to MySQL
	* @var resource
	* @access private
	*/
	var $Connection;

	/**
	* Conecruct a record
	* @param object Connection
	* @return newly constructed objects
	* @access protected
	*/
	function MySqlRecord($Connection) {
		$this->Connection = $Connection;
	}

	/**
	* Build SQL fragment to assign values to columns
	* @param array associative of field_name => type
	* @param array associative (optional)  of field_name => value
	* @return string SQL fragment
	* @access protected
	*/
	function buildAssignmentSQL($fields, $extrafields) {
		$query = ' SET ';
		$sep = '';
		foreach($fields as $fieldname => $type) {
			if (!is_string($fieldname)) {
				$fieldname = $type; // Swap if no type is specified
				$type = NULL;
			}
			$query .= $sep . $fieldname . '=' . 
				$this->Connection->makeLiteral($this->get($fieldname), $type);
			$sep = ', ';
		}
		if (!is_null($extrafields)) {
			foreach($extrafields as $fieldname => $value) {
				$query .= $sep . $fieldname . '=' . $value;
				$sep = ', ';
			}
		}
		return $query;
	}

	/**
	* Performs an INSERT to a single table
	* the field list parameter allows expressions to defined in the sql
	* statements as well as field values defined in the record.
	* requires MySQL Version 3.22.10 or better.
	* @param string table name
	* @param array associative of field_name => type
	* @param boolean (default = null) whether to return the insert id
	* @param array associative (optional)  of field_name => value
	* @return mixed either true or false on success or int of insert id
	* @access public
	*/
	function insert($table, $fields, $autoincrement = NULL, $extrafields = NULL) {

		$query = "INSERT " . $table . $this->buildAssignmentSQL($fields, $extrafields);

		$result = $this->Connection->execute($query);
		if ($result) {
			if ($autoincrement) {
				return mysql_insert_id($this->Connection->getConnectionId());
			} else {
				return TRUE;
			}
		} else {
			return FALSE;
		}
	}

	/**
	* Performs an UPDATE on a single table
	* @param string table name
	* @param array associative of field_name => type
	* @param string (optional) SQL where clause
	* @param array associative (optional)  of field_name => value
	* @return resource MySQL query result
	* @access public
	*/
	function update($table, $fields, $where = NULL, $extrafields = NULL) {

		$query = "UPDATE " . $table . $this->buildAssignmentSQL($fields, $extrafields);

		if (!is_null($where)) {
			$query .= " WHERE " . $where;
		}

		return $this->Connection->execute($query);
	}

	/**
	* Gets the number of rows changed by an insert, delete or update query.
	* @return int number of affected rows
	* @access public
	*/
	function getAffectedRowCount() {
		return mysql_affected_rows($this->Connection->getConnectionId());
	}

	/**
	* Performs any query that does not return a cursor.
	* @param string SQL query
	* @return resource MySQL result resource
	* @access public
	* @deprecated
	*/
	function execute($sql) {
		return $this->Connection->execute($sql);
	}
	
}

/**
* Encapsulates the cursor result of a SELECT, SHOW, DESCRIBE or EXPLAIN 
* sql statement.  Implements the Iterator interface.
* @see NewRecordSet
* @see http://wact.sourceforge.net/index.php/MySQLRecordSet
* @access public
* @package WACT_DB
*/
class MySqlRecordSet /* implements iterator */ extends MySqlRecord {
	/**
	* MySQL query resource
	* @var resource
	* @access private
	*/
	var $QueryId;
	
	/**
	* Pager
	* @var object The current pager for this query.
	* @access private
	*/
	var $pager;
	
	/**
	* SQL Statement
	* @var string
	* @access private
	*/
	var $Query;

	/**
	* Construct a record set.
	* @param object MySQL Connection
	* @param string SQL SELECT, SHOW, DESCRIBE, or EXPLAIN statement
	* @return void
	* @access public
	*/
	function MySqlRecordSet($Connection, $Query_String) {
		$this->Connection = $Connection;
		$this->Query = $Query_String;
	}

	/**
	* Assign a query for this object to process.
	* @param string SQL statement
	* @return void
	* @access public
	*/
	function query($Query_String) {
		$this->freeQuery();
		$this->Query = $Query_String;
	}

	/**
	* Assign a pager to this query for the purposes of breaking up the resulting
	* cursor into paged chucks.
	* The pager must implement an interface with three methods:
	*	setPagedDataSet()
	*	getStartingItem()
	*	getItemsPerPage()
	* The pager may call back to this object using one of two functions:
	*	getTotalRowCount()
	*	getRowCount()
	* The callback interface is to allow the pager to determine the number
	* of items in the full query.  Not all pagers require this information so
	* it was implemented as a call back.
	* @param object Pager
	* @return void
	* @access public
	*/
	function paginate(&$pager) {
		$this->pager =& $pager;
		$pager->setPagedDataSet($this);
	}

	/**
	* UNIMPLEMENTED:
	* examine the types of the fields in the query and build a filter for this DataSpace
	* That converts database types to PHP Types.  This is the reverse of
	* makeLiteral.
	* Probably doesn't need to do anything except for date/time/datetime/timestamp fields.
	* What to do for these fields, I am unsure.
	* @return void
	*/
	function buildFilter() {
	}

	/**
	* Frees up the Query resource.  can be called even if no
	* resource is set or if has already been freed.
	* @return void
	* @access private
	*/
	function freeQuery() {
		if (isset($this->QueryId) && is_resource($this->QueryId)) {
			mysql_free_result($this->QueryId);
			$this->QueryId = NULL;
		}
	}

	/**
	* Iterator reset method to move the current pointer to the first position
	* in the query.
	* @access public
	* @return boolean TRUE if the query is valid.
	*/
	function reset() {
		if (isset($this->QueryId) && is_resource($this->QueryId)) {
			if (mysql_data_seek($this->QueryId, 0) === FALSE) {
				$this->Connection->RaiseError();
			}
		} else {
			$query = $this->Query;
			if (isset($this->pager)) {
				$query .= ' LIMIT ' . 
					$this->pager->getStartingItem() . ',' . 
					$this->pager->getItemsPerPage();
			}
			
			$this->QueryId = $this->Connection->execute($query);
			return TRUE;
		}
	}

	/**
	* Routes calls through to reset for dataspace implementation
	* @return void
	*/
	function prepare() {
		$this->reset();
	}

	/**
	* Iterator next method.  Load the data values from the next record
	* in the query into the current data values.
	* @return boolean TRUE if there are more results to fetch
	* @access public
	*/
	function next() {
		if (!isset($this->QueryId)) {
			return FALSE;
		}
	
		$this->vars =& mysql_fetch_assoc($this->QueryId);

		if (is_array($this->vars)) {
			parent::prepare();
			return TRUE;
		} else {
			$this->freeQuery();
			return FALSE;
		}
	}

	/**
	* Returns the number of rows in a query
	* @return int number of rows
	* @access public
	*/
	function getRowCount() {
		return mysql_num_rows($this->QueryId);
	}
	
	/**
	* Returns the total number of rows that a query would return, ignoring paging
	* restrictions.  Query re-writing based on _adodb_getcount.
	* @return int number of rows
	* @access public
	*/
	function getTotalRowCount() {
		if (!(preg_match("/^\s*SELECT\s+DISTINCT/is", $this->Query) && preg_match('/\s+GROUP\s+BY\s+/is',$this->Query))) {
			$rewritesql = preg_replace(
						'/^\s*SELECT\s.*\s+FROM\s/Uis','SELECT COUNT(*) FROM ',$this->Query);
			$rewritesql = preg_replace('/(\sORDER\s+BY\s.*)/is','',$rewritesql);

			$QueryId = $this->Connection->execute($rewritesql);
			$row = mysql_fetch_row($QueryId);
			mysql_free_result($QueryId);
			if (is_array($row)) {
				return $row[0];
			}
		}
		
		// could not re-write the query, try a different method.

		$QueryId = $this->Connection->execute($this->Query);
		$count = mysql_num_rows($QueryId);
		mysql_free_result($QueryId);
		return $count;
	}
}
?>