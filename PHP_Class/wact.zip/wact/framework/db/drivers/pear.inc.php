<?php
//--------------------------------------------------------------------------------
// Copyright 2003 Procata, Inc.
// Released under the LGPL license (http://www.gnu.org/copyleft/lesser.html)
//--------------------------------------------------------------------------------
/**
* @package WACT_DB
* @version $Id: pear.inc.php,v 1.12 2003/12/09 10:04:12 jeffmoore Exp $
*/
//--------------------------------------------------------------------------------
/**
* Make sure dataspace is loaded
*/
if (!defined('DATASPACE_LOADED')) {
	require WACT_ROOT . '/util/dataspace.inc.php';
}

/**
* Define globals
*/
// Can't really figure out a better way to do this as of yet.
$GLOBALS['DatabaseConnectionClass'] = 'PearConnection';
$GLOBALS['DatabaseRecordClass'] = 'PearRecord';
$GLOBALS['DatabaseRecordSetClass'] = 'PearRecordSet';

/**
* Include PEAR::DB
*/
if ( !defined('PEAR_LIBRARY_PATH') ) {
    define('PEAR_LIBRARY_PATH', getConfigOption('config', 'pear', 'library_path'));
}
if (!@include_once PEAR_LIBRARY_PATH . 'DB.php') {
    RaiseError('runtime', 'LIBRARY_REQUIRED', array(
        'library' => 'PEAR::DB',
        'path' => PEAR_LIBRARY_PATH));
}

/**
* Define database type (provider)
* @ignore
*/
if ( !defined('DBC_TYPE') )
	define ('DBC_TYPE','mysql');
//--------------------------------------------------------------------------------
/**
* Encapsulates a database connection.  Allows for lazy connections.
* @see http://wact.sourceforge.net/index.php/PearConnection
* @access public
* @package WACT_DB
*/
class PearConnection {
	/**
	* PEAR DB Connection object
	* @var object subclass of PEAR::DB_Common
	* @access private
	*/
	var $ConnectionId;

	/**
	* Type of database
	* @var string
	* @access private
	*/
	var $dbtype = NULL;

	/**
	* Database to connect to
	* @var string
	* @access private
	*/
	var $database = NULL;

	/**
	* User to connect as
	* @var string
	* @access private
	*/
	var $user;

	/**
	* password to connect with
	* @var string
	* @access private
	*/
	var $password;
	
	/**
	* host to connect to
	* @var string
	* @access private
	*/
	var $host;
	
	/**
	* Create a PEAR::DB database connection.  If the database isn't specified, all parameters
	* will be read from the configuration file parameters:
	*  pear.type  ; Database type e.g. pgsql for postgresql
	*  pear.database
	*  pear.user
	*  pear.password
	*  pear.host
	* @param string Database to connect to
	* @param string User to connect as
	* @param string Password to connect with
	* @param string Host to connect to
	* @access private
	*/
	function PearConnection($database = '', $user = '', $password = '', $host = 'localhost') {
		if (func_num_args() == 0) {
			$this->dbtype = getConfigOption('config', 'database', 'pear.dbtype');
			$this->database = getConfigOption('config', 'database', 'pear.database');
			$this->user = getConfigOption('config', 'database', 'pear.user');
			$this->password = getConfigOption('config', 'database', 'pear.password');
			$this->host = getConfigOption('config', 'database', 'pear.host');
		} else {
			$this->database = $database;
			$this->user = $user;
			$this->password = $password;
			$this->host = $host;
		}
		if ( is_null($this->dbtype) ) {
			$this->dbtype = DBC_TYPE;
		}
	}

	/**
	* Return connectionId for a PEAR database.  Allow a lazy connection.
	* @return object subclass of PEAR::DB_Common
	* @access protected
	*/
	function & getConnectionId() {
		if (!isset($this->ConnectionId)) {
			$this->connect();
		}
		return $this->ConnectionId;
	}

	/**
	* Connect to the the database
	* @return void
	* @access protected
	*/
	function connect() {
		$dsn = "{$this->dbtype}://{$this->user}:{$this->password}@{$this->host}/{$this->database}";
		$this->ConnectionId = DB::connect($dsn);
		if (DB::isError($this->ConnectionId)) {
			$this->RaiseError();
		}
	}

	/**
	* Raises an error, passing it on to the framework level error mechanisms
	* @param string (optional) SQL statement
	* @return void
	* @access private
	*/
	function RaiseError($sql = NULL) {
		$error = & $this->getConnectionId();
		$id = 'DB_ERROR';
		$info = array('driver' => 'Pear');
		if ( DB::isError($error) ) {
			$errno = $error->getCode();
			if ($errno != -1) {
				$info['errorno'] = $errno;
				$info['error'] = $error->getMessage();
				$id .= '_MESSAGE';
			}
		}
		if (!is_null($sql)) {
			$info['sql'] = $sql;
			$id .= '_SQL';
		}
		RaiseError('db', $id, $info);
	}
	
	/**
	* EXPERIMENTAL:
	* Convert a PHP value into an SQL literal.
	* @param mixed value to convert
	* @param string (optional) type to convert to
	* @return mixed literal scalar type
	* @access public
	*/
	function makeLiteral($value, $type = NULL) {
		if (is_null($type)) {
			$type = gettype($value);
		}
		switch (strtolower($type)) {
		case 'string':
			if ( !class_exists('DB_'.$this->dbtype) )
				require_once 'DB/'.$this->dbtype.'.php';
			return "'" . addslashes(DB_Common::quote($value)) . "'";
			break;
		case 'boolean':
			return ($value) ? 1 : 0;
			break;
		case 'null':
			return 'NULL';
			break;
		default:
			return strval($value);
		}
	}

	/**
	* Retreive a single record from the database based on a query.
	* @param string SQL Query
	* @return Record object or NULL if not found
	* @access public
	*/
	function &FindRecord($query) {
		$Record =& new PearRecord($this);
		$QueryId = $this->execute($query);
		$Record->vars =& $QueryId->fetchRow(DB_FETCHMODE_ASSOC);
		$QueryId->free();
		if (is_array($Record->vars)) {
			return $Record;
		}
	}
	
	/**
	* Get a single value from the first column of a single record from
	* a database query.
	* @param string SQL Query
	* @return Value or NULL if not found
	* @access public
	*/
	function getOneValue($query) {
		$QueryId = $this->execute($query);
		$row = $QueryId->fetchRow();
		$QueryId->free();
		if (is_array($row)) {
			return $row[0];
		}
	}
	
	/**
	* Retreive an array where each element of the array is the value from the
	* first column of a database query.
	* @param string SQL Query
	* @access public
	*/
	function getOneColumnArray($query) {
		$Column = array();
		$QueryId = $this->execute($query);
		while (is_array($row = $QueryId->fetchRow())) {
			$Column[] = $row[0];
		}
		$QueryId->free();
		return $Column;
	}

	/**
	* Retreive an associative array where each element of the array is based
	* on the first column as a key and the second column as data.
	* @param string SQL Query
	* @access public
	*/
	function getTwoColumnArray($query) {
		$Column = array();
		$QueryId = $this->execute($query);
		while (is_array($row = $QueryId->fetchRow())) {
			$Column[$row[0]] = $row[1];
		}
		$QueryId->free();
		return $Column;
	}

	/**
	* Performs any query that does not return a cursor.
	* @param string SQL query
	* @return object PEAR DB_Result or DB_Error
	* @access public
	*/
	function execute($sql) {
		$conn = & $this->getConnectionId();
		$result = & $conn->query($sql);
		if (DB::isError($result)) {
			$this->RaiseError($sql);
		}
		return $result;
	}

	/**
	* Disconnect from database
	* @return void
	* @access public
	*/
	function disconnect() {
		$conn = & $this->getConnectionId();
		$conn->disconnect();
		$this->ConnectionId = NULL;
	}
	
}
//--------------------------------------------------------------------------------
/**
* Encapsulates operations on a database via PEAR::DB. Generally this
* class is only used for INSERT, UPDATE and DELETE operations
* @see http://wact.sourceforge.net/index.php/PearRecord
* @access public
* @package WACT_DB
*/
class PearRecord extends DataSpace {
	/**
	* Database connection encasulated in PearConnection
	* @var PearConnection instance
	* @access private
	*/
	var $Connection;

	/**
	* Construct a record
	* @param PearConnection
	* @access protected
	*/
	function PearRecord(& $Connection) {
		$this->Connection = & $Connection;
	}

	/**
	* Build SQL fragment to assign values to columns
	* @param array associative of field_name => type
	* @param array associative (optional)  of field_name => value
	* @return string SQL fragment
	* @access protected
	*/
	function buildAssignmentSQL($fields, $extrafields) {
		$query = ' SET ';
		$sep = '';
		foreach($fields as $fieldname => $type) {
			if (!is_string($fieldname)) {
				$fieldname = $type; // Swap if no type is specified
				$type = NULL;
			}
			$query .= $sep . $fieldname . '=' . 
				$this->Connection->makeLiteral($this->get($fieldname), $type);
			$sep = ', ';
		}
		if (!is_null($extrafields)) {
			foreach($extrafields as $fieldname => $value) {
				$query .= $sep . $fieldname . '=' . $value;
				$sep = ', ';
			}
		}
		return $query;
	}

	/**
	* Performs an INSERT to a single table
	* the field list parameter allows expressions to defined in the sql
	* statements as well as field values defined in the record.
	* Note that autoincrement does not work for PEAR::DB driver
	* @param string table name
	* @param array associative of field_name => type
	* @param boolean (default = null) whether to return the insert id (not working!)
	* @param array associative (optional)  of field_name => value
	* @return mixed either true or false on success
	* @access public
	*/
	function insert($table, $fields, $autoincrement = NULL, $extrafields = NULL) {

		$query = "INSERT " . $table . $this->buildAssignmentSQL($fields, $extrafields);

		$result = $this->Connection->execute($query);
		if ($result) {
			return TRUE;
		} else {
			return FALSE;
		}
	}

	/**
	* Performs an UPDATE on a single table
	* @param string table name
	* @param array associative of field_name => type
	* @param string (optional) SQL where clause
	* @param array associative (optional)  of field_name => value
	* @return object DB_Result or DB_Error
	* @access public
	*/
	function update($table, $fields, $where = NULL, $extrafields = NULL) {
		$query = "UPDATE " . $table . $this->buildAssignmentSQL($fields, $extrafields);
		if (!is_null($where)) {
			$query .= " WHERE " . $where;
		}
		return $this->Connection->execute($query);
	}

	/**
	* Gets the number of rows changed by a query
	* @return int number of affected rows
	* @access public
	*/
	function getAffectedRowCount() {
		$QueryId = & $this->Connection->getConnectionId();
		return $QueryId->affectedRows();
	}

	/**
	* Performs any query that does not return a cursor.
	* @param string SQL query
	* @return object PEAR DB_Result or DB_Error
	* @access public
	* @deprecated
	*/
	function execute($sql) {
		return $this->Connection->execute($sql);
	}
}
//--------------------------------------------------------------------------------
/**
* Encapsulates the results of a SELECT, SHOW, DESCRIBE or EXPLAIN sql statement
* Implements the Iterator interface defined in the DataSpace
* @see http://wact.sourceforge.net/index.php/PearRecordSet
* @access public
* @package WACT_DB
*/
class PearRecordSet extends PearRecord {
	/**
	* PEAR::DB Result Object
	* @var object
	* @access private
	*/
	var $QueryId;
	/**
	* Pager
	* @var object The current pager for this query.
	* @access private
	*/
	var $pager;
	/**
	* SQL Statement
	* @var string
	* @access private
	*/
	var $Query;
	/**
	* Switch to watch if this is the first row
	* @var boolean (default = TRUE)
	* @access private
	*/
	var $first = TRUE;
	/**
	* Switch to watch for resets
	* @var boolean (default = FALSE)
	* @access private
	*/
	var $reentry = FALSE;
	/**
	* Construct a record set.
	* @param object PearConnection
	* @param string SQL SELECT, SHOW, DESCRIBE, or EXPLAIN statement
	* @access public
	*/
	function PearRecordSet($Connection, $Query_String) {
		$this->Connection = $Connection;
		$this->Query = $Query_String;
	}
	/**
	* Stores the SQL statement and makes sure the result object is
	* empty
	* @param string SQL statement
	* @return void
	* @access protected
	*/
	function query($Query_String) {
		$this->freeQuery();
		$this->Query = $Query_String;
	}
	/**
	* Assign a pager to this query for the purposes of breaking up the resulting
	* cursor into paged chucks.
	* The pager must implement an interface with three methods:
	*    setPagedDataSet()
	*    getStartingItem()
	*    getItemsPerPage()
	* The pager may call back to this object using one of two functions:
	*    getTotalRowCount()
	*    getRowCount()
	* The callback interface is to allow the pager to determine the number
	* of items in the full query.  Not all pagers require this information so
	* it was implemented as a call back.
	* @param object Pager
	* @return void
	* @access public
	*/
	function paginate(&$pager) {
		$this->pager =& $pager;
		$pager->setPagedDataSet($this);
	}

	/**
	* UNIMPLEMENTED:
	* examine the types of the fields in the query and build a filter for this DataSpace
	* That converts database types to PHP Types.  This is the reverse of
	* makeLiteral.
	* Probably doesn't need to do anything except for date/time/datetime/timestamp fields.
	* What to do for these fields, I am unsure.
	* @return void
	*/
	function buildFilter() {
	}
	/**
	* Frees up the Result object if one exists
	* @return void
	* @access private
	*/
	function freeQuery() {
		if (isset($this->QueryId) && is_object($this->QueryId)) {
			$this->QueryId->free();
			$this->QueryId = NULL;
		}
	}
	/**
	* Iterator reset method
	* @return void
	* @access public
	*/
	function reset() {
		$query = $this->Query;
		if (isset($this->pager)) {
			$conn = & $this->Connection->getConnectionId();
			$query = $conn->modifyLimitQuery($query,
				$this->pager->getStartingItem(),$this->pager->getItemsPerPage());
		}
		$this->QueryId = $this->Connection->execute($query);
		return TRUE;
	}

	/**
	* Prepares the recordset for iteration
	* @access public
	* @return void
	*/
	function prepare() {
		$this->reset();
	}
	/**
	* Iterator next method
	* @return boolean TRUE if there are more results to fetch
	* @access public
	*/
	function next() {
		if (!isset($this->QueryId)) {
			return FALSE;
		}
		$this->vars = $this->QueryId->fetchRow(DB_FETCHMODE_ASSOC);
		if (is_array($this->vars)) {
			parent::prepare();
			return TRUE;
		} else {
			$this->freeQuery();
			return FALSE;
		}
	}
	/**
	* Returns the number of rows in a query
	* @return int number of rows
	* @access public
	*/
	function getRowCount() {
		return $this->QueryId->numRows();
	}

	/**
	* Returns the total number of rows that a query would return, ignoring paging
	* restrictions.  Query re-writing based on _adodb_getcount.
	* @return int number of rows
	* @access public
	*/
	function getTotalRowCount() {
		if (!(preg_match("/^\s*SELECT\s+DISTINCT/is", $this->Query) && preg_match('/\s+GROUP\s+BY\s+/is',$this->Query))) {
			$rewritesql = preg_replace(
						'/^\s*SELECT\s.*\s+FROM\s/Uis','SELECT COUNT(*) FROM ',$this->Query);
			$rewritesql = preg_replace('/(\sORDER\s+BY\s.*)/is','',$rewritesql);
			$QueryId = $this->Connection->execute($rewritesql);
			$row = $QueryId->fetchRow();
			$QueryId->free();
			if (is_array($row)) {
				return $row[0];
			}
		}

		// could not re-write the query, try a different method.
		$QueryId = $this->Connection->execute($this->Query);
		$count = $QueryId->numRows();
		$QueryId->free();
		return $count;
	}
}
?>