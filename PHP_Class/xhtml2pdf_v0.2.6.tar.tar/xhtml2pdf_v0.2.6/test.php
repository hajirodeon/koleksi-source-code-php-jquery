<?php 
define('X_PATH', $_SERVER['DOCUMENT_ROOT'].'/xhtml2pdf_v0.2.6');

$pdf['author'] = 'Your name';
$pdf['name'] = 'xhtml2pdf.pdf'; // the pdf's name
$pdf['title'] = "XHTML2PDF"; // the pdf's title !!!
$pdf['chapo'] = 'A demonstration of the Xhtml2PDF Power Builder !!!'; // an short explanation of your pdf text ...
$pdf['date']['created'] = '';
$pdf['date']['modified'] = '';

include_once(X_PATH.'/classes/x2fpdf.php');
$xpdf = new xhtml2pdf (X_PATH.'/xhtml2pdf.html', X_PATH.'/test.css', $config);

$xpdf->SetTitle($pdf['title']);
$xpdf->SetAuthor($pdf['author']);
$xpdf->SetCreator('XHTML2PDF v0.2.6');
$xpdf->SetSubject($pdf['chapo']);
$xpdf->SetKeywords($keywords='');

/*** Don't Touch it ! ***/
$xpdf->WriteRights();
/*********************/

$xpdf->output($pdf['name'], 'I');
?>
