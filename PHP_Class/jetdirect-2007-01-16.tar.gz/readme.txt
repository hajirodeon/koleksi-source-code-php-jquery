
[Conversion of original C Code from 'Printer Hack 12/8/97 sili@l0pht.com']

This class provides a method to send a message string to HP printers LCD on the
network which support JetDirect.

Maybe it works on other printers on the network, maybe not.

Very easy to use - see example code for usage.

Tested on Linux - good luck on other platforms!

Have Fun ;)

2007-01-16	ultrasine@gmail.com
