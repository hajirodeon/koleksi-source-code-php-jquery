$schools=$db->getRowsWithPaging(TBL_UNI_SCHOOLS.' as s, '.TBL_COMMON_SCHOOLS.' as cs', $_REQUEST['_pno'], $_SERVER['PHP_SELF'].'?uid='.$university['uni_id'], 's.uni_id='.$university['uni_id'].' and s.common_school_id=cs.common_school_id');
if(isset($schools) && $schools->isAnyDataAvailable()){
	$schldata=$schools->get();
	foreach($schldata as $schl){
		echo '<div>'.$schl['school_title'].'</div>';
	}
	# pagination here
	echo '<p>'.$schools.'</p>';
}