<?PHP
Require "lib/border.inc";
Require "lib/list.inc";

$border = New mBorder;
// table 0
// list section
$lst = New mList;
$lst->ImageName = "images/purple1.gif";
// border section
$border->mBorder();
$border->Color = "#6B4360";
$border->Border = 2;
$border->BorderType = "P";
$border->CornerType = "A";
$border->CornerWidth = "10";
$border->CornerHeight = "10";
$border->TitleWidth = 118;
$border->TitleHeight = 20;
$border->ArrayMargins = Array(10, 10, 10, 10);
If ($tabs == 2) {
 $lst->arrayValue = Array("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday");
 //$lst->ImageName = "images/purple2.gif";
 $border->TitleName = "images/tab2.gif";
} Else {
 $lst->arrayValue = Array("Blue", "Red", "White", "Green");
 $border->TitleName = "images/tab1.gif";
}
$border->TopRightName = "images/top_right1020purple.gif";
$border->BottomLeftName = "images/bottom_left1010purple.gif";
$border->BottomRightName = "images/bottom_right1010purple.gif";
$border->MapName = "Tabs";
$border->Map =
 "<AREA SHAPE=\"RECT\" COORDS=\"1, 0, 64, 20\" HREF=\"" . $PHP_SELF . "?tabs=1\" ALT=\"Colors\">\n" .
 "<AREA SHAPE=\"RECT\" COORDS=\"65, 0, 118, 20\" HREF=\"" . $PHP_SELF . "?tabs=2\" ALT=\"Days\">\n";
$border->Value = $lst->Show();
Echo $border->ShowBorder();
Echo "&nbsp;";
Echo "\n\n\n\n\n\n";


// table 1
// list section
$lst = New mList;
$lst->ImageName = "images/red.gif";
$lst->arrayValue = Array("Blue", "Red", "White", "Green");
// border section
$border->Color = "#E6877B";
$border->Border = 2;
$border->BorderType = "P";
$border->CornerType = "N";
$border->ArrayMargins = Array(10, 10, 10, 10);
$border->Value = $lst->Show();
Echo $border->ShowBorder();
Echo "&nbsp;";
Echo "\n\n\n\n\n\n";

// table 2
// list section
$lst = New mList;
$lst->ImageName = "images/desert.gif";
$lst->arrayValue = Array("Blue", "Red", "White", "Green");
// border section
$border->mBorder();
$border->Color = "#CAC251";
$border->TableColor = "#CAC251";
$border->Border = "10";
$border->BorderType = "P";
$border->CornerType = "A";
$border->CornerWidth = 10;
$border->CornerHeight = 10;
$border->ArrayMargins = Array(0, 0, 0, 0);
$border->TopLeftName = "images/top_left1001.gif";
$border->TopRightName = "images/top_right1001.gif";
$border->BottomLeftName = "images/bottom_left1001.gif";
$border->BottomRightName = "images/bottom_right1001.gif";
$border->Value = $lst->Show();
Echo $border->ShowBorder();
Echo "&nbsp;";
Echo "\n\n\n\n\n\n";

// table 3
// list section
$lst = New mList;
$lst->ImageName = "images/green.gif";
$lst->arrayValue = Array("Blue", "Red", "White", "Green");
// border section
$border->mBorder();
$border->Color = "#69C071";
//$border->TableColor = "#69C071";
$border->Border = 2;
$border->BorderType = "P";
$border->CornerType = "A";
$border->CornerWidth = "10";
$border->CornerHeight = "10";
$border->ArrayMargins = Array(10, 10, 10, 10);
$border->TopLeftName = "images/top_left1010.gif";
$border->TopRightName = "images/top_right1010.gif";
$border->BottomLeftName = "images/bottom_left1010.gif";
$border->BottomRightName = "images/bottom_right1010.gif";
$border->Value = $lst->Show();
Echo $border->ShowBorder();
Echo "&nbsp;";
Echo "\n\n\n\n\n\n";

// table 4
// list section
$lst = New mList;
$lst->ImageName = "images/green.gif";
$lst->arrayValue = Array("Blue", "Red", "White", "Green");
// border section
$border->mBorder();
$border->Color = "#69C071";
$border->Border = 2;
$border->BorderType = "P";
$border->CornerType = "A";
$border->CornerWidth = "10";
$border->CornerHeight = "10";
$border->TitleWidth = 200;
$border->TitleHeight = 20;
$border->ArrayMargins = Array(10, 10, 10, 10);
$border->TopLeftName = "images/top_left1020.gif";
$border->TopRightName = "images/top_right1020.gif";
$border->BottomLeftName = "images/bottom_left1010.gif";
$border->BottomRightName = "images/bottom_right1010.gif";
$border->Value = $lst->Show();
Echo $border->ShowBorder();
Echo "&nbsp;";
Echo "\n\n\n\n\n\n";

// table 5
// list section
$lst = New mList;
$lst->ImageName = "images/blue.gif";
$lst->arrayValue = Array("Blue", "Red", "White", "Green");
// border section
$border->mBorder();
$border->Color = "#5E9AD2";
$border->Border = 1;
$border->BorderType = "P";
$border->CornerType = "N";
$border->CornerWidth = "10";
$border->CornerHeight = "10";
$border->ArrayMargins = Array(10, 10, 10, 10);
$border->TitleText = "&nbsp;&nbsp;Colors";
$border->TitleColor = "white";
$border->Value = $lst->Show();
Echo $border->ShowBorder();
Echo "&nbsp;";
Echo "\n\n\n\n\n\n";

// table 6
// list section
$lst = New mList;
$lst->ImageName = "images/purple.gif";
$lst->arrayValue = Array("Blue", "Red", "White", "Green");
// border section
$border->mBorder();
$border->Height = 130;
$border->Border = 5;
$border->BorderType = "B";
$border->CornerType = "N";
$border->TopImgName = "images/horizontal.gif";
$border->BottomImgName = "images/horizontal.gif";
$border->LeftImgName = "images/vertical.gif";
$border->RightImgName = "images/vertical.gif";
$border->ArrayMargins = Array(10, 10, 10, 10);
$border->Value = $lst->Show();
Echo $border->ShowBorder();
Echo "&nbsp;";
Echo "\n\n\n\n\n\n";


// table 7
// list section
$lst = New mList;
$lst->ImageName = "images/desert.gif";
$lst->arrayValue = Array("Blue", "Red", "White", "Green");
// border section
$border->mBorder();
$border->Height = 50;
$border->Border = 5;
$border->BorderType = "C";
$border->CornerType = "A";
$border->ArrayTopColors = Array("#60470C", "#89691A", "#A57E23", "#BF912B", "#CF9F31");
$border->ArrayBottomColors = Array("#CF9F31", "#BF912B", "#A57E23", "#89691A", "#60470C");
$border->ArrayLeftColors = $border->ArrayTopColors;
$border->ArrayRightColors = $border->ArrayBottomColors;
$border->CornerWidth = "5";
$border->CornerHeight = "5";
$border->TopLeftName = "images/top_left2001.gif";
$border->TopRightName = "images/top_right2001.gif";
$border->BottomLeftName = "images/bottom_left2001.gif";
$border->BottomRightName = "images/bottom_right2001.gif";
$border->Value = $lst->Show();
Echo $border->ShowBorder();

?>
