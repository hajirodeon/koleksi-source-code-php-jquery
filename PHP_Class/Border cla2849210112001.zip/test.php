<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<META HTTP-EQUIV="Expires" CONTENT="Fri, Jan 01 1900 00:00:00 GMT">
<META HTTP-EQUIV="Pragma" CONTENT="no-cache">
<META HTTP-EQUIV="Cache-Control" CONTENT="no-cache">
<META http-equiv="Content-Type" content="text/html; charset=windows-1251">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta http-equiv="content-language" content="en">
<meta name="author" content="">
<META HTTP-EQUIV="Reply-to" CONTENT="@.com">
<meta name="generator" content="PHPEd 1.80">
<META NAME="description" CONTENT="">
<meta name="keywords" content="">
<META NAME="Creation_Date" CONTENT="08/15/2000">
<meta name="revisit-after" content="15 days">
        <title>Untitled</title>
<link rel="stylesheet" type="text/css" href="my.css">
</head>
<?
echo $HTTP_SERVER_VARS;
echo sizeof($HTTP_SERVER_VARS);
for ($i=0;$i<sizeof($HTTP_SERVER_VARS);$i++) {
 Echo next($HTTP_SERVER_VARS) . "<BR>";
}
?>
<table width=500-100 border=1>
<tr>
<td>
tablica testowa
</td>
</tr>
</table>

<body>

</body>
</html>