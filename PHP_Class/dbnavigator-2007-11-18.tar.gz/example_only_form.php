<?php session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>DBNavigator class - only Form</title>
<style type="text/css" media="screen">
	@import "style.css";
</style>
</head>
<body>
<?php

/*
EXAMPLE: how build a form for inserting (or editing) a row in a database

This example try to show major functionalities of DBNavigator class

Enjoy :)

Michele Castellucci
castellucci@cottonbit.it
http://www.direfareprogrammare.com
*/

require("HTMLForm.php");
require("PageNavigator.php"); 
require("DBNavigator.php");  	
require("functions.inc.php");
  
////CONFIG
$images_path_for_textarea_absolute='http://www.XXX.com';
$images_path_for_textarea_relative='.';

mysql_connect('localhost',"username","userpassword");
mysql_select_db("dbname");
//////////


$DBNUsers=new DBNavigator("
						SELECT users.id, users.name, users.surname, users.password, users.email, users.gender,
							   provinces.name AS province, provinces.region,
							   users.birth_date, users.profession, users.notes, users.curriculum, users.photo_1, users.photo_2, users.attachment								   								   
						FROM users 
								   LEFT JOIN provinces ON provinces.id=users.province_id  ");

//layout options 
$DBNUsers->setClassForFormInput('mini','mini_btn','mini_txa');
/////

$DBNUsers->setPrimaryTable("users");
$DBNUsers->setLanguage('english');
$DBNUsers->setDateInterval(date('Y')-90,date('Y'));

$DBNUsers->setHTMLTextareaParams(array('imagesPath'=>array('absolute'=>$images_path_for_textarea_absolute,
														   'relative'=>$images_path_for_textarea_relative),
									   'fontSize'=>true,
									   'selectFont'=>true));

$DBNUsers->setPhotoField(array('photo_1','photo_2'),100,true);
$DBNUsers->setPasswordField("password");
$DBNUsers->setFileField("attachment");
$DBNUsers->setMailField("email");
$DBNUsers->setFilePath("."); 


$DBNUsers->editForm->addInput("hidden","inserting_date",date("Y-m-d H:i:s"));

$DBNUsers->setFormHeading("<em style=\"font-size:18px;color:#D11\">Please fill this form for registration</em>");

function emailNotification() {
mail("castellucci@cottonbit.it","New user registration","User named <strong>{$_POST['name']} {$_POST['surname']}</strong> has been registered","Content-Type: text/html; charset=utf-8");
}

$DBNUsers->editForm->addVerificationCode("Write what you see..",'mini',"This is a <strong>CAPTCHA</strong> system..for security");

//after you see the example, try to use an existent id number as first argument of this function
$DBNUsers->go_only_for_form('here a non existent id value for a record insertion'
							,"<h1>You have been successfully inserted in the Database !</h1><a href=\"{$_SERVER['PHP_SELF']}\">Want to insert another one!??</a>"
							,'emailNotification');

?>
</body>
</html>