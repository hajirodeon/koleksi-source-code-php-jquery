<?php

/**
  *	@author Michele Castellucci <castellucci@cottonbit.it>
  *
  * questo file contiene la classe HTMLForm, la classe Adv_TextArea e 3 funzioni esterne
  */

		define("REGEXP_NOTNULL","/^(.|\\n|\\r|\\r\\n)+$/"); //vale per le text e le textarea (ritorni a capo)
		define("REGEXP_NUMREAL","/^-{0,1}((\d{1,})|(\d{1,}\.\d{1,}))$/");
		define("REGEXP_NUMINT","/^-{0,1}\d{1,}$/");
		define("REGEXP_DATE","/^\d{2}\/\d{2}\/\d{4}$/");
		define("REGEXP_EMAIL","/^.{1,}@.{1,}\..{1,}$/");		
		define("REGEXP_IMAGE","/^.+\.((gif)|(jpg)|(png))$/");
		define("REGEXP_FILE","/^.+\..{2,4}$/");	
		
/** 
 *	Questo metodo consente di inserire sulla tabella $table i dati contenuti nell'array globale $_POST e $_FILES, per ogni
 *	campo presente su $table. Il metodo proverà a costruire una query SQL di inserimento o modifica a prescindere dal valore di
 *	$_POST['edit_'.$table]. Per una documentazione più dettagliata consultare HTMLForm.doc
 */		
 
 
function insertIntoDBFromPOST($table,$submit_button,$primaryKey='id',$fileSavePath="uploaded_files",$resizeImg=false,$keepOriginal=false)
{
	if (!isset($_POST[$submit_button]))  return 0; else unset($_POST[$submit_button]);
/*	echo"<pre>";
	print_r($_POST);
	echo "</pre><br /><br />";*/
	

	if (!isset($_POST['edit_'.$table]) || $_POST['edit_'.$table]=='0') //oppure la chiave primaria è una stringa... 
	$edit=0; else $edit=1;
	//unset($_POST['edit_'.$table]);
	
	
	$query=$edit==1?"UPDATE $table SET ":"INSERT INTO $table {{{}}} VALUES {{{}}}";
	
	//print_r($_FILES);

	
	foreach($_POST as $nome=>$valore)
	{	
		if ($valore=='ignore_this_post') continue;
		if ($nome==$primaryKey) continue;

		if (substr($nome,strlen($nome)-4,4)=="_day") {$data_generica=$valore;continue;}
		if (substr($nome,strlen($nome)-4,4)=="_mon") {$data_generica=$valore."-".$data_generica;continue;}
		if (substr($nome,strlen($nome)-4,4)=="_yea") {$valore=$valore."-".$data_generica; $nome=substr($nome,0,strlen($nome)-4);}
			
		if (is_array($valore)) //set 
		$valore=implode(",",$valore);
			
		if ($nome=="verification_code" && $_SESSION['verification_string']!=$valore) return array("wrong_vercode",$nome);//codice di verifica errato
					
					
		if (substr($nome,0,7)=="verify_") //verifica via php della compilazione dei campi
		{
			$field_to_verify=substr($nome,7);//campo da verificare
			
			/*echo "<pre>".print_r($_POST,true)."</pre>";*/
			
			if (!isset($_POST[$field_to_verify]) && !isset($_FILES[$field_to_verify])) //si tratta della data che è divisa in 3 POST oppure di enum che non effettua il submit
			{
				if (isset($_POST[$field_to_verify."_day"]))//data
				$_POST_field_to_verify=$_POST[$field_to_verify."_day"]."/".$_POST[$field_to_verify."_mon"]."/".$_POST[$field_to_verify."_yea"];
				else 
				if (isset($_POST[$field_to_verify."_ifr"]))//iframe
				$_POST_field_to_verify=$_POST[$field_to_verify."_ifr"];
				else //ENUM e SET
				return array('format_conflict',$field_to_verify);
			}
			else
			if (isset($_POST[$field_to_verify])) 
			$_POST_field_to_verify=$_POST[$field_to_verify];
			else
			if (isset($_FILES[$field_to_verify])) 
			$_POST_field_to_verify=$_FILES[$field_to_verify]['name'];
			
			$valore=stripslashes($valore);
			
			if ($valore==1) $valore=REGEXP_NOTNULL; //
		
			//controllo valori
			if ($valore===REGEXP_NOTNULL)
			{
				if (trim(strip_tags($_POST_field_to_verify))!="")
				$ok=true;
				else $ok=false;
			}
			else
			if (preg_match($valore,strtolower($_POST_field_to_verify))==1)
			$ok=true;
			else
			$ok=false; 
			
			if ($ok==true) continue; else 
			//die ($field_to_verify."---".$_POST_field_to_verify);
			return array('format_conflict',$field_to_verify);
			
		}
		
		if (substr($nome,strlen($nome)-4,4)=="_ifr")
		{ 
			$nome=substr($nome,0,strlen($nome)-4);
			$valore=str_replace("\n"," ",$valore); //elimina carattere di ritorno a capo
			$valore=str_replace("\r","",$valore); //elimina carattere di ritorno a capo
			$valore=str_replace("<P>","",$valore);
			$valore=str_replace("</P>","",$valore);	
			$valore=str_replace("<BR>","<br />",$valore);
			$valore=str_replace("<br>","<br />",$valore);		
			$valore=str_replace("STRONG>","strong>",$valore);
			$valore=str_replace("EM>","em>",$valore);
			$valore=str_replace("UL>","ul>",$valore);
			$valore=str_replace("LI>","li>",$valore);
			$valore=str_replace("U>","u>",$valore);
			$valore=str_replace("A>","a>",$valore);
			$valore=str_replace("<A","<a",$valore);
			$valore=str_replace("onclick=window.open(this.href);return false","onclick=\"window.open(this.href);return false\"",$valore);
			$valore=autochiudi_tag("img",$valore);
			$valore=autochiudi_tag("br",$valore);
			$valore=autochiudi_tag("IMG",$valore);
			$valore=autochiudi_tag("BR",$valore);
			$valore=autochiudi_tag("hr",$valore);
			$valore=autochiudi_tag("HR",$valore);
		}
		else
		{			
			//$valore=str_replace('"',"'",$valore);
			//$valore=str_replace("\n","<br />",$valore);	
			
			//SOSTITUZIONE CARATTERI PARTICOLARI
			//(&) -in visualizzazione deve essere scritta &amp;
			//    -in modifica deve essere scritta &amp; (per scrivere letteralmente "&amp;" bisogna avere "&amp;mp;")
			//    -quindi viene memorizzato come &amp;
			$valore=str_replace("&","&amp;",$valore);
			//(>) -in visualizzazione deve essere scritta &gt;
			//    -in modifica (textbox) deve essere scritta &gt;
			//    -quindi viene memorizzato come &gt;
			//	lo stesso vale per (<)
			$valore=str_replace(">","&gt;",$valore);
			$valore=str_replace("<","&lt;",$valore);				
			//(") -in visualizzazione può essere scritto " o &quot; 
			//    -in modifica deve essere scritta &quot;
			//     ma sulle textarea però può anche essere scritta "
			//    -quindi viene memorizzato come " e rimpiazzato in &quot; solo in fase di modifica
			// si potrebbe memorizzare qui solo &quot; ma per maggiore flessibilità non si fa
			
			//tutte queste considerazioni non valgono per la textarea con IFRAME che gestisce tutto autonomamente 
			
			//QUESTE SOSTITUZIONI VENGO APPLICATE ANCHE IN FASE DI RICERCA NEL DBNAVIGATOR - funzione convertSpecialChars!!! 
			//PER TROVARE I CARATTERI EFFETTIVAMENTE MEMORIZZATI
		}
			


//////////////////////////////////////////CHECK COLUMN EXISTENCE
		$founded=false;
		
		$result=mysql_query("DESCRIBE $table");  	
		while ($row=mysql_fetch_array($result))
		{
		
			if ($row['Field']==$nome || strpos($nome,'delete_')!==false) //..
			{
				$founded=true;
								
			    if ($row['Key']=="UNI") //controllo chiavi uniche
				{
					if (is_array($_POST[$primaryKey])) return array('query_error',"Si è inviato un input di un campo univoco in un form di modifica di più record");
					
					//controllo se esiste un record con un campo con lo stesso valore
					$result2=mysql_query("SELECT * FROM {$table} WHERE {$primaryKey}!='".$_POST[$primaryKey]."' AND {$nome}=\"{$valore}\"") 
							 or die ('errore controllo univocità '.mysql_error());	
					if (mysql_num_rows($result2)>0) return array('key_conflict',$nome);	
				}
				
				break;			
		 	  }		
	 	 }	
		  
		if ($founded==false) continue; //se non c'è un campo della tabella con nome=al post allora ignora il post MANCA SU _FILES
///////////////////////////////////////////////////////////////

		if ($edit==1) //query di aggiornamento
		{	
		
			if (strpos($nome,'delete_')!==false) //ELIMINA FILE CORRENTE
			{
				if (is_array($_POST[$primaryKey])) return array('query_error',"Si è inviato un input di eliminazione file in un form di modifica di più record");
				
				$nome=substr($nome,7,strlen($nome));
				$valore="";
				//echo "-->".$nome."<--";
				$row=mysql_fetch_array(mysql_query("SELECT $nome FROM $table WHERE $primaryKey='{$_POST[$primaryKey]}'"));
				if ($row[$nome]!="" && file_exists($fileSavePath."/".$row[$nome]))
				{
					
					unlink($fileSavePath."/".$row[$nome]); //elimina il file
					if (file_exists($fileSavePath."/small_".$row[$nome])) unlink($fileSavePath."/small_".$row[$nome]); //se è un'immagine elimina anche quella piccola
				}			
			}

			if ($nome==$primaryKey) continue;
			$query.="`$nome`='$valore', ";
			
					
		}
		else //query di inserimento
		{
			//die('ciao');
			if ($nome==$primaryKey && (int)($_POST[$primaryKey])) $valore=""; //se la chiave primaria è intera mettila a '' per fare l'autoincrement
			
			$exp=explode("}}}",$query);
			$exp[0].="`".$nome."`,";
			$exp[1].="'".$valore."',";
			$query=implode("}}}",$exp);
			
		}
	}
	
	if (!is_array($_POST[$primaryKey])) //non si assegnano più file ad un record
	foreach ($_FILES as $nome=>$file)
	{
		//print_r($_FILES);
		//die('');
		if ($file['error']==1) return array('file_too_big',$nome);	

		if (!$file['size']>0) continue;	
		$file['name']=str_replace(array('"',"'"," ","&"),"_",stripslashes($file['name'])); //sostituisce i caratteri non ammessi con _



		if (!file_exists($fileSavePath)) mkdir($fileSavePath,0777); //CREA LA DIRECTORY PER SALVARE I FILE
		
		
		
		$result=mysql_query("SELECT $nome FROM $table WHERE $primaryKey!='{$_POST[$primaryKey]}'");	
		while ($row=mysql_fetch_array($result))
		{
			//controllo se esiste un record con un file collegato con lo stesso nome
			if ($row[$nome]==$file['name']) return array('file_conflict',$nome);
		}
				
		if ($edit==1) //query di aggiornamento
		{
			if ($nome==$primaryKey) continue;
			$row=mysql_fetch_array(mysql_query("SELECT $nome FROM $table WHERE $primaryKey='{$_POST[$primaryKey]}'"));
			if ($row[$nome]!="" && file_exists($fileSavePath."/".$row[$nome]))
			{
				unlink($fileSavePath."/".$row[$nome]); //elimina il file precedente
				if (file_exists($fileSavePath."/small_".$row[$nome])) unlink($fileSavePath."/small_".$row[$nome]); //se è un'immagine elimina anche quella piccola
			}
			$query.="$nome='{$file['name']}', ";		
		}
		else //query di inserimento
		{
			if ($nome==$primaryKey && (int)($_POST[$primaryKey])) $valore=""; //se la chiave primaria è intera mettila a '' per fare l'autoincrement
			$exp=explode("}}}",$query);
			$exp[0].="`".$nome."`,";
			$exp[1].="'".$file['name']."',";
			$query=implode("}}}",$exp);
		}
			
	}	
	
	foreach ($_FILES as $nome=>$file)//copia fisica dei file per evitare upload inutili
	{
		if (!$file['size']>0) continue;	
		$file['name']=str_replace(array('"',"'"," ","&"),"_",stripslashes($file['name'])); //sostituisce i caratteri non ammessi con _
			
		$ext=strtolower(substr($file['name'],(strlen($file['name'])-4),4)); //prende le ultime 4 lettere
		
		if ($resizeImg && ($ext==".gif" || $ext==".jpg" || $ext==".png"))
		{
			resize_img($file['tmp_name'],$resizeImg,$resizeImg,$fileSavePath."/small_".$file['name'],$ext);
		}
		if (($resizeImg && $keepOriginal) || !$resizeImg) copy($file['tmp_name'],$fileSavePath."/".$file['name']);		
	}	
	
	
	// ELIMINA LE VIRGOLE FINALI
	if ($edit==1)
	{
		if ($query=="UPDATE $table SET ") //nessuna modifica ai campi
		return 1;
		else
		{
			if (is_array($_POST[$primaryKey]))
			{
				foreach($_POST[$primaryKey] as $id)
				$cond[]="{$primaryKey}=\"{$id}\"";
				
				$cond=implode (" OR ",$cond);
			}
			else
			$cond="`$primaryKey`='{$_POST[$primaryKey]}'";
		
			$query=substr($query,0,strlen($query)-2);
			$query.=" WHERE ".$cond;
		}
	}
	else
	{
		$exp=explode("}}}",$query);
		$exp[0]=substr($exp[0],0,count($exp[0])-2);
		$exp[1]=substr($exp[1],0,count($exp[1])-2);
		$query=implode(")",$exp);
		$query=str_replace("{{{","(",$query);
	}
	//////

/*	print_r($_POST);

	die($query);*/

	$executeQuery=false;

	if (!mysql_query($query)) //le 2 condizioni finali servono x query "vuote" (senza campi) 
	{
	
		//echo "ERRORE QUERY: ".$query;		
		return array('query_error',mysql_error()."($query)");
	} else return 1;	
}

/**
 * Questa funzione ridimensiona l'immagine con percorso $pathimage con formato $ext (estenzione) alle dimensioni $new_sizex, $new_sizey e salva l'immagine 
 * redimensionata sul percorso $dest_file. 
 */

	function resize_img($pathimage, $new_sizex, $new_sizey, $dest_file,$ext) 
	{
	  $imagename = $pathimage;
	  if(file_exists($pathimage)) 
	  {
		
		switch ($ext)
		{
			case '.jpg':$pic = imagecreatefromjpeg($pathimage); break;
			case '.gif':$pic = imagecreatefromgif($pathimage); break;
			case '.png':$pic = imagecreatefrompng($pathimage); break;							
		}
		
		$sizex = imagesx($pic) ;
		$sizey = imagesy($pic) ;
		if (($sizex > $new_sizex) || ($sizey > $new_sizey) ) 
		{
			
				if($sizex>$sizey) 
				{ 
					$s0x = $new_sizex ;
					$s0y = (($new_sizex * $sizey)/$sizex) ;
					settype ($s0y, "integer")  ;
				} 
				 else
				if ($sizex<$sizey) 
				{
					$s0y = $new_sizey ;
					$s0x = (($new_sizey * $sizex)/$sizey) ;
					settype ($s0x, "integer")  ;
				} else 
				{
						$s0x = $new_sizex ;
						$s0y = $new_sizey ;
				}
			 
			 $gd_info=gd_info();
			 
			if(strstr($gd_info['GD Version'],"2.")) ///mmmmmmhhh....... 
			{
				$out = imagecreatetruecolor( $s0x, $s0y) ;
				imagecopyresampled ($out, $pic, 0, 0, 0, 0, $s0x, $s0y, $sizex, $sizey) ;
			}else 
			{
				$out = imagecreate( $s0x, $s0y) ;
				imagecopyresized($out, $pic, 0, 0, 0, 0, $s0x, $s0y, $sizex, $sizey) ;
			}
			
			switch ($ext)
			{
				case '.jpg':$pic = imagejpeg($out, $dest_file,100); break;
				case '.gif':$pic = imagegif($out, $dest_file) ; break;
				case '.png':$pic = imagepng($out, $dest_file) ; break;							
			}
			
			//imagedestroy($pic);
			imagedestroy($out); 
			return 1 ;
		} else //
		{
			copy($pathimage, $dest_file) ;
			return 1;
		}
	  } else //!file_exists
	  {
		return 0 ;
	  }
	}

	
		
/**
  * Questa classe consente di costruire 
  *	un form XHTML accessibile con metodi avanzati di validazione dati Javascript. Il form costruito è inserito in una tabella di 2 colonne.		
  */
  		
class HTMLForm
{
	/**
  	* Contiene il codice XHTML del form creato 
  	* @var string    	
	*/
	var $result="";
	/**
  	* nome del form
	* @var string 
  	*/	
	var $name;
	/**
  	* La largezza della prima colonna della tabella del form
  	* @var int 
	*/		
	var $width1;
	/**
  	* La largezza della seconda colonna della tabella del form
  	* @var int 
	*/		
	var $width2;	
	/**
  	* Contiene il codice JavaScript di validazione del form
  	* @var string 
	*/		
	var $validateFunction="";
	/**
  	* Array contenente come indici i nomi di tutti gli input inseriti
 	* @var array  
  	*/	
	var $input=array();
	/**
  	* Distanza orizzontale tra un input e il successivo, in poche parole l'altezza della riga vuota tra 2 input
  	* @var int 
	*/		
	var $horizSpace;
	/**
  	* Booleano che indica se i paramentri iniziali sono stati reimpostati dopo l'istanziamento della classe
  	* @var boolean 
	*/			
	var $params_redefined=false;

	/**
  	* Contiene il codice XHTML del form creato da aggiungere in coda. 
  	* @var string    	
	*/				
	var $result_end="";
	/**
  	* Contiene il codice JavaScript di validazione del form da aggiungere in coda
  	* @var string 
	*/		
	var $validateFunction_end="";
	/**
  	* Contiene il nome dell'input focalizzato
  	* @var string 
	*/		
	var $focused_field="";
	/**
  	* Contiene il messaggio abbinato all'input focalizzato
  	* @var string 
	*/		
	var $focused_msg="";
	/**
  	* Contiene un booleano che indica se visualizzare i label degli input e gli input su una nuova riga
  	* @var boolean 
	*/		
	var $ever_new_line=false;
	/**
  	* Contiene la lingua con cui si stampa il form
  	* @var string 
	*/		
	var $lang=array();
	/**
  	* Contiene un booleano che indica se le funzioni comuni di Adv_TextArea sono state già stampate
  	* @var boolean 
	*/		
			
	var $Adv_TextArea_common_javascript_functions_PRINTED=false;
	/**
		Definisce $field (aggiunto o da aggiungere tramite addInput ) come un campo ‘focused’ ovvero come un campo in cui è impostato automaticamente il focus. Inoltre inserisce $msg sulla riga di spaziatura della tabella situata sopra l’input.
		Il focus e l’inserimento del messaggio vengono effettuati tramite una funzione javascript associata all’evento onload della finestra. Il javascript viene aggiunto ALLA FINE di tutto l’output generato da HTMLForm.  
	*/		
	
	
	var $removeServerValidation='';
	
	function setFocused($field,$msg)
	{
		$this->focused_field=$field;
		$this->focused_msg=$msg;
	}
	
	/** Imposta la lingua dei testi del form */
	function setLanguage($lang)
	{
		$lang=strtolower($lang);
		$this->lang['languageName']=$lang;
		
		if ($lang=='english')
		{
			$this->lang['insertPassword']="Insert new password";
			$this->lang['passwordsDifferent']="Inserted passwords are different";
			$this->lang['authorizeTreatment']="You must authorize personal data treatment";
			$this->lang['insertVerifyCode']="You must insert verify code";	
			$this->lang['day']="day";
			$this->lang['month']="month";
			$this->lang['year']="year";
			$this->lang['old']="Old";
			$this->lang['rewrite']="Rewrite";
			$this->lang['new']="New";
			$this->lang['missingInformation']="Missing information";
			$this->lang['notValidNumber']="This is not a valid number";
			$this->lang['notValidInt']="This is not a valid int number";
			$this->lang['notDate']="This is not a date";
			$this->lang['notValidEmail']="This is not a valid E-mail address";
			$this->lang['notImage']="Selected file is not an image";
			$this->lang['notFile']="Selected file is not valid";	
			$this->lang['incompleteInformation']="Incomplete information";
			$this->lang['deleteCurrent']="Delete current";	
			$this->lang['selectAnOption']="Select an option";													
			$this->lang['selectTheOption']="Select the option";	
			$this->lang['selectTheOption']="Select at least one option";														
			
					
		}else
		{
			$this->lang['insertPassword']="Inserire la nuova password";
			$this->lang['passwordsDifferent']="Le password inserite sono differenti";
			$this->lang['authorizeTreatment']="Devi autorizzare il trattamento personale dei dati";	
			$this->lang['insertVerifyCode']="Devi inserire il codice di verifica";
			$this->lang['day']="giorno";
			$this->lang['month']="mese";
			$this->lang['year']="anno";
			$this->lang['old']="Vecchia";
			$this->lang['rewrite']="Riscrivi";
			$this->lang['new']="Nuova";
			$this->lang['missingInformation']="Informazione mancante";
			$this->lang['notValidNumber']="Il valore inserito non è un numero";
			$this->lang['notValidInt']="Il valore inserito non è un numero valido";
			$this->lang['notDate']="Il valore non è una data";
			$this->lang['notValidEmail']="Il valore inserito non è un indirizzo E-mail valido";
			$this->lang['notImage']="Il file selezionato non è una immagine";
			$this->lang['notFile']="Il file selezionato non è valido";	
			$this->lang['incompleteInformation']="Informazione incompleta";
			$this->lang['deleteCurrent']="Elimina corrente";
			$this->lang['selectAnOption']="Selezione una opzione";													
			$this->lang['selectTheOption']="Seleziona l'opzione";	
			$this->lang['selectOneOption']="Seleziona almeno una opzione";												
			
		}
	}
	
	/**
  	* Definisce i parametri generali del form, VEDI COSTRUTTORE
	*/		
	function defineParams($name,$target,$width1,$width2,$summary="",$method="post",$horizSpace=14,$ever_new_line=false)
	{
		if (!$this->params_redefined) //può ridefinire i paramentri solo una volta
		{
			$this->ever_new_line=$ever_new_line;
			$this->horizSpace=$horizSpace;
			$this->name=$name;
			$this->width1=$width1;
			$this->width2=$width2;
			
			$begin="<form method=\"$method\" action=\"$target\" id=\"$name\" enctype=\"multipart/form-data\">
			<table  summary=\"$summary\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" style=\"width:".($width1+$width2)."%\" >";
			
			$this->result=substr($this->result,strpos($this->result,'%" >')+4); //elimina il tag form e table
			$this->result=$begin.$this->result;
			$this->params_redefined=true;
		}
	}		
	/*
	 *	Costruttore della classe: $width1 e $width2 sono la larghezza delle 2 colonne della tabella in percentuale. 
	 *	$horizSpace è il valore in pixel della distanza inserita tra un input ed un altro.
	 *	La spaziatura avviene ad ogni esecuzione del metodo addInput() inserendo una riga vuota della tabella, a tale riga viene associato un id che consenta di poterla identificare per inserire un messaggio su un input impostato a ‘focused’: vedi metodo setFocused() .
	*/
	function HTMLForm($name,$target,$width1,$width2,$summary="",$method="post",$horizSpace=14,$ever_new_line=false)
	{
		$this->ever_new_line=$ever_new_line;
		$this->horizSpace=$horizSpace;
		$this->name=$name;
		$this->width1=$width1;
		$this->width2=$width2;
		$this->result="<form method=\"$method\" action=\"$target\" id=\"$name\" enctype=\"multipart/form-data\">
		<table  summary=\"$summary\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" style=\"width:".($width1+$width2)."%\" >";
		$this->setLanguage("italiano");
	}
	
	/*
 	 *	Aggiunge alla tabella del form una cella con testo $text arbitrario.
 	 */	
	function addExternalContent($text,$at_end=false)
	{
		if ($at_end)
		$this->result_end.="<tr><td colspan=\"2\" style=\"height:".$this->horizSpace."px;\"></td></tr>
							<tr><td colspan=\"2\">{$text}</td></tr>";
		else
		$this->result.="<tr><td colspan=\"2\" style=\"height:".$this->horizSpace."px;\"></td></tr>
						<tr><td colspan=\"2\">{$text}</td></tr>";
	}	
	
	/*
 	 *	Aggiunge alla tabella del form una cella con testo $text arbitrario.
 	 */	
	function addExternalValidation($js,$at_end=false)
	{
		if ($at_end)
		$this->validateFunction_end.=$js;
		else
		$this->validateFunction.=$js;
	}		
	
	/*
	 *	aggiunge al form una textarea (semplice) non editabile contenente il testo $law (tipicamente l’attuale legge sulla privacy) e una checkbox con validazione di tipo NOT_NULL con intestazione ($heading).
	 */
	function addPrivacyInput($law,$heading,$class="")
	{
		$class=$class==""?"":"class=\"$class\"";
		$this->result_end.="
		<tr>
			<td colspan=\"2\" style=\"width:".($this->width1+$this->width2)."%\" >
				<label for=\"%frmName%_privacy_textarea\"></label>
				<br /><textarea id=\"%frmName%_privacy_textarea\" $class readonly=\"readonly\" style=\"width:".($this->width1+$this->width2)."%;height:100px\" cols=\"0\" rows=\"0\">$law</textarea>
			</td>
		</tr>
		<tr>
			<td colspan=\"2\" style=\"width:".($this->width1+$this->width2)."%\" >
				<input type=\"checkbox\" name=\"%frmName%_privacy_checkbox\" id=\"%frmName%_privacy_checkbox\" value=\"ignore_this_post\" />
				<label for=\"%frmName%_privacy_checkbox\"><strong>$heading</strong></label><br />
			</td>
		</tr>	
			";
	
		$this->validateFunction_end.="if ( document.getElementById('%frmName%').%frmName%_privacy_checkbox.checked==false) 
					{alert('{$this->lang['authorizeTreatment']}'); document.getElementById('%frmName%').%frmName%_privacy_checkbox.focus(); return false;}
					";
	}
	/*
 	 *  aggiunge 2 password input con validazione di tipo NOT_NULL e una aggiuntiva validazione che verifica che il contenuto del primo input sia uguale a quello del secondo. Il nome del primo input è naturamente $name, quello del secondo “{$name}_retyped” (questo dato è chiaramente inutile quindi in fase di ricezione dati deve essere eliminato)
 	 */
	function addInsertPasswordInputs($name,$heading="",$class="")
	{
		$this->addInput("password",$name,"",$heading,false,false,true,$class);
		$this->addInput("password",$name."_retyped","",$this->lang['rewrite']." ".$heading,false,false,true,$class);
		
	$this->validateFunction.="
		if ( document.getElementById('%frmName%').{$name}.value!=document.getElementById('%frmName%').{$name}_retyped.value  ) 
		{
			document.getElementById('%frmName%').{$name}.focus();
			alert(\"{$this->lang['passwordsDifferent']}\");
			return false;	
		}";
	}
	
	/*
	 *	aggiunge 3 password input “{$name}_old” , $name, “{$name}_retyped” (la vecchia password, la nuova password, la nuova password ridigitata) che permettono di modificare facoltativamente la password. Vengono inserite 2 validazioni: 
	 *	La prima effettua validazione di tipo NOT_NULL sulla nuova password, solo se si è inserito un valore per la vecchia password.
	 *	La seconda verifica che la nuova password sia uguale a quella ridigitata
	 *	sempre se si è inserito un valore per la vecchia password.	
	 */
	function addChangePasswordInputs($name,$heading="",$class="")
	{
		$this->addInput("password",$name."_old","",$this->lang['old']." ".$heading,false,false,false,$class);
		$this->addInput("password",$name,"",$this->lang['new']." ".$heading,false,false,false,$class);
		$this->addInput("password",$name."_retyped","",$this->lang['rewrite']." ".$heading,false,false,false,$class);
	
		
	$this->validateFunction.="
	
		if ( document.getElementById('%frmName%').{$name}_old.value!='' && 
			document.getElementById('%frmName%').{$name}.value==document.getElementById('%frmName%').{$name}_retyped.value  &&
			document.getElementById('%frmName%').{$name}.value==''
			) 
		{
			document.getElementById('%frmName%').{$name}.focus();
			alert(\"{$this->lang['insertPassword']}\");
			return false;	
		}
	
		if ( document.getElementById('%frmName%').{$name}_old.value!='' && document.getElementById('%frmName%').{$name}.value!=document.getElementById('%frmName%').{$name}_retyped.value  ) 
		{
			document.getElementById('%frmName%').{$name}.focus();
			alert(\"{$this->lang['passwordsDifferent']}\");
			return false;	
		}";
	
	}

	/*
	 *	aggiunge 3 password input “{$name}_old” , $name, “{$name}_retyped” (la vecchia password, la nuova password, la nuova password ridigitata) che permettono di modificare facoltativamente la password. Vengono inserite 2 validazioni: 
	 *	La prima effettua validazione di tipo NOT_NULL sulla nuova password, solo se si è inserito un valore per la vecchia password.
	 *	La seconda verifica che la nuova password sia uguale a quella ridigitata
	 *	sempre se si è inserito un valore per la vecchia password.	
	 */
	function addChangePasswordInputsWithoutOldPassword($name,$heading="",$class="")
	{
		$this->addInput("password",$name,"",$this->lang['new']." ".$heading,false,false,false,$class);
		$this->addInput("password",$name."_retyped","",$this->lang['rewrite']." ".$heading,false,false,false,$class);
	
		
	$this->validateFunction.="
	
		if ( 
			document.getElementById('%frmName%').{$name}.value!=document.getElementById('%frmName%').{$name}_retyped.value  &&
			(document.getElementById('%frmName%').{$name}.value!='' || document.getElementById('%frmName%').{$name}_retyped.value!='')
			) 
		{
			document.getElementById('%frmName%').{$name}.focus();
			alert(\"{$this->lang['passwordsDifferent']}\");
			return false;	
		}
		";
	
	}

	/*
	 *	aggiunge un input testuale con intestazione $heading e classe del foglio di stile $class ed una immagine contenente un codice di verifica. 
	 *	Tale POST verrà controllato dal metodo insertIntoDBFromPost per controllare
	 *  che il valore inserito sia uguale al codice generato, contenuto nella variabile di sessione $_SESSION['verification_string'].
	 *  L'immagine contenente il codice di verifica è generata dal file verimage.php
	 */

	function addVerificationCode($heading="",$class="",$otherHTML="")
	{
		if ($class!="") $class="class=\"{$class}\"";
		if ($otherHTML!="") $otherHTML="<br />{$otherHTML}";
	
		if (file_exists("verimage.php")) //cartella corrente dello script
			$path="verimage.php";
		else 
		if (file_exists("classes/verimage.php")) //cartella corrente dello script
			$path="classes/verimage.php";
		else 
		if (file_exists("../classes/verimage.php")) //cartella superiore dello script
			$path="../classes/verimage.php";
		else 
		if (file_exists("writein3/classes/verimage.php")) //cartella del writein
			$path="writein3/classes/verimage.php";

		$this->result_end.="
		<tr>
			<td colspan=\"2\" style=\"height:".$this->horizSpace."px;\" id=\"verification_code_message\">
			
			</td>
		</tr>
		<tr>
			<td style=\"width:".$this->width1."%\" >
				<label for=\"verification_code\"><strong>$heading</strong></label>
			</td>
			<td style=\"width:".$this->width2."%\">	
				<img src=\"".$path."\" alt=\"codice di verifica\" style=\"vertical-align:bottom;border:1px solid #FF0000;\" />
				<input id=\"verification_code\" name=\"verification_code\" $class style=\"width:50%\" />
				{$otherHTML}
			</td>
		</tr>
			";
			
		$this->validateFunction_end.="
		if ( document.getElementById('%frmName%').verification_code.value=='') 
			{
				alert('{$this->lang['insertVerifyCode']}'); 
				document.getElementById('%frmName%').verification_code.focus(); 
				return false;
			}";			
	}	
		
	/*
 	 * Aggiunge un input al form, VEDI HTMLForm.doc per spiegazione dettagliata
 	 */
	function addInput($inputType,$name,$value,$heading="",$bool=false,$selected=null,$validate=false,$class="",$at_end=false)
	{
		$inputType=strtoupper($inputType);
		
		$result="";
		$validateFunction="";
		

		if (!isset($this->input[$name]) || substr($name,-2,2)=="[]")
		{
			$this->input[$name]='yes';
			if ($class!="") $class="class=\"$class\"";
			
			
		//if ($name==$this->focused_field) $heading="<span style=\"color:#FF0000\">&raquo;&raquo;</span> <em>".$heading."</em>";	
			
			
			if ($inputType!="TEXTAREA") //le virgolette possono restare così in modifica nelle textarea's
			{
				///SOSTITUZIONE " con &quot;				
				if (is_array($value))
				{			
					$oldValue=$value;
					$value=array();
					foreach ($oldValue as $key=>$val)
					$value[str_replace("\"","&quot;",$key)]=str_replace("\"","&quot;",$val);
				}
				else $value=str_replace("\"","&quot;",$value);

				if (is_array($selected))
				{				
					$oldSelected=$selected;
					$selected=array();
					foreach ($oldSelected as $key=>$val)
					$selected[str_replace("\"","&quot;",$key)]=str_replace("\"","&quot;",$val);
				}
				else $selected=str_replace("\"","&quot;",$selected);
			}	


			if ($inputType=="TEXTAREA" && ( (is_array($bool) && count($bool>0)) || $bool===true)) //bool indica la textarea avanzata	
			{
				$inputType="ADV_TEXTAREA";
				$this->validateFunction.="save_iframe_text('{$name}');  ";  //SALVATAGGIO DATI IFRAME	
			}


			if ($inputType!="HIDDEN")
			{ 
				if ($name==$this->focused_field)
				{
					$focused_msg_style="color:#FF0000;padding:6px 0px 6px 0px;";
					$focused_input_style="border:1px solid #FF0000";
					$focused_msg=$this->focused_msg;
				}
				else
				{ 
					$focused_msg_style="";
					$focused_input_style="";
					$focused_msg="";
				}
				
				$result.="
				<tr>
					<td colspan=\"2\" style=\"height:".$this->horizSpace."px;{$focused_msg_style}\" id=\"{$name}_message\">
						{$focused_msg}
					</td>
				</tr>"; //aggiunge una riga vuota 
			}
	
	
			if ($inputType=="DATE")
			{
				$is_day_empty="(document.getElementById('%frmName%').{$name}_day.disabled=='' && document.getElementById('%frmName%').{$name}_day.value=='')";
				$is_mon_empty="(document.getElementById('%frmName%').{$name}_mon.disabled=='' && document.getElementById('%frmName%').{$name}_mon.value=='')";
				$is_yea_empty="(document.getElementById('%frmName%').{$name}_yea.disabled=='' && document.getElementById('%frmName%').{$name}_yea.value=='')";
				
				$is_day_filled="(document.getElementById('%frmName%').{$name}_day.disabled=='' && document.getElementById('%frmName%').{$name}_day.value!='')";
				$is_mon_filled="(document.getElementById('%frmName%').{$name}_mon.disabled=='' && document.getElementById('%frmName%').{$name}_mon.value!='')";
				$is_yea_filled="(document.getElementById('%frmName%').{$name}_yea.disabled=='' && document.getElementById('%frmName%').{$name}_yea.value!='')";			
			}	
		
	
			if ($validate || is_array($validate)) //validazione javascript
			{
				//print_r($validate);
				if (is_array($validate))
				{
					$not_null=$validate[0];
					$validate=$validate[1];
				}
				else 
				$not_null=true;
				
				if ($inputType=="DATE")
				{
					$validateCondition="($is_day_empty || $is_mon_empty || $is_yea_empty)";
					
					$validateFunction.="
					if {$validateCondition}
					{
							 if {$is_day_empty}
								{alert('$heading {$this->lang['day']}: {$this->lang['missingInformation']}'); document.getElementById('%frmName%').{$name}_day.focus(); return false;}	
						else if {$is_mon_empty}
								{alert('$heading {$this->lang['month']}: {$this->lang['missingInformation']}'); document.getElementById('%frmName%').{$name}_mon.focus(); return false;}	
						else if {$is_yea_empty}
								{alert('$heading {$this->lang['year']}: {$this->lang['missingInformation']}'); document.getElementById('%frmName%').{$name}_yea.focus(); return false;}	
					}
					";				
				}
				else if ($inputType=="RADIO")
				{
					if (count($value)>1)
					{
						$cond=array();
						$cond2=array();
						for($i=0;$i<count($value);$i++)
						{
							$cond[] ="document.getElementById('%frmName%').{$name}[$i].checked==false";
							$cond2[]="document.getElementById('%frmName%').{$name}[$i].disabled==''";
						}
						$cond=implode(" && ",$cond);
						$cond2=implode(" || ",$cond2);
					}
					else
					{
						$cond="document.getElementById('%frmName%').{$name}.checked==false";
						$cond2="document.getElementById('%frmName%').{$name}.disabled==''";
					
					}
					//se sono tutti non selezionati ed almeno uno è selezionabile, ferma il form
					$validateCondition="((".$cond.") && (".$cond2."))";
					$validateFunction.="if {$validateCondition} {alert(\"$heading: {$this->lang['selectAnOption']}\"); document.getElementById('%frmName%').{$name}[0].focus(); return false;}
					";
				} 
				else if ($inputType=="CHECKBOX")
				{
					if (!is_array($value))
					$validateFunction.="if ( document.getElementById('%frmName%').{$name}.disabled=='' && document.getElementById('%frmName%').{$name}.checked==false) {alert(\"{$this->lang['selectTheOption']}\"); document.getElementById('%frmName%').{$name}.focus(); return false;}
					";
					else
					{
						$cond=array();
						$cond2=array();
						$i=0;
						foreach($value as $val)
						{
							$cond[] ="document.getElementById('%frmName%').elements['{$name}[{$i}]'].checked==false";
							$cond2[]="document.getElementById('%frmName%').elements['{$name}[{$i}]'].disabled==''";
							$i++;
						}
						$cond=implode("  &&  ",$cond);
						$cond2=implode("  ||  ",$cond2);
						$validateCondition="((".$cond.") && (".$cond2."))";
						$validateFunction.="if {$validateCondition} {alert(\"{$heading}: {$this->lang['selectOneOption']}\"); document.getElementById('%frmName%').elements['{$name}[0]'].focus(); return false;}
						";
	
					}
	
				}
				else if ($inputType=="ADV_TEXTAREA")
				{
					$validateCondition="(!validate_iframe('{$name}'))";
					$validateFunction.="if {$validateCondition} 
					{					
						alert(\"$heading: {$this->lang['missingInformation']}\"); 
						return false;					  
					}"; 
				}
				else		
				{
					if (is_bool($validate)) $validate=REGEXP_NOTNULL; //Se il valore di $validate impostato a true viene usato per altri tipi di input come TEXT, PASSWORD, FILE, allora $validate viene interpretato come la costante predefinita NOT_NULL. 
				
	
					switch($validate)
					{
						 case REGEXP_NOTNULL:$check=".match($validate)==null"; $msg="$heading: {$this->lang['missingInformation']}"; break;
						 case REGEXP_NUMREAL: $check=".match($validate)==null"; $msg="$heading: {$this->lang['notValidNumber']}"; break;
						 case REGEXP_NUMINT: $check=".match($validate)==null"; $msg="$heading: {$this->lang['notValidInt']}"; break;
						 case REGEXP_DATE: $check=".match($validate)==null"; $msg="$heading: {$this->lang['notDate']}"; break;
						 case REGEXP_EMAIL: $check=".match($validate)==null"; $msg="$heading: {$this->lang['notValidEmail']}"; break;
						 case REGEXP_IMAGE: $check=".toLowerCase().match($validate)==null"; $msg="$heading: {$this->lang['notImage']} (gif,jpg o png)"; break;
						 case REGEXP_FILE: $check=".toLowerCase().match($validate)==null"; $msg="$heading: {$this->lang['notFile']}"; break;
						 default  :$check="==''"; $msg="$heading: {$this->lang['missingInformation']}.."; break;
					}
					//echo $name."-".$validate."-".$check."<br>";
					$and=$not_null===false?"&& document.getElementById('%frmName%').$name.value!=''":"";
					$validateCondition="(document.getElementById('%frmName%').$name.disabled=='' && document.getElementById('%frmName%').$name.value{$check} $and)";
					$validateFunction.=" if  {$validateCondition}
											 {alert(\"$msg\"); document.getElementById('%frmName%').$name.focus(); return false;} 
									   ";
													   
														   
				}
				if ($not_null===true) $heading.=" (*)"; //visualizza l'asterisco per i campi (strettamente) obbligatori
	
			}
			else //non obbligatorio
			if ($inputType=="DATE") //controllo che si selezionino tutte e tre le select  si seleziona giorno o mese o ora e non si seleziona giorno o mese o ora
			{
				$validateFunction.= "
					
				if (
					( {$is_day_filled} || {$is_mon_filled} || {$is_yea_filled} )
						&&
					( {$is_day_empty}  || {$is_mon_empty}  || {$is_yea_empty}  )
				   )																									
				   {
						alert('$heading: {$this->lang['incompleteInformation']}'); 
						document.getElementById('%frmName%').{$name}_day.focus(); 
						return false;
				   }
				   ";			
			}
		
		
		
			if ($this->ever_new_line && $inputType!='HIDDEN') 
			$result.="<tr><td colspan=\"2\" style=\"width:".($this->width1+$this->width2)."%\" ><strong><label for=\"$name\">$heading</label></strong><br />";
			else
			switch($inputType) //tabella
			{
				case 'CHECKBOX':break;
				case 'SELECT':
				case 'FILE':
				case 'PASSWORD':
				case 'TEXT':
				case 'DATE':	
					$result.="<tr>
								<td style=\"width:{$this->width1}%\"><strong><label for=\"$name\">$heading</label></strong></td>
								<td style=\"width:{$this->width2}%\">
					";
					break;
				case 'RADIO':
					$result.="<tr>
								<td style=\"width:{$this->width1}%\"><strong><label for=\"$name\">$heading</label></strong></td>
								<td style=\"width:{$this->width2}%;{$focused_input_style}\">
					";
					break;			
				case 'TEXTAREA':
				case 'ADV_TEXTAREA':$result.="<tr><td colspan=\"2\" style=\"width:".($this->width1+$this->width2)."%\" ><strong><label for=\"$name\">$heading</label></strong><br />"; break;
				case 'HIDDEN':$result.="<tr><td colspan=\"2\" style=\"height:0px\" >
				";
			}
		
			switch($inputType) //tag input
			{
				case 'FILE':if ($bool) $script="var cb=document.getElementById('%frmName%').delete_{$name};
				if (document.getElementById('%frmName%').$name.value!='') {cb.disabled=true; cb.checked=true;}
					else {cb.disabled=false; cb.checked=false;}
					"; else $script="";
				$result.="<input $class type=\"file\"  id=\"$name\" name=\"$name\" value=\"$value\" 
				onchange=\"$script\" onkeyup=\"$script\" />";
				if ($bool) $result.="<br /><input class=\"$class\" type=\"checkbox\" value=\"1\" name=\"delete_{$name}\" style=\"{$focused_input_style}\" onchange=\"
				if (document.getElementById('%frmName%').delete_{$name}.checked==true) document.getElementById('%frmName%').$name.disabled=true;
					else document.getElementById('%frmName%').$name.disabled=false\" />{$this->lang['deleteCurrent']} $heading 
				"; 
							break;
				case 'TEXT':$result.="<input $class style=\"width:85%;{$focused_input_style}\" maxlength=\"255\" type=\"text\" id=\"$name\" name=\"$name\" value=\"$value\" size=\"30\" />
				"; 
						break;
				case 'PASSWORD':$result.="<input $class style=\"width:85%;{$focused_input_style}\" type=\"password\" id=\"$name\" name=\"$name\" value=\"$value\" size=\"30\" />
				"; 
							break;			
				case 'HIDDEN':$result.="<input type=\"hidden\" name=\"$name\" value=\"$value\" />";
							break;
							  
				case 'CHECKBOX':
					
							if (!is_array($value)) //checkbox semplice
							{
								if ($selected) $selected="checked=\"checked\""; 
						
								$result.="<tr>
											<td colspan=\"2\">
												<input $class type=\"checkbox\" id=\"$name\" name=\"$name\" value=\"$value\" style=\"{$focused_input_style}\" $selected style=\"vertical-align:middle\" />
												<strong><label for=\"$name\">$heading</label></strong>
											";
							}
							else //checkbox con più scelte
							{
								$result.="<tr>
											<td style=\"width:{$this->width1}%\">
												<strong><label for=\"$name\">$heading</label></strong>
											</td>
											<td style=\"width:{$this->width2}%\">
											";
								$first=true;
								$i=0;
								foreach ($value as $key=>$val)
								{
									if ($first)
									{
										$first=false;
										$id="id=\"{$name}\" ";
									}else $id="";
									
									if (in_array($key,$selected)) $sel="checked=\"checked\""; else $sel="";
									
									$result.="<input type=\"checkbox\" {$id}name=\"{$name}[{$i}]\" value=\"{$key}\" {$sel} /> {$val}<br />";
									++$i;
								}
								
							}						
							break;	
				case 'ADV_TEXTAREA':					
							
							$adv_textarea_params=array();
								
							if (is_array($bool['imagesPath']) && $bool['imagesPath']['absolute'] && $bool['imagesPath']['relative'])
							$adv_textarea_params['imagesPath']=$bool['imagesPath'];
							else
							if ($bool['absolute'] && $bool['relative'])//per compatibilità (moduli newsletter) si consente il passaggio dei 2 valori direttamente su bool
							$adv_textarea_params['imagesPath']=$bool;
							else
							$adv_textarea_params['imagesPath']="";
							
							$adv_textarea_params['fontSize']=isset($bool['fontSize'])?$bool['fontSize']:'';
							$adv_textarea_params['selectFont']=isset($bool['selectFont'])?$bool['selectFont']:'';
							$adv_textarea_params['bodyStyleOrCSS']=isset($bool['bodyStyleOrCSS'])?$bool['bodyStyleOrCSS']:'';																				
							
							if (!$this->Adv_TextArea_common_javascript_functions_PRINTED) //stampa una volta sola
							{
								Adv_TextArea::print_common_javascript_functions(); 
								$this->Adv_TextArea_common_javascript_functions_PRINTED=true;
							}
							$result.=Adv_TextArea::get_xhtml_and_javascript($name,addslashes($value),$class,"width:100%;",true,true,true,true,true,true,true,true
																			,true
																			,$adv_textarea_params['fontSize']
																			,$adv_textarea_params['selectFont']
																			,$adv_textarea_params['imagesPath']
																			,$adv_textarea_params['bodyStyleOrCSS']);							
						break;
						
			 	case "TEXTAREA":

							$value=str_replace("<br />","\n",$value); ////////!
							
							//if ($bool) $bool="readonly=\"readonly\""; else $bool="";
							$result.="
							<textarea $class id=\"$name\" name=\"$name\" style=\"width:100%;{$focused_input_style}\" cols=\"0\" rows=\"0\" >$value</textarea>
							"; 													
						break;
				
				case 'RADIO'://$result.="<FIELDSET>";
						 $i=0;
						 if ($bool) $bool=""; else $bool="<br />";
						 
						 $first=true;
						 
						 foreach($value as $thevalue=>$hdn)
						 {
								if ($first)
								{
									$first=false;
									$id="id=\"$name\" ";
								}
								else $id="";
								
								if ((string)($thevalue)==(string)($selected))
								$checked="checked=\"checked\"";
								else $checked="";
										
								$result.="<input type=\"radio\" {$id}name=\"$name\" value=\"$thevalue\" $checked />$hdn $bool";$i++;
						 }	
						
						 break;
				case 'SELECT':
							if (is_int($bool)) 
							{
								$mult="multiple=\"multiple\" size=\"{$bool}\""; 
								$arr="[]";
							}else
							{
								$mult=""; 
								$arr="";
							}
							
							$result.="<select $class $mult id=\"$name\" name=\"{$name}{$arr}\" style=\"width:auto;{$focused_input_style}\">
							";
									 $i=0;
									 foreach($value as $thevalue=>$hdn)
									 {
			
											if 
											( 
												(is_array($selected) && in_array((string)($thevalue),$selected)) 
											|| 
												(!is_array($selected) && (string)($thevalue)==(string)($selected) )   
											) 
											
											$sel="selected=\"selected\"";
											else 
											$sel="";					 
				
											$result.="<option value=\"$thevalue\" $sel>$hdn</option>
											";$i++;
									 }	
									 $result.="</select>
									 "; 
							
								break;
					
				case 'DATE':
							$selected=explode("-",$selected);
							$three_array=$this->dateArray($value[0],$value[1]);
							//if (strstr($heading," (*)")) $heading=substr($heading,0,strpos($heading," (*)"));
							$name_heading=str_replace("_"," ",$name);
							
							
							$result.="<table id=\"{$name}\" border=\"0\" summary=\"Selezione ".str_replace("_"," ",$name)."\" style=\"{$focused_input_style}\">";
							
							$result.="<tr><td><label for=\"{$name}_day\"></label></td>"; 	
							$result.="<td><select $class id=\"{$name}_day\" name=\"{$name}_day\" style=\"width:auto\">
							";
									 $i=0;
									 foreach($three_array[0] as $thevalue=>$hdn)
									 {
											if (isset($selected[2]) && $thevalue==$selected[2]) $sel="selected=\"selected\""; else	$sel="";					 
											$result.="<option value=\"$thevalue\" $sel>$hdn</option>
											";$i++;
									 }	$result.="</select></td></tr>
									 "; 
											 
									 
							$result.="<tr><td><label for=\"{$name}_mon\"></label></td>"; 	
							$result.="<td><select $class id=\"{$name}_mon\" name=\"{$name}_mon\" style=\"width:auto\">
							";
									 $i=0;
									 foreach($three_array[1] as $thevalue=>$hdn)
									 {
											if (isset($selected[1]) && $thevalue==$selected[1]) $sel="selected=\"selected\""; else	$sel="";					 
											$result.="<option value=\"$thevalue\" $sel>$hdn</option>
											";$i++;
									 }	$result.="</select></td></tr>
									 "; 								 	 
	
							$result.="<tr><td><label for=\"{$name}_yea\"></label></td>"; 	//intestazioni per l'accessibilità
							$result.="<td><select $class id=\"{$name}_yea\" name=\"{$name}_yea\" style=\"width:auto\">
							";
									 $i=0;
									 foreach($three_array[2] as $thevalue=>$hdn)
									 {
											if (isset($selected[0]) && $thevalue==$selected[0]) $sel="selected=\"selected\""; else	$sel="";					 
											$result.="<option value=\"$thevalue\" $sel>$hdn</option>
											";$i++;
									 }	$result.="</select></td></tr></table>
									 "; 							
									 
									 
						break;				
					
			}

			if (isset($not_null) && $not_null==true)
			{
				$result.="<input type=\"hidden\" id=\"verify_{$name}\" name=\"verify_{$name}\" value=\"{$validate}\" />
				";
				if (isset($validateCondition)) //aggiunge il js per disabilitare gli input già validati con js ed eliminare la validazione via php
				$this->removeServerValidation.="if (!{$validateCondition}) {document.getElementById('%frmName%').verify_{$name}.name='';}";
			}	
			
			$result.="</td></tr>";	 		
			//if ($bool) $result.="<br />";	
		
			if ($at_end)
			{
				$this->result_end.=$result;
				$this->validateFunction_end.=$validateFunction;
			}else
			{
				$this->result.=$result;
				$this->validateFunction.=$validateFunction;
			}
		
		} //end if iniziale
	}
	

	function buildForm($caption,$class="",$reset=true)
	{
		$this->result.=$this->result_end; //aggiungo gli input da mettere alla fine del form
		$this->validateFunction.=$this->validateFunction_end.$this->removeServerValidation;
		
		$this->result=str_replace("%frmName%",$this->name,$this->result);
		$this->validateFunction=str_replace("%frmName%",$this->name,$this->validateFunction);
				
		$this->result="
		<script type=\"text/javascript\"> 
		                <!-- 
					    validateFunction_{$this->name}=function () 
						{ 
							$this->validateFunction
						 
						 	return true;
						 
						} 
						//--></script> ".$this->result; //questione di estetica del codice
		
		
		if ($class!="") $class="class=\"$class\"";

			$this->result.="<tr><td colspan=\"2\" style=\"height:".($this->horizSpace*2)."px\" ></td></tr>
		
							<tr>	
								<td colspan=\"2\" style=\"text-align:center;width:".($this->width1+$this->width2)."%\" >
									<input $class type=\"submit\" name=\"{$this->name}_submit\" value=\"$caption\" 
									onclick=\"return validateFunction_{$this->name}()\" onkeypress=\"if (this.event.keyCode!=13) return false; else return validateFunction_{$this->name}()\" /> ";
									if ($reset) $this->result.="
									<input $class type=\"reset\" name=\"{$this->name}_reset\" value=\"&nbsp;Reset&nbsp;\" />";
			    $this->result.="</td>
							  </tr>
							</table>
						</form>";
		
		if ($this->focused_field!="") $this->result.="
		<script type=\"text/javascript\">
		
			function focus_it()
			{
				document.getElementById('{$this->focused_field}').focus();
				document.getElementById('{$this->focused_field}').style.border='1px solid #FF0000';
				document.getElementById('{$this->focused_field}_message').style.color='#FF0000';
				document.getElementById('{$this->focused_field}_message').style.paddingTop='6px';
				document.getElementById('{$this->focused_field}_message').style.paddingBottom='6px';
				document.getElementById('{$this->focused_field}_message').innerHTML=\"".str_replace('"',"'",$this->focused_msg)."\";
			}	
			
			//window.onload=new Function (\"focus_it();\");
			focus_it();
		
		</script>";
		
		return $this->result;
	}

	/*
	 *	restituisce un array di 3 elementi che a loro volta contengono un array con un numero di elementi pari rispettivamente a 31 (i giorni), 12 (i mesi), ($end_year-$start_year) (gli anni). Ogni sottoarray contiene come valore l’intestazione del dato che è diversa dalla chiave solo nel caso dei mesi (“11”=>”Novembre”) mentre negli altri casi è uguale (“1984=>”1984”)
	 */
 
	function dateArray($start_year,$end_year)
	{
		$result=array();
		if ($this->lang['languageName']=='english')
		$value=array(""=>"Day");
		else
		$value=array(""=>"Giorno");
		
		for ($i=1;$i<=31;$i++)
		{
			$j=($i<10)?"0$i":$i;
			$value[$j]=$i;
		}
		
		$result[]=$value;
		
		if ($this->lang['languageName']=='english')
		$value=array(""=>"Month");
		else
		$value=array(""=>"Mese");

		for ($i=1;$i<=12;$i++)
		{
			$j=($i<10)?"0$i":$i; 
			
			switch($i)
			{
				case "1":$show=$this->lang['languageName']=='english'?"January":"Gennaio";break;
				case "2":$show=$this->lang['languageName']=='english'?"February":"Febbraio";break;
				case "3":$show=$this->lang['languageName']=='english'?"March":"Marzo";break;
				case "4":$show=$this->lang['languageName']=='english'?"April":"Aprile";break;
				case "5":$show=$this->lang['languageName']=='english'?"May":"Maggio";break;
				case "6":$show=$this->lang['languageName']=='english'?"June":"Giugno";break;
				case "7":$show=$this->lang['languageName']=='english'?"July":"Luglio";break;
				case "8":$show=$this->lang['languageName']=='english'?"August":"Agosto";break;
				case "9":$show=$this->lang['languageName']=='english'?"September":"Settembre";break;
				case "10":$show=$this->lang['languageName']=='english'?"October":"Ottobre";break;
				case "11":$show=$this->lang['languageName']=='english'?"November":"Novembre";break;
				case "12":$show=$this->lang['languageName']=='english'?"December":"Dicembre";break;
			}
			$value[$j]=$show;
		}	
		
		$result[]=$value;
		
		if ($this->lang['languageName']=='english')
		$value=array(""=>"Year");
		else
		$value=array(""=>"Anno");

		for ($i=$start_year;$i<=$end_year;$i++)
		{
			$value[$i]=$i;
		}			
		$result[]=$value;
		
		return $result;		
	}	

}



/*  
 * Questa classe permette di creare una textarea con tasti di formattazione del testo utilizzando un IFRAME in modalità design.
 */
 
class Adv_TextArea
{ 
	/*
	 * ritorna una stringa contenente il codice XHTML che definisce una textarea (IFrame) con tasti bold,italic,underline,list,link e il codice JavaScript (non racchiuso in una funzione) necessario ad inizializzare la textarea appena creata.
	 * Inoltre è presente un hidden input (necessario per inserire fisicamente i dati) con id uguale ad “{$id}_ifr” (nome necessario per far riconoscere al metodo insertIntoDBFromPOST che si tratta di testo contenente tag HTML da correggere in XHTML) 
	*/
	 function get_xhtml_and_javascript($id,$value,$class,$style,
	 								   $bold,$italic,$underline,$ulist,$jleft,$jcenter,$jright,$link,$unformat,
									   $fontSize=false,$selectFont=false,$imagesPath="",$bodyStyleOrCSS=false)
	{
		if (!$bodyStyleOrCSS) $bodyStyleOrCSS="font-size:14px;font-family:Arial,Helvetica,sans serif;";
	
		$value=str_replace("\n","<br />",$value);
		$value=str_replace("\r","",$value);

		//$value=str_replace(array("\n","\r"),"<br />",$value);
		
		$button_style="style=\"color:#111111;border:1px solid #666666;margin:0px 4px 4px 0px;vertical-align:middle\"";

		if (is_array($imagesPath))
		{		
			$handle=opendir($imagesPath['relative']);
			$pre="";	
			$count=0;
			while (false !== ($file = readdir($handle))) 
			if ( !is_dir($file) && preg_match("/\.((gif)|(png)|(jpg)|(jpeg))$/i",$file)!=0 )
			{
				if ($count % 3 == 0 ) $clear="both"; else $clear="none";
				//notare che nel src metto il path relative e quando aggiungo tale valore (un src di img) alla textarea, viene aggiunto autom. il path assoluto
				$pre.="<div style=\"margin:5px;width:100px;height:100px;float:left;text-align:center\">";
						   					
					$pre.="<img src=\"{$imagesPath['relative']}/{$file}\" style=\"clear:{$clear};cursor:pointer;"
							.getImageResizedValues("{$imagesPath['relative']}/{$file}",100,100).";\"
							onclick=\"document.getElementById('preview_images_{$id}').style.display='none';command('{$id}','InsertImage',
							{imgSrc:this.src,float:this.parentNode.parentNode.parentNode.getElementsByTagName('select')[0].value
										   ,border:this.parentNode.parentNode.parentNode.getElementsByTagName('select')[1].value})\" 
							alt=\"{$file}\" title=\"{$file}\" />
						</div>";
				++$count;
			}
			
			if ($pre=="") $dis="alt=\"No image available\" title=\"No image available\" disabled=\"disabled\""; else $dis="$button_style";
			
			$insert_images="
					<button type=\"button\" $dis onclick=\"document.getElementById('preview_images_{$id}').style.display=document.getElementById('preview_images_{$id}').style.display=='block'?'none':'block';\" _onclick=\"this.blur();command('{$id}','InsertImage',document.getElementById('choose_image_{$id}').value);\" >
						Insert Image
					</button>
					<br />
					<div id=\"preview_images_{$id}\" style=\"display:none;position:absolute;width:350px;border:1px solid #000;background-color:#DDD;font-size:10px;font-family:Arial,Verdana\">
						<div style=\"border-bottom:1px solid #000;padding:4px\">
						Before you select an image, select the mode (float) and the border you want apply to the image.<br />
						<strong>Float:</strong> 						
							   <select style=\"font-size:10px;font-family:Arial,Verdana;margin-bottom:3px\">
								   <option value=\"none\" selected=\"selected\">none</option>
								   <option value=\"left;margin:3px 4px 3px 0px\" >Left</option>
								   <option value=\"right;margin:3px 0px 3px 4px\">Right</option>
							   </select>					
						
						<strong>Border:</strong> 						
							   <select style=\"font-size:10px;font-family:Arial,Verdana;margin-bottom:3px\">
								   <option value=\"none\" selected=\"selected\">none</option>
								   <option value=\"1px solid #000\">Black</option>
								   <option value=\"1px solid #999\">Grey</option>
	
							   </select>					
						</div>
						<div style=\"height:350px;overflow:auto\">
							{$pre}
						</div>
					</div>
					
					
					";
		}
		else $insert_images="<br />";
		

		if ($selectFont!=false)		
		{
			if (!is_array($selectFont))//valori di default
			$selectFont=array('Arial','Verdana','Georgia','Geneva','Courier new','Times new roman');
			
			$option="<option value=\"\">Font family</option>";
			
			foreach($selectFont as $font)
			$option.="<option value=\"{$font}\">{$font}</option>";
			
			$select_font="<select $button_style onchange=\"this.blur();command('{$id}','fontname',this.value);this.selectedIndex=0\">
						  	{$option}
						  </select>  &nbsp;
						  ";
		}
		else $select_font="";

		if ($fontSize!=false)		
		{
			if (!is_array($fontSize))//valori di default
			$fontSize=array('start'=>8,'end'=>'23');
							
			$option="<option value=\"\">Font size</option>";
			for($i=$fontSize['start'];$i<=$fontSize['end'];$i++)
			$option.="<option value=\"{$i}\">{$i}</option>";
			
			$font_size="<select $button_style onchange=\"this.blur();command('{$id}','fontsize',this.value);this.selectedIndex=0\">
						  	{$option}
						  </select>  &nbsp;
						  ";
		}
		else $font_size="";		
		

		$result="
		
		<div style=\"background-color:#EEEEEE;padding:5px;\" >
			
			".($bold?"<button type=\"button\" onclick=\"this.blur();command('{$id}','Bold');\" $button_style><strong>Bold</strong></button> &nbsp;":"")."
			".($italic?"<button type=\"button\" onclick=\"this.blur();command('{$id}','Italic');\" $button_style><em>Italic</em></button> &nbsp;":"")."
			".($underline?"<button type=\"button\" onclick=\"this.blur();command('{$id}','Underline');\" $button_style><span style=\"text-decoration:underline\">Underline</span></button> &nbsp;":"")."
			".($ulist?"<button type=\"button\" onclick=\"this.blur();command('{$id}','insertunorderedlist');\" $button_style>&bull; List</button> &nbsp;":"")."
			".($jleft?"<button type=\"button\" onclick=\"this.blur();command('{$id}','justifyleft');\" $button_style>Justify Left</button> &nbsp;":"")."
			".($jcenter?"<button type=\"button\" onclick=\"this.blur();command('{$id}','justifycenter');\" $button_style>Justify Center</button> &nbsp;":"")."
			".($jright?"<button type=\"button\" onclick=\"this.blur();command('{$id}','justifyright');\" $button_style>Justify Right</button> &nbsp;":"")."
			".($link?"<button type=\"button\" onclick=\"this.blur();command('{$id}','CreateLink');\" $button_style>&raquo;Link&laquo;</button> &nbsp;":"")."
			".($unformat?"<button type=\"button\" onclick=\"this.blur();command('{$id}','RemoveFormat');\" $button_style><em>Un</em>Format</button> &nbsp;":"")."				
			{$select_font}
			{$font_size}		
			<button type=\"button\" onclick=\"if (confirm('Really empty TextArea?')) {this.blur();command('{$id}','Empty')};\" $button_style >Empty</button> &nbsp;
			<button type=\"button\" onclick=\"this.blur();command('{$id}','Code');\" $button_style >View code</button> &nbsp; 		
			{$insert_images}
			To copy and paste use [CTRL + C] and [CTRL + V]<br />
			<strong>Important:</strong> Don't paste text directly from Word, paste first into a simple editor like NotePad
		</div>
		<iframe {$class} style=\"{$style}\" id=\"{$id}\" name=\"{$id}\" ></iframe>
		<input type=\"hidden\" name=\"{$id}_ifr\" id=\"{$id}_ifr\" value=\"\" />
		

		
		<script type=\"text/javascript\">
		
		////INIZIALIZZAZIONE

		initialize_iframe('$id',\"$value\",'{$bodyStyleOrCSS}');	

		//////////////
		
		</script>
		";
		return $result;
		
	}
	/*
 	 *	restituisce una stringa contenente 4 funzioni javascript necessarie ad effettuare la validazione della textarea, il salvataggio dei dati nell’hidden input associato e l’esecuzione dei comandi predefiniti di per applicare i tag di formattazione testo alla textarea. 
 	 */
	 function print_common_javascript_functions()
	{
	?>
	
		<script type="text/javascript">
		<!--	
		
		initialize_iframe=function (id,value,bodyStyleOrCSS)
		{
			if (bodyStyleOrCSS.match(/.+\.(css|CSS)/))
			{
				bodyStyle='';
				css="<link rel=\"stylesheet\" type=\"text/css\" href=\""+bodyStyleOrCSS+"\" />"; 
			}
			else
			{
				bodyStyle="style='"+bodyStyleOrCSS+"'";
				css=''; 
			}
		
			iFrameDoc = (document.all)? "window.document.frames('"+id+"').document;": "document.getElementById('"+id+"').contentDocument;";
			eval(iFrameDoc).open();
			eval(iFrameDoc).write(css+"<body "+bodyStyle+">"+value+"</body>");
			eval(iFrameDoc).close();
			eval(iFrameDoc).designMode = "on";
			
			eval(iFrameDoc).onkeydown=function () ///Solo per IE, INSERISCE BR qundo si preme invio
			{
				iFrameDoc = (document.all)? "window.document.frames('"+id+"');": "document.getElementById('"+id+"');";
			
				if (eval(iFrameDoc).event.keyCode==13)
				{
					r=eval(iFrameDoc).document.selection.createRange();
					r.pasteHTML('<br />');
					r.select();
					r.collapse(false);
					return false;
				}				
			}
			
			eval(iFrameDoc).onfocus=function () 
			{
				iFrameDoc = (document.all)? "window.document.frames('"+id+"').document;": "document.getElementById('"+id+"').contentDocument;";
			
				if (pure_text(eval(iFrameDoc).body.innerHTML)=="") eval(iFrameDoc).body.innerHTML="&nbsp;";	

			}			
		}		
		
		
		pure_text=function (res)
		{
			var temp = new Array();
			
			if (res.indexOf("<")!=-1) ///////////////////////////////////elimina i tag
			{
				//alert ('elimina_tag');
				temp = res.split('<'); res=""; 
				for (i=0;i<temp.length;i++) 
				{ 
					if ( temp[i].substr(0,3).toLowerCase()!='img' ) //le immagini vengono considerate come contenuto
						res=res+temp[i].substring(temp[i].indexOf('>')+1); 	
					else
						res=res+'<'+temp[i].substring(0,temp[i].indexOf('>')+1); 
				}
				 
				
			}	
			
			if (res.indexOf("&")!=-1)////////////////////////////////elimina le entita
			{			
				//alert ('elimina_entita');
				temp = res.split("&"); res="";  

				for (i=0;i<temp.length;i++)	{ res=res+temp[i].substring(temp[i].indexOf(';')+1); }	
			}
			
			//if (res.charAt(0)==" " && res.charAt(res.length)==" ")
			//res=res.substring(res.indexOf(" ")+1,res.lastIndexOf(" ")-1); 

			while (res.charAt(0)==" " && res.length!=0) {res=res.substring(1);} //LEFT TRIM	
			while (res.charAt(res.length)==" " && res.length!=0) {res=res.substring(0,res.length-1);} //RIGHT TRIM
			
			return res;
			
		}
		
		
		save_iframe_text=function (iframe)
		{
			var iFrameDoc = (document.all)? "document.frames(\""+iframe+"\").document\;": "document.getElementById(\""+iframe+"\").contentDocument\;";
			
			if (eval(iFrameDoc).designMode=='on')
			{
				document.getElementById(iframe+"_ifr").disabled=false;
				
				if (pure_text(eval(iFrameDoc).body.innerHTML)!="")
				document.getElementById(iframe+"_ifr").value=eval(iFrameDoc).body.innerHTML;		
				else 
				document.getElementById(iframe+"_ifr").value="&nbsp;";		
			}
			else //se è disabilitata l'iframe, disabilita l'input hidden di dati (l'input di verifica viene disabilitato col js generato da htmlform)
			{
				document.getElementById(iframe+"_ifr").disabled=true; 
			}
		}

		validate_iframe=function (iframe)
		{
			var iFrameDoc = (document.all)? "document.frames(\""+iframe+"\").document\;": "document.getElementById(\""+iframe+"\").contentDocument\;";
			var iFrameFoc = (document.all)? "document.frames(\""+iframe+"\").focus()\;": "document.getElementById(\""+iframe+"\").contentWindow.focus()\;";
			
				
			if ( eval(iFrameDoc).designMode=='on' && pure_text(eval(iFrameDoc).body.innerHTML)=="" ) //se non è disabilitato ed è vuoto fallisce la validazione
			{
				////alert(eval(iFrameDoc).body.innerHTML);
				eval(iFrameDoc).body.innerHTML="&nbsp;"; //pulisce :\
				eval(iFrameFoc);
				return false;
			}
			return true;
			
					
		}		
		
		
		command=function (iframe,command,param)
		{
		
			var iFrameDoc = (document.all)? "document.frames(\""+iframe+"\").document\;": "document.getElementById(\""+iframe+"\").contentDocument\;";
			var iFrameFoc = (document.all)? "document.frames(\""+iframe+"\").focus()\;": "document.getElementById(\""+iframe+"\").contentWindow.focus()\;";
		
			eval(iFrameFoc); //FOCUS - Explorer lo vuole prima del comando altrimenti non inserisce bene le immagini
		
			if (command=='CreateLink')
			{
				href=prompt("Insert full URL or command\nEX:\nhttp://www.cottonbit.it\nmailto:info@cottonbit.it");
				
				if (href!=null) //se href==null è stato premuto Annulla
				{
					//if (href.indexOf('http://') != 0) {href='http://'+href;}   //aggiunge http://
					eval(iFrameDoc).execCommand("CreateLink",false,href);
					
					if (confirm("Open link in new window?"))
					{
						nuovo_html=eval(iFrameDoc).body.innerHTML;
						nuovo_html=nuovo_html.replace("<a href=\""+href+"\">","<a href=\""+href+"\" onclick=\"window.open(this.href);return false\">");
						nuovo_html=nuovo_html.replace("<A href=\""+href+"\">","<A href=\""+href+"\" onclick=\"window.open(this.href);return false\">");		
						eval(iFrameDoc).body.innerHTML=nuovo_html;
					}
				} 
			}
			else if (command=='InsertImage')
			{
				eval(iFrameDoc).execCommand(command,false,param.imgSrc);
				
				//param.float contiene il valore di float + l'attributo margin

				nuovo_html=eval(iFrameDoc).body.innerHTML;
				nuovo_html=nuovo_html.replace(new RegExp("<(img|IMG) src=(\")?"+param.imgSrc+"(\")?>")
											 ,"<img style=\"float:"+param.float+";border:"+param.border+"\" src=\""+param.imgSrc+"\" alt=\"\">");
				eval(iFrameDoc).body.innerHTML=nuovo_html;

			}			
			else if (command=='Code')
			{ 
				////if (eval(iFrameDoc).body.innerHTML.indexOf("\n")!=-1) alert("Ci sono i caratteri di ritorno a capo!");
				alert(eval(iFrameDoc).body.innerHTML);
			}
			else if (command=='Empty')
			{ 
				eval(iFrameDoc).body.innerHTML='&nbsp;';			
			}
			else if (command=='fontsize')
			{ 
				eval(iFrameDoc).execCommand(command,false,2);

				nuovo_html=eval(iFrameDoc).body.innerHTML;
				nuovo_html=nuovo_html.replace("<font size=\"2\">","<span style=\"font-size:"+param+"px\">");
				nuovo_html=nuovo_html.replace("</font>","</span>");		
				nuovo_html=nuovo_html.replace("<FONT size=2>","<span style=\"font-size:"+param+"px\">");
				nuovo_html=nuovo_html.replace("</FONT>","</span>");		
				eval(iFrameDoc).body.innerHTML=nuovo_html;
				
			}									
			else	eval(iFrameDoc).execCommand(command,false,param);
			
			
			
		}
		-->
		</script>
	<?php
	}
}



?>
