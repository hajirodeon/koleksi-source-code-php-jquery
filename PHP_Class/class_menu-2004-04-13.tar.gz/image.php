<?
header("Content-Type: image/gif");
header("Content-Disposition: inline");
echo base64_decode(
"R0lGODlhoAAVANUAAOfn5////6urq93d3dvb2+zs7N/f3+Hh4fv7++Li4u/v78LCwvPz8+7u7vf3".
"96qqqrW1te3t7ebm5vDw8NXV1fj4+Nra2srKysvLy+jo6J+fn76+vs/Pz9TU1KCgoKysrLKysry8". "vOnp6eTk5NHR0erq6qOjo+Xl5ZycnKSkpM3NzZ2dnevr62ZnaN7e3gAAAAAAAAAAAAAAAAAAAAAA".
"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACwAAAAAoAAVAAAG/8BAAMFoFFjIpHLJ". "bDqf0Kh0Sq1apwVFRRhwRAAJg2tMLpvP6LR6zW673/C423BIKIaFkXzP7/v/gG8GHQwTEoGIiYqL". "iQQXIgeMkpOSBJRlIACXm3uWnJ8fmmktLZKkpGWefqifrWoComiop7SlLqdjtbmsu2Sztri3tb+4".
"rMGurrBqv8LNzM+lvNLR1M7V0NbNyK3Ko9ff2di9vre92Ofg25/dsuDT7rS+wdFlxfDh8eqc7Gfo".
"+NlmeAkDds+fQH2b+AUs+M2etoflCP4zWA3hJYX1GEIU95DixHsWKWGU99GhMYHxoJlsyGxgyIux". "EB27dPBlqwEPAAywyRPRzkdNFB6U+NmzqFEyAzZAcEBA1dGnLzGkyBAAwAIOFohC3fqJAIkQHlRw". "abBAgIYVaNOqXcu2rdu3cOPKnUu3rl25KExAOCEkCAA7");
?>