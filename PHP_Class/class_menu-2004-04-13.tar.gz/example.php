<?

    /// Drop Down Menu ///
    /// Class usage sample ///////
    /// Programer: Marcos Thiago - <fabismt@yahoo.com.br> ///////

    require_once("class_MENU.php");
    $menu = new MENU();

    $menu->openHtmlTest(); // this exists just for test the class.
    
    /* --------------------------- */
    // Set and build Menu Example 1.
    $menu->addMenuName("Example_1"); // menu id or name. Do not use white spaces, special chars or repeated names on this parameter. this parameter is like a primary key of this menu.
    $menu->addMenuImg("image.php");// path to menu image(image src).
    $menu->addSubMenu("Page 1.1","example.php?argument=1.1","_self"); // name, link, target
    $menu->addSubMenu("Page 1.2","example.php?argument=1.2","_self"); // name, link, target
    $menu->addSubMenu("Page 1.3","example.php?argument=1.3","_self"); // name, link, target
    $menu->addSubMenu("Page 1.4","example.php?argument=1.4","_self"); // name, link, target
    $menu->addSubMenu("Page 1.5","example.php?argument=1.5","_self"); // name, link, target
    $menu->buildMenu();
    /* --------------------------- */
    // Set and build Menu Example 2.
    $menu->addMenuName("Example_2"); // menu id or name. Do not use white spaces, special chars or repeated names on this parameter. this parameter is like a primary key of this menu.
    $menu->addMenuImg("image.php");// path to menu image(image src).
    $menu->addSubMenu("Page 2.1","example.php?argument=2.1","_self"); // name, link, target
    $menu->addSubMenu("Page 2.2","example.php?argument=2.2","_self"); // name, link, target
    $menu->addSubMenu("Page 2.3","example.php?argument=2.3","_self"); // name, link, target
    $menu->addSubMenu("Page 2.4","example.php?argument=2.4","_self"); // name, link, target
    $menu->addSubMenu("Page 2.5","example.php?argument=2.5","_self"); // name, link, target
    $menu->buildMenu();
    /* --------------------------- */
    // Set and build Menu Example 3.
    $menu->addMenuName("Example_3"); // menu id or name. do not use white spaces, special chars or repeated names on this parameter. this parameter is like a primary key of this menu.
    $menu->addMenuImg("image.php");// path to menu image(image src).
    $menu->addSubMenu("Page 3.1","example.php?argument=3.1","_self"); // name, link, target
    $menu->addSubMenu("Page 3.2","example.php?argument=3.2","_self"); // name, link, target
    $menu->addSubMenu("Page 3.3","example.php?argument=3.3","_self"); // name, link, target
    $menu->addSubMenu("Page 3.4","example.php?argument=3.4","_self"); // name, link, target
    $menu->addSubMenu("Page 3.5","example.php?argument=3.5","_self"); // name, link, target
    $menu->buildMenu();
    /* --------------------------- */    
    // Show all builded menu.
    @$menu->showMenu($_GET['selected_menu']); // this parameter maintain menu on the opened one!
    /* --------------------------- */

    @$menu->closeHtmlTest($_GET["argument"]); // this exists just for test the class.
?>