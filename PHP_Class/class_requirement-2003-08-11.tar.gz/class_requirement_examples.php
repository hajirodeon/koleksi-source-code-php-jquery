<?php
 require_once "class_requirement.php";
 $rq = new requirement();
 print $rq->check("class_requirement_examples.php");
 if (count($rq->aErrors)>0){
        echo "error";
      print_r($rq->aErrors);
 }


 /*
 error_reporting(1024);
 $rq->build('/home/user/path_to_doc_of_php');
 if (count($rq->aErrors)>0){
        echo "error";
      print_r($rq->aErrors);
 }
 */
?>
