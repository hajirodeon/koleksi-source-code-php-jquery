<?php

/**
 * Image.php call this file in your html for example :
 * 
 * <img src="image.php?img=img_name_gif" alt="">
 * 
 * @author Ben Yacoub Hatem <hatem@php.net>
 * @copyright Copyright (c) 2004
 * @version $Id$ - 05/04/2004 09:23:32 - image.php
 * @access public
 **/

require_once("gonximages.class.php");
if (isset($img) and $img!="") {
    gonximage::getimage($img);
}

?>