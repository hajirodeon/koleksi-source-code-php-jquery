<?php

require_once("img2php.class.php");

$t = new img2php;
$t->generate("images/tabs/gonx");

?>