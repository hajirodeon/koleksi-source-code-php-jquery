<?php
// ============================================
//  Copyright:   (r)(c) 2000.
//  File:        style.cfg.php
//  Subsystem:   Core
//  Description: Core skeleton styles
// ============================================

	// ===========================================
	//  BODY attributes
	// ===========================================

	$BODY_BGCOLOR	= "#ffffff";
	$BODY_LINK		= "#000000";
	$BODY_ALINK		= "#990033";
	$BODY_VLINK		= "#000000";

	// ===========================================
	//  Main table attributes
	// ===========================================

	$MAINTABLE_WIDTH		= 780;
	$MAINTABLE_HEIGHT		= 0;
	$MAINTABLE_ALIGN		= "center";
	$MAINTABLE_BORDER		= 0;
	$MAINTABLE_CELLPADDING	= 0;
	$MAINTABLE_CELLSPACING	= 0;
	$MAINTABLE_BGCOLOR		= "#ffffff";
	$COPYRIGHT_ALLIGN		= "right";

	// ===========================================
	//  Menu table attributes
	// ===========================================

	$MENUTABLE_WIDTH		= "100%";
	$MENUTABLE_BORDER		= 0;
	$MENUTABLE_CELLPADDING	= 0;
	$MENUTABLE_CELLSPACING	= 2;
	$MENUTABLE_BGCOLOR		= "#999999";

	// ===========================================
	//  Content table attributes
	// ===========================================

	$CONTENTTABLE_WIDTH		= "100%";
	$CONTENTTABLE_BORDER	= 0;
	$CONTENTCOLUMN_WIDTH	= "100%";
	$CONTENTCOLUMN_VALIGN	= "top";
?>