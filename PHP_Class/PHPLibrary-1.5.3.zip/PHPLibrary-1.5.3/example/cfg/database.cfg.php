<?php if (!defined ("_DATABASE_CFG_")):

// Define include checking flag
define ("_DATABASE_CFG_", "database.cfg.php");

// -------------------------------------------------------------
//  Database connect parameters
// -------------------------------------------------------------

define ("DB_HOST", "localhost");
define ("DB_USER", "root");
define ("DB_PASSWORD", "");
define ("DB_NAME", "phplibex");

// -------------------------------------------------------------
//  SQL patterns definitions
// -------------------------------------------------------------

define ("SEARCHEXP_ANYCHAR", "?");
define ("SEARCHEXP_ANYSEQUENCE", "*");
define ("SQL_ANYCHAR", "_");
define ("SQL_ANYSEQUENCE", "%");

$SqlWildcardToSeacrhWildcard = array
	(
		SQL_ANYCHAR => SEARCHEXP_ANYCHAR,
		SQL_ANYSEQUENCE => SEARCHEXP_ANYSEQUENCE
	);

$SeacrhWildcardToSqlWildcard = array
	(
		SEARCHEXP_ANYCHAR => SQL_ANYCHAR,
		SEARCHEXP_ANYSEQUENCE => SQL_ANYSEQUENCE
	);

// -------------------------------------------------------------
//  Table names definitions
// -------------------------------------------------------------
define ("TBL_DEPARTMENTS", "DEPARTMENTS");
define ("TBL_EQUIPMENT", "EQUIPMENT");
define ("TBL_MAINTENANCE", "MAINTENANCE");
define ("TBL_PRODUCTS", "PRODUCTS");
define ("TBL_USERS", "USERS");

endif ?>
