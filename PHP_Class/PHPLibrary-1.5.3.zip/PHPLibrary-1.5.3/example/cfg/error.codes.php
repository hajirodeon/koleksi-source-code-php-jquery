<?php if (!defined ("_APP_ERROR_CODES_")):
// ============================================
//  Copyright:   (r)(c) 2000.
//  File:        error.codes.php
//  Subsystem:   Core
//  Description: Error code constants
// ============================================

define ("_APP_ERROR_CODES_", "error.codes.php");

// -------------------------------------------------------------
//  Warning code definition
// -------------------------------------------------------------

define ("WARNING_BASE", 100);

// -------------------------------------------------------------
//  Error codes definitions
// -------------------------------------------------------------

define ("SUCCESS", 0);
define ("ERROR_BASE", 500);

define ("ERROR_SQLQUERY", ERROR_BASE+1);
define ("ERROR_INSERT", ERROR_BASE+2);
define ("ERROR_UPDATE", ERROR_BASE+3);
define ("ERROR_DELETE", ERROR_BASE+4);
define ("ERROR_NODATA", ERROR_BASE+5);
define ("ERROR_IGNORE", ERROR_BASE+6);

define ("ERROR_USEREXISTS", ERROR_BASE+10);
define ("ERROR_USERNOTEXISTS", ERROR_BASE+11);
define ("ERROR_BADPASSWORD", ERROR_BASE+12);
define ("ERROR_USERDISABLED", ERROR_BASE+13);
define ("ERROR_UNAUTHORIZEDACCESS", ERROR_BASE+14);
define ("ERROR_SENDMAIL", ERROR_BASE+15);
define ("ERROR_IDEXISTS", ERROR_BASE+16);
define ("ERROR_MAINTEXISTS", ERROR_BASE+17);
define ("ERROR_MAINTNOTEXISTS", ERROR_BASE+18);
define ("ERROR_REPEXISTS", ERROR_BASE+19);
define ("ERROR_EQUIPMENTEXISTS", ERROR_BASE+20);
define ("ERROR_EQUIPMENTNOTEXISTS", ERROR_BASE+21);
define ("ERROR_SCHEDULEXISTS", ERROR_BASE+22);
define ("ERROR_SCHEDULENOTEXISTS", ERROR_BASE+23);
define ("ERROR_TASKEXISTS", ERROR_BASE+24);
define ("ERROR_TASKNOTEXISTS", ERROR_BASE+25);
define ("ERROR_ABRECORDEXISTS", ERROR_BASE+26);
define ("ERROR_ABRECORDNOTEXISTS", ERROR_BASE+27);
define ("ERROR_ABEXISTS", ERROR_BASE+28);
define ("ERROR_ABNOTEXISTS", ERROR_BASE+29);
define ("ERROR_ITEM_IN_USE", ERROR_BASE+34);
define ("ERROR_TRY_DELETE_ADMIN", ERROR_BASE+35);
define ("ERROR_PRODEXISTS", ERROR_BASE+36);
define ("ERROR_PRODNOTEXISTS", ERROR_BASE+37);
define ("ERROR_DEPEXISTS", ERROR_BASE+38);
define ("ERROR_DEPNOTEXISTS", ERROR_BASE+39);
define ("ERROR_CANTCREATE", ERROR_BASE+40);
define ("ERROR_TOPICEXISTS", ERROR_BASE+41);
define ("ERROR_ERRORNOTEXISTS", ERROR_BASE+42);
define ("ERROR_HISTORYEXISTS", ERROR_BASE+43);
define ("ERROR_HISTORYNOTEXISTS", ERROR_BASE+44);

define ("ERROR_UNKNOWNACTION", ERROR_BASE+101);
define ("ERROR_WRONGPARAMS", ERROR_BASE+102);
define ("ERROR_MOVE", ERROR_BASE+103);

define ("ERROR_UNDEFINED", ERROR_BASE+201);
endif;?>
