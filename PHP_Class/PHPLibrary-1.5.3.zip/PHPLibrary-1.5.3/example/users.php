<?php

	$inc_dir = "inc/";
	$lib_dir = "../lib/";
	$cfg_dir = "cfg/";
	$img_dir = "img/";

	$admin_inc_dir = "inc/";
	$admin_lib_dir = "lib/";

	require ($cfg_dir . "style.cfg.php");
	require ($admin_lib_dir . "users.class.php");
	$grid = new usersGrid ();

	$leftmenu = $admin_inc_dir . "menu.inc.php";
	$content_page = $admin_inc_dir . "users.inc.php";
	$strTitle = "Admin - Users";
	require ($inc_dir . "skeleton.inc.php");
?>
