<?php

	header ('Location: users.php');
	exit;
?>