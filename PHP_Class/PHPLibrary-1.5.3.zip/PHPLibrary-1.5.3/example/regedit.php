<?php


	$inc_dir = "inc/";
	$lib_dir = "../lib/";
	$cfg_dir = "cfg/";
	$img_dir = "img/";
	$admin_inc_dir = "inc/";

	require ($cfg_dir . "style.cfg.php");
	require ($cfg_dir . "database.cfg.php");

	$leftmenu = $admin_inc_dir . "menu.inc.php";
	$content_page = $admin_inc_dir . "regedit.inc.php";
	$strTitle = "Admin - Configuration Manager";
	require ($inc_dir . "skeleton.inc.php");

?>
