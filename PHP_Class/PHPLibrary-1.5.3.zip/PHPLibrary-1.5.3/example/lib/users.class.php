<?php

require_once ($admin_lib_dir . "grid3.lib.php");

define (REG_SCHEDULE_GRID_NAME, "Users");
define (GRID_NO_USERS, "You have no users in the system at the moment");

// ------------------------------------------
//  Grid class
// ------------------------------------------

class usersGrid extends softerraGrid
{
	function usersGrid ($bDebug=false)
	{
		global $session_uid;
		// call parent constructor
		$this->softerraGrid (REG_SCHEDULE_GRID_NAME);
		// setup database fields
		$this->vQryTable = array (TBL_USERS);
		$this->aQryFields = array (
				"USER_NAME",
				"USER_DESCRIPTION",
				"USER_EMAIL",
				"USER_LAST_LOGIN",
				"USER_ENABLED",
				"USER_ID"
				);
		$this->vQryConditions=false;
		if ($bDebug) $this->debugOn ();
		$this->sNoDataMessage = MSG_NO_USERS;
	}
} // end of scheduleGrid

?>