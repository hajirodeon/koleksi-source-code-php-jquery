<?php
if (!isset($TopicName))
	$TopicName = "";
?>
<tr> 
	<td width="160"><img src="<? echo $img_dir . "logo.gif"?>" width="160" height="60"></td>
	<td width="620"><img src="<? echo $img_dir . "banner.gif"?>" width="620" height="60"></td>
</tr>
<tr> 
	<td><img src="<? echo $img_dir . "menu.gif"?>" width="160" height="20"></td>
	<td>
		<table cellpadding="0" cellspacing="0" border="0">
			<tr>
				<td><img src="<? echo $img_dir . "line.gif"?>" width="620" height="20"></td>
			</tr>
		</table>
	</td>
</tr>
