//<script language="JavaScript">
<!--
var image_dir = './img/';
function si(imgid, newimg){ if (document.images) {imgid.src=newimg.src;} }
if (document.images) {
        first_n=new Image(32,20); first_n.src=image_dir+'first_n.gif';
        first_h=new Image(32,20); first_h.src=image_dir+'first_h.gif';
        prev_n=new Image(32,20); prev_n.src=image_dir+'prev_n.gif';
        prev_h=new Image(32,20); prev_h.src=image_dir+'prev_h.gif';
        next_n=new Image(32,20); next_n.src=image_dir+'next_n.gif';
        next_h=new Image(32,20); next_h.src=image_dir+'next_h.gif';
        last_n=new Image(32,20); last_n.src=image_dir+'last_n.gif';
        last_h=new Image(32,20); last_h.src=image_dir+'last_h.gif';
}
//-->
//</script>
