<table width="100%" border=<? echo $MENUTABLE_BORDER ?> cellpadding=<?php echo $MENUTABLE_CELLPADDING ?> cellspacing=<?php echo $MENUTABLE_CELLSPACING ?> >
<tr>
	<td width="11%"><img src="<? echo $img_dir . "menua.gif"?>" width=22 height=22></td>
	<td width="89%" bgcolor=<?php echo $MENUTABLE_BGCOLOR ?>>&nbsp;&nbsp;&nbsp;<a href="users.php">Users</a></td>
</tr>
<tr>
	<td width="11%"><img src="<? echo $img_dir . "menua.gif"?>" width=22 height=22></td>
	<td width="89%" bgcolor=<?php echo $MENUTABLE_BGCOLOR ?>>&nbsp;&nbsp;&nbsp;<a href="regedit.php">Configuration</a></td>
</tr>
</table>