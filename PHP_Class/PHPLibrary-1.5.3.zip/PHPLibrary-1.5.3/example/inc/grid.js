//<script language="JavaScript">
<!--
var image_dir = './img/';
function si(imgid, newimg){ if (document.images) {imgid.src=newimg.src;} }
if (document.images)
{
	first_n=new Image(32,20); first_n.src=image_dir+'first_n.gif';
	first_h=new Image(32,20); first_h.src=image_dir+'first_h.gif';
	prev_n=new Image(32,20); prev_n.src=image_dir+'prev_n.gif';
	prev_h=new Image(32,20); prev_h.src=image_dir+'prev_h.gif';
	next_n=new Image(32,20); next_n.src=image_dir+'next_n.gif';
	next_h=new Image(32,20); next_h.src=image_dir+'next_h.gif';
	last_n=new Image(32,20); last_n.src=image_dir+'last_n.gif';
	last_h=new Image(32,20); last_h.src=image_dir+'last_h.gif';
}

function isPositiveInt (s)
{
	if ((s == null) || (s.length == 0)) return false;
	for (var i = 0; i < s.length; i++) {
		var c = s.charAt(i);
		if (!((c >= "0") && (c <= "9"))) return false;
	}
	return true;
}

function onGridShowClick(fname)
{
	var f = document.forms[fname];
	var sUrl = f.gpUrl.value;
	var nRowsCount = f.gpRows.value;
	var nStartFrom = f.gpFrom.value;
	var nRowsTotal = f.gpTotal.value;
	if (!isPositiveInt (nRowsCount))
	{
		alert ("Rows count shoud be a valid integer");
		return;
	}
	if (!isPositiveInt (nStartFrom))
	{
		alert ("Start from shoud be a valid integer");
		return;
	}
	if (parseInt(nRowsCount) == 0)
	{
		alert ("Rows count shoud be non zero");
		return;
	}
	if (parseInt(nRowsCount) + parseInt(nStartFrom) > parseInt(nRowsTotal))
	{
		alert ("'Start row' + 'Rows to show' should be less than total rows");
		return;
	}
	sUrl += "&sr=" + nStartFrom + "&rows=" + nRowsCount;
	location.href = sUrl;
}

function onGridShowAllClick(fname)
{
	var f = document.forms[fname];
	var nRowsTotal = f.gpTotal.value;
	var choice = true;
	if (nRowsTotal > 25)
		choice = confirm ('You have selected to load '+nRowsTotal+' records into one screen view.\n  This may take several minutes, do you wish to proceed?');
	if (choice == true) {
		var sUrl = f.gpUrl.value;
		var nStartFrom = 0;
		var nRowsCount = f.gpTotal.value;
		if (parseInt(nRowsCount) == 0)
		{
			alert ("Rows count shoud be non zero");
			return;
		}
		sUrl += "&sr=" + nStartFrom + "&rows=" + nRowsCount;
		location.href = sUrl;
	}
}
//-->
//</script>
