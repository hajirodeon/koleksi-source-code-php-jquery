<?php
if (!isset ($img_dir))
	$img_dir = "img/";
$whfile = $inc_dir . "wh.js";
?>
<html>
<head>
	<meta name="description" content="">
	<meta name="keywords" content="">
	<meta name="robots" content="index,nofollow">
	<meta name="revisit-after" content="7 days">
	<meta http-equiv="cache-control" content="no-cache, must-revalidate">
	<meta http-equiv="pragma" content="no-cache">
	<meta http-equiv="expires" content="240">
	<link href="css/style.css" rel="styleSheet" type="text/css">
	<title><? echo $strTitle ?></title>
	<SCRIPT SRC="<? echo $whfile;?>"></SCRIPT>
</head>
<body bgcolor=<? echo $BODY_BGCOLOR;?> link=<? echo $BODY_LINK;?> alink=<? echo $BODY_ALINK;?> vlink=<? echo $BODY_VLINK;?> text=#000000 marginwidth=0 marginheight=0 leftmargin=0 topmargin=0 background="<? echo $img_dir;?>back.gif">
<table width=<? echo $MAINTABLE_WIDTH;?> border=<? echo $MAINTABLE_BORDER;?> cellpadding=<?php echo $MAINTABLE_CELLPADDING;?> cellspacing=<?php echo $MAINTABLE_CELLSPACING;?>>
<? include ($inc_dir . "header.inc.php") ?>
<tr><td valign="top">
	<table border="0" cellspacing="0" cellpadding="0" width="100%">
		<tr>
			<td width="1%"><SCRIPT LANGUAGE="JavaScript1.2">WriteWidth();</SCRIPT></td>
			<td  width="99%" valign="top"><? include ($leftmenu);?></td>
		</tr>
	</table>
	</td>
	<td valign=<? echo $CONTENTCOLUMN_VALIGN;?>><? include ($content_page);?></td>
</tr>
<? include ($inc_dir . "footer.inc.php") ?>
</table>
</body>
</html>