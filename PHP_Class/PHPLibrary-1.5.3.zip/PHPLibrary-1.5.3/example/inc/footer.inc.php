<tr><td bgcolor="#999999">&nbsp;</td>
	<td bgcolor="#cccccc" class="copy">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Copyright
	&copy; &reg; Softerra LLC 2000, 2001</td>
</tr>
