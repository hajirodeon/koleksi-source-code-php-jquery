<script src="<? echo $validfile; ?>"></script>

<script language="JavaScript">

function checkForm (form)
{
	if (!isInteger(form.user_id.value))
	{
		alertInput (form.user_id, "User PIN must be integer");
		return false;
	}

	if (form.user_name.value.length < 3)
	{
		alertInput (form.user_name, "The user login must be more than 3 characters.");
		return false;
	}

	var password = Trim(form.user_password.value);
	if (password.length == 0)
	{
		alertInput (form.user_password, "Plase enter the user password");
		return false;
	}

	if (!isEmail(form.user_email.value))
	{
		alertInput (form.user_email, "Please enter a valid email");
		return false;
	}

	value = form.user_fetch_count.value;
	if (!isInteger(value) || value < 2 || value > 30)
	{
		alertInput (form.user_fetch_count, "Plase enter correct grid's rows count.\nMust be between 2 and 30");
		return false;
	}

	return true;
}

</script>

<? if ($error == ERROR_UNKNOWNACTION): ?>
	<font class=error><b>&nbsp;Unknown action type: <em><? echo $mode ?></em></b></font>
<? elseif ($error == ERROR_WRONGPARAMS): ?>
	<font class=error><b>&nbsp;Wrong parameters were passed!</b></font>
<? elseif ($error == ERROR_SQLQUERY): ?>
	<font class=error><b>&nbsp;An error occured while executing query!</b></font>
<? elseif ($error == ERROR_INSERT): ?>
	<font class=error><b>&nbsp;An error occured while insert data!</b></font>
<? elseif ($error == ERROR_UPDATE): ?>
	<font class=error><b>&nbsp;An error occured while update data!</b></font>
<? elseif ($error == ERROR_USEREXISTS): ?>
	<font class=error><b>&nbsp;User <em><? echo $user_name ?></em> already exists</b></font>
<? elseif ($error == ERROR_TRY_DELETE_ADMIN): ?>
	<font class=error><b>&nbsp;Superuser cannot be deleted!</b></font>
<? $error = ""; ?>
<? elseif ($error == ERROR_IDEXISTS): ?>
	<font class=error><b>&nbsp;User with ID = <em><? echo $user_id ?></em> already exists</b></font>
<?	$error = ""; ?>
<? endif ?>

<? if (!$error): ?>

<form action="useredit.php" method="post" onsubmit="return checkForm (this)">

<table width="100%" cellspacing="0" cellpadding="2">
<tr>
	<td width="1%" align="left"><img src="<? echo $img_dir; ?>menua.gif"></td>
	<td class="big" colspan="2"><? if ($mode == 'update') echo "Edit user. (PIN: " . $users[USER_ID] . ")"; else echo "Add new user";?></td>
</tr>
</table>
<table width="100%" border="0" cellspacing="2" cellpadding="4">
	<? if ($mode != 'update'): ?>
	<tr>
		<td width="13%" class="basetext">PIN</td>
		<td width="87%" bgcolor="#CCCCCC">
			<input type="text" name="user_id" value="<? echo $users[USER_ID] ;?>" size="9" maxlength="9">
		</td>
	</tr>
	<? else: ?>
		<input type="hidden" name="user_id" value="<? echo $users[USER_ID]; ?>">
	<? endif ?>
	<tr>
		<td width="13%" class="basetext" nowrap>Login name</td>
		<td width="87%" bgcolor="#CCCCCC">
			<input type="text" name="user_name" size="32" maxlength="32" value="<? echo $users[USER_NAME];?>">
		</td>
	</tr>
	<tr>
	<td width="13%" class="basetext">Password</td>
	<td width="87%" bgcolor="#CCCCCC">
		<input type="text" name="user_password" value="<? echo htmlspecialchars ($users[USER_PASSWORD]); ?>" size="32" maxlength="16">
	</td>
</tr>
<tr>
		<td width="13%" class="basetext">Description</td>
		<td width="87%" bgcolor="#CCCCCC">
			<input type="text" name="user_description" size="32" maxlength="128" value="<? echo htmlspecialchars ($users[USER_DESCRIPTION]); ?>">
		</td>
	</tr>
	<tr>
		<td width="13%" class="basetext">Email</td>
		<td width="87%" bgcolor="#CCCCCC">
			<input type="text" name="user_email" size="32" maxlength="64" value="<? echo htmlspecialchars ($users[USER_EMAIL]) ;?>">
		</td>
	</tr>
	<tr>
		<td width="13%" class="basetext">Grid's rows count</td>
		<td width="87%" bgcolor="#CCCCCC">
			<input type="text" name="user_fetch_count" size="9" maxlength="9" value="<? echo $users[USER_FETCH_COUNT];?>">
		</td>
	</tr>
	<tr>
		<td width="13%" class="basetext">Enabled ?</td>
		<td width="87%" bgcolor="#CCCCCC" class="bt">
<?php
	if (!isset ($users) || ($users[USER_ENABLED] == 'yes')) {
		$yesradio = "checked";
		$noradio = "";
	}
	else {
		$yesradio = "";
		$noradio = "checked";
	}
?>
			<input type="radio" name="user_enabled" value="yes" class="radiob" <? echo $yesradio;?>>Yes
			<input type="radio" name="user_enabled" value="no" class="radiob" <? echo $noradio;?>>No
		</td>
	</tr>
	<tr>
		<td align="center" colspan="2">
		<input type="submit" name="submBtn" value="Submit" class="bt">
		&nbsp;&nbsp;&nbsp;
		<input type="reset" name="resBtn" value="Reset" class="bt">
		</td>
	</tr>
</table>
<input type="hidden" name="action" value="<? echo $mode ?>">
<? if ($mode == "update") echo '<input type="hidden" name="uname" value="'.$users[USER_NAME].'">';?>
<input type="hidden" name="urlvars" value="<? echo urlencode($referer_uri[1]);?>">
</form>
<? endif ?>

