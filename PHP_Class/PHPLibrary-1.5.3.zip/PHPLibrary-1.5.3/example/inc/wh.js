<!--
function WriteWidth() {
	if (window.innerHeight == null) wh = document.body.clientHeight; 
	else wh = window.innerHeight;

	if (navigator.appName == "Netscape") wh = wh - 99;
	else wh = wh - 99; // Explorer

	document.write('<img src="img/sp.gif" width="1" height="'+wh+'">');
}
//-->
