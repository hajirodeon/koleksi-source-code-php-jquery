<table width="100%" cellspacing="0" cellpadding="2">
<tr>
	<td width="1%" align="left"><img src="<? echo $img_dir; ?>menua.gif"></td>
	<td class="big" colspan="2">Users</td>
	<td width="1%" align="right" nowrap><a href="useredit.php?mode=insert">Add a new user</a></td>
</tr>
<? if (isset($error) && $error == ERROR_TRY_DELETE_ADMIN): ?>
	<tr><td class="error" colspan="3">&nbsp;Superuser cannot be deleted!</td></tr>
<? endif ?>
</table>
<form name="Users">
<? $grid->renderGrid(); ?>
</form>
