#
# Table structure for table 'DEPARTMENTS'
#

CREATE TABLE DEPARTMENTS (
   DEPARTMENT_ID int(11) NOT NULL auto_increment,
   USER_ID int(11) DEFAULT '0' NOT NULL,
   DEPARTMENT_NAME varchar(32) NOT NULL,
   PARENT_DEPARTMENT int(11) DEFAULT '0' NOT NULL,
   PRIMARY KEY (DEPARTMENT_ID),
   KEY INDX_PARENT_DEPARTMENT (PARENT_DEPARTMENT)
);
		  
#
# Dumping data for table 'DEPARTMENTS'
#

INSERT INTO DEPARTMENTS VALUES ( '1', '2', 'First Dep', '0');
INSERT INTO DEPARTMENTS VALUES ( '2', '2', 'SecondDeptartment', '0');
INSERT INTO DEPARTMENTS VALUES ( '3', '2', '0', '1');
INSERT INTO DEPARTMENTS VALUES ( '4', '2', '1', '1');
INSERT INTO DEPARTMENTS VALUES ( '5', '2', '0', '2');
INSERT INTO DEPARTMENTS VALUES ( '6', '2', '1', '2');
INSERT INTO DEPARTMENTS VALUES ( '7', '2', '2', '2');

#
# Table structure for table 'EQUIPMENT'
#

CREATE TABLE EQUIPMENT (
   EQUIPMENT_ID int(11) DEFAULT '0' NOT NULL,
   USER_ID int(11) DEFAULT '0' NOT NULL,
   DEPARTMENT_ID int(11) DEFAULT '0' NOT NULL,
   VEHICLE_ID varchar(32) NOT NULL,
   VEHICLE_DESCRIPTION varchar(32),
   CURRENT_ODOMETER int(11) DEFAULT '0' NOT NULL,
   PRIMARY KEY (EQUIPMENT_ID)
);
#
# Dumping data for table 'EQUIPMENT'
#

INSERT INTO EQUIPMENT VALUES ( '1', '2', '4', 'MERSedes_IS_very_COOL_car_do_you', '600_600_600_600_600_600', '300000');
INSERT INTO EQUIPMENT VALUES ( '2', '2', '2', 'TRACTOR', 'Very, very big device....', '235');

#
# Table structure for table 'MAINTENANCE'
#

CREATE TABLE MAINTENANCE (
   USER_ID int(11) DEFAULT '0' NOT NULL,
   PRODUCT_ID int(11) DEFAULT '0' NOT NULL,
   MAINTENANCE_PROCEDURE varchar(255),
   PRIMARY KEY (USER_ID, PRODUCT_ID)
);

#
# Dumping data for table 'MAINTENANCE'
#

INSERT INTO MAINTENANCE VALUES ( '2', '2703', 'asdasdasdasdasd');
INSERT INTO MAINTENANCE VALUES ( '2', '1890', '234623asdfasdf');

#
# Table structure for table 'PRODUCTS'
#

CREATE TABLE PRODUCTS (
   PRODUCT_ID int(11) DEFAULT '0' NOT NULL,
   PRODUCT_NAME varchar(64) NOT NULL,
   PRODUCT_TYPE enum('maintenance','fuel') DEFAULT 'maintenance' NOT NULL,
   PRIMARY KEY (PRODUCT_ID),
   KEY INDX_PRODUCT_TYPE (PRODUCT_TYPE)
);

#
# Dumping data for table 'PRODUCTS'
#

INSERT INTO PRODUCTS VALUES ( '1', 'Premium2', 'fuel');
INSERT INTO PRODUCTS VALUES ( '2', 'Prod #2', 'maintnance');
INSERT INTO PRODUCTS VALUES ( '3', 'Unleaded P', 'fuel');
INSERT INTO PRODUCTS VALUES ( '4', 'Diesel', 'fuel');
INSERT INTO PRODUCTS VALUES ( '5', 'Alt Fuel', 'fuel');
INSERT INTO PRODUCTS VALUES ( '7', 'Methanol', 'fuel');

#
# Table structure for table 'REGISTRY'
#

CREATE TABLE REGISTRY (
   REGKEY varchar(255) NOT NULL,
   VALUE text NOT NULL,
   PRIMARY KEY (REGKEY)
);

#
# Dumping data for table 'REGISTRY'
#

INSERT INTO REGISTRY VALUES ( 'RegEdit', 's:11:"regedit.php";');
INSERT INTO REGISTRY VALUES ( 'RegEdit/Interface', '');
INSERT INTO REGISTRY VALUES ( 'RegEdit/Interface/BODY', '');
INSERT INTO REGISTRY VALUES ( 'RegEdit/Interface/BODY/bgcolor', 's:6:"eeeeee";');
INSERT INTO REGISTRY VALUES ( 'RegEdit/Interface/BODY/link', 's:4:"blue";');
INSERT INTO REGISTRY VALUES ( 'RegEdit/Interface/BODY/vlink', 's:4:"blue";');
INSERT INTO REGISTRY VALUES ( 'RegEdit/Interface/BODY/alink', 's:4:"blue";');
INSERT INTO REGISTRY VALUES ( 'RegEdit/Interface/MAIN_TABLE', '');
INSERT INTO REGISTRY VALUES ( 'RegEdit/Interface/MAIN_TABLE/width', 'i:620;');
INSERT INTO REGISTRY VALUES ( 'RegEdit/Interface/MAIN_TABLE/border', 'i:0;');
INSERT INTO REGISTRY VALUES ( 'RegEdit/Interface/MAIN_TABLE/align', 's:6:"center";');
INSERT INTO REGISTRY VALUES ( 'RegEdit/Interface/MAIN_TABLE/bgcolor', 's:6:"eeeeee";');
INSERT INTO REGISTRY VALUES ( 'RegEdit/Interface/MAIN_TABLE/cellspacing', 'i:2;');
INSERT INTO REGISTRY VALUES ( 'RegEdit/Interface/MAIN_TABLE/cellpadding', 'i:0;');
INSERT INTO REGISTRY VALUES ( 'RegEdit/Interface/VIEW_TABLE', '');
INSERT INTO REGISTRY VALUES ( 'RegEdit/Interface/VIEW_TABLE/width', 's:4:"100%";');
INSERT INTO REGISTRY VALUES ( 'RegEdit/Interface/VIEW_TABLE/border', 'i:0;');
INSERT INTO REGISTRY VALUES ( 'RegEdit/Interface/VIEW_TABLE/cellspacing', 'i:1;');
INSERT INTO REGISTRY VALUES ( 'RegEdit/Interface/VIEW_TABLE/cellpadding', 'i:0;');
INSERT INTO REGISTRY VALUES ( 'RegEdit/Interface/VIEW_TABLE/bgcolor', 's:6:"999999";');
INSERT INTO REGISTRY VALUES ( 'RegEdit/Interface/COLOR', '');
INSERT INTO REGISTRY VALUES ( 'RegEdit/Interface/COLOR/Path', 's:6:"7AA0E9";');
INSERT INTO REGISTRY VALUES ( 'RegEdit/Interface/COLOR/Caption', 's:6:"000099";');
INSERT INTO REGISTRY VALUES ( 'RegEdit/Interface/COLOR/Editor', 's:6:"e0e0e0";');
INSERT INTO REGISTRY VALUES ( 'RegEdit/Strings', '');
INSERT INTO REGISTRY VALUES ( 'FMWC/Settings/ServerSide/Weekly/DeleteFilesAfterProcessing', 'b:0;');
INSERT INTO REGISTRY VALUES ( 'RegEdit/Strings/Root', 's:2:"..";');
INSERT INTO REGISTRY VALUES ( 'FMWC', 's:38:"Fleet Managers Web Console Application";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Settings', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Reports', 's:29:"Predefined reports (for user)";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Users/Columns', 'i:5;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Reports/Columns/Default/BodyAttributes', 's:10:"class="bt"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TransError/Columns/2', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TransError/Columns/0/TitleAttributes', 's:42:"class="basetext" align="center" width="1%"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Reports/Columns/Default/TitleAttributes', 's:31:"class="basetext" align="center"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Reports/Columns/0/Title', 's:11:"Report name";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Reports/Columns', 'i:1;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Reports/Columns/Default', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Reports/Columns/Default/Title', 's:6:"&nbsp;";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Reports/Columns/0', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Settings/ServerSide', 's:29:"Server side programs settings";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Settings/ServerSide/Weekly', 's:22:"Weekly script settings";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Settings/ServerSide/Daily', 's:21:"Daily script settings";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Settings/ServerSide/Common', 's:15:"Common settings";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Settings/ServerSide/Common/adminEmail', 's:16:"h2o@softerra.com";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Settings/ServerSide/Common/transactionsTTL', 'i:120;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Settings/Defaults/UserLogsTTL', 'i:120;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Settings/Defaults', 's:18:"Default parameters";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Settings/ServerSide/Daily/NotificationMessageHeader', 's:23:"Hello
it is time to do";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Logs/Columns/0/BodyAttributes', 's:28:"width="1%" class="st" nowrap";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Settings/Defaults/UserLogFlags', 'i:63;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABT/Columns/2', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABT/Columns/2/Title', 's:14:"Notify through";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABT/Rows/1', 's:15:"bgcolor=#eeeeee";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABT/Table/Attributes', 's:86:"width="99%" border="0" cellspacing="1" cellpadding="2" bgcolor="999999" align="center"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABT/Table', 's:10:"main table";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABT/Rows/0', 's:15:"bgcolor=#dddddd";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABT/Rows', 's:27:"Even and odd row properties";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABT/Navigator/RightCell', 's:35:"align="right" width="1%" class="st"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABT/Navigator/LeftCell', 's:34:"align="left" width="1%" class="st"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Settings/ServerSide/Daily/NotificationSubject', 's:32:"The maintenance date is comming.";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABT/Navigator/CenterCell', 's:37:"align="center" width="99%" class="st"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABT/Navigator', 's:15:"Navigator table";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABT/ExtraColumns/RightExtra', 's:16:"class="basetext"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABT/ExtraColumns/Default/BodyAttributes', 's:39:"width="1%" class="st" bgcolor="#bfcff0"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABT/ExtraColumns/Default/TitleAttributes', 's:42:"width="1%" class="basetext" align="center"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABT/ExtraColumns/Default', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABT/ExtraColumns/1/Variables', 's:28:"EQUIPMENT_ID,ADDRESS_BOOK_ID";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABT/ExtraColumns/1/Type', 's:5:"Right";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABT/ExtraColumns/1/TextPattern', 's:141:"<a href="abequip.php?mode=delete&eqid=%d&abid=%d&go=alert" onclick="if (confirm(''Are you sure?'')) return true; else return false;">delete</a>";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABT/ExtraColumns/1', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABT/ExtraColumns/0/Variables', 's:28:"EQUIPMENT_ID,ADDRESS_BOOK_ID";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABT/ExtraColumns/0/Type', 's:5:"Right";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABT/ExtraColumns/0/TextPattern', 's:67:"<a href="abequip.php?mode=update&eqid=%d&abid=%d&go=alert">edit</a>";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABT/ExtraColumns/0', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABT/ExtraColumns', 'i:2;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABT/Columns/RightExtra', 's:16:"class="basetext"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABT/Columns/Default/TitleAttributes', 's:31:"class="basetext" align="center"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABT/Columns/Default/Title', 's:6:"&nbsp;";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABT/Columns/Default/BodyAttributes', 's:10:"class="st"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/ExtraColumns/1', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/ExtraColumns/1/Variables', 's:12:"TASK_OVERDUE";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Settings/ServerSide/Common/feedbackEmail', 's:34:"FWMC Manager <kirill@softerra.com>";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Settings/ServerSide/Daily/ReportSubject', 's:23:"Daily processing report";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/ExtraColumns/1/Type', 's:5:"Right";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Queries/EQUIPMENT_VEHICLE_DESCRIPTION/USER', 'b:1;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/ExtraColumns/1/TextPattern', 's:42:"<img src="/img/%s" width="24" height="20">";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/ExtraColumns/2', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/ExtraColumns/2/TextPattern', 's:42:"<img src="/img/%s" width="24" height="20">";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/ExtraColumns/2/Type', 's:5:"Right";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/ExtraColumns/2/Variables', 's:15:"ERRORS_DETECTED";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABT/Columns/0/Title', 's:7:"Vehicle";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Queries/EQUIPMENT_VEHICLE_DESCRIPTION/VAL', 'i:0;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Queries/EQUIPMENT_VEHICLE_DESCRIPTION', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Vehicles/ExtraColumns/0', '');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABT/Columns/Default', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABT/Columns/1/Title', 's:11:"Description";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AB/ExtraColumns/2/Type', 's:5:"Right";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABT/Columns/1', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AB/ExtraColumns/2/Variables', 's:15:"ADDRESS_BOOK_ID";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AB/ExtraColumns/2/TextPattern', 's:55:"<a href="addrbookedit.php?mode=update&abid=%d">edit</a>";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABMaps/ExtraColumns/1/TextPattern', 's:132:"<a href="abedit.php?mode=delete&depid=%d&abid=%d" onclick="if (confirm(''Are you sure?'')) return true; else return false;">delete</a>";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Reports/ExtraColumns/Default/TitleAttributes', 's:42:"class="basetext" align="center" width="1%"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminReports/Columns/Default/TitleAttributes', 's:31:"class="basetext" align="center"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminReports/Navigator/Attributes', 's:44:"width="100%" cellspacing="0" cellpadding="2"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABT/Navigator/Attributes', 's:44:"width="100%" cellspacing="0" cellpadding="2"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminReports/Navigator/CenterCell', 's:37:"align="center" width="99%" class="st"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Settings/ServerSide/Weekly/FilesPath', 's:49:"/mnt/storage/projects/fleet/apps/checkmaint/data/";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Settings/ServerSide/Weekly/Errors/OpenDirectory', 's:24:"Can''t open directory: %s";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Settings/ServerSide/Weekly/Errors', 's:15:"Errors Messages";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Settings/ServerSide/Weekly/Errors/OpenFile', 's:65:"Cant open the file%s. Please check file name or program settings.";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Settings/ServerSide/Weekly/Errors/OpenFileSubject', 's:26:"Weekly processing faild!!!";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminReports/Table', 's:10:"main table";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Logs/Columns/3/BodyAttributes', 's:15:"class="st" wrap";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Reports/Rows/1', 's:17:"bgcolor="#eeeeee"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminReports/ExtraColumns/RightExtra', 's:16:"class="basetext"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminReports/Navigator', 's:15:"Navigator table";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Reports/ExtraColumns/RightExtra', 's:16:"class="basetext"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Reports/Rows/0', 's:17:"bgcolor="#dddddd"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminReports/Columns/Default', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminReports/Columns/Default/BodyAttributes', 's:10:"class="st"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Reports/Table/Attributes', 's:86:"width="99%" border="0" cellspacing="1" cellpadding="2" bgcolor="999999" align="center"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Reports/ExtraColumns/0/TextPattern', 's:40:"<a href="runreport.php?rname=%s">run</a>";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Reports/ExtraColumns', 'i:2;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Reports/ExtraColumns/0/Type', 's:5:"Right";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Reports/ExtraColumns/0', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminReports/ExtraColumns/Default/TitleAttributes', 's:42:"class="basetext" align="center" width="1%"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminReports/Table/Attributes', 's:86:"width="99%" border="0" cellspacing="1" cellpadding="2" bgcolor="999999" align="center"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Reports/ExtraColumns/0/Variables', 's:11:"REPORT_NAME";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Reports/Navigator', 's:15:"Navigator table";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TransError/Columns/2/Title', 's:6:"VEH_ID";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Reports/ExtraColumns/Default', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Reports/Navigator/Attributes', 's:44:"width="100%" cellspacing="0" cellpadding="2"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TransError/Columns/2/BodyAttributes', 's:40:"class="st" align="left" width="1" nowrap";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Reports/ExtraColumns/Default/BodyAttributes', 's:39:"width="1%" class="bt" bgcolor="#bfcffo"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Reports/Navigator/CenterCell', 's:37:"align="center" width="99%" class="bt"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Reports/Navigator/LeftCell', 's:34:"align="left" width="1%" class="st"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Reports/Navigator/RightCell', 's:35:"align="right" width="1%" class="bt"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Reports/Rows', 's:27:"Even and odd row properties";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Reports/Table', 's:10:"main table";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminReports', 's:34:"Administrator - predefined reports";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminReports/Columns', 'i:1;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminReports/Columns/0', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminReports/Columns/0/Title', 's:11:"Report name";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminReports/Columns/Default/Title', 's:6:"&nbsp;";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminReports/Columns/RightExtra', 's:16:"class="basetext"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminReports/ExtraColumns', 'i:1;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminReports/ExtraColumns/0', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminReports/ExtraColumns/0/TextPattern', 's:58:"<a href="predefrun.php?mode=update&uid=0&repid=%d">run</a>";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminReports/ExtraColumns/0/Type', 's:5:"Right";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminReports/ExtraColumns/0/Variables', 's:9:"REPORT_ID";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Reports/ExtraColumns/1', '');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Reports/ExtraColumns/1/Type', 's:5:"Right";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminReports/ExtraColumns/Default', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminReports/ExtraColumns/Default/BodyAttributes', 's:39:"width="1%" class="st" bgcolor="#bfcff0"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminReports/Navigator/RightCell', 's:35:"align="right" width="1%" class="st"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminReports/Rows', 's:27:"Even and odd row properties";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminReports/Rows/0', 's:17:"bgcolor="#dddddd"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminReports/Rows/1', 's:17:"bgcolor="#eeeeee"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminReports/Navigator/LeftCell', 's:34:"align="left" width="1%" class="st"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/ExtraColumns/1', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/ExtraColumns/2/TextPattern', 's:56:"<a href="scheduledit.php?action=edit&taskID=%d">edit</a>";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/ExtraColumns/1/Type', 's:5:"Right";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/ExtraColumns/1/TextPattern', 's:45:"<a href="tasks.php?taskID=%d">association</a>";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AB/ExtraColumns/2', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABT/Columns', 'i:3;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABT/Columns/0', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABT', 's:32:"Alert/equipment association grid";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Users/ExtraColumns/RightExtra', 's:16:"class="basetext"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Users/ExtraColumns/LeftExtra', 's:16:"class="basetext"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Users/ExtraColumns/Default/TitleAttributes', 's:36:"class="bt" align="center" width="1%"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Reports/ExtraColumns/1/TextPattern', 's:56:"<a href="reportedit.php?rname=%s&mode=delete">delete</a>";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Users/ExtraColumns/Default/BodyAttributes', 's:53:"class="st" align="left" width="1%"  bgcolor="#bfcffo"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Users/Columns/1/BodyAttributes', 's:22:"class="st" width="96%"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Users/ExtraColumns/Default', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Reports/Columns/RightExtra', 's:16:"class="basetext"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Queries/EQUIPMENT_VEHICLE_DESCRIPTION/TXT', 'i:0;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Queries/EQUIPMENT_VEHICLE_DESCRIPTION/QUERY', 's:58:"SELECT VEHICLE_DESCRIPTION FROM EQUIPMENT WHERE USER_ID=%d";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Users/ExtraColumns/1/Variables', 's:7:"USER_ID";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Users/ExtraColumns/1/Type', 's:5:"Right";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Users/Columns/2/BodyAttributes', 's:28:"class="st" width="1%" nowrap";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Users/ExtraColumns/1/TextPattern', 's:124:"<a href="useredit.php?mode=delete&uid=%d" onclick="if (confirm(''Are you sure?'')) return true; else return false;">Delete</a>";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Users/ExtraColumns/0/Variables', 's:7:"USER_ID";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Users/ExtraColumns/1', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Settings/ServerSide/Weekly/ReportSubject', 's:24:"Weekly processing report";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Users/ExtraColumns/0/Type', 's:5:"Right";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Settings/ServerSide/Weekly/NotificationMessageHeader', 's:25:"Hello, it is time to do  ";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Settings/ServerSide/Weekly/NotificationSubject', 's:21:"The event was happend";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Users/Columns/4/Title', 's:7:"Enabled";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Users/Columns/4/BodyAttributes', 's:21:"class="st" width="1%"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Users/Table/Attributes', 's:86:"width="99%" border="0" cellspacing="1" cellpadding="2" bgcolor="999999" align="center"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Users/Table', 's:10:"main table";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Users/ExtraColumns/0/TextPattern', 's:49:"<a href="useredit.php?mode=update&uid=%d">Edit</>";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Users/ExtraColumns/0', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Users/Navigator/RightCell', 's:35:"align="right" width="1%" class="st"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Users/Navigator/LeftCell', 's:34:"align="left" width="1%" class="st"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Users/Navigator/CenterCell', 's:37:"align="center" width="99%" class="st"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Users/Navigator/Attributes', 's:45:"width="100%" cellspacing="0"  cellpadding="2"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Users/Navigator', 's:15:"Navigator table";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Users/ExtraColumns', 'i:2;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Users/Columns/Default/TitleAttributes', 's:31:"class="basetext" align="center"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Users/Columns/Default/Title', 's:6:"&nbsp;";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Users/Columns/Default/BodyAttributes', 's:10:"class="st"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Users/Columns/Default', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Users/Columns/3/Title', 's:10:"Last login";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Users/Columns/3/BodyAttributes', 's:28:"class="st" width="1%" nowrap";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Users/Columns/3', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Users/Columns/2/Title', 's:5:"Email";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Users/Columns/2', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Users/Columns/1/Title', 's:11:"Description";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Users/Columns/4', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Users/Columns/1', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Users/Columns/0/Title', 's:5:"Login";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Users/Columns/0/BodyAttributes', 's:21:"class="st" width="1%"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Users/Columns/0', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule', 's:10:"Tasks grid";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/Columns', 'i:7;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/ExtraColumns/3/Variables', 's:7:"TASK_ID";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/ExtraColumns/3/Type', 's:5:"Right";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/Columns/1/BodyAttributes', 's:33:"class="st" align="left" width="1"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/Columns/3/BodyAttributes', 's:23:"class="st" align="left"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/Columns/3', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/Columns/1/Title', 's:4:"TASK";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/Columns/1', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/Columns/1/TitleAttributes', 's:42:"class="basetext" align="center" width="1%"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/Columns/2', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/Columns/2/TitleAttributes', 's:31:"class="basetext" align="center"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/Columns/2/Title', 's:5:"MCODE";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/Columns/2/BodyAttributes', 's:23:"class="st" align="left"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/ExtraColumns/3/TextPattern', 's:132:"<a href="scheduledit.php?action=delete&taskID=%d" onclick="if (confirm(''Are you sure?'')) return true; else return false;">delete</a>";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/Columns/1/BodyAttributes', 's:40:"class="st" align="left" width="1" nowrap";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/Columns/1', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/Columns/Default', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/Columns/Default/BodyAttributes', 's:23:"class="bt" align="left"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/Columns/Default/Title', 's:8:"Column #";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/Columns/Default/TitleAttributes', 's:31:"class="basetext" align="center"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/ExtraColumns', 'i:4;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/ExtraColumns/1/Variables', 's:11:"SCHEDULE_ID";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/ExtraColumns/2/Type', 's:5:"Right";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/ExtraColumns/2/Variables', 's:11:"SCHEDULE_ID";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Prods/Columns/1/Title', 's:4:"Name";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Prods/Columns/Default/BodyAttributes', 's:10:"class="st"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Prods', 's:29:"Administrator - products grid";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Prods/Columns/0', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Prods/Columns', 'i:3;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Prods/Columns/Default', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Prods/Columns/Default/Title', 's:6:"&nbsp;";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Prods/Columns/0/Title', 's:4:"Code";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Prods/Columns/1', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/ExtraColumns/Default', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/ExtraColumns/Default/BodyAttributes', 's:54:"class="nt" align="center" width="1%" bgcolor="#cccccc"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/ExtraColumns/Default/TitleAttributes', 's:36:"class="bt" align="center" width="1%"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/Navigator', 's:15:"Navigator table";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/Navigator/Attributes', 's:44:"width="100%" cellspacing="0" cellpadding="2"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/Navigator/CenterCell', 's:37:"align="center" width="99%" class="st"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/Navigator/LeftCell', 's:34:"class="st" align="left" width="1%"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/Navigator/RightCell', 's:35:"align="right" width="1%" class="st"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/Rows', 's:27:"Even and odd row properties";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/Rows/0', 's:17:"bgcolor="#dddddd"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/Rows/1', 's:17:"bgcolor="#eeeeee"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/Table', 's:10:"main table";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/Table/Attributes', 's:88:"width="99%" border="0" cellspacing="1" cellpadding="2" bgcolor="999999" align="center"
";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/ExtraColumns/3/Variables', 's:11:"SCHEDULE_ID";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/ExtraColumns/3', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/ExtraColumns/3/Type', 's:5:"Right";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/Columns/1/Title', 's:11:"Description";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/Columns/2', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/Columns/1/TitleAttributes', 's:42:"class="basetext" align="center" width="1%"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/ExtraColumns/2', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/Columns/6/BodyAttributes', 's:23:"class="st" align="left"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/Columns/4/TitleAttributes', 's:31:"class="basetext" align="center"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/Columns/6', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/Columns/4/Title', 's:7:"Uncompl";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/Columns/6/Title', 's:6:"Errors";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminLogs/Navigator/RightCell', 's:35:"align="right" width="1%" class="st"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/Columns/6/TitleAttributes', 's:31:"class="basetext" align="center"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Vehicles/ExtraColumns/0/TextPattern', 's:42:"<img src="/img/%s" width="24" height="20">";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Vehicles/ExtraColumns/0/Type', 's:5:"Right";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Vehicles/ExtraColumns/0/Variables', 's:15:"ASSIGNED_EVENTS";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminLogs/Navigator/LeftCell', 's:34:"align="left" width="1%" class="st"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/ExtraColumns/LeftExtra', 's:16:"class="basetext"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/ExtraColumns/RightExtra', 's:16:"class="basetext"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminLogs/Navigator/CenterCell', 's:37:"align="center" width="99%" class="st"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Settings/ServerSide/Weekly/Errors/ChangeDirectory', 's:26:"Can''t change directory: %s";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/Columns/4/BodyAttributes', 's:23:"class="st" align="left"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/Columns/4', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Queries/MAINTENANC_MAINTENANCE_PROCEDURE/TXT', 'i:0;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Queries/MAINTENANC_MAINTENANCE_PROCEDURE/QUERY', 's:184:"SELECT  MAINTENANCE.MAINTENANCE_PROCEDURE FROM MAINTENANCE,  PRODUCTS, USERS WHERE USERS.USER_ID=MAINTENANCE.USER_ID AND MAINTENANCE.PRODUCT_ID=PRODUCTS.PRODUCT_ID AND USERS.USER_ID=%d";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Queries/MAINTENANC_MAINTENANCE_PROCEDURE', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Queries/MAINTENANC_MAINTENANCE_PROCEDURE/USER', 'b:1;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Queries/MAINTENANCE_MAINTENANCE_PROCEDURE/TXT', 'i:0;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Queries/MAINTENANCE_MAINTENANCE_PROCEDURE/USER', 'b:1;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Queries/MAINTENANCE_MAINTENANCE_PROCEDURE/VAL', 'i:0;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminLogs/Rows', 's:27:"Even and odd row properties";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminLogs/Rows/0', 's:17:"bgcolor="#dddddd"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminLogs/Rows/1', 's:17:"bgcolor="#eeeeee"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminLogs/Columns/4/Title', 's:4:"User";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminLogs/Columns/4', 's:5:"Title";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/Columns/5/BodyAttributes', 's:23:"class="st" align="left"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/Columns/5/Title', 's:7:"Overdue";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/Columns/5/TitleAttributes', 's:31:"class="basetext" align="center"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminLogs', 's:12:"Admin''s logs";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminLogs/Columns/0', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminLogs/Columns', 'i:5;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminLogs/Columns/1', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminLogs/Columns/1/Title', 's:5:"Level";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminLogs/Columns/3', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminLogs/Columns/2', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminLogs/Columns/2/Title', 's:8:"Facility";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminLogs/Columns/3/BodyAttributes', 's:15:"class="st" wrap";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminLogs/Columns/3/Title', 's:7:"Message";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminLogs/Columns/Default/BodyAttributes', 's:10:"class="st"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminLogs/Columns/Default', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminLogs/Columns/Default/Title', 's:6:"&nbsp;";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminLogs/Columns/Default/TitleAttributes', 's:31:"class="basetext" align="center"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminLogs/ExtraColumns', 'i:0;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminLogs/Navigator', 's:15:"Navigator table";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminLogs/Navigator/Attributes', 's:45:"width="100%" cellspacing="0"  cellpadding="2"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminLogs/Columns/0/Title', 's:9:"Date Time";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminLogs/Columns/0/BodyAttributes', 's:28:"width="1%" class="st" nowrap";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Vehicles', 's:14:"Equipment grid";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Vehicles/Columns', 'i:6;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Vehicles/Columns/0', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Vehicles/Columns/0/Title', 's:2:"ID";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Vehicles/Columns/1', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Vehicles/Columns/1/Title', 's:11:"Description";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Vehicles/Columns/2', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Vehicles/Columns/2/Title', 's:10:"Department";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Vehicles/Columns/Default', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Vehicles/Columns/Default/BodyAttributes', 's:10:"class="st"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Vehicles/Columns/Default/Title', 's:6:"&nbsp;";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Vehicles/Columns/Default/TitleAttributes', 's:31:"class="basetext" align="center"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Vehicles/Rows/0', 's:16:"bgcolor="dddddd"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Vehicles/ExtraColumns', 'i:3;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Vehicles/ExtraColumns/1', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Vehicles/ExtraColumns/1/TextPattern', 's:55:"<a href="vehicledit.php?mode=update&eqid=%d">events</a>";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Vehicles/ExtraColumns/1/Type', 's:5:"Right";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Vehicles/ExtraColumns/1/Variables', 's:12:"EQUIPMENT_ID";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Vehicles/ExtraColumns/2', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Vehicles/ExtraColumns/2/Type', 's:5:"Right";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Vehicles/ExtraColumns/2/Variables', 's:12:"EQUIPMENT_ID";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Vehicles/ExtraColumns/2/TextPattern', 's:127:"<a href="vehicledit.php?mode=delete&eqid=%d" onclick="if (confirm(''Are you sure?'')) return true; else return false;">delete</a>";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Maints', 's:27:"User maintenance procedures";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Maints/Columns', 'i:2;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Vehicles/ExtraColumns/Default', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Vehicles/ExtraColumns/Default/BodyAttributes', 's:54:"width="1%" class="st" bgcolor="#bfcff0" align="center"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Vehicles/ExtraColumns/Default/TitleAttributes', 's:42:"class="basetext" align="center" width="1%"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Vehicles/ExtraColumns/RightExtra', 's:16:"class="basetext"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Vehicles/Navigator', 's:15:"Navigator table";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Vehicles/Navigator/Attributes', 's:44:"width="100%" cellspacing="0" cellpadding="2"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Vehicles/Navigator/CenterCell', 's:44:"align="center" width="49%" class="st" nowrap";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Vehicles/Navigator/LeftCell', 's:34:"align="left" width="1%" class="st"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Vehicles/Navigator/RightCell', 's:35:"align="right" width="1%" class="st"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Vehicles/Rows', 's:27:"Even and odd row properties";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Vehicles/Table', 's:10:"main table";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Vehicles/Table/Attributes', 's:86:"width="99%" border="0" cellspacing="1" cellpadding="2" bgcolor="999999" align="center"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Users', 's:26:"Administrator - users grid";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Vehicles/Columns/3', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Vehicles/Columns/3/Title', 's:6:"Subdep";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Vehicles/Columns/4', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Vehicles/Columns/4/Title', 's:8:"Odometer";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Vehicles/Columns/5', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Vehicles/Columns/5/Title', 's:5:"Hours";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Maints/Columns/0', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Maints/Columns/0/Title', 's:4:"Code";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Maints/Columns/1', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Maints/Columns/1/Title', 's:9:"Procedure";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AB/Columns/1', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AB/Columns/1/Title', 's:11:"Description";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Maints/Columns/Default', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Maints/Columns/Default/BodyAttributes', 's:10:"class="st"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Maints/Columns/Default/Title', 's:6:"&nbsp;";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Maints/Columns/Default/TitleAttributes', 's:31:"class="basetext" align="center"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Maints/Columns/RightExtra', 's:16:"class="basetext"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Maints/ExtraColumns', 'i:2;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Maints/ExtraColumns/0', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Maints/ExtraColumns/1/Variables', 's:10:"PRODUCT_ID";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Maints/ExtraColumns/1/Type', 's:5:"Right";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Maints/ExtraColumns/1', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Maints/ExtraColumns/0/Type', 's:5:"Right";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Maints/ExtraColumns/0/Variables', 's:10:"PRODUCT_ID";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Maints/ExtraColumns/0/TextPattern', 's:51:"<a href="maintedit.php?mode=update&pid=%d">edit</a>";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AB', 's:12:"Address book";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AB/Columns', 'i:2;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Maints/ExtraColumns/1/TextPattern', 's:125:"<a href="maintedit.php?mode=delete&pid=%d" onclick="if (confirm(''Are you sure?'')) return true; else return false;">delete</a>";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AB/Columns/0/Title', 's:9:"User name";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AB/Columns/0', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Maints/ExtraColumns/Default', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Maints/ExtraColumns/Default/BodyAttributes', 's:39:"width="1%" class="st" bgcolor="#bfcffo"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Maints/ExtraColumns/Default/TitleAttributes', 's:42:"class="basetext" align="center" width="1%"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Maints/ExtraColumns/RightExtra', 's:16:"class="basetext"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Maints/Navigator', 's:15:"Navigator table";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Maints/Navigator/Attributes', 's:44:"width="100%" cellspacing="1" cellpadding="2"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Maints/Navigator/CenterCell', 's:37:"align="center" width="99%" class="st"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Maints/Navigator/LeftCell', 's:34:"align="left" width="1%" class="st"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Maints/Navigator/RightCell', 's:35:"align="right" width="1%" class="st"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Maints/Rows', 's:27:"Even and odd row properties";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Maints/Rows/0', 's:17:"bgcolor="#dddddd"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Maints/Rows/1', 's:17:"bgcolor="#eeeeee"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Maints/Table', 's:10:"main table";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Maints/Table/Attributes', 's:86:"width="99%" border="0" cellspacing="1" cellpadding="2" bgcolor="999999" align="center"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AB/Columns/Default', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AB/Columns/Default/BodyAttributes', 's:10:"class="st"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AB/Columns/Default/Title', 's:6:"&nbsp;";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AB/Columns/Default/TitleAttributes', 's:31:"class="basetext" align="center"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AB/Columns/RightExtra', 's:16:"class="basetext"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AB/ExtraColumns', 'i:4;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AB/ExtraColumns/0', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AB/ExtraColumns/0/TextPattern', 's:45:"<a href="alertdeps.php?abid=%d">(sub)deps</a>";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AB/ExtraColumns/0/Type', 's:5:"Right";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AB/ExtraColumns/0/Variables', 's:15:"ADDRESS_BOOK_ID";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AB/ExtraColumns/1', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AB/ExtraColumns/1/Type', 's:5:"Right";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AB/ExtraColumns/1/Variables', 's:15:"ADDRESS_BOOK_ID";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AB/ExtraColumns/Default', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AB/ExtraColumns/Default/BodyAttributes', 's:39:"width="1%" class="st" bgcolor="#bfcffo"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AB/ExtraColumns/Default/TitleAttributes', 's:42:"class="basetext" align="center" width="1%"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AB/ExtraColumns/RightExtra', 's:16:"class="basetext"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AB/Navigator', 's:15:"Navigator table";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AB/Navigator/Attributes', 's:44:"width="100%" cellspacing="0" cellpadding="2"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AB/Navigator/CenterCell', 's:37:"align="center" width="99%" class="st"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AB/Navigator/LeftCell', 's:34:"align="left" width="1%" class="st"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AB/Navigator/RightCell', 's:35:"align="right" width="1%" class="st"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AB/Rows', 's:27:"Even and odd row properties";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AB/Rows/0', 's:17:"bgcolor="#dddddd"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AB/Rows/1', 's:17:"bgcolor="#eeeeee"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AB/Table', 's:10:"main table";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AB/Table/Attributes', 's:86:"width="99%" border="0" cellspacing="1" cellpadding="2" bgcolor="999999" align="center"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AB/ExtraColumns/1/TextPattern', 's:43:"<a href="alertequip.php?abid=%d">equips</a>";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Settings/Defaults/UserFetchCount', 'i:5;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Logs', 's:11:"User''s logs";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Logs/Columns', 'i:4;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Logs/Columns/0', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Logs/Columns/0/Title', 's:9:"Date Time";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Logs/Columns/1', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Logs/Columns/1/Title', 's:5:"Level";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Logs/Columns/Default', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Logs/Columns/Default/BodyAttributes', 's:10:"class="st"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Logs/Columns/Default/Title', 's:6:"&nbsp;";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Logs/Columns/Default/TitleAttributes', 's:31:"class="basetext" align="center"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Logs/Columns/2', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Logs/ExtraColumns', 'i:0;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Logs/Navigator', 's:15:"Navigator table";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Logs/Navigator/Attributes', 's:45:"width="100%" cellspacing="0"  cellpadding="2"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Logs/Navigator/CenterCell', 's:37:"align="center" width="99%" class="st"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Logs/Navigator/LeftCell', 's:34:"align="left" width="1%" class="st"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Logs/Navigator/RightCell', 's:35:"align="right" width="1%" class="st"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Logs/Rows', 's:27:"Even and odd row properties";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Logs/Rows/0', 's:17:"bgcolor="#dddddd"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Logs/Rows/1', 's:17:"bgcolor="#eeeeee"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Logs/Table', 's:10:"main table";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Logs/Table/Attributes', 's:86:"width="99%" border="0" cellspacing="1" cellpadding="2" bgcolor="999999" align="center"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Logs/Columns/2/Title', 's:8:"Facility";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Logs/Columns/3', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Logs/Columns/3/Title', 's:7:"Message";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Vehicles/Rows/1', 's:16:"bgcolor="eeeeee"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Users/Rows', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Users/Rows/0', 's:17:"bgcolor="#dddddd"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Users/Rows/1', 's:17:"bgcolor="#eeeeee"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Reports/ExtraColumns/1/Variables', 's:11:"REPORT_NAME";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/Columns/5', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TransError/Columns/2/TitleAttributes', 's:43:"class="basetext" align="center" width="10%"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/Columns/0/BodyAttributes', 's:33:"class="st" align="left" width="1"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/Columns/0/Title', 's:2:"ID";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/Columns/0/TitleAttributes', 's:42:"class="basetext" align="center" width="1%"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/Columns/0', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Helps/Columns', 'i:1;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Helps/ExtraColumns/RightExtra', 's:16:"class="basetext"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Helps', 's:31:"Administrator - help items grid";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Helps/Navigator', 's:15:"Navigator table";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Helps/ExtraColumns/Default/TitleAttributes', 's:42:"class="basetext" align="center" width="1%"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Helps/ExtraColumns/Default/BodyAttributes', 's:39:"width="1%" class="st" bgcolor="#bfcff0"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Helps/ExtraColumns/Default', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Helps/ExtraColumns/1/Variables', 's:8:"HELP_KEY";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Helps/ExtraColumns/1/Type', 's:5:"Right";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Helps/ExtraColumns/1/TextPattern', 's:126:"<a href="helpedit.php?mode=delete&topic=%s" onclick="if (confirm(''Are you sure?'')) return true; else return false;">delete</a>";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Helps/ExtraColumns/1', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Helps/ExtraColumns/0/Variables', 's:8:"HELP_KEY";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Helps/ExtraColumns/0/Type', 's:5:"Right";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Helps/ExtraColumns/0/TextPattern', 's:52:"<a href="helpedit.php?mode=update&topic=%s">edit</a>";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Helps/ExtraColumns', 'i:2;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Helps/ExtraColumns/0', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Helps/Columns/RightExtra', 's:16:"class="basetext"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Helps/Columns/Default/TitleAttributes', 's:31:"class="basetext" align="center"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Helps/Columns/Default/Title', 's:6:"&nbsp;";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Helps/Columns/Default/BodyAttributes', 's:10:"class="st"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Helps/Columns/Default', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Helps/Columns/0', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Helps/Columns/0/Title', 's:10:"Help topic";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Helps/Navigator/Attributes', 's:44:"width="100%" cellspacing="0" cellpadding="2"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Helps/Navigator/CenterCell', 's:37:"align="center" width="99%" class="st"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Helps/Navigator/LeftCell', 's:34:"align="left" width="1%" class="st"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Helps/Navigator/RightCell', 's:35:"align="right" width="1%" class="st"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Helps/Rows', 's:27:"Even and odd row properties";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Helps/Rows/0', 's:17:"bgcolor="#dddddd"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Helps/Rows/1', 's:17:"bgcolor="#eeeeee"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Helps/Table', 's:10:"main table";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Helps/Table/Attributes', 's:86:"width="99%" border="0" cellspacing="1" cellpadding="2" bgcolor="999999" align="center"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks', 's:31:"Task/equipment association grid";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/Columns', 'i:4;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/Columns/0', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/Columns/0/BodyAttributes', 's:33:"class="st" align="left" width="1"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/Columns/0/Title', 's:9:"Equipment";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/Columns/0/TitleAttributes', 's:42:"class="basetext" align="center" width="1%"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/Columns/1', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/Columns/1/BodyAttributes', 's:40:"class="st" align="left" width="1" nowrap";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/Columns/1/Title', 's:11:"Description";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/Columns/1/TitleAttributes', 's:42:"class="basetext" align="center" width="1%"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/Columns/2', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/Columns/2/BodyAttributes', 's:23:"class="st" align="left"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/Columns/2/Title', 's:5:"Event";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/Columns/2/TitleAttributes', 's:31:"class="basetext" align="center"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/Columns/3', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/Columns/3/BodyAttributes', 's:23:"class="st" align="left"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/Columns/3/Title', 's:10:"Start date";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/Columns/3/TitleAttributes', 's:31:"class="basetext" align="center"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History', 's:12:"History grid";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/Columns/0/BodyAttributes', 's:33:"class="st" align="left" width="1"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/Columns', 'i:9;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/Columns/0', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/Columns/5', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/ExtraColumns/3', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/ExtraColumns/0', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/ExtraColumns/3/TextPattern', 's:53:"<a href="taskedit.php?action=view&taskID=%d">view</a>";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/ExtraColumns/0/TextPattern', 's:83:"<a href="taskreport.php?taskID=%d"><img src="img/icon.gif" alt="%s" border="0"></a>";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/ExtraColumns/0/Variables', 's:28:"SCHEDULE_ID,TASK_DESCRIPTION";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/ExtraColumns/0/Type', 's:5:"Right";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/Columns/0/TitleAttributes', 's:42:"class="basetext" align="center" width="1%"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/Columns/0/Title', 's:9:"Equipment";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/Columns/Default', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/Columns/Default/BodyAttributes', 's:23:"class="st" align="left"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/Columns/Default/Title', 's:8:"Column #";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/Columns/Default/TitleAttributes', 's:31:"class="basetext" align="center"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/ExtraColumns', 'i:6;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/ExtraColumns/0', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/ExtraColumns/0/BodyAttributes', 's:54:"class="nt" align="center" width="1%" bgcolor="#eeeeee"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/ExtraColumns/0/TextPattern', 's:51:"<input type="checkbox" name="task_ID[]" value="%d">";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/ExtraColumns/0/Type', 's:4:"Left";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/ExtraColumns/0/Variables', 's:7:"TASK_ID";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/ExtraColumns/5/TextPattern', 's:129:"<a href="taskedit.php?action=delete&taskID=%d" onclick="if (confirm(''Are you sure?'')) return true; else return false;">delete</a>";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminLogs/Table', 's:10:"main table";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/ExtraColumns/4', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/ExtraColumns/4/TextPattern', 's:53:"<a href="taskedit.php?action=edit&taskID=%d">edit</a>";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/ExtraColumns/4/Type', 's:5:"Right";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/ExtraColumns/4/Variables', 's:7:"TASK_ID";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/ExtraColumns/5', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/ExtraColumns/5/Type', 's:5:"Right";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/ExtraColumns/5/Variables', 's:7:"TASK_ID";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/ExtraColumns/Default', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/ExtraColumns/Default/BodyAttributes', 's:54:"class="st" align="center" width="1%" bgcolor="#cccccc"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/ExtraColumns/Default/TitleAttributes', 's:36:"class="bt" align="center" width="1%"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/ExtraColumns/LeftExtra', 's:16:"class="basetext"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/ExtraColumns/RightExtra', 's:16:"class="basetext"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/Navigator', 's:15:"Navigator table";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/Navigator/Attributes', 's:44:"width="100%" cellspacing="0" cellpadding="2"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/Navigator/CenterCell', 's:37:"align="center" width="99%" class="st"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/Navigator/LeftCell', 's:34:"class="st" align="left" width="1%"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/Navigator/RightCell', 's:35:"align="right" width="1%" class="st"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/Rows', 's:27:"Even and odd row properties";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/Rows/0', 's:17:"bgcolor="#dddddd"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/Rows/1', 's:17:"bgcolor="#eeeeee"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/Table', 's:10:"main table";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Tasks/Table/Attributes', 's:86:"width="99%" border="0" cellspacing="1" cellpadding="2" bgcolor="999999" align="center"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Prods/Columns/Default/TitleAttributes', 's:31:"class="basetext" align="center"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Prods/Columns/RightExtra', 's:16:"class="basetext"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Prods/ExtraColumns', 'i:2;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Prods/ExtraColumns/0', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Prods/ExtraColumns/0/TextPattern', 's:50:"<a href="prodedit.php?mode=update&pid=%d">edit</a>";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Prods/ExtraColumns/0/Type', 's:5:"Right";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Prods/ExtraColumns/0/Variables', 's:10:"PRODUCT_ID";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Prods/ExtraColumns/1', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Prods/ExtraColumns/1/Type', 's:5:"Right";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Prods/ExtraColumns/1/Variables', 's:10:"PRODUCT_ID";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Prods/ExtraColumns/Default', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Prods/ExtraColumns/Default/BodyAttributes', 's:39:"width="1%" class="st" bgcolor="#bfcffo"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Prods/ExtraColumns/Default/TitleAttributes', 's:42:"class="basetext" align="center" width="1%"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Prods/ExtraColumns/RightExtra', 's:16:"class="basetext"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Prods/Navigator', 's:15:"Navigator table";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Prods/Navigator/Attributes', 's:44:"width="100%" cellspacing="1" cellpadding="2"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Prods/Navigator/CenterCell', 's:37:"align="center" width="99%" class="st"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Prods/Navigator/LeftCell', 's:34:"align="left" width="1%" class="st"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Prods/Navigator/RightCell', 's:35:"align="right" width="1%" class="st"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Prods/Rows', 's:27:"Even and odd row properties";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Prods/Rows/0', 's:17:"bgcolor="#dddddd"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Prods/Rows/1', 's:17:"bgcolor="#eeeeee"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Prods/Table', 's:10:"main table";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Prods/Table/Attributes', 's:86:"width="99%" border="0" cellspacing="1" cellpadding="2" bgcolor="999999" align="center"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Prods/Columns/2', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Prods/Columns/2/Title', 's:4:"Type";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Prods/ExtraColumns/1/TextPattern', 's:124:"<a href="prodedit.php?mode=delete&pid=%d" onclick="if (confirm(''Are you sure?'')) return true; else return false;">delete</a>";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABMaps', 's:33:"Alert/Department association grid";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABMaps/Columns', 'i:3;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABMaps/Columns/0', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABMaps/Columns/0/Title', 's:20:"(Sub)department name";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABMaps/Columns/1', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABMaps/Columns/1/Title', 's:17:"Parent department";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABMaps/Columns/Default', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABMaps/Columns/Default/BodyAttributes', 's:10:"class="st"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABMaps/Columns/Default/Title', 's:6:"&nbsp;";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABMaps/Columns/Default/TitleAttributes', 's:31:"class="basetext" align="center"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABMaps/Columns/RightExtra', 's:16:"class="basetext"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABMaps/ExtraColumns', 'i:2;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABMaps/ExtraColumns/0', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABMaps/ExtraColumns/0/TextPattern', 's:58:"<a href="abedit.php?mode=update&depid=%d&abid=%d">edit</a>";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABMaps/ExtraColumns/0/Type', 's:5:"Right";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABMaps/ExtraColumns/0/Variables', 's:29:"DEPARTMENT_ID,ADDRESS_BOOK_ID";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABMaps/ExtraColumns/1', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABMaps/ExtraColumns/1/Type', 's:5:"Right";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABMaps/ExtraColumns/1/Variables', 's:29:"DEPARTMENT_ID,ADDRESS_BOOK_ID";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABMaps/ExtraColumns/Default', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABMaps/ExtraColumns/Default/BodyAttributes', 's:39:"width="1%" class="st" bgcolor="#bfcff0"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABMaps/ExtraColumns/Default/TitleAttributes', 's:42:"width="1%" class="basetext" align="center"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABMaps/ExtraColumns/RightExtra', 's:16:"class="basetext"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABMaps/Navigator', 's:15:"Navigator table";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABMaps/Navigator/Attributes', 's:44:"width="100%" cellspacing="0" cellpadding="2"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABMaps/Navigator/CenterCell', 's:37:"align="center" width="99%" class="st"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABMaps/Navigator/LeftCell', 's:34:"align="left" width="1%" class="st"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABMaps/Navigator/RightCell', 's:35:"align="right" width="1%" class="st"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABMaps/Rows', 's:27:"Even and odd row properties";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABMaps/Rows/0', 's:15:"bgcolor=#dddddd";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABMaps/Rows/1', 's:15:"bgcolor=#eeeeee";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABMaps/Table', 's:10:"main table";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABMaps/Table/Attributes', 's:86:"width="99%" border="0" cellspacing="1" cellpadding="2" bgcolor="999999" align="center"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AB/ExtraColumns/3', '');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AB/ExtraColumns/3/Type', 's:5:"Right";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AB/ExtraColumns/3/Variables', 's:15:"ADDRESS_BOOK_ID";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AB/ExtraColumns/3/TextPattern', 's:129:"<a href="addrbookedit.php?mode=delete&abid=%d" onclick="if (confirm(''Are you sure?'')) return true; else return false;">delete</a>";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABMaps/Columns/2', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/ABMaps/Columns/2/Title', 's:14:"Notify through";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/ExtraColumns/1/Type', 's:5:"Right";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/ExtraColumns/1/TextPattern', 's:62:"<a href="historyedit.php?action=view&trID=%d&flag=%s">view</a>";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/ExtraColumns/1', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/ExtraColumns/0/Variables', 's:16:"TR_ID,TR_HISTORY";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/ExtraColumns/0/Type', 's:4:"Left";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/ExtraColumns/0/TextPattern', 's:51:"<input type="checkbox" name="trID[]" value="%d,%s">";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/ExtraColumns/0/BodyAttributes', 's:54:"class="nt" align="center" width="1%" bgcolor="#eeeeee"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/ExtraColumns', 'i:3;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/ExtraColumns/0', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/Columns/Default/Title', 's:8:"Column #";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/Columns/Default/TitleAttributes', 's:31:"class="basetext" align="center"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/Columns/Default/BodyAttributes', 's:23:"class="st" align="left"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/Columns/Default', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/Columns/4/TitleAttributes', 's:31:"class="basetext" align="center"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/Columns/4/Title', 's:4:"Date";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/Columns/4', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/Columns/4/BodyAttributes', 's:23:"class="st" align="left"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/Columns/3/TitleAttributes', 's:31:"class="basetext" align="center"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/Columns/3/Title', 's:11:"Maintenance";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/Columns/3/BodyAttributes', 's:23:"class="st" align="left"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/Columns/3', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/Columns/2/TitleAttributes', 's:31:"class="basetext" align="center"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/Columns/2/Title', 's:4:"P_ID";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/Columns/2/BodyAttributes', 's:23:"class="st" align="left"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/Columns/3/Title', 's:5:"MPROC";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/Schedule/Columns/3/TitleAttributes', 's:31:"class="basetext" align="center"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/ExtraColumns/1/Variables', 's:16:"TR_ID,TR_HISTORY";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/ExtraColumns/2', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/ExtraColumns/2/Type', 's:5:"Right";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/ExtraColumns/2/Variables', 's:16:"TR_ID,TR_HISTORY";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/ExtraColumns/Default', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/ExtraColumns/Default/BodyAttributes', 's:54:"class="st" align="center" width="1%" bgcolor="#cccccc"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/ExtraColumns/Default/TitleAttributes', 's:36:"class="bt" align="center" width="1%"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/ExtraColumns/LeftExtra', 's:16:"class="basetext"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/ExtraColumns/RightExtra', 's:16:"class="basetext"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/Navigator', 's:15:"Navigator table";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/Navigator/Attributes', 's:44:"width="100%" cellspacing="0" cellpadding="2"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/Navigator/CenterCell', 's:37:"align="center" width="99%" class="st"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/Navigator/LeftCell', 's:34:"class="st" align="left" width="1%"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/Navigator/RightCell', 's:35:"align="right" width="1%" class="st"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/Rows', 's:27:"Even and odd row properties";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/Rows/0', 's:17:"bgcolor="#dddddd"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/Rows/1', 's:17:"bgcolor="#eeeeee"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/Table', 's:10:"main table";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/Table/Attributes', 's:86:"width="99%" border="0" cellspacing="1" cellpadding="2" bgcolor="999999" align="center"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/ExtraColumns/2/TextPattern', 's:138:"<a href="historyedit.php?action=delete&trID=%d&flag=%s" onclick="if (confirm(''Are you sure?'')) return true; else return false;">delete</a>";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/AdminLogs/Table/Attributes', 's:86:"width="99%" border="0" cellspacing="1" cellpadding="2" bgcolor="999999" align="center"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Queries', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Queries/DEPARTMENTS_DEPARTMENT_ID', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Queries/DEPARTMENTS_DEPARTMENT_ID/QUERY', 's:154:"SELECT DISTINCT DEPARTMENTS.DEPARTMENT_ID, DEPARTMENTS.DEPARTMENT_NAME  FROM DEPARTMENTS WHERE DEPARTMENTS.USER_ID=%d ORDER BY DEPARTMENTS.DEPARTMENT_NAME";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Queries/DEPARTMENTS_DEPARTMENT_ID/TXT', 'i:1;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Queries/DEPARTMENTS_DEPARTMENT_ID/USER', 'b:1;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Queries/DEPARTMENTS_DEPARTMENT_ID/VAL', 'i:0;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Queries/EQUIPMENT_EQUIPMENT_ID', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Queries/EQUIPMENT_EQUIPMENT_ID/QUERY', 's:93:"SELECT EQUIPMENT.EQUIPMENT_ID, EQUIPMENT.VEHICLE_ID FROM EQUIPMENT WHERE EQUIPMENT.USER_ID=%d";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Queries/EQUIPMENT_EQUIPMENT_ID/TXT', 'i:1;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Queries/EQUIPMENT_EQUIPMENT_ID/USER', 'b:1;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Queries/EQUIPMENT_EQUIPMENT_ID/VAL', 'i:0;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Queries/MAINTENANC_MAINTENANCE_PROCEDURE/VAL', 'i:0;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Queries/PRODUCTS_PRODUCT_NAME', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Queries/PRODUCTS_PRODUCT_NAME/QUERY', 's:172:"SELECT  PRODUCTS.PRODUCT_NAME FROM MAINTENANCE,  PRODUCTS, USERS WHERE USERS.USER_ID=MAINTENANCE.USER_ID AND MAINTENANCE.PRODUCT_ID=PRODUCTS.PRODUCT_ID AND USERS.USER_ID=%d";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Queries/PRODUCTS_PRODUCT_NAME/TXT', 'i:0;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Queries/PRODUCTS_PRODUCT_NAME/USER', 'b:1;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Queries/PRODUCTS_PRODUCT_NAME/VAL', 'i:0;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Queries/Q1', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Queries/TRANSACTIONS_TR_CUSTOMER_ID', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Queries/TRANSACTIONS_TR_CUSTOMER_ID/QUERY', 's:98:"SELECT DISTINCT TRANSACTIONS.TR_CUSTOMER_ID FROM TRANSACTIONS WHERE TRANSACTIONS.TR_CUSTOMER_ID=%d";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Queries/TRANSACTIONS_TR_CUSTOMER_ID/TXT', 'i:0;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Queries/TRANSACTIONS_TR_CUSTOMER_ID/USER', 'b:1;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Queries/TRANSACTIONS_TR_CUSTOMER_ID/VAL', 'i:0;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Queries/TRANSACTIONS_TR_SITE_DESCRIPTION', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Queries/TRANSACTIONS_TR_SITE_DESCRIPTION/QUERY', 's:66:"SELECT DISTINCT TRANSACTIONS.TR_SITE_DESCRIPTION FROM TRANSACTIONS";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Queries/TRANSACTIONS_TR_SITE_DESCRIPTION/TXT', 'i:0;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Queries/TRANSACTIONS_TR_SITE_DESCRIPTION/USER', 'b:0;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Queries/TRANSACTIONS_TR_SITE_DESCRIPTION/VAL', 'i:0;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Queries/TRANSACTIONS_TR_SITE_ID', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Queries/TRANSACTIONS_TR_SITE_ID/QUERY', 's:57:"SELECT DISTINCT TRANSACTIONS.TR_SITE_ID FROM TRANSACTIONS";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Queries/TRANSACTIONS_TR_SITE_ID/TXT', 'i:0;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Queries/TRANSACTIONS_TR_SITE_ID/USER', 'b:0;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Queries/TRANSACTIONS_TR_SITE_ID/VAL', 'i:0;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Queries/TRANSACTIONS_TR_DEPARTMENT_NAME', '');
INSERT INTO REGISTRY VALUES ( 'FMWC/Queries/TRANSACTIONS_TR_DEPARTMENT_NAME/QUERY', 's:80:"SELECT DEPARTMENTS.DEPARTMENT_NAME FROM DEPARTMENTS WHERE DEPARTMENTS.USER_ID=%d";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Queries/TRANSACTIONS_TR_DEPARTMENT_NAME/TXT', 'i:0;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Queries/TRANSACTIONS_TR_DEPARTMENT_NAME/USER', 'b:1;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Queries/TRANSACTIONS_TR_DEPARTMENT_NAME/VAL', 'i:0;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TransError/Columns/0/Title', 's:5:"TR_ID";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TransError/Columns/0/BodyAttributes', 's:34:"class="st" align="left" width="1%"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TransError/Columns/0', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TransError/Columns', 'i:4;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TransError', 's:18:"Transaction errors";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/Columns/7/TitleAttributes', 's:31:"class="basetext" align="center"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/Columns/7/Title', 's:2:"$$";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/Columns/7', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/Columns/7/BodyAttributes', 's:23:"class="st" align="left"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/Columns/6/TitleAttributes', 's:31:"class="basetext" align="center"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/Columns/6/Title', 's:16:"Site description";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/Columns/6/BodyAttributes', 's:23:"class="st" align="left"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/Columns/6', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/Columns/5/TitleAttributes', 's:31:"class="basetext" align="center"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/Columns/5/Title', 's:7:"Site ID";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/Columns/5/BodyAttributes', 's:23:"class="st" align="left"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TransError/Columns/3', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TransError/Columns/3/BodyAttributes', 's:23:"class="st" align="left"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TransError/Columns/3/Title', 's:8:"VEH_DESC";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TransError/Columns/3/TitleAttributes', 's:43:"class="basetext" align="center" width="25%"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TransError/ExtraColumns/2/TextPattern', 's:128:"<a href="trans_er.php?action=delete&errID=%d" onclick="if (confirm(''Are you sure?'')) return true; else return false;">delete</a>";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TransError/ExtraColumns/2/Variables', 's:8:"ERROR_ID";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TransError/ExtraColumns/1/TextPattern', 's:62:"<a href="vehicledit.php?mode=update&eqid=%d&errID=%d">view</a>";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TransError/Columns/1/BodyAttributes', 's:35:"class="st" align="left" width="60%"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TransError/Columns/1', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TransError/Columns/1/TitleAttributes', 's:43:"class="basetext" align="center" width="60%"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TransError/Columns/1/Title', 's:7:"MESSAGE";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TaskReport/Columns/0', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TaskReport/Columns', 'i:5;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TaskReport', 's:23:"Task ''mini-report'' grid";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TaskReport/Columns/0/BodyAttributes', 's:33:"class="st" align="left" width="1"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TaskReport/Columns/0/TitleAttributes', 's:42:"class="basetext" align="center" width="1%"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TaskReport/Columns/0/Title', 's:2:"ID";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TransError/Columns/Default', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TransError/Columns/Default/BodyAttributes', 's:23:"class="st" align="left"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TransError/Columns/Default/Title', 's:8:"Column #";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TransError/Columns/Default/TitleAttributes', 's:31:"class="basetext" align="center"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TransError/ExtraColumns', 'i:3;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TransError/ExtraColumns/0', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TransError/ExtraColumns/0/BodyAttributes', 's:54:"class="nt" align="center" width="1%" bgcolor="#eeeeee"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TransError/ExtraColumns/0/TextPattern', 's:49:"<input type="checkbox" name="errID[]" value="%d">";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TransError/ExtraColumns/0/Type', 's:4:"Left";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TransError/ExtraColumns/0/Variables', 's:8:"ERROR_ID";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TransError/ExtraColumns/1', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TransError/ExtraColumns/2', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TransError/ExtraColumns/2/Type', 's:5:"Right";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TransError/ExtraColumns/1/Variables', 's:21:"EQUIPMENT_ID,ERROR_ID";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TransError/ExtraColumns/1/Type', 's:5:"Right";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TransError/ExtraColumns/Default', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TransError/ExtraColumns/Default/BodyAttributes', 's:54:"class="st" align="center" width="1%" bgcolor="#cccccc"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TransError/ExtraColumns/Default/TitleAttributes', 's:36:"class="bt" align="center" width="1%"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TransError/ExtraColumns/LeftExtra', 's:16:"class="basetext"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TransError/ExtraColumns/RightExtra', 's:16:"class="basetext"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TransError/Navigator', 's:15:"Navigator table";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TransError/Navigator/Attributes', 's:44:"width="100%" cellspacing="0" cellpadding="2"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TransError/Navigator/CenterCell', 's:37:"align="center" width="99%" class="st"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TransError/Navigator/LeftCell', 's:34:"class="st" align="left" width="1%"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TransError/Navigator/RightCell', 's:35:"align="right" width="1%" class="st"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TransError/Rows', 's:27:"Even and odd row properties";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TransError/Rows/0', 's:17:"bgcolor="#dddddd"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TransError/Rows/1', 's:17:"bgcolor="#eeeeee"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TransError/Table', 's:10:"main table";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TransError/Table/Attributes', 's:86:"width="99%" border="0" cellspacing="1" cellpadding="2" bgcolor="999999" align="center"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TaskReport/ExtraColumns/Default/BodyAttributes', 's:54:"class="st" align="center" width="1%" bgcolor="#cccccc"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TaskReport/ExtraColumns/Default', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TaskReport/ExtraColumns/0/Variables', 's:12:"TASK_OVERDUE";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TaskReport/Columns/1', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TaskReport/Columns/1/BodyAttributes', 's:23:"class="st" align="left"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TaskReport/Columns/1/Title', 's:5:"MCODE";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TaskReport/Columns/1/TitleAttributes', 's:31:"class="basetext" align="center"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TaskReport/Columns/2', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TaskReport/Columns/2/BodyAttributes', 's:23:"class="st" align="left"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TaskReport/Columns/2/Title', 's:5:"MPROC";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TaskReport/Columns/2/TitleAttributes', 's:31:"class="basetext" align="center"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TaskReport/Columns/3', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TaskReport/Columns/3/BodyAttributes', 's:23:"class="st" align="left"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TaskReport/Columns/3/Title', 's:7:"VEHICLE";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TaskReport/Columns/3/TitleAttributes', 's:31:"class="basetext" align="center"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TaskReport/Columns/4', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TaskReport/Columns/4/BodyAttributes', 's:23:"class="st" align="left"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TaskReport/Columns/4/Title', 's:19:"VEHICLE DESCRIPTION";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TaskReport/Columns/4/TitleAttributes', 's:31:"class="basetext" align="center"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TaskReport/ExtraColumns/0/Type', 's:5:"Right";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TaskReport/ExtraColumns/0', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TaskReport/ExtraColumns/0/TextPattern', 's:42:"<img src="/img/%s" width="24" height="20">";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TaskReport/Columns/Default', 's:0:"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TaskReport/Columns/Default/BodyAttributes', 's:23:"class="bt" align="left"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TaskReport/Columns/Default/Title', 's:8:"Column #";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TaskReport/Columns/Default/TitleAttributes', 's:31:"class="basetext" align="center"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/Columns/8/TitleAttributes', 's:31:"class="basetext" align="center"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/Columns/8/Title', 's:6:"Compl.";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/Columns/8/BodyAttributes', 's:23:"class="st" align="left"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/History/Columns/8', '');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TaskReport/ExtraColumns/RightExtra', 's:16:"class="basetext"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TaskReport/ExtraColumns/Default/TitleAttributes', 's:36:"class="bt" align="center" width="1%"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TaskReport/ExtraColumns', 'i:1;');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TaskReport/Navigator', 's:15:"Navigator table";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TaskReport/Navigator/Attributes', 's:44:"width="100%" cellspacing="0" cellpadding="2"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TaskReport/Navigator/CenterCell', 's:37:"align="center" width="99%" class="st"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TaskReport/Navigator/LeftCell', 's:34:"class="st" align="left" width="1%"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TaskReport/Navigator/RightCell', 's:35:"align="right" width="1%" class="st"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TaskReport/Rows', 's:27:"Even and odd row properties";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TaskReport/Rows/0', 's:17:"bgcolor="#dddddd"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TaskReport/Rows/1', 's:17:"bgcolor="#eeeeee"";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TaskReport/Table', 's:10:"main table";');
INSERT INTO REGISTRY VALUES ( 'FMWC/Interface/GridsV2/TaskReport/Table/Attributes', 's:88:"width="99%" border="0" cellspacing="1" cellpadding="2" bgcolor="999999" align="center"
";');

#
# Table structure for table 'USERS'
#

CREATE TABLE USERS (

   USER_ID int(11) DEFAULT '0' NOT NULL,
   USER_NAME varchar(32) NOT NULL,
   USER_PASSWORD varchar(16) NOT NULL,
   USER_DESCRIPTION varchar(128),
   USER_EMAIL varchar(64) NOT NULL,
   USER_FETCH_COUNT int(11) DEFAULT '0' NOT NULL,
   USER_LAST_LOGIN datetime,
   USER_ENABLED enum('yes','no') DEFAULT 'yes' NOT NULL,
   PRIMARY KEY (USER_ID),
   UNIQUE UNI_LOGIN (USER_NAME)
);

#
# Dumping data for table 'USERS'
#

INSERT INTO USERS VALUES ( '0', 'admin', 'admin', 'Superuser', 'h2o@softerra.com', '5', '2001-06-21 15:48:13', 'yes');
INSERT INTO USERS VALUES ( '2', 'test', 'test', 'Test user', 'me@somewhere.net', '5', '2001-05-25 13:19:03', 'yes');

