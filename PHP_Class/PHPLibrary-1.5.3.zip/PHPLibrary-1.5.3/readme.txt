
 +----------------------------------------------------------------------+
 | Softerra PHP developer library                                       |
 +----------------------------------------------------------------------+
 | Copyright (c) 1999-2002 Softerra, LLC                                |
 +----------------------------------------------------------------------+
 | This library is free software; you can redistribute it and/or modify |
 | it  under  the  terms  of  the  GNU Lesser General Public License as |
 | published by the Free Software Foundation; either version 2.1 of the |
 | License, or (at your option) any later version.                      |
 |                                                                      |
 | This  library is distributed in the hope that it will be useful, but |
 | WITHOUT   ANY  WARRANTY;  without  even  the  implied  warranty  of  |
 | MERCHANTABILITY  or  FITNESS  FOR A PARTICULAR PURPOSE.  See the GNU |
 | Lesser General Public License for more details.                      |
 +----------------------------------------------------------------------+
 | Contacts: http://www.softerra.com, mailto:phplib@softerra.com        |
 +----------------------------------------------------------------------+

We hope these PHP libraries will help you write more structured
PHP application (or at least you'll see the way how we do this ;) ).

1. CONTENTS & FILES

Please read these files:
Introduction - some words regarding how to write Web-based PHP applications
Description  - library description
Install      - how to install this package


1.1. MySQL DB support
	/lib/lib.cfg.php          - library configuration settings
        /lib/sal/mysql.fun.php    - MySQL specific functions
        /lib/corban.lib.php       - debug output library
        /lib/sqlcompose.lib.php   - query compose library
        /lib/sqlsearch.lib.php    - search library
        /lib/sqlstorage.class.php - DB access class
1.2. Registry
        /lib/registry.lib.php     - Registry support library
        /addons/regedit.php       - Registry editor
1.3. Array support library
        /lib/array.lib.php        - array-specific functions
1.4. Example
	/example/....             - example application
1.5. Documents
	/docs/....             	  - documents

Please, look into example directory. There you can find a small application
that demonstrates how these libraries can be used.
