<?php
//
// +----------------------------------------------------------------------+
// | Softerra PHP developer library                                       |
// +----------------------------------------------------------------------+
// | Copyright (c) 1999-2002 Softerra, LLC                                |
// +----------------------------------------------------------------------+
// | This library is free software; you can redistribute it and/or modify |
// | it  under  the  terms  of  the  GNU Lesser General Public License as |
// | published by the Free Software Foundation; either version 2.1 of the |
// | License, or (at your option) any later version.                      |
// |                                                                      |
// | This  library is distributed in the hope that it will be useful, but |
// | WITHOUT   ANY  WARRANTY;  without  even  the  implied  warranty  of  |
// | MERCHANTABILITY  or  FITNESS  FOR A PARTICULAR PURPOSE.  See the GNU |
// | Lesser General Public License for more details.                      |
// +----------------------------------------------------------------------+
// | Contacts: http://www.softerra.com, mailto:phplib@softerra.com        |
// +----------------------------------------------------------------------+
//

/**
 *
 * SQL Keywords Search Library.
 *
 * @module		SQLSearch
 * @modulegroup	SQL
 * @package		Softerra
 * @author		Softerra <phplib@softerra.com>
 * @copyright	(c) 1999-2002 Softerra, LLC
 * @link		http://www.softerra.com/products/ [Softerra PHP Developer Library Home Page]
 * @version		1.3.7
 * @access		public
 * @since		PHP 4.0.1pl2
 */

require_once ($lib_dir . "array.lib.php");

/**
 * SQL type of search pattern.
 *
 * @const	SQL_PATTERN
 * @access	private
 */
define ("SQL_PATTERN", 0);
/**
 * REGEXP type of search pattern.
 *
 * @const	REGEXP_PATTERN
 * @access	private
 */
define ("REGEXP_PATTERN", 1);
/**
 * Name of field for search.
 *
 * @const	KWFIELD
 * @access	private
 */
define ("KWFIELD", "KEYWORDS");
/**
 *
 *
 * @const	SEARCHEXP_SEPARATOR
 * @access	private
 */
define ("SEARCHEXP_SEPARATOR", " ");
/**
 * "Any symbol" search pattern.
 *
 * @const	SYMBOL_ANYCHAR
 * @access	private
 */
define ("SYMBOL_ANYCHAR", "?");
/**
 * "Any symbol sequence" search pattern.
 *
 * @const	SYMBOL_ANYSEQUENCE
 * @access	private
 */
define ("SYMBOL_ANYSEQUENCE", "*");
/**
 * "Any symbol" SQL search pattern.
 *
 * @const	SQL_ANYCHAR
 * @access	private
 */
define ("SQL_ANYCHAR", "_");
/**
 * "Any symbol sequence" SQL search pattern.
 *
 * @const	SQL_ANYSEQUENCE
 * @access	private
 */
define ("SQL_ANYSEQUENCE", "%");
if ($sqlExtendedSearch)
{
	/**
	 * "Any symbol" REGEXP search pattern.
	 *
	 * @const	REGEXP_ANYCHAR
	 * @access	private
	 */
	define ("REGEXP_ANYCHAR", "[[:alnum:]]");
	/**
	 * "Separator" REGEXP search pattern.
	 *
	 * @const	REGEXP_SEPARATOR
	 * @access	private
	 */
	define ("REGEXP_SEPARATOR", "[^[:alnum:]]");
}
else
{
	/**
	 * "Any symbol" REGEXP search pattern.
	 *
	 * @const	REGEXP_ANYCHAR
	 * @access	private
	 */
	define ("REGEXP_ANYCHAR", "[[:alnum:] ]");
	/**
	 * REGEXP search pattern "separator".
	 *
	 * @const	REGEXP_SEPARATOR
	 * @access	private
	 */
	define ("REGEXP_SEPARATOR", ",");
}
/**
 * "Any symbol sequence" REGEXP search pattern.
 *
 * @const	REGEXP_ANYSEQUENCE
 * @access	private
 */
define ("REGEXP_ANYSEQUENCE", REGEXP_ANYCHAR . "*");

/**
 * Prepares and returns the search keyword.
 *
 * Prepares and returns the search keyword to be used in SQL or REGEXP search patterns.
 *
 * @param	string	$pattern	Search keyword.
 * @param	integer	$type		Type of search pattern.
 * @return	string	Prepared search keyword.
 * @access	private
 * @todo	Change ereg_replace() to preg_replace()
 */
function searchPattern ($pattern, $type=SQL_PATTERN)
{
	switch ($type)
	{
		case SQL_PATTERN:
			$anychar = SQL_ANYCHAR;
			$anysequence = SQL_ANYSEQUENCE;
		break;
		case REGEXP_PATTERN:
			$anychar = REGEXP_ANYCHAR;
			$anysequence = REGEXP_ANYSEQUENCE;
			$pattern = sql_regcase ($pattern);
		break;
	}
	$pattern = ereg_replace (quotemeta (SYMBOL_ANYCHAR), $anychar, $pattern);
	$pattern = ereg_replace (quotemeta (SYMBOL_ANYSEQUENCE), $anysequence, $pattern);
	return $pattern;
} // end function searchPattern

/**
 * Setting field name for keyword search.
 *
 * @param	string	$target	Field name for keyword search.
 * @return	string	Field name for keyword search.
 * @global	string	$targetField
 * @access	public
 */
function targetfield ($target="")
{
	global $targetField;
	if (strlen ($target)) $targetField = $target;
	else return $targetField;
} // end function targetfield

/**
 * Prepares search keywords.
 *
 * Prepares search keywords to be used in REGEXP search patterns.
 *
 * @param	string	&$keyword	Search keyword.
 * @param	integer	$number		Keywords array key.
 * @param	array	$extension	Additional condition prefix and suffix.
 * @access	private
 */
function re_k2c (&$keyword, $number, $extension)
{
	$keyword = $extension["prefix"] .
			targetfield () . " REGEXP " .
			"\"(^|" . REGEXP_SEPARATOR . ")" .
			searchPattern ($keyword, REGEXP_PATTERN) .
			"(" . REGEXP_SEPARATOR . "|$)\"" .
			$extension["suffix"];
} // end function re_k2c

/**
 * Prepares search keywords.
 *
 * Prepares search keywords to be used in SQL search patterns.
 *
 * @param	string	&$keyword	Search keyword.
 * @param	integer	$number		Keywords array key.
 * @param	array	$extension	Additional condition prefix and suffix.
 * @global	boolean	$sqlExtendedSearch	Defines search mode.
 * @access	private
 */
function sql_k2c (&$keyword, $number, $extension)
{
	global $sqlExtendedSearch;
	$keyword = $extension["prefix"] .
			targetfield () . " like " .
			($sqlExtendedSearch ? "'%" : "'") .
			searchPattern ($keyword) .
			($sqlExtendedSearch ? "%'" : "'") .
			$extension["suffix"];
} // end function sql_k2c

/**
 * Returns prepared search keywords array.
 *
 * Returns search keywords array prepared for use in SQL query.
 *
 * @param	array	$keywords	Searh keywords.
 * @param	integer	$type		Type of search pattern.
 * @param	array	$extension	Additional condition prefix and suffix.
 * @return	array	Search keywords array.
 * @access	private
 */
function keywords2conditions ($keywords, $type=SQL_PATTERN, $extension=array())
{
	if ($type==REGEXP_PATTERN) $userfunc = 're_k2c';
	else $userfunc = 'sql_k2c';
	array_walk ($keywords, $userfunc, $extension);
	return $keywords;
} // end function keywords2conditions

/**
 * Returns prepared search array.
 *
 * Returns prepared search array for the expression2conditions() function.
 *
 * @param	string	$expression	Search string.
 * @return	array	Prepared search array.
 * @access	private
 * @see		expression2conditions()
 */
function expression2internal ($expression)
{
	$allquoted = array ();
	if (preg_match_all ('/([+-]?)"([^"]*)"/', $expression, $quoted))
	{
		$expression = preg_replace ('/[+-]{0,1}"[^"]*"/', "", $expression);
		for ($i=0; $i<count ($quoted[0]); $i++)
			$allquoted[] = $quoted[1][$i] . $quoted[2][$i];
	}
	$all = preg_split("/[\s]+/", $expression, -1, PREG_SPLIT_NO_EMPTY);
	if (!empty($allquoted) && is_array($allquoted))
		$all = array_merge ($all, $allquoted);

	$internal["with"] = array_values (preg_grep ("/^\+/", $all));
	$internal["without"] = array_values (preg_grep ("/^-/", $all));
	$internal["withany"] = array_values (preg_grep ("/^[\w\?\* ]/", $all));
	for ($i=0; $i<count ($internal["with"]); $i++)
		$internal["with"][$i] = substr ($internal["with"][$i], 1);
	for ($i=0; $i<count ($internal["without"]); $i++)
		$internal["without"][$i] = substr ($internal["without"][$i], 1);
	return $internal;
} // end function expression2internal

/**
 * Returns the composed WHERE part of SQL query.
 *
 * Converts the word1 word2 +word3 -word4 "word5 word6" types of SQL search to the WHERE part of SQL query.
 *
 * @param	string	$expression	Search string.
 * @param	integer	$type		Type of search pattern.
 * @return	string	WHERE part of SQL query.
 * @access	public
 */
function expression2conditions ($expression, $type=SQL_PATTERN)
{
	$query = "";
	$internal = expression2internal ($expression);
	if ($internal["withany"]) $query .= composeSearchConditions ($internal["withany"], $type);
	if ($internal["with"]) $query .= composeSearchConditions ($internal["with"], $type, "and");
	if ($internal["without"]) $query .= composeSearchConditions ($internal["without"], $type, "and", true);
	return $query;
} // end function expression2conditions

/**
 * Returns part of the WHERE condition.
 *
 * Returns part of the WHERE condition.
 *
 * @param	array	$keywords	Search keywords.
 * @param	integer	$type		Type of search pattern.
 * @param	string	$operation	Logical operation OR or AND.
 * @param	boolean	$negation	If TRUE set WHERE prefix to NOT.
 * @return	string	Part of the WHERE condition.
 * @access	private
 */
function composeSearchConditions ($keywords, $type, $operation="or", $negation=false)
{
	$extension = array("prefix"=>"", "suffix"=>"");
	$query = " and (";
	if ($negation)
	{
		$extension["prefix"] = "not (";
		$extension["suffix"] = ")";
	}
	$conditions = keywords2conditions ($keywords, $type, $extension);
	$query .= listArrayValues ($conditions, " $operation ");
	$query .= ")";
	return $query;
} // end function composeSearchConditions

/**
 * Returns the prepared WHERE part of SQL query.
 *
 * Returns the prepared WHERE part of SQL query with the "WHERE" string. Should be used with expression2conditions().
 *
 * @param	string	$conditions	SQL query conditions.
 * @return	string	Prepared WHERE part of SQL query.
 * @access	public
 * @see expression2conditions()
 */
function standalone ($conditions, $type=true)
{
	if ($conditions && $type) $conditions = "where " . substr ($conditions, 5);
	elseif ($conditions) $conditions = substr ($conditions, 5);
	return $conditions;
} // end function standalone

// Set default target field name
targetfield (KWFIELD);

?>