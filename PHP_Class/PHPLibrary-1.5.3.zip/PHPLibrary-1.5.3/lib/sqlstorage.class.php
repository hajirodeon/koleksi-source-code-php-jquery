<?php
//
// +----------------------------------------------------------------------+
// | Softerra PHP developer library                                       |
// +----------------------------------------------------------------------+
// | Copyright (c) 1999-2002 Softerra, LLC                                |
// +----------------------------------------------------------------------+
// | This library is free software; you can redistribute it and/or modify |
// | it  under  the  terms  of  the  GNU Lesser General Public License as |
// | published by the Free Software Foundation; either version 2.1 of the |
// | License, or (at your option) any later version.                      |
// |                                                                      |
// | This  library is distributed in the hope that it will be useful, but |
// | WITHOUT   ANY  WARRANTY;  without  even  the  implied  warranty  of  |
// | MERCHANTABILITY  or  FITNESS  FOR A PARTICULAR PURPOSE.  See the GNU |
// | Lesser General Public License for more details.                      |
// +----------------------------------------------------------------------+
// | Contacts: http://www.softerra.com, mailto:phplib@softerra.com        |
// +----------------------------------------------------------------------+
//

/**
 * Library configuration settings.
 *
 * @author		Softerra <phplib@softerra.com>
 * @copyright	(c) 1999-2002 Softerra, LLC
 * @link		http://www.softerra.com/products/ [Softerra PHP Developer Library Home Page]
 * @version		1.0.3
 * @since		PHP 4.0.1pl2
 */
require_once ("lib.cfg.php");
/**
 *
 * SQL Abstraction Layer
 *
 * @author		Softerra <phplib@softerra.com>
 * @copyright	(c) 1999-2002 Softerra, LLC
 * @link		http://www.softerra.com/products/ [Softerra PHP Developer Library Home Page]
 * @since		PHP 4.0.1pl2
 */
require_once ("sal/" . $salServer . ".fun.php");
/**
 * "Corban, dear" - Debug Output Library.
 *
 * @author		Softerra <phplib@softerra.com>
 * @copyright	(c) 1999-2002 Softerra, LLC
 * @link		http://www.softerra.com/products/ [Softerra PHP Developer Library Home Page]
 * @version		1.3.5
 * @since		PHP 4.0.1pl2
 */
require_once ("corban.lib.php");
/**
 *
 * Simple SQL Query Compose Library.
 *
 * @author		Softerra <phplib@softerra.com>
 * @copyright	(c) 1999-2002 Softerra, LLC
 * @link		http://www.softerra.com/products/ [Softerra PHP Developer Library Home Page]
 * @version		1.3.5
 * @since		PHP 4.0.1pl2
 */
require_once ("sqlcompose.lib.php");
/**
 *
 * SQL Keywords Search Library.
 *
 * @author		Softerra <phplib@softerra.com>
 * @copyright	(c) 1999-2002 Softerra, LLC
 * @link		http://www.softerra.com/products/ [Softerra PHP Developer Library Home Page]
 * @version		1.3.6
 * @since		PHP 4.0.1pl2
 */
require_once ("sqlsearch.lib.php");

/**
 * Connection error message.
 *
 * @const	strErrorConnect
 * @access	private
 */
define ("strErrorConnect", "Fatal: Can't connect to database.\n");
/**
 * Selection error message.
 *
 * @const	strErrorSelect
 * @access	private
 */
define ("strErrorSelect", "Fatal: Can't select from database.\n");
/**
 * Row format type.
 *
 * @const	fmtRow
 * @access	private
 */
define ("fmtRow", 1);
/**
 * Array format type.
 *
 * @const	fmtArr
 * @access	private
 */
define ("fmtArr", 2);
/**
 * Object format type.
 *
 * @const	fmtObj
 * @access	private
 */
define ("fmtObj", 3);

/**
 * Printing error message.
 *
 * @param	string	$method
 * @return	boolean
 * @access	private
 */
function sal_unsupported_method ($method)
{
	$msg = "SAL error!\\nMethod '$method' is not supported by " . strtoupper ($GLOBALS["salServer"]) . " server.";
	echo "<script language=\"JavaScript\">";
	echo "alert (\"$msg\")";
	echo "</script>";
	return false;
} // end function sal_unsupported_method

/**
 * SQL Storage Abstraction Layer Class.
 *
 * Simple wrapper class for SQL.
 *
 * @package		Softerra
 * @author		Softerra <phplib@softerra.com>
 * @copyright	(c) 1999-2002 Softerra, LLC
 * @version		1.3.8
 * @access		public
 * @since		PHP 4.0.1pl2
 * @link		http://www.softerra.com/products/ [Softerra PHP Developer Library Home Page]
 */
class sqlStorage
{

	/**
	 * Debug flag.
	 *
	 * @var	boolean
	 */
	var $debug;
	/**
	 * Debug message.
	 *
	 * @var	string
	 */
	var $debugmessage;
	/**
	 * Connection link ID.
	 *
	 * @var	integer
	 */
	var $connection;
	/**
	 * Result data link ID.
	 *
	 * @var	integer
	 */
	var $queryresult;
	/**
	 * DB link ID.
	 *
	 * @var	integer
	 */
	var $database;
	/**
	 * Query counter.
	 *
	 * @var	integer
	 */
	var $query_count;

	/**
	 * SQL Storage Class Constructor.
	 *
	 * @access	public
	 */
	function sqlStorage ()
	{
		$this->query_count = 0;
		$this->debug = false;
		$this->debugmessage = "";
	} // end function sqlStorage

	/**
	 * Get type of SQL server to connect to.
	 *
	 * @return	string	SQL server type, e.g. "MySQL".
	 * @access	public
	 * @global	boolean	$salServer	SQL server type.
	 */
	function getServer ()
	{
		return $GLOBALS["salServer"];
	} // end function getServer

	/**
	 * Turns SQL debugger on.
	 *
	 * @access	public
	 */
	function debugOn ()
	{
		$this->debug = true;
	} // end function debugOn

	/**
	 * Turns SQL debugger off.
	 *
	 * @access	public
	 */
	function debugOff ()
	{
		$this->debug = false;
	} // end function debugOff

	/**
	 * Connects to SQL Server.
	 *
	 * Stops HTML output and displays error message on failure.
	 *
	 * @param 	string  $host		The hostname string can also include a port number. E.g. "hostname:port".
	 * @param	string  $user		User name
	 * @param	string  $password	Password
	 * @param	string  $name 		DB name
	 * @access	public
	 * @see close()
	 */
	function connect ($host, $user, $password, $name)
	{
		$this->connection = sql_connect ($host, $user, $password, $name) or die (strErrorConnect . $this->error ());
		$this->database = $name;
	} // end function connect

	/**
	 * Disconnects from SQL server.
	 *
	 * This isn't usually necessary, as non-persistent open links are automatically closed at the end of the script's execution.
	 *
	 * @access	public
	 * @see 	connect()
	 */
	function close ()
	{
		sql_close ($this->connection);
	} // end function close

	/**
	 * Selects an SQL database.
	 *
	 * Sets the current active database on the server.
	 *
	 * @param	string 	$database	DB name
	 * @access	public
	 * @see 	connect()
	 */
	function select_db ($database)
	{
		if (sql_select_db ($database))	$this->database = $database;
	} // end function select_db

	/**
	 * Lists databases available on SQL server.
	 *
	 * Returns an array of database names available from the current sql daemon.
	 *
	 * @return 	array	Database names.
	 * @access	public
	 * @see 	list_tables()
	 * @see 	list_fields()
	 */
	function list_dbs ()
	{
		return sql_list_dbs ($this->connection);
	} // end function list_dbs

	/**
	 * Lists tables contained in SQL database.
	 *
	 * Takes a database name and returns an array of table names.
	 *
	 * @param	string	$database	DB Name.
	 * @return 	array	Table names.
	 * @access	public
	 * @see 	list_dbs()
	 * @see 	list_fields()
	 */
	function list_tables ($database="")
	{
		if (!$database) $database = $this->database;
		return sql_list_tables ($database, $this->connection);
	} // end function list_tables

	/**
	 * Lists SQL result fields.
	 *
	 * Takes a table name and returns an array of field names.
	 *
	 * @param	string	$table 		Table Name.
	 * @param	string	$database 	DB Name (optional).
	 * @return 	array	Field names.
	 * @access	public
	 * @see 	list_dbs()
	 * @see 	list_tables()
	 */
	function list_fields ($table, $database="")
	{
		if (!$database) $database = $this->database;
		return $this->queryresult = sql_list_fields ($database, $table, $this->connection);
	} // end function list_fields

	/**
	 * Returns error message from the previous SQL operation.
	 *
	 * Returns error message text from the previous SQL operation or an empty string if no error occurred.
	 *
	 * @return 	string
	 * @access	public
	 */
	function error ()
	{
		return sql_error ($this->connection);
	} // end function error

	/**
	 * Frees result memory.
	 *
	 * Only needs to be called if you are worried about using too much memory while your script is running. All associated result memory for the specified result identifier will automatically be freed.
	 *
	 * @return 	integer
	 * @access	public
	 */
	function free_result ()
	{
		return sql_free_result ($this->queryresult);
	} // end function free_result

	/**
	 * Sends an SQL query.
	 *
	 * The query string should not end with a semicolon.
	 * Returns SQL result on success, or FALSE on error.
	 *
	 * @param	string	$query	SQL query.
	 * @return 	mixed	SQL result on success, or FALSE on error.
	 * @access	public
	 * @see 	select()
	 * @see 	update()
	 * @see 	insert()
	 * @see 	delete()
	 */
	function query ($query)
	{
		if ($this->debug)
		{
			cd ($query, "query", $this->debugmessage);
			ci ("query");
		}
		$this->queryresult = sql_query ($query, $this->connection);
		$this->query_count++;
		if ($this->debug)
		{
			cs ("query", "Query execution time (sec.) ");
			if (!$this->queryresult) cd ($this->error (), "error", $this->debugmessage);
		}
		return $this->queryresult;
	} // end function query

	/**
	 * Gets the number of rows affected during previous SQL operation.
	 *
	 * Returns the number of rows affected by the last INSERT, UPDATE or DELETE query.
	 * If the last query was a DELETE query with no WHERE clause, all of the records will have been deleted from the table but this function will return zero.
	 * This method is not effective for SELECT statements, only on statements which modify records.
	 *
	 * @return	integer
	 * @access	public
	 * @see 	num_rows()
	*/
	function affected_rows ()
	{
		return sql_affected_rows ($this->connection);
	} // end function affected_rows

	/**
	 * Sends an SQL SELECT query.
	 *
	 * Returns SQL result on success, or FALSE on error.
	 *
	 * @param	mixed	$tables		Table name(s) - array or string.
	 * @param	mixed	$fields		Field name(s) - array or string. If not specified, select all fields.
	 * @param	mixed	$conditions	Condition - array or string.
	 * @return 	mixed	SQL result on success, or FALSE on error.
	 * @access	public
	 * @see 	query()
	 * @see 	select_count()
	 * @see 	select_exists()
	 * @see 	select_record()
	 * @see 	select_row()
	 * @see 	select_column()
	 * @see 	select_result()
	 */
	function select ($tables, $fields="*", $conditions="")
	{
		$query = composeSelectQuery ($tables, $fields, $conditions);
		return $this->query ($query) or die (strErrorSelect . $this->error ());
	} // end function select

	/**
	 * Sends an SQL UPDATE query.
	 *
	 * Returns SQL result on success, or FALSE on error.
	 *
	 * @param	string	$table		Table name.
	 * @param	array	$values		An associative array contains field name(s) as key(s).
	 * @param	mixed	$conditions	Condition - array or string.
	 * @return 	mixed	SQL result on success, or FALSE on error.
	 * @access	public
	 * @see 	query()
	 */
	function update ($table, $values, $conditions="")
	{
		$query = composeUpdateQuery ($table, $values, $conditions);
		return $this->query ($query);
	} // end function update

	/**
	 * Sends an SQL INSERT query.
	 *
	 * Returns SQL result on success, or FALSE on error.
	 *
	 * @param	string	$table	Table name.
	 * @param	array	$values	An associative array contains field name(s) as key(s).
	 * @return 	mixed	SQL result on success, or FALSE on error.
	 * @access	public
	 * @see 	query()
	 * @see 	insert_id()
	 */
	function insert ($table, $values)
	{
		$query = composeInsertQuery ($table, $values);
		return $this->query ($query);
	} // end function insert

	/**
	 * Sends an SQL DELETE query.
	 *
	 * Returns SQL result on success, or FALSE on error.
	 *
	 * @param	string	$table 		Table name.
	 * @param	mixed	$conditions Condition - array or string.
	 * @return 	mixed	SQL result on success, or FALSE on error.
	 * @access	public
	 * @see 	query()
	 */
	function delete ($table, $conditions="")
	{
		$query = composeDeleteQuery ($table, $conditions);
		return $this->query ($query);
	} // end function delete

	/**
	 * Gets result data.
	 *
	 * Returns the contents of one cell from an SQL result set.
	 * The field argument can be the field's offset, or the field's name, or the field's table dot field's name (fieldname.tablename).
	 * If the column name has been aliased ('select foo as bar from...'), use the alias instead of the column name.
	 *
	 * @param	integer	$row
	 * @param	mixed	$field	Field name - integer or string.
	 * @return 	mixed	The contents of one cell from a SQL result set.
	 * @access	public
	 * @see 	fetch_row()
	 * @see 	fetch_array()
	 * @see 	fetch_object()
	 * @see 	fetch_field()
	 * @see 	fetch_fields()
	 * @see 	fetch_result()
	 * @see 	fetch_rows()
	 * @see 	fetch_arrays()
	 * @see 	fetch_objects()
	 */
	function result ($row=0, $field=0)
	{
		return sql_result ($this->queryresult, $row, $field);
	} // end function result

	/**
	 * Gets the number of rows in result.
	 *
	 * This method is only valid for SELECT statements. To retrieve the number of rows returned from an INSERT, UPDATE or DELETE query, use affected_rows().
	 *
	 * @return 	integer	The number of rows in a result set.
	 * @access	public
	 * @see 	affected_rows()
	 * @see 	num_fields()
	 */
	function num_rows ()
	{
		return sql_num_rows ($this->queryresult);
	} // end function num_rows

	/**
	 * Gets the number of fields in result.
	 *
	 * This method is only valid for SELECT statements.
	 *
	 * @return 	integer	The number of fields in result has been preset.
	 * @access	public
	 * @see 	num_rows()
	 */
	function num_fields ()
	{
		return sql_num_fields ($this->queryresult);
	} // end function num_fields

	/**
	 * Get a result row as an enumerated array.
	 *
	 * Returns an array that corresponds to the fetched row, or FALSE if there are no more rows.
	 * Fetch one row of data from the result associated with the specified result identifier.
	 * The row is returned as an array. Each result column is stored in an array offset, starting at offset 0.
	 *
	 * @return 	mixed	Array that corresponds to the fetched row, or FALSE if there are no more rows.
	 * @access	public
	 * @see 	result()
	 * @see 	fetch_array()
	 * @see 	fetch_object()
	 * @see 	fetch_field()
	 * @see 	fetch_fields()
	 * @see 	fetch_result()
	 * @see 	fetch_rows()
	 * @see 	fetch_arrays()
	 * @see 	fetch_objects()
	 */
	function fetch_row ($nr=0)
	{
		return sql_fetch_row ($this->queryresult, $nr);
	} // end function fetch_row

	/**
	 * Fetch a result row as an associative array.
	 *
	 * Returns an array that corresponds to the fetched row, or FALSE if there are no more rows.
	 * In addition to storing the data in the numeric indices of the result array,
	 * it also stores the data in associative indices, using the field names as keys.
	 *
	 * @return 	array	Array that corresponds to the fetched row, or FALSE if there are no more rows.
	 * @access	public
	 * @see 	result()
	 * @see 	fetch_row()
	 * @see 	fetch_object()
	 * @see 	fetch_field()
	 * @see 	fetch_fields()
	 * @see 	fetch_result()
	 * @see 	fetch_rows()
	 * @see 	fetch_arrays()
	 * @see 	fetch_objects()
	 */
	function fetch_array ($nr=0)
	{
		return sql_fetch_array ($this->queryresult, $nr);
	} // end function fetch_array

	/**
	 * Fetch a result row as an object.
	 *
     * Returns an object with properties that correspond to the fetched row, or FALSE if there are no more rows.
	 *
	 * @param	integer	$type
	 * @return 	mixed	Object with properties that correspond to the fetched row, or FALSE if there are no more rows.
	 * @access	public
	 * @see 	result()
	 * @see 	fetch_row()
	 * @see 	fetch_array()
	 * @see 	fetch_field()
	 * @see 	fetch_fields()
	 * @see 	fetch_result()
	 * @see 	fetch_rows()
	 * @see 	fetch_arrays()
	 * @see 	fetch_objects()
	 */
	function fetch_object ($type=0)
	{
		return sql_fetch_object ($this->queryresult, $type);
	} // end function fetch_object

	/**
	 * Gets column information from a result and returns it as an object.
	 *
	 * Returns an object containing field information.
	 * Can be used in order to obtain information about fields in a certain query result.
	 * If the field offset isn't specified, the next field that wasn't yet retrieved by fetch_field() is retrieved.
	 *
	 * @param 	integer	$offset		Field offset.
	 * @return 	object	stdClass	Object containing field information.
	 * @access	public
	 * @see 	result()
	 * @see 	fetch_row()
	 * @see 	fetch_array()
	 * @see 	fetch_object()
	 * @see 	fetch_fields()
	 * @see 	fetch_result()
	 * @see 	fetch_rows()
	 * @see 	fetch_arrays()
	 * @see 	fetch_objects()
	 */
	function fetch_field ($offset)
	{
		return sql_fetch_field ($this->queryresult, $offset);
	} // end function fetch_field

	/**
	 * Gets column information from a result and returns it as an array of objects.
	 *
	 * Can be used in order to obtain information about fields in a certain query result.
	 *
	 * @access	public
	 * @return 	array	Array of objects containing field information.
	 * @see 	result()
	 * @see 	fetch_row()
	 * @see 	fetch_array()
	 * @see 	fetch_object()
	 * @see 	fetch_field()
	 * @see 	fetch_result()
	 * @see 	fetch_rows()
	 * @see 	fetch_arrays()
	 * @see 	fetch_objects()
	 */
	function fetch_fields ()
	{
		for ($i=0; $i<$this->num_fields (); $i++)
			$fields[] = $this->fetch_field ($i);
		return $fields;
	} // end function fetch_fields

	/**
	 * Fetches all rows of result data into a multi-dimensional array.
	 *
	 * Returns a multi-dimensional array[row][field] or array[row] of objects depending on $format parameter.
	 *
	 * @param 	integer	$format	Accept the following constants: fmtRow, fmtArr, fmtObj.
	 * @return 	mixed
	 * @access	public
	 * @see 	result()
	 * @see 	fetch_row()
	 * @see 	fetch_array()
	 * @see 	fetch_object()
	 * @see 	fetch_field()
	 * @see 	fetch_fields()
	 * @see 	fetch_rows()
	 * @see 	fetch_arrays()
	 * @see 	fetch_objects()
	 */
	function fetch_result ($format=fmtRow)
	{
		$result = array ();
		for ($i=0; $i<$this->num_rows (); $i++)
		{
			switch ($format)
			{
				case fmtRow:
					$result[] = $this->fetch_row ($i);
				break;
				case fmtArr:
					$result[] = $this->fetch_array ($i);
				break;
				case fmtObj:
					$result[] = $this->fetch_object ();
				break;
			}
		}
		return $result;
	} // end function fetch_result

	/**
	 * Fetches all rows of result data into a multi-dimensional array.
	 *
	 * Returns a multi-dimensional array[row][field].
	 *
	 * @return 	array
	 * @access	public
	 * @see 	result()
	 * @see 	fetch_row()
	 * @see 	fetch_array()
	 * @see 	fetch_object()
	 * @see 	fetch_field()
	 * @see 	fetch_fields()
	 * @see 	fetch_result()
	 * @see 	fetch_arrays()
	 * @see 	fetch_objects()
	 */
	function fetch_rows ()
	{
		return $this->fetch_result (fmtRow);
	} // end function fetch_rows

	/**
	 * Fetches all rows of result data into a multi-dimensional array.
	 *
	 * Returns a multi-dimensional array[row][field].
	 *
	 * @return 	array
	 * @access	public
	 * @see 	result()
	 * @see 	fetch_row()
	 * @see 	fetch_array()
	 * @see 	fetch_object()
	 * @see 	fetch_field()
	 * @see 	fetch_fields()
	 * @see 	fetch_result()
	 * @see 	fetch_rows()
	 * @see 	fetch_objects()
	 */
	function fetch_arrays ()
	{
		return $this->fetch_result (fmtArr);
	} // end function fetch_arrays

	/**
	 * Fetches all rows of result data.
	 *
	 * Returns an array[row] of objects.
	 *
	 * @return 	array
	 * @access	public
	 * @see 	result()
	 * @see 	fetch_row()
	 * @see 	fetch_array()
	 * @see 	fetch_field()
	 * @see 	fetch_fields()
	 * @see 	fetch_result()
	 * @see 	fetch_rows()
	 * @see 	fetch_arrays()
	 * @see 	fetch_objects()
	 */
	function fetch_objects ()
	{
		return $this->fetch_result (fmtObj);
	} // end function fetch_objects

	/**
	 * Gets the ID generated from the previous INSERT operation.
	 *
	 * Returns the ID generated for an AUTO_INCREMENTED field.
	 *
	 * @return 	integer
	 * @access	public
	 * @see 	insert()
	 */
	function insert_id ()
	{
		return sql_insert_id ($this->queryresult, $this->connection);
	} // end function insert_id

	/**
	 * Check if the previous SELECT operation returns result data.
	 *
	 * Returns TRUE if the previous SELECT operation returns result data, or FALSE.
	 *
	 * @return 	boolean
	 * @access	public
	 * @see 	queryresult_record()
	 * @see 	queryresult_column()
	 */
	function queryresult_exists ()
	{
		return ($this->num_rows () > 0);
	} // end function queryresult_exists

	/**
	 * Fetches next row and returns the first field value.
	 *
	 * @return 	mixed
	 * @access	public
	 * @see 	queryresult_exists()
	 * @see 	queryresult_column()
	 */
	function queryresult_record ()
	{
		$row = $this->fetch_row ();
		return $row[0];
	} // end function queryresult_record

	/**
	 * Fetches all rows of result data and returns the first column values.
	 *
	 * @return 	array
	 * @access	public
	 * @see 	queryresult_record()
	 * @see 	queryresult_exists()
	 */
	function queryresult_column ()
	{
		$column = array ();
		while ($row = $this->fetch_row ())
			$column[] = $row[0];
		return $column;
	} // end function queryresult_column

	/**
	 * Sends a SELECT query and checks if the result data is not empty.
	 *
	 * @param	mixed	$tables		Table name(s) - array or string.
	 * @param	mixed	$conditions Condition - array or string.
	 * @return 	boolean
	 * @access	public
	 * @see 	select()
	 * @see 	select_count()
	 * @see 	select_record()
	 * @see 	select_row()
	 * @see 	select_column()
	 * @see 	select_result()
	 */
	function select_exists ($tables, $conditions="")
	{
		$this->select ($tables, "*", $conditions);
		return $this->queryresult_exists ();
	} // end function select_exists

	/**
	 * Prepares and sends a SELECT query to count the number of rows for the specified conditions.
	 *
	 * @param	mixed	$tables		Table name(s) - array or string.
	 * @param	mixed	$conditions Condition - array or string.
	 * @return 	integer
	 * @access	public
	 * @see 	select()
	 * @see 	select_exists()
	 * @see 	select_record()
	 * @see 	select_row()
	 * @see 	select_column()
	 * @see 	select_result()
	 */
	function select_count ($tables, $conditions="")
	{
		$this->select ($tables, "count(*) as TOTAL", $conditions);
		if (substr_count($conditions, "group by")) return intval ($this->num_rows());
		else return intval ($this->queryresult_record ());
	} // end function select_count

	/**
	 * Sends a SELECT query and returns value of the first row and the first field.
	 *
	 * @param	mixed	$tables		Table name(s) - array or string.
	 * @param	mixed	$fields		Field name(s) - array or string. If not specified, select all fields.
	 * @param	mixed	$conditions Condition - array or string.
	 * @return 	integer
	 * @access	public
	 * @see 	select()
	 * @see 	select_count()
	 * @see 	select_exists()
	 * @see 	select_row()
	 * @see 	select_column()
	 * @see 	select_result()
	 */
	function select_record ($tables, $fields, $conditions="")
	{
		$this->select ($tables, $fields, $conditions);
		return $this->queryresult_record ();
	} // end function select_record

	/**
	 * Sends a SELECT query and returns the first result row as an associative array.
	 *
	 * @param	mixed	$tables		Table name(s) - array or string.
	 * @param	mixed	$fields		Field name(s) - array or string. If not specified, select all fields.
	 * @param	mixed	$conditions Condition - array or string.
	 * @return 	array
	 * @access	public
	 * @see 	select()
	 * @see 	select_count()
	 * @see 	select_exists()
	 * @see 	select_record()
	 * @see 	select_column()
	 * @see 	select_result()
	 */
	function select_row ($tables, $fields, $conditions="")
	{
		$this->select ($tables, $fields, $conditions);
		return $this->fetch_array ();
	} // end function select_row

	/**
	 * Sends a SELECT query and returns the first column values.
	 *
	 * @param	mixed	$tables		Table name(s) - array or string.
	 * @param	mixed	$fields		Field name(s) - array or string. If not specified, select all fields.
	 * @param	mixed	$conditions	Condition - array or string.
	 * @access	public
	 * @return 	array
	 * @see 	select()
	 * @see 	select_count()
	 * @see 	select_exists()
	 * @see 	select_record()
	 * @see 	select_row()
	 * @see 	select_result()
	 */
	function select_column ($tables, $fields, $conditions="")
	{
		$this->select ($tables, $fields, $conditions);
		return $this->queryresult_column ();
	} // end function select_column

	/**
	 * Sends a SELECT query and returns all rows of result data as a multi-dimensional array.
	 *
	 * @param	mixed	$tables Table name(s) - array or string.
	 * @param	mixed	$fields 	Field name(s) - array or string. If not specified, select all fields.
	 * @param	mixed	$conditions Condition - array or string.
	 * @param 	integer	$format Accept the following constants: fmtRow, fmtArr, fmtObj
	 * @return 	mixed
	 * @access	public
	 * @see 	select()
	 * @see 	select_count()
	 * @see 	select_exists()
	 * @see 	select_record()
	 * @see 	select_row()
	 * @see 	select_column()
	 */
	function select_result ($tables, $fields, $conditions="", $format=fmtArr)
	{
		$this->select ($tables, $fields, $conditions);
		return $this->fetch_result ($format);
	} // end function select_result

	/**
	 * Prepares and sends a SELECT query according to the specified expression.
	 *
	 * Returns all rows of result data as a multi-dimensional array.
	 *
	 * @param	string	$expression	Expression.
	 * @param	string	$table		Table name.
	 * @param	string	$field		Field name.
	 * @param	mixed	$fields		Field name(s) - array or string. If not specified, select all fields.
	 * @param 	integer	$type		Accept the following constants: SQL_PATTERN, REGEXP_PATTERN
	 * @param 	array	$limit		Result data limit.
	 * @return 	array
	 * @access	public
	 */
	function search ($expression, $table, $field="", $fields="*", $type=SQL_PATTERN, $limit=array())
	{
		if ($field) targetfield ($field);
		$conditions = expression2conditions ($expression, $type);
		$conditions = standalone ($conditions);
		if ($limit)
		{
			$cnt = $this->select_count ($table, $conditions);
			$conditions .= " limit $limit[FIRST], $limit[NUM]";
		}
		$this->select ($table, $fields, $conditions);
		if (!$limit) $cnt = $this->num_rows ();
		$result = $this->fetch_result (fmtArr);
		$result["COUNT"] = $cnt;
		return $result;
	} // end function search

	/**
	 * Prepares and sends a SELECT query according to the specified expressions.
	 *
	 * Returns all rows of result data as a multi-dimensional array.
	 *
	 * @param	string	$expression	Expression.
	 * @param	string	$table		Table name.
	 * @param	string	$field		Field name.
	 * @param	mixed	$fields		Field name(s) - array or string. If not specified, select all fields.
	 * @param 	integer	$type		Accept the following constants: SQL_PATTERN, REGEXP_PATTERN
	 * @param 	array	$orderby	$orderby["FIELD"] - ordering field, $orderby["DIRECTION"] - ordering direction
	 * @param 	array	$limit		Result data limit.
	 * @return 	array
	 * @access	public
	 */
	function advancedSearch ($expression, $table, $field, $fields="*", $type=SQL_PATTERN, $orderby=array(), $limit=array())
	{
		$conditions = "";
		for ($i=0; $i<sizeof($expression); $i++)
		{
			if ((is_integer (strpos ($expression[$i], EXP_FLAG))) && (strpos ($expression[$i], EXP_FLAG) == 0))
			{
				$condition = $field[$i] . substr ($expression[$i], strlen (EXP_FLAG));
			}
			else
			{
			targetfield ($field[$i]);
			$condition = expression2conditions ($expression[$i], $type);
			$condition = standalone ($condition, false);

			}
			if ($i==0) $conditions .= " ( " . $condition ." ) ";
			else $conditions .= " and (" . $condition ." ) ";
		}
		if ($conditions!="") $conditions = composeQueryConditions ($conditions, $type=CND_SIMPLE);

		if ($orderby) $conditions .= " order by " . $orderby["FIELD"] . " " . $orderby["DIRECTION"];

		if ($limit)
		{
			$cnt = $this->select_count ($table, $conditions);
			$conditions .= " limit $limit[FIRST], $limit[NUM]";
		}
		$this->select ($table, $fields, $conditions);
		if (!$limit) $cnt = $this->num_rows ();
		$result = $this->fetch_result (fmtArr);
		$result["COUNT"] = $cnt;
		return $result;
	} // end function advancedSearch

} // end class sqlStorage

?>
