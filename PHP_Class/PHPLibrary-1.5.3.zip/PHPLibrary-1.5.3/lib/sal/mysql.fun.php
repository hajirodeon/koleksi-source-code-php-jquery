<?php
//
// +----------------------------------------------------------------------+
// | Softerra PHP developer library                                       |
// +----------------------------------------------------------------------+
// | Copyright (c) 1999-2002 Softerra, LLC                                |
// +----------------------------------------------------------------------+
// | This library is free software; you can redistribute it and/or modify |
// | it  under  the  terms  of  the  GNU Lesser General Public License as |
// | published by the Free Software Foundation; either version 2.1 of the |
// | License, or (at your option) any later version.                      |
// |                                                                      |
// | This  library is distributed in the hope that it will be useful, but |
// | WITHOUT   ANY  WARRANTY;  without  even  the  implied  warranty  of  |
// | MERCHANTABILITY  or  FITNESS  FOR A PARTICULAR PURPOSE.  See the GNU |
// | Lesser General Public License for more details.                      |
// +----------------------------------------------------------------------+
// | Contacts: http://www.softerra.com, mailto:phplib@softerra.com        |
// +----------------------------------------------------------------------+
//

/**
 *
 * MySQL SQL Abstraction Layer
 *
 * @module		MySQL
 * @modulegroup	SAL
 * @package		Softerra
 * @author		Softerra <phplib@softerra.com>
 * @copyright	(c) 1999-2002 Softerra, LLC
 * @link		http://www.softerra.com/products/ [Softerra PHP Developer Library Home Page]
 * @version		1.2.5
 * @access		private
 * @since		PHP 4.0.1pl2
 */

/**
 * Connects to a MySQL Server.
 *
 * @param	string		$host		database host
 * @param	string		$user		database user name
 * @param	string		$password	database user password
 * @param	string		$name		database name
 * @return	mixed		Returns a MySQL link identifier on success, or FALSE on failure.
 * @global	boolean		$salPersistentConnect	Define whether to perform persistent connect to SQL server
 * @access	private
 */
function sql_connect ($host, $user, $password, $name="")
{
	if ($GLOBALS["salPersistentConnect"])
		$connection = @mysql_pconnect ($host, $user, $password);
	else
		$connection = @mysql_connect ($host, $user, $password);
	if ($name && $connection) mysql_select_db ($name);
	return $connection;
} // end function sql_connect

/**
 * Disconnects from a MySQL server.
 *
 * @param	resource	$connection	MySQL link identifier
 * @return	boolean		TRUE on success, FALSE on error.
 * @global	boolean		$salPersistentConnect	Define whether to perform persistent connect to SQL server
 * @access	private
 */
function sql_close ($connection=NULL)
{
	if ($GLOBALS["salPersistentConnect"])
		return true;
	else
		return mysql_close ($connection);
} // end function sql_close

/**
 * Selects a MySQL database.
 *
 * @param	string		$name		database name
 * @return	boolean		TRUE on success, FALSE on error.
 * @access	private
 */
function sql_select_db ($name)
{
	return mysql_select_db ($name);
} // end function sql_select_db

/**
 * Sends a MySQL query.
 *
 * @param	string		$query		MySQL query
 * @param	resource	$connection	MySQL link identifier
 * @return	mixed		MySQL result on success, or FALSE on error.
 * @access	private
 */
function sql_query ($query, $connection=NULL)
{
	return mysql_query ($query, $connection);
} // end function sql_query

/**
 * Gets the number of rows in result.
 *
 * @param	resource	$queryresult	MySQL result
 * @return	integer		Returns the number of rows in a result set.
 * @access	private
 */
function sql_num_rows ($queryresult)
{
	return mysql_num_rows ($queryresult);
} // end function sql_num_rows

/**
 * Gets the number of fields in result.
 *
 * @param	resource	$queryresult	MySQL result
 * @return	integer	Returns the number of fields in a result set.
 * @access	private
 */
function sql_num_fields ($queryresult)
{
	return mysql_num_fields ($queryresult);
} // end function sql_num_fields

/**
 * Gets a result row as an enumerated array.
 *
 * Returns an array that corresponds to the fetched row, or FALSE if there are no more rows.
 * Fetch one row of data from the result associated with the specified result identifier.
 * The row is returned as an array. Each result column is stored in an array offset, starting at offset 0.
 *
 * @param	resource	$queryresult	MySQL result
 * @param	integer		$nr				reserved
 * @return	mixed		Array that corresponds to the fetched row, or FALSE if there are no more rows.
 * @access	private
 */
function sql_fetch_row ($queryresult, $nr=0)
{
	return mysql_fetch_row ($queryresult);
} // end function sql_fetch_row

/**
 * Fetch a result row as an associative array, a numeric array, or both.
 *
 * Returns an array that corresponds to the fetched row, or FALSE if there are no more rows.
 * In addition to storing the data in the numeric indices of the result array,
 * it also stores the data in associative indices, using the field names as keys.
 *
 * @param	resource	$queryresult	MySQL result
 * @param	integer		$nr				reserved
 * @return	mixed		Array that corresponds to the fetched row, or FALSE if there are no more rows.
 * @todo	implement result type: MYSQL_ASSOC, MYSQL_NUM, and MYSQL_BOTH.
 * @access	private
 */
function sql_fetch_array ($queryresult, $nr=0)
{
	return mysql_fetch_array ($queryresult);
} // end function sql_fetch_array

/**
 * Fetches a result row as an object.
 *
 * Returns an object with properties that correspond to the fetched row, or FALSE if there are no more rows.
 *
 * @param	resource	$queryresult	MySQL result
 * @param	integer		$resulttype		Result type
 * @param	integer		$nr				Reserved
 * @return	mixed		Object with properties that correspond to the fetched row, or FALSE if there are no more rows.
 * @todo	implement result type: MYSQL_ASSOC, MYSQL_NUM, and MYSQL_BOTH.
 * @access	private
 */
function sql_fetch_object ($queryresult, $resulttype=0, $nr=0)
{
	return mysql_fetch_object ($queryresult, $resulttype);
} // end function sql_fetch_object

/**
 * Gets column information from a result and returns it as an object.
 *
 * Returns an object containing field information.
 * Can be used in order to obtain information about fields in a certain query result.
 * If the field offset isn't specified, the next field that wasn't yet retrieved by fetch_field() is retrieved.
 *
 * @param	resource	$queryresult	MySQL result.
 * @param	integer		$offset			Field offset.
 * @return	object		stdClass		Object containing field information.
 * The object properties are:
 * <ul>
 * 	<li>name - column name
 * 	<li>table - name of the table the column belongs to;</li>
 * 	<li>max_length - maximum length of the column;</li>
 * 	<li>not_null - 1 if the column cannot be NULL;</li>
 * 	<li>primary_key - 1 if the column is a primary key;</li>
 * 	<li>unique_key - 1 if the column is a unique key;</li>
 * 	<li>multiple_key - 1 if the column is a non-unique key;</li>
 * 	<li>numeric - 1 if the column is numeric;</li>
 * 	<li>blob - 1 if the column is a BLOB;</li>
 * 	<li>type - the type of the column;</li>
 * 	<li>unsigned - 1 if the column is unsigned;</li>
 * 	<li>zerofill - 1 if the column is zero-filled.</li>
 * </ul>
 * @access	private
 */
function sql_fetch_field ($queryresult, $offset=0)
{
	return mysql_fetch_field ($queryresult, $offset);
} // end function sql_fetch_field

/**
 * Gets result data.
 *
 * @param	resource	$queryresult	MySQL result
 * @param	integer		$row			The rows offset
 * @param	mixed		$field			The field's offset, or the field's name, or the field's table dot field's name (tabledname.fieldname). If the column name has been aliased ('select foo as bar from...'), use the alias instead of the column name.
 * @return	mixed		The contents of one cell from a MySQL result set.
 * @access	private
 */
function sql_result ($queryresult, $row=0, $field=0)
{
	return mysql_result ($queryresult, $row, $field);
} // end function sql_result

/**
 * Frees result memory.
 *
 * Will free all memory associated with the result identifier result.
 *
 * @param	resource	$queryresult	MySQL result
 * @return	boolean		TRUE on success, FALSE on error.
 * @access	private
 */
function sql_free_result ($queryresult)
{
	return mysql_free_result ($queryresult);
} // end function sql_free_result

/**
 * Gets the ID generated from the previous INSERT operation.
 *
 * @param	resource	$queryresult	MySQL result
 * @param	resource	$connection		MySQL link identifier
 * @return	integer		The ID generated for an AUTO_INCREMENT column by the previous INSERT query using the given MySQL link identifier.
 * @todo	Investigate all SQL functions and recode this function
 * @access	private
 */
function sql_insert_id ($queryresult=NULL, $connection=NULL)
{
	return mysql_insert_id ($connection);
} // end function sql_insert_id

/**
 * Returns the text of the error message from the previous MySQL operation.
 *
 * @param	resource	$connection		MySQL link identifier
 * @return	string		Returns the error text from the last MySQL function, or '' (the empty string) if no error occurred.
 * @access	private
 */
function sql_error ($connection=NULL)
{
	return @mysql_error ($connection);
} // end function sql_error

/**
 * Lists databases available on a MySQL server.
 *
 * @param	resource	$connection		MySQL link identifier
 * @return	array		Array of database names
 * @access	private
 */
function sql_list_dbs ($connection=NULL)
{
	$result = mysql_list_dbs ($connection);
	for ($i=0; $i<mysql_num_rows ($result); $i++)
		$dbs[] = mysql_tablename ($result, $i);
	return $dbs;
} // end function sql_list_dbs

/**
 * Lists tables in a MySQL database.
 *
 * @param	string		$db				Database name
 * @param	resource	$connection		MySQL link identifier
 * @return	array		Array of table names
 * @access	private
 */
function sql_list_tables ($db, $connection=NULL)
{
	$result = mysql_list_tables ($db, $connection);
	for ($i=0; $i<mysql_num_rows ($result); $i++)
		$tables[] = mysql_tablename ($result, $i);
	return $tables;
} // end function sql_list_tables

/**
 * Lists MySQL result fields.
 *
 * @param	string		$db				Database name
 * @param	string		$table			Table name
 * @param	resource	$connection		MySQL link identifier
 * @return	array		Array of fields names
 * @access	private
 */
function sql_list_fields ($db, $table, $connection=NULL)
{
	$columns = array ();
	$result = mysql_list_fields ($db, $table, $connection);
	for ($i=0; $i<mysql_num_fields ($result); $i++)
		$columns[] = mysql_field_name ($result, $i);
	return $columns;
} // end function sql_list_fields

/**
 * Gets the number of affected rows in the previous MySQL operation.
 *
 * @param	resource	$connection		MySQL link identifier
 * @return	integer		Returns the number of rows affected by the last INSERT, UPDATE or DELETE query associated with the MySQL link identifier.
 * @access	private
 */
function sql_affected_rows ($connection=NULL)
{
	return mysql_affected_rows ($connection);
} // end function sql_affected_rows

?>