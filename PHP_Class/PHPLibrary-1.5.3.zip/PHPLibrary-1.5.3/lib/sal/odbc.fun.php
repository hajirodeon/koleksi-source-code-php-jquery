<?php
/**
 *
 * ODBC SQL Abstraction Layer
 *
 * @module		ODBC
 * @modulegroup	SAL
 * @package		Softerra
 * @author		Softerra <phplib@softerra.com>
 * @copyright	(c) 1999-2001 Softerra, LLC
 * @link		http://www.softerra.com/products/ [Softerra PHP Developer Library Home Page]
 * @version		0.0.2
 * @access		private
 * @since		PHP 4.0.1pl2
 */

// +----------------------------------------------------------------------+
// | Softerra PHP developer library                                       |
// +----------------------------------------------------------------------+
// | Copyright (c) 1999-2001 Softerra, LLC                                |
// +----------------------------------------------------------------------+
// | This library is free software; you can redistribute it and/or modify |
// | it  under  the  terms  of  the  GNU Lesser General Public License as |
// | published by the Free Software Foundation; either version 2.1 of the |
// | License, or (at your option) any later version.                      |
// |                                                                      |
// | This  library is distributed in the hope that it will be useful, but |
// | WITHOUT   ANY  WARRANTY;  without  even  the  implied  warranty  of  |
// | MERCHANTABILITY  or  FITNESS  FOR A PARTICULAR PURPOSE.  See the GNU |
// | Lesser General Public License for more details.                      |
// +----------------------------------------------------------------------+
// | Contacts: http://www.softerra.com, mailto:phplib@softerra.com        |
// +----------------------------------------------------------------------+

/**
 * Connects to a ODBC datasource.
 *
 * @param	string		$dsn		datasource name
 * @param	string		$user		datasource user name
 * @param	string		$password	datasource user password
 * @param	string		$name		database name
 * @return	mixed		Returns a MySQL link identifier on success, or FALSE on failure.
 * @global	boolean		$salPersistentConnect	Define whether to perform persistent connect to SQL server
 * @access	private
 */
function sql_connect ($dsn, $user, $password, $name="")
{
	if ($GLOBALS["salPersistentConnect"])
		$connection = @odbc_pconnect ($dsn, $user, $password);
	else
		$connection = @odbc_connect ($dsn, $user, $password);
	return $connection;
} // end function sql_connect

/**
 * Close an ODBC connection.
 *
 * @param	resource	$connection	ODBC link identifier
 * @return	boolean		TRUE on success, FALSE on error.
 * @global	boolean		$salPersistentConnect	Define whether to perform persistent connect to SQL server
 * @access	private
 */
function sql_close ($connection=NULL)
{
	if ($GLOBALS["salPersistentConnect"])
		return true;
	else
		return odbc_close ($connection);
} // end function sql_close

/**
 * Get the last error message
 *
 * @param	resource	$connection		MySQL link identifier
 * @return	string		Returns a string containing the last ODBC error message, or an empty string if there has been no errors.
 * @access	private
 */
function sql_error ($connection=NULL)
{
	return @odbc_errormsg ($connection);
} // end function sql_error

function sql_list_tables ($db, $connection=NULL)
{
	$tables = array();
	$result = odbc_tables ($connection);
	while ( odbc_fetch_into ($result, $table) )
	{
		if ( $table[3] == "TABLE" ) // ToDo - define 3 and TABLE
			$tables[] = $table[2];
	}
	return $tables;
} // end function sql_list_tables

function sql_list_fields ($db, $table, $connection=NULL)
{
	$server = sql_get_db_type ($connection);
	$fields = array ();

	switch ( $server[DB_INFO_ODBCTYPE] )
	{
		case DB_ODBC_MYSQL:
			$result = odbc_columns ($connection, "%", "%", $table); // MySQL
		break;

		case DB_ODBC_MSSQL:
		case DB_ODBC_MSACCESS:
		case DB_ODBC_UNKNOWN:
		default:
			$result = odbc_columns ($connection); // MS Access, MS SQL
		break;

	}

	if ( $result )
		while ( odbc_fetch_into ($result, $field) )
		{
			if ( $field[2] == $table)
				$fields[] = $field[3];
		}
	return $fields;
} // end function sql_list_fields

function sql_query ($query, $connection=NULL)
{
	return odbc_exec ($connection, $query);
} // end function sql_query

function sql_num_rows ($queryresult)
{
	if ( ($numRows = odbc_num_rows ($queryresult)) < 0)
	{
		$numRows = 0;
		odbc_fetch_row($queryresult, 0);
		while ( odbc_fetch_row($queryresult) )
		{
			$numRows++;
		}
		odbc_fetch_row($queryresult, 0);
	}
	return $numRows;
} // end function sql_num_rows

function sql_fetch_array ($queryresult, $nr=0)
{
	$result = array();
	if (odbc_fetch_row($queryresult, $nr+1))
		for ($i=0; $i<odbc_num_fields($queryresult); $i++)
		{
			$result[$i] = odbc_result($queryresult, $i+1);
			$result[odbc_field_name($queryresult, $i+1)] = $result[$i];
		}
	return $result;
} // end function sql_fetch_array

function sql_fetch_row ($queryresult, $nr=0)
{
	$result = array();
	if (odbc_fetch_row($queryresult, $nr+1))
		for ($i=0; $i<odbc_num_fields($queryresult); $i++)
		{
			$result[$i] = odbc_result($queryresult, $i+1);
		}
	return $result;
} // end function sql_fetch_row

function sql_free_result ($queryresult)
{
	return odbc_free_result ($queryresult);
} // end function sql_free_result

define ("DB_ODBC_UNKNOWN",	1);
define ("DB_ODBC_MSSQL",	2);
define ("DB_ODBC_MSACCESS",	3);
define ("DB_ODBC_MYSQL",	4);

define ("DB_ODBC_MSSQL_FIELD",		"uniqueidentifier");
define ("DB_ODBC_MSACCESS_FIELD",	"GUID");
define ("DB_ODBC_MYSQL_FIELD",		"set");

define ("DB_INFO_ODBCTYPE", 0);

function sql_get_db_type ($connection)
{
	$serverInfo = array ();
	if ( $result = odbc_gettypeinfo($connection) )
	{
		$type = false;
		while ( odbc_fetch_into ($result, $field) && !$type )
		{
			switch ($field[0])
			{
				case DB_ODBC_MSSQL_FIELD:
					$type = DB_ODBC_MSSQL;
				break;

				case DB_ODBC_MSACCESS_FIELD:
					$type = DB_ODBC_MSACCESS;
				break;

				case DB_ODBC_MYSQL_FIELD:
					$type = DB_ODBC_MYSQL;
				break;

			}
 		}
 		$serverInfo[DB_INFO_ODBCTYPE] = ($type) ? $type : DB_ODBC_UNKNOWN;
	}
	else
	{
		$serverInfo[DB_INFO_ODBCTYPE] = DB_ODBC_UNKNOWN;
	}

	return $serverInfo;
} // end function sql_get_db_type

function sql_select_db ($name)
{
	return true;
} // end function sql_select_db

function sql_num_fields ($queryresult)
{
	return odbc_num_fields ($queryresult);
} // end function sql_num_fields

function sql_fetch_field ($queryresult, $offset=0)
{
	return NULL;
} // end function sql_fetch_field

function sql_insert_id ($queryresult=NULL, $connection=NULL)
{
	return NULL;
} // end function sql_insert_id

function sql_list_dbs ($connection=NULL)
{
	return NULL;
} // end function sql_list_dbs

?>