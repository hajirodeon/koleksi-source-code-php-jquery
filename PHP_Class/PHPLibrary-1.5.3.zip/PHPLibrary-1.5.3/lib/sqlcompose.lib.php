<?php
//
// +----------------------------------------------------------------------+
// | Softerra PHP developer library                                       |
// +----------------------------------------------------------------------+
// | Copyright (c) 1999-2002 Softerra, LLC                                |
// +----------------------------------------------------------------------+
// | This library is free software; you can redistribute it and/or modify |
// | it  under  the  terms  of  the  GNU Lesser General Public License as |
// | published by the Free Software Foundation; either version 2.1 of the |
// | License, or (at your option) any later version.                      |
// |                                                                      |
// | This  library is distributed in the hope that it will be useful, but |
// | WITHOUT   ANY  WARRANTY;  without  even  the  implied  warranty  of  |
// | MERCHANTABILITY  or  FITNESS  FOR A PARTICULAR PURPOSE.  See the GNU |
// | Lesser General Public License for more details.                      |
// +----------------------------------------------------------------------+
// | Contacts: http://www.softerra.com, mailto:phplib@softerra.com        |
// +----------------------------------------------------------------------+
//

/**
 *
 * Simple SQL Query Compose Library.
 *
 * @module		SQLCompose
 * @modulegroup	SQL
 * @package		Softerra
 * @author		Softerra <phplib@softerra.com>
 * @copyright	(c) 1999-2002 Softerra, LLC
 * @link		http://www.softerra.com/products/ [Softerra PHP Developer Library Home Page]
 * @version		1.3.5
 * @access		public
 * @since		PHP 4.0.1pl2
 */

/**
 *
 * Array Functions Library.
 *
 * @author		Softerra <phplib@softerra.com>
 * @copyright	(c) 1999-2002 Softerra, LLC
 * @link		http://www.softerra.com/products/ [Softerra PHP Developer Library Home Page]
 * @version		1.1.7
 * @since		PHP 4.0.1pl2
 */
require_once ($lib_dir . "array.lib.php");

/**
 * Expression flag.
 *
 * @const	EXP_FLAG
 * @access	private
 */
define ("EXP_FLAG", 'EXPRESSION=');

/**
 * Equality condition.
 *
 * @const	CND_EQUALITY
 * @access	private
 */
define ("CND_EQUALITY", 1);

/**
 * Homogenic condition.
 *
 * @const	CND_HOMOGENIC
 * @access	private
 */
define ("CND_HOMOGENIC", 2);

/**
 * Complex condition.
 *
 * @const	CND_COMPLEX
 * @access	private
 */
define ("CND_COMPLEX", 3);

/**
 * Simple condition.
 *
 * @const	CND_SIMPLE
 * @access	private
 */
define ("CND_SIMPLE", 4);

/**
 * Dummy condition.
 *
 * @const	CND_DUMMY
 * @access	private
 */
define ("CND_DUMMY", 5);

/**
 * Returns a single-quoted value.
 *
 * Returns a quoted $value with backslashes before characters that need to be quoted in database queries, etc. These characters are a single quote ('), a double quote ("), a backslash (\) and NUL (the NULL byte).
 *
 * @param	string	$value
 * @return	string
 * @access	public
 */
function quotedValue ($value)
{
	return "'" . addslashes ($value) . "'";
} // end function quotedValue

/**
 * Prepares a value or expression.
 *
 * Prepares a value or expression to be used in SQL statements. Add slashes if $sqlAddSlashes is set.
 *
 * @param	string	&$value
 * @global	boolean	$sqlAddSlashes
 * @see		prepareValuesOrExpressions()
 * @access	private
 */
function prepareValueOrExpression (&$value)
{
	global $sqlAddSlashes;
	if (is_string ($value) && (strtoupper ($value) != "NULL"))
		if ((is_integer (strpos ($value, EXP_FLAG))) && (strpos ($value, EXP_FLAG) == 0))
			$value = substr ($value, strlen (EXP_FLAG));
		else
			if ($sqlAddSlashes)
				$value = "'" . addslashes ($value) . "'";
			else
				$value = "'" . $value . "'";
} // end function prepareValueOrExpression

/**
 * Prepares values or expressions.
 *
 * Prepares values or expressions to be used in SQL statements.
 *
 * @param	array	&$values
 * @see		prepareValuesOrExpressions()
 * @access	private
 */
function prepareValuesOrExpressions (&$values)
{
	array_walk ($values, 'prepareValueOrExpression');
} // end function prepareValuesOrExpressions

/**
 * Returns an array of field names.
 *
 * Returns an array of field names in the TABLE_NAME.FIELD_NAME format.
 *
 * @param	array	$fields	Field names
 * @param	string	$table	Table name
 * @return	array
 * @access	private
 */
function withTablePrefix ($fields, $table)
{
	alterArray ($fields, $table . ".");
	return $fields;
} // end function withTablePrefix

/**
 * Returns the INSERT SQL query string.
 *
 * Returns the composed INSERT SQL query string.
 *
 * @param	string	$table	Table name
 * @param	array	$values	Array of values to insert. Array keys should be an integer or FIELD_NAMES.
 * @return	string	SQL query
 * @access	public
 * @todo	Example
 */
function composeInsertQuery ($table, $values)
{
	$query = "insert into $table";
	if (key ($values) != "0")
	{
		$query .= " (" . listArrayKeys ($values) . ")";
	}
	prepareValuesOrExpressions ($values);
	$query .= " values (" . listArrayValues ($values) . ")";
	return $query;
} // end function composeInsertQuery


/**
 * Returns the UPDATE SQL query string.
 *
 * Returns the composed UPDATE SQL query string.
 *
 * @param	string	$table		Table name.
 * @param	array	$values		Array of values to update. Array keys should be FIELD_NAMES.
 * @param	mixed	$conditions	Conditions, an array or string, if needed.
 * @return	string	SQL query.
 * @access	public
 * @todo	Example
 */
function composeUpdateQuery ($table, $values, $conditions)
{
	prepareValuesOrExpressions ($values);
	$query = "update $table set " . listArrayKeysAndValues ($values);
	$query .= simpleConditions ($conditions);
	return $query;
} // end function composeUpdateQuery

/**
 * Returns the SELECT SQL query string.
 *
 * Returns the composed SELECT SQL query string.
 *
 * @param	mixed	$tables		Tables names, array or string.
 * @param	mixed	$fields		Fields names, array or string.
 * @param	mixed	$conditions	Conditions, an array or string, if needed.
 * @return	string	SQL query.
 * @access	public
 * @todo	Example
 */
function composeSelectQuery ($tables, $fields, $conditions)
{
	$query = "select ";
	if (is_array ($fields))
		$query .= listArrayValues ($fields);
	else
		$query .= $fields;
	$query .= " from ";
	if (is_array ($tables))
		$query .= listArrayValues ($tables);
	else
		$query .= $tables;
	$query .= simpleConditions ($conditions);
	return $query;
} // end function composeSelectQuery

/**
 * Returns the DELETE SQL query string.
 *
 * Returns the composed DELETE SQL query string.
 *
 * @param	string	$table		Table name.
 * @param	mixed	$conditions	Conditions, an array or string, if needed.
 * @return	string	SQL query.
 * @access	public
 * @todo	Example
 */
function composeDeleteQuery ($table, $conditions)
{
	$query = "delete from $table";
	$query .= simpleConditions ($conditions);
	return $query;
} // end function composeDeleteQuery

/**
 * Returns the simple condition string.
 *
 * Return the composed simple condition string. The string returned should begin with "WHERE" if $conditions is an array.
 *
 * @param	mixed	$conditions	Conditions, an array or string.
 * @return	string	SQL query WHERE part.
 * @access	public
 * @todo	Example. If the $conditions string does not begin with "WHERE", returns "WHERE".$conditions.
 */
function simpleConditions ($conditions)
{
	if ($conditions)
	{
		if (is_array ($conditions))
			$result = composeQueryConditions ($conditions);
		else
			$result = " " . $conditions;
	}
	else $result = "";
	return $result;
} // end function simpleConditions

/**
 * Returns homogenic condition.
 *
 * Returns an SQL query with the WHERE part being in the following format:
 * <pre>
 * "$conditions[key] $relation $conditions[value] [$operation $conditions[key] $relation $conditions[value]]"
 * </pre>
 * without the "WHERE" string.
 *
 * @param	array	$conditions	Array where the array key is a table field and the array value is a field value.
 * @param	string	$relation	One of the allowed SQL relations.
 * @param	string	$operation	One of the allowed SQL operations.
 * @return	string	WHERE part of SQL query without the "WHERE" string.
 * @access	private
 * @see		equalityConditions()
 * @todo	Example
 */
function homogenicConditions ($conditions, $relation="=", $operation="and")
{
	prepareValuesOrExpressions ($conditions);
	$relation = " " . $relation . " ";
	$operation = " " . $operation . " ";
	return listArrayKeysAndValues ($conditions, $relation, $operation);
} // end function homogenicConditions

/**
 * Returns equality condition.
 *
 * If $sqlLikeStringEquality is not set, calls homogenicConditions().
 * If the array value is a string, returns the WHERE part of an SQL query in the following format:
 * <pre>
 * "$conditions[key] like $conditions[value]"
 * </pre>
 * else return
 * <pre>
 * "$conditions[key] = $conditions[value]"
 * </pre>
 *
 * @param	array	$conditions	Array where the array key is a table field and the array value is a field value.
 * @return	string	WHERE part of an SQL query without the "WHERE" string.
 * @global	boolean	$sqlLikeStringEquality
 * @access	private
 * @see		homogenicConditions()
 * @todo	Example
 */
function equalityConditions ($conditions)
{
	global $sqlLikeStringEquality;
	$equalities = "";
	if ($sqlLikeStringEquality)
	{
		prepareValuesOrExpressions ($conditions);
		reset ($conditions);
		while (list ($field, $value) = each ($conditions))
		{
			$equalities .= $field;
			if (is_string ($value) && ($value[0] == "'"))
				$equalities .= " like " . $value;
			else
				$equalities .= " = " . $value;
			$equalities .= " and ";
		}
		$equalities = substr ($equalities, 0, -strlen (" and "));
	}
	else $equalities = homogenicConditions ($conditions);
	return $equalities;
} // end function equalityConditions

/**
 * Returns complex condition.
 *
 * Returns the composed complex condition string.
 * If the array value is a string, returns the WHERE part of an SQL query in the following format:
 * <pre>
 * "$conditions[key] like $conditions[value]"
 * </pre>
 * else return
 * <pre>
 * "$conditions[key] = $conditions[value]"
 * </pre>
 *
 * @param	array	$conditions		This array contains the $field string and the $condition array
 *			$field is the $condition's key and $condition is the $condition's value
 *			$condition contains the $relation and $value string
 *			Supported $relation list: "like", "=", "!=", "<>", "<", ">", "<=", ">=", "in", "not in", "between", "not between", "IS NULL", "IS NOT NULL"
 * @param	array	$operations		This array contains the "and" and "or" operations to be placed before the condition. I.e., the first element can be empty ("").
 * @return	string	WHERE part of an SQL query without the "WHERE" string.
 * @todo	GROUP BY. More than one condition for $field
 */
function complexConditions ($conditions, $operations)
{
	$result = "";
	while (list ($field, $condition) = each ($conditions))
	{
		list ($relation, $value) = each ($condition);
		$result .= $field . " " . $relation . " ";
		switch ($relation) {
			case "like": case "=": case "<>": case "!=":
			case "<": case ">": case "<=": case ">=":
				prepareValueOrExpression ($value);
				$result .= $value;
			break;
			case "in": case "not in":
				if (is_array($value))
				{
					prepareValuesOrExpressions ($value);
					$result .= "(" . listArrayValues ($value) . ")";
				}
				else
				{
					//$result .= "(" . prepareValueOrExpression ($value) . ")";
					$result .= "(" . $value . ")";
				}
			break;
			case "between": case "not between":
				prepareValuesOrExpressions ($value);
				$result .= $value[0] . " and " . $value[1];
			break;
			case "IS NULL": case "IS NOT NULL":
			break;
		}
		if ($operation = next ($operations))
			$result .= " " . $operation . " ";
	}
	return "(" . $result . ")";
} // end function complexConditions

/**
 * Returns dummy condition.
 *
 * Returns the composed dummy condition string - "(1)". Needs to be used when user does not require any conditions.
 *
 * @return	string	WHERE part of an SQL query without the "WHERE" string.
 * @access	private
 */
function dummyCondition ()
{
	return "(1)";
} // end function dummyCondition

/**
 * Returns SQL query end part.
 *
 * Returns the composed WHERE, LIMIT, ORDER BY and GROUP BY parts of an SQL query.
 *
 * @param	mixed	$conditions
 * @param	integer	$type			Type of condition:
 * <ul>
 * 	<li>CND_EQUALITY - equalityConditions;</li>
 * 	<li>CND_HOMOGENIC - homogenicConditions;</li>
 * 	<li>CND_COMPLEX - complexConditions;</li>
 * 	<li>CND_SIMPLE - simpleConditions;</li>
 * 	<li>CND_DUMMY - dummyCondition.</li>
 * </ul>
 * @param	array	$limit		Where $limit[0] - oofset, $limit[1] - rows.
 * @param	array	$parameters Additional parameters. If $type == CND_HOMOGENIC, you need to specify $parameters["relation"] and  $parameters["operation"].
 * @param	array	$orderby	$orderby[0] - string or array - field(s), $orderby[1] - direction (ASC, DESC).
 * @param	array	$groupby
 * @return	string
 * @access	public
 */
function composeQueryConditions ($conditions, $type=CND_EQUALITY, $limit=array(), $parameters=array("relation" => "=", "operation" => "and"), $orderby=array(), $groupby=array())
{
	$where = " where ";
	switch ($type)
	{
		case CND_EQUALITY:
			$where .= equalityConditions ($conditions);
		break;
		case CND_HOMOGENIC:
			$where .= homogenicConditions ($conditions, $parameters["relation"], $parameters["operation"]);
		break;
		case CND_COMPLEX:
			$where .= complexConditions ($conditions, $parameters);
		break;
		case CND_SIMPLE:
			$where .= $conditions;
			//$where .= simpleConditions ($conditions);
		break;
		case CND_DUMMY:
			$where .= dummyCondition ();
		break;
	}

	if (($groupby) && is_array($groupby)) $where .= " group by " . listArrayValues($groupby);
	elseif (($groupby) && is_string($groupby)) $where .= " group by " . $groupby;

	if (($orderby) && (is_array($orderby[0]))) $where .= " order by " . listArrayValues($orderby[0]) . " " . $orderby[1];
	elseif (($orderby) && (is_array($orderby))) $where .= " order by " . $orderby[0] . " " . $orderby[1];

	if ($limit) $where .= " limit $limit[0], $limit[1]";
	return $where;
} // end function composeQueryConditions

?>
