<?php
//
// +----------------------------------------------------------------------+
// | Softerra PHP developer library                                       |
// +----------------------------------------------------------------------+
// | Copyright (c) 1999-2002 Softerra, LLC                                |
// +----------------------------------------------------------------------+
// | This library is free software; you can redistribute it and/or modify |
// | it  under  the  terms  of  the  GNU Lesser General Public License as |
// | published by the Free Software Foundation; either version 2.1 of the |
// | License, or (at your option) any later version.                      |
// |                                                                      |
// | This  library is distributed in the hope that it will be useful, but |
// | WITHOUT   ANY  WARRANTY;  without  even  the  implied  warranty  of  |
// | MERCHANTABILITY  or  FITNESS  FOR A PARTICULAR PURPOSE.  See the GNU |
// | Lesser General Public License for more details.                      |
// +----------------------------------------------------------------------+
// | Contacts: http://www.softerra.com, mailto:phplib@softerra.com        |
// +----------------------------------------------------------------------+
//

/**
 *
 * "Corban, dear" - Debug Output Library.
 *
 * Capable of facilitating the application development process quite considerably. It allows developers to derive information on variables, objects and resources. While the current version features just the html output derivation, the following releases are going to be supplemented with more info derivation types like �file�, �port�, �email� and �database�.
 *
 * @module		Corban
 * @modulegroup	Debug
 * @package		Softerra
 * @author		Softerra <phplib@softerra.com>
 * @copyright	(c) 1999-2002 Softerra, LLC
 * @link		http://www.softerra.com/products/ [Softerra PHP Developer Library Home Page]
 * @version		1.3.5
 * @access		public
 * @since		PHP 4.0.1pl2
 */

/**
 * Break line.
 *
 * @const	BR
 * @access	private
 */
define ("BR", "<br>");
/**
 * Non-breakable space.
 *
 * @const	NBSP
 * @access	private
 */
define ("NBSP", "&nbsp;");
/**
 * Default text style.
 *
 * @const	FONTTEXT
 * @access	private
 */
define ("FONTTEXT", "<font face=\"Arial\" color=\"%s\" style=\"font-size:%dpt\">%s</font>");
/**
 * Bold text style.
 *
 * @const	BOLDTEXT
 * @access	private
 */
define ("BOLDTEXT", "<b>%s</b>");
/**
 * Die message.
 *
 * @const	CORBAN_DIE_SCREAM
 * @access	private
 */
define ("CORBAN_DIE_SCREAM", "<br>CORBAN MUST DIE!<br>");
/**
 * Debug message prefix.
 *
 * @const	CORBAN_PREFIX
 * @access	private
 */
define ("CORBAN_PREFIX", "&nbsp;Corban, dear! [%d]:&nbsp;");

/**
 * Internal calls counter.
 *
 * @var		integer
 * @access	private
 */
$corban_counter = 0;
/**
 * Defines need to output CORBAN_PREFIX.
 *
 * @var		boolean
 * @access	private
 */
$corban_blabla = true;
/**
 * Used colors array - specify colors for each type of variables.
 *
 * @var		array
 * @access	private
 */
$corban_color = array
(
	"prefix"	=> "gray",
	"die"		=> "red",
	"comment"	=> "teal",
	"boolean"	=> "green",
	"integer"	=> "red",
	"double"	=> "magenta",
	"string"	=> "blue",
	"array"		=> "navy",
	"object"	=> "olive",
	"resource"	=> "maroon",
	"null"		=> "black"
);

/**
 * Outputs a debug message.
 *
 * cd() outputs a debug message. Supported PHP variable types:
 * <ul>
 * 	<li>boolean (green color);</li>
 * 	<li>integer (red color);</li>
 * 	<li>double (magenta color);</li>
 * 	<li>string (blue color);</li>
 * 	<li>array (navy color);</li>
 * 	<li>object (olive color);</li>
 * 	<li>resource (maroon color).</li>
 * </ul>
 * Note: The NULL type is not supported. If the variable type is NULL, the folowing message will be displayed: "...is not set or NULL".
 *
 * You can use this function to output control debug messages or in case you want to check value and type of the specific variable.
 *
 * Output format:
 *
 * [Debug prefix Calls counter:] [Debug message comment] ( Variable name | Variable type) = (Variable value | "is not set" | "is empty")
 *
 * <b>Example:</b>
 *
 * <pre>
 *  //Include required files
 *  require_once "corban.lib.php";
 * 		require_once "sqlstorage.class.php";
 *
 *  //Outputs the $HTTP_POST_VARS array
 *  cd ($HTTP_POST_VARS, "HTTP_POST_VARS");
 *
 * 		$storage = new sqlStorage ();
 *  //Outputs information on all the $storage object properties
 *  cd ($storage);
 * </pre>
 *
 * @param	mixed		$val		Variable
 * @param	string		$name		Variable name to display
 * @param	string		$comment	Comment for variable
 * @param	boolean		$die		Defines to die or not after displaying
 * @access	public
 * @see		corban_dear()
 */
function cd ($val, $name="", $comment="", $die=false)
{
	corban_dear ($val, $name, $comment, $die);
} // end function cd

/**
 * Inits the specified timer.
 *
 * <b>Example:</b>
 * <pre>
 *  require_once "corban.lib.php";
 *
 *  // Init timer with name "query"
 *  ci ("query");
 *
 *  $query = "select * from USERS";
 *  mysql_query ($query, $connection);
 *
 *  // Show timer with name "query"
 *  cs ("query");
 * </pre>
 *
 * @param	mixed		$name		Timer name
 * @see		corban_inittimer(), cs(), corban_showtimer()
 * @access	public
 */
function ci ($name=0)
{
	corban_inittimer ($name);
} // end function ci

/**
 * Displays timer value.
 *
 * @param	mixed	$name		Timer name
 * @param	string	$comment	Some comment text
 * @see		corban_inittimer(), ci(), corban_showtimer()
 * @access	public
 */
function cs ($name=0, $comment="")
{
	corban_showtimer ($name, $comment);
} // end function cs

/**
 * Outputs a debug message.
 *
 * @param	mixed		$val		Variable
 * @param	string		$name		Variable name to display
 * @param	string		$comment	Comment for variable
 * @param	boolean		$die		Defines to die or not after displaying
 * @param	string		$internal	Function call type
 * @access	private
 * @global	integer		$corban_counter	Internal calls counter
 * @global	boolean		$corban_blabla	Defines need to output CORBAN_PREFIX
 * @global	array		$corban_color	Used colors array
 */
function corban_dear ($val, $name="", $comment="", $die=false, $internal="")
{
	global $corban_counter, $corban_blabla, $corban_color;

	$type = gettype ($val);
	if (!$internal)
	{
		$corban_counter++;
		if ($corban_blabla)
			$corban_message = corban_format (sprintf (CORBAN_PREFIX, $corban_counter), $corban_color["prefix"]);
		if ($comment)
			$corban_message .= corban_format ($comment, $corban_color["comment"]);
		if ($name)
			$corban_message .= corban_format (corban_bold ("\$$name")) . NBSP;
		elseif (!isset ($val))
			$corban_message .= corban_format (corban_bold ("VARIABLE")) . NBSP;
		else
			$corban_message .= corban_format (corban_bold (strtoupper ($type)));
	}
	else $corban_message = $internal;
	if (!isset ($val)) echo $corban_message . corban_format (" is not set or NULL".BR);
	else
	{
		switch ($type)
		{
			case "boolean":
				$val = $val ? "true" : "false";
			case "integer":
			case "double":
			case "string":
				corban_scalar (htmlspecialchars($val), $type, $corban_message);
			break;
			case "array":
				corban_array ($val , $corban_message);
			break;
			case "object":
				corban_object ($val, $corban_message);
			break;
			case "resource":
				corban_resource ($val, $corban_message);
			break;
			default:
				corban_scalar (strval ($val), "string", $corban_message);
			break;
		}
	}
	if ($die) corban_die ($die);
} // end function corban_dear

/**
 * Outputs the die message and die a script.
 *
 * @param	boolean		$die
 * @access	private
 * @global	boolean		$corban_blabla	Defines need to output CORBAN_PREFIX
 * @global	array		$corban_color	Used colors array
 */
function corban_die ($die)
{
	global $corban_blabla, $corban_color;
	if (!is_string ($die))
	{
		if ($corban_blabla)
			$die = CORBAN_DIE_SCREAM;
		else
			$die = "";
	}
	$die = corban_format ($die, $corban_color["die"], 3);
	die ($die);
} // end function corban_die

/**
 * Applies bold style to text.
 *
 * @param	string		$text
 * @return	string		Bold formatted text
 * @access	private
 */
function corban_bold ($text)
{
	return sprintf (BOLDTEXT, $text);
} // end function corban_bold

/**
 * Formats text with specified color and size.
 *
 * @param	string		$text	Text string
 * @param	string		$color	Text color
 * @param	integer		$size	Text size in pt.
 * @return	string		Formatted string
 * @access	private
 */
function corban_format ($text, $color="black", $size=8)
{
	return sprintf (FONTTEXT, $color, $size, $text);
} // end function corban_format

/**
 * Prints a debug message.
 *
 * @param	string		$val	Variable value
 * @param	string		$type	Variable type
 * @param	string		$prefix Output prefix
 * @global	array		$corban_color	Used colors array
 * @access	private
 */
function corban_scalar ($val, $type, $prefix)
{
	global $corban_color;
	echo $prefix . corban_format (NBSP."=".NBSP) . corban_format ($val, $corban_color[$type]) . BR;
} // end function corban_scalar

/**
 * Outputs an array.
 *
 * @param	array		$arr		Array to output
 * @param	string		$prefix		Message	prefix
 * @access	private
 * @global	array		$corban_color	Used colors array
 */
function corban_array ($arr, $prefix)
{
	global $corban_color;
	if (!$arr) echo $prefix . corban_format (" is empty array") . BR;
	while (list ($key, $value) = each ($arr))
	{
		$curprefix = $prefix . corban_format (" [") . corban_format ($key , $corban_color["array"]) . corban_format ("]");
		corban_dear ($value, false, false, false, $curprefix);
	}
} // end function corban_array

/**
 * Gets and returns a variable from a serialized object or its part.
 *
 * @param	string		&$varlist	Serialized object or it's part
 * @return	mixed		Unseralized value of object property
 * @access	private
 */
function corban_unserialize (&$varlist)
{
	if (strtolower ($varlist[0])=="o" || strtolower ($varlist[0])=="a")
	{
		$pos=strpos ($varlist, "{")+1;
		$intcnt = 0;
		while ($pos<strlen ($varlist))
		{
			if ($varlist[$pos]=="{") $intcnt++;
			elseif ($varlist[$pos]=="}")
			{
				if ($intcnt) $intcnt--;
				else
				{
					$pos++;
					break;
				}
			}
			$pos++;
		}
	}
	else $pos = strpos ($varlist, ";")+1;
	$value = unserialize (substr ($varlist, 0, $pos));
	$varlist = substr ($varlist, $pos);
	return $value;
} // end function corban_unserialize

/**
 * Outputs an object.
 *
 * @param	object		stdClass	$obj	Object to output
 * @param	string		$prefix Debug prefix
 * @access	private
 * @global	array		$corban_color	Used colors array
 */
function corban_object ($obj, $prefix)
{
	global $corban_color;
	$ver = phpversion ();
	$php4add = ($ver[0] == "4") ? 2 : 0;
	$objAsStr = serialize ($obj);
	$objAsArr = split (":", $objAsStr, 3 + $php4add);
	$objPropCount = $objAsArr[3];
	if ($php4add) $objClassName = ucfirst(substr($objAsArr[2], 1, $objAsArr[1]));
	else $objClassName = "Unknown";
	$objPropList = substr ($objAsArr[2+$php4add], 1, -1);
	if (strlen ($objPropList)==0) echo $prefix . corban_format (NBSP . $objClassName, $corban_color["object"]) . corban_format (" is empty object") . BR;
	while (strlen ($objPropList))
	{
		$curprefix = $prefix . corban_format (NBSP . $objClassName."->", $corban_color["object"]) . corban_format (corban_unserialize ($objPropList), $corban_color["object"]);
		corban_dear (corban_unserialize ($objPropList), false, false, false, $curprefix);
	}
} // end function corban_object

/**
 * Outputs a resourse.
 *
 * @param	resource	$res	Resource to output
 * @param	string		$prefix Debug prefix
 * @access	private
 * @global	array		$corban_color	Used colors array
 */
function corban_resource ($res, $prefix)
{
	global $corban_color;
	if (!$res) echo $prefix . corban_format (" is empty resource") . BR;
	$curprefix = $prefix . corban_format (" [") . corban_format (ucwords(get_resource_type ($res)) , $corban_color["resource"]) . corban_format ("]");
	corban_dear (strval ($res), false, false, false, $curprefix);
} // end function corban_resource

/**
 * Returns current time in microseconds.
 *
 * Returns current time measured in the number of  microseconds since the Unix Epoch (0:00:00 January 1, 1970 GMT).
 *
 * @return	double
 * @access	private
 */
function corban_microtime ()
{
	$time = explode (" ", microtime ());
	return doubleval ($time[0]) + doubleval ($time[1]);
} // end function corban_microtime

/**
 * Returns the specified timer value.
 *
 * @param	mixed		$name		Timer name
 * @return	double		Specified timer value
 * @global	array		$corban_timer	Array of timers
 * @access	private
 */
function corban_timer ($name=0)
{
	global $corban_timer;
	return corban_microtime () - $corban_timer[$name];
} // end function corban_timer

/**
 * Inits the specified timer.
 *
 * @param	mixed		$name		Timer name
 * @see		ci(), cs(), corban_showtimer()
 * @global	array		$corban_timer	Array of timers
 * @access	private
 */
function corban_inittimer ($name=0)
{
	global $corban_timer;
	$corban_timer[$name] = corban_microtime ();
} // end function corban_inittimer

/**
 * Displays timer value.
 *
 * @param	mixed	$name		Timer name
 * @param	string	$comment	Some comment text
 * @see		corban_inittimer(), ci(), cs()
 * @access	private
 */
function corban_showtimer ($name=0, $comment="")
{
	if (!$comment) $comment = "CORBAN TIMER {$name} ";
	cd (sprintf ("%.3f", corban_timer ($name)), "time", $comment);
} // end function corban_showtimer

?>