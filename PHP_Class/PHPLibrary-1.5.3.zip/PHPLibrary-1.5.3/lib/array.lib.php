<?php
//
// +----------------------------------------------------------------------+
// | Softerra PHP developer library                                       |
// +----------------------------------------------------------------------+
// | Copyright (c) 1999-2002 Softerra, LLC                                |
// +----------------------------------------------------------------------+
// | This library is free software; you can redistribute it and/or modify |
// | it  under  the  terms  of  the  GNU Lesser General Public License as |
// | published by the Free Software Foundation; either version 2.1 of the |
// | License, or (at your option) any later version.                      |
// |                                                                      |
// | This  library is distributed in the hope that it will be useful, but |
// | WITHOUT   ANY  WARRANTY;  without  even  the  implied  warranty  of  |
// | MERCHANTABILITY  or  FITNESS  FOR A PARTICULAR PURPOSE.  See the GNU |
// | Lesser General Public License for more details.                      |
// +----------------------------------------------------------------------+
// | Contacts: http://www.softerra.com, mailto:phplib@softerra.com        |
// +----------------------------------------------------------------------+
//

/**
 *
 * Array Functions Library.
 *
 * @module		Array
 * @modulegroup	Utils
 * @package		Softerra
 * @author		Softerra <phplib@softerra.com>
 * @copyright	(c) 1999-2002 Softerra, LLC
 * @link		http://www.softerra.com/products/ [Softerra PHP Developer Library Home Page]
 * @version		1.1.7
 * @access		public
 * @since		PHP 4.0.1pl2
 */

/**
 * Alters value.
 *
 * Adds $prefix to $value.
 *
 * @param	mixed	&$value
 * @param	mixed	$key
 * @param	string	$prefix
 * @access	public
 */
function alterValue (&$value, $key, $prefix)
{
	$value = $prefix . $value;
} // end function alterValue

/**
 * Alters array.
 *
 * Alters array values - add $prefix to all array values.
 *
 * @param	array	&$array
 * @param	string	$prefix
 * @access	public
 */
function alterArray (&$array, $prefix)
{
	array_walk ($array, 'alterValue', $prefix);
} // end function alterArray

/**
 * Returns the list of array values separated by $separator.
 *
 * @param	array	$array
 * @param	string	$separator
 * @return	string
 * @access	public
 */
function listArrayValues ($array, $separator=",")
{
	$list = "";
	while (list ($key, $value) = each ($array))
		$list .= $value . $separator;
	$list = substr ($list, 0, -strlen ($separator));
	return $list;
} // end function listArrayValues

/**
 * Returns the list of array keys separated by $separator.
 *
 * @param	array	$array
 * @param	string	$separator
 * @return	string
 * @access	public
 */
function listArrayKeys ($array, $separator=",")
{
	while (list ($key, $value) = each ($array))
		$list .= $key . $separator;
	$list = substr ($list, 0, -strlen ($separator));
	return $list;
} // end function listArrayKeys

/**
 * Returns the list of array keys and values.
 *
 * Returns the list of array keys and values joined by $relation and separated by $separator. Values will be double-quoted if $inQuotes is TRUE.
 *
 * @param	array	$array
 * @param	string	$relation
 * @param	string	$separator
 * @param	boolean	$inQuotes
 * @return	string
 * @access	public
 */
function listArrayKeysAndValues ($array, $relation="=", $separator=",", $inQuotes=false)
{
	$list = "";
	if ($inQuotes) $qoute = "\"";
	else $qoute = "";
	while (list ($key, $value) = each ($array))
		$list .= $key . $relation . $qoute . $value . $qoute . $separator;
	$list = substr ($list, 0, -strlen ($separator));
	return $list;
} // end function listArrayKeysAndValues

/**
 * Outputs an array with the specified $prefix.
 *
 * @param	array	$array
 * @param	string	$prefix
 * @return	string
 * @access	public
 */
function printArray ($array, $prefix="")
{
	if (!$prefix) $prefix = "array";
	while (list ($key, $value) = each ($array))
	{
		$curprefix = $prefix . " [" . $key . "]";
		if (is_array ($value))
			printArray ($value, $curprefix);
		else
			echo $curprefix . " = " . $value . "<br>";
	}
} // end function printArray

/**
 * Return the array's maximal element.
 *
 * @param	array	$array
 * @return	int
 * @access	public
 */
function array_max ($array)
{
	sort ($array);
	return array_pop ($array);
} // end function array_max

/**
 * Removes integer values from array.
 *
 * @param	array	&$array
 * @access	public
 * @todo	while (list ($key, $value) = each ($array))
 */
function removeIntegerValuesFromArray (&$array)
{
	for($i=0; $i<count ($array); $i++)
		if (is_integer ($array[$i]))
		{
			array_splice ($array, $i, 1);
			$i--;
		}
} // end function removeIntegerValuesFromArray

/**
 * Removes non-integer values from array.
 *
 * @param	array	&$array
 * @access	public
 * @todo	while (list ($key, $value) = each ($array))
 */
function removeNotIntegerValuesFromArray (&$array)
{
	for($i=0; $i<count ($array); $i++)
		if (!is_integer ($array[$i]))
		{
			array_splice ($array, $i, 1);
			$i--;
		}
} // end function removeNotIntegerValuesFromArray

?>