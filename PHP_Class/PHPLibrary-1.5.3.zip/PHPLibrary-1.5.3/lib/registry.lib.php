<?php
//
// +----------------------------------------------------------------------+
// | Softerra PHP developer library                                       |
// +----------------------------------------------------------------------+
// | Copyright (c) 1999-2002 Softerra, LLC                                |
// +----------------------------------------------------------------------+
// | This library is free software; you can redistribute it and/or modify |
// | it  under  the  terms  of  the  GNU Lesser General Public License as |
// | published by the Free Software Foundation; either version 2.1 of the |
// | License, or (at your option) any later version.                      |
// |                                                                      |
// | This  library is distributed in the hope that it will be useful, but |
// | WITHOUT   ANY  WARRANTY;  without  even  the  implied  warranty  of  |
// | MERCHANTABILITY  or  FITNESS  FOR A PARTICULAR PURPOSE.  See the GNU |
// | Lesser General Public License for more details.                      |
// +----------------------------------------------------------------------+
// | Contacts: http://www.softerra.com, mailto:phplib@softerra.com        |
// +----------------------------------------------------------------------+
//

/**
 *
 * Registry Library.
 *
 * @module		Registry
 * @modulegroup	Registry
 * @package		Softerra
 * @author		Softerra <phplib@softerra.com>
 * @copyright	(c) 1999-2002 Softerra, LLC
 * @link		http://www.softerra.com/products/ [Softerra PHP Developer Library Home Page]
 * @version		1.3.3
 * @access		public
 * @since		PHP 4.0.1pl2
 */

require_once ($lib_dir . "sqlstorage.class.php");

/**
 * Registry DB host.
 *
 * @const	REGISTRY_HOST
 * @access	private
 */
define ("REGISTRY_HOST", DB_HOST);
/**
 * Registry DB user name.
 *
 * @const	REGISTRY_USER
 * @access	private
 */
define ("REGISTRY_USER", DB_USER);
/**
 * Registry DB user password.
 *
 * @const	REGISTRY_PASSWORD
 * @access	private
 */
define ("REGISTRY_PASSWORD", DB_PASSWORD);
/**
 * Registry DB name.
 *
 * @const	REGISTRY_DATABASE
 * @access	private
 */
define ("REGISTRY_DATABASE", DB_NAME);
/**
 * Registry table.
 *
 * @const	TBL_REGISTRY
 * @access	private
 */
define ("TBL_REGISTRY", "REGISTRY");
/**
 * Registry keys table field name.
 *
 * @const	FLD_KEY
 * @access	private
 */
define ("FLD_KEY", "REGKEY");
/**
 * Registry values table field name.
 *
 * @const	FLD_VAL
 * @access	private
 */
define ("FLD_VAL", "VALUE");

/**
 * Registry keys separator.
 *
 * @const	REGKEY_SEPARATOR
 * @access	private
 */
define ("REGKEY_SEPARATOR", "/");
/**
 * Max registry key name length.
 *
 * @const	MAX_NAME_LENGTH
 * @access	private
 */
define ("MAX_NAME_LENGTH", 32);
/**
 * Max registry full key name length.
 *
 * @const	MAX_KEY_LENGTH
 * @access	private
 */
define ("MAX_KEY_LENGTH", 255);
/**
 * Registry valid name regular expression pattern.
 *
 * @const	REG_VALID_NAME
 * @access	private
 */
define ("REG_VALID_NAME", "[a-zA-Z0-9_]{1," . MAX_NAME_LENGTH . "}");

/**
 * Success code.
 *
 * @const	E_SUCCESS
 * @access	private
 */
define ("E_SUCCESS", 0);
/**
 * Error base offset.
 *
 * @const	E_BASE
 * @access	private
 */
define ("E_BASE", -100);
/**
 * "Bad key" error code.
 *
 * @const	E_BADKEY
 * @access	private
 */
define ("E_BADKEY", E_BASE-1);
/**
 * "Bad name" error code.
 *
 * @const	E_BADNAME
 * @access	private
 */
define ("E_BADNAME", E_BASE-2);
/**
 * "Key already exists" error code
 *
 * @const	E_KEYEXISTS
 * @access	private
 */
define ("E_KEYEXISTS", E_BASE-3);
/**
 * "Key does not exist" error code.
 *
 * @const	E_KEYNOTEXISTS
 * @access	private
 */
define ("E_KEYNOTEXISTS", E_BASE-4);
/**
 * "Unknown error" error code.
 *
 * @const	E_UNKNOWN
 * @access	private
 */
define ("E_UNKNOWN", E_BASE-100);

/**
 * Boolean type
 *
 * @const	TYPE_BOOLEAN
 * @access	private
 */
define ("TYPE_BOOLEAN", "boolean");
/**
 * Integer type
 *
 * @const	TYPE_INTEGER
 * @access	private
 */
define ("TYPE_INTEGER", "integer");
/**
 * Double type
 *
 * @const	TYPE_DOUBLE
 * @access	private
 */
define ("TYPE_DOUBLE", "double");
/**
 * String type.
 *
 * @const	TYPE_STRING
 * @access	private
 */
define ("TYPE_STRING", "string");
/**
 * Array type.
 *
 * @const	TYPE_ARRAY
 * @access	private
 */
define ("TYPE_ARRAY", "array");

/**
 * Root key.
 *
 * @const	ROOTKEY
 * @access	private
 */
define ("ROOTKEY", "");


/**
 * Establishes connection to registry database.
 *
 * If $regDefaultConnection is false you need to initialize registry using
 * REG_CONNECT ($host, $user, $password, $database). Otherwise the registry
 * will initialize automatically. Returns MySQL link identifier on success,
 * or FALSE on failure.
 *
 * @param	string	$host		registry database host
 * @param	string	$user		registry database user name
 * @param	string	$password	registry database user password
 * @param	string	$database	registry database name
 * @return	mixed	MySQL link identifier on success, or FALSE on failure
 * @global	object	sqlStorage	$regStorage		registry storage
 * @access	public
 */
function REG_CONNECT ($host=REGISTRY_HOST, $user=REGISTRY_USER, $password=REGISTRY_PASSWORD, $database=REGISTRY_DATABASE)
{
	global $regStorage;
	return $regStorage->connect ($host, $user, $password, $database);
} // end function REG_CONNECT

/**
 * Sets the $registry_error and returns result
 *
 * Sets the $registry_error to last error and returns the last operation result.
 *
 * @param	mixed		$result
 * @param	integer		$error
 * @return	mixed
 * @global	integer		$registry_error	Last registry error code
 * @access	private
 */
function REG_EXIT ($result, $error)
{
	global $registry_error;
	$registry_error = $error;
	return $result;
} // end function REG_EXIT

/**
 * Returns the last registry error code
 *
 * @global	integer	$registry_error	Last registry error code
 * @return	integer	Last registry error code
 * @access	public
 */
function regLastError ()
{
	global $registry_error;
	return $registry_error;
} // end function regLastError

/**
 * Returns TRUE if $name is a valid registry key name, or FALSE.
 *
 * @param	string	$name	registry key name
 * @return	boolean	TRUE if $name is a valid registry key name, or FALSE
 * @access	private
 */
function regValidName ($name)
{
	return ereg ("^" . REG_VALID_NAME . "$", $name);
} // end function regValidName

/**
 * Returns TRUE if $key is a valid registry key, or FALSE.
 *
 * @param	string	$key	registry key
 * @return	boolean	TRUE if $key is a valid registry key, or FALSE
 * @access	private
 */
function regValidKey ($key)
{
	return (strlen ($key)<MAX_KEY_LENGTH) && ereg ("^(" . REG_VALID_NAME . REGKEY_SEPARATOR . ")*" . REG_VALID_NAME . "$", $key);
} // end function regValidKey

/**
 * Returns a registry key name extracted from the $key.
 *
 * @param	string	$key	registry key
 * @return	string	registry key name
 * @access	private
 */
function regNameFromKey ($key)
{
	$pos = strrpos ($key, REGKEY_SEPARATOR);
	return substr ($key, $pos ? $pos+1 : 0);
} // end function regNameFromKey

/**
 * Returns a registry path extracted from the $key.
 *
 * @param	string	$key	registry key
 * @return	string	registry path
 * @access	private
 */
function regPathFromKey ($key)
{
	$pos = strrpos ($key, REGKEY_SEPARATOR);
	return substr ($key, 0, $pos);
} // end function regPathFromKey

/**
 * Returns a registry key.
 *
 * @param	string	$path	registry path
 * @param	string	$name	registry key name
 * @return	string	registry key
 * @access	public
 */
function regKeyFromPathAndName ($path, $name)
{
	if (strlen ($path)) $path .= REGKEY_SEPARATOR;
	return $path . $name;
} // end function regKeyFromPathAndName

/**
 * Explodes and returns key names extracted from key.
 *
 * @param	string	$key
 * @return	array	key names
 * @access	private
 */
function regExplodeKey ($key)
{
	return explode (REGKEY_SEPARATOR, $key);
} // end function regExplodeKey

/**
 * Returns TRUE if $key exists, or FALSE.
 *
 * @param	string	$key
 * @return	boolean	TRUE if $key exist or FALSE
 * @global	object	sqlStorage	$regStorage		registry storage
 * @access	private
 */
function regKeyExists ($key)
{
	global $regStorage;
	return $regStorage->select_exists (TBL_REGISTRY, array (FLD_KEY => $key));
} // end function regKeyExists

/**
 * Create a registry key.
 *
 * Creates a registry key with the $key name if it is a valid name and does not exist.
 * Note: the default type is boolean and the value is FALSE.
 *
 * @param	string	$key
 * @return	boolean	TRUE on success, FALSE on error
 * @global	object	sqlStorage	$regStorage		registry storage
 * @access	public
 */
function regCreateKey ($key)
{
	global $regStorage;
	if (!regValidKey ($key)) return REG_EXIT (false, E_BADKEY);
	if (regKeyExists ($key)) return REG_EXIT (false, E_KEYEXISTS);
	do
	{
		$regStorage->insert (TBL_REGISTRY, array (FLD_KEY => $key));
		$key = regPathFromKey ($key);
	}
	while (strlen ($key)>0 && !regKeyExists ($key));
	return REG_EXIT (true, E_SUCCESS);
} // end function regCreateKey

/**
 * Deletes a registry key.
 *
 * Deletes a registry key name $key if it is valid name and exist.
 *
 * @param	string	$key
 * @return	boolean	TRUE on success, FALSE on error
 * @global	object	sqlStorage	$regStorage		registry storage
 * @access	public
 */
function regDeleteKey ($key)
{
	global $regStorage;
	if (!regValidKey ($key)) return REG_EXIT (false, E_BADKEY);
	if (!regKeyExists ($key)) return REG_EXIT (false, E_KEYNOTEXISTS);
	$regStorage->delete (TBL_REGISTRY, array (FLD_KEY => regKeyFromPathAndName ($key, "%")));
	return REG_EXIT ($regStorage->delete (TBL_REGISTRY, array (FLD_KEY => $key)), E_SUCCESS);
} // end function regDeleteKey

/**
 * Rename a registry key.
 *
 * Rename a registry key name $key to $name if they both valid and $key exist.
 *
 * @param	string	$key
 * @param	string	$name
 * @return	boolean	TRUE on success, FALSE on error
 * @global	object	sqlStorage	$regStorage		registry storage
 * @access	public
 */
function regRenameKey ($key, $name)
{
	global $regStorage;
	if (!regValidKey ($key)) return REG_EXIT (false, E_BADKEY);
	if (!regValidName ($name)) return REG_EXIT (false, E_BADNAME);
	if (!regKeyExists ($key)) return REG_EXIT (false, E_KEYNOTEXISTS);
	$newkey = regKeyFromPathAndName (regPathFromKey ($key), $name);
	if (regKeyExists ($newkey)) return REG_EXIT (false, E_KEYEXISTS);
	$children = $regStorage->select_column (TBL_REGISTRY, FLD_KEY, array (FLD_KEY => regKeyFromPathAndName ($key, "%")));
	for ($i=0; $i<count ($children); $i++)
		$regStorage->update (TBL_REGISTRY, array (FLD_KEY => ereg_replace ($key, $newkey, $children[$i])), array (FLD_KEY => $children[$i]));
	return REG_EXIT ($regStorage->update (TBL_REGISTRY, array (FLD_KEY => $newkey), array (FLD_KEY => $key)), E_SUCCESS);
} // end function regRenameKey

/**
 * Creates a registry key and copies the subtree of the current key.
 *
 * Creates a registry key with the $dest name at the root entry and copies the subtree of the current key whose path is $source.
 *
 * @param	string	$dest		Created key name
 * @param	string	$source		Key path wich must be copied
 * @return	boolean	TRUE on success, FALSE on error
 * @global	object	sqlStorage	$regStorage		registry storage
 * @access	public
 */
function regCopySubTree ($dest, $source)
{
	global $regStorage;
	if (!regValidKey ($source)) return REG_EXIT (false, E_BADKEY);
	if ($source==ROOTKEY) return REG_EXIT (false, E_CANNOTCOPYROOT);
	if (!regKeyExists ($source)) return REG_EXIT (false, E_KEYNOTEXISTS);
	if (!regKeyExists ($dest)) if (!regCreateKey ($dest)) return false;
	$children = $regStorage->select_result (TBL_REGISTRY, "*", array (FLD_KEY => regKeyFromPathAndName ($source, "%")));
	for ($i=0; $i<count ($children); $i++)
		$regStorage->insert (TBL_REGISTRY, array (FLD_KEY => ereg_replace ($source, $dest, $children[$i][FLD_KEY]), FLD_VAL => $children[$i][FLD_VAL]));
	return REG_EXIT (count ($children)>0, E_SUCCESS);
} // end function regCopySubTree

/**
 * Returns a key value.
 *
 * Returns a key value with the $key name if that key already exists.
 *
 * @param	string	$key	Key name
 * @return	mixed	Key value on success, FALSE on error
 * @global	object	sqlStorage	$regStorage		registry storage
 * @access	public
 */
function regGetValue ($key)
{
	global $regStorage;
	if (!regValidKey ($key)) return REG_EXIT (false, E_BADKEY);
	$value = $regStorage->select_record (TBL_REGISTRY, FLD_VAL, array (FLD_KEY => $key));
	if ($regStorage->queryresult_exists ())
		return REG_EXIT (unserialize ($value), E_SUCCESS);
	else
		return REG_EXIT (false, E_KEYNOTEXISTS);
} // end function regGetValue

/**
 * Sets a key value.
 *
 * Sets a key value with the $key name as the $value value.
 *
 * @param	string	$key	Key name
 * @param	mixed	$value	Key value
 * @return	boolean	TRUE on success, FALSE on error
 * @global	object	sqlStorage	$regStorage		registry storage
 * @global	boolean	$sqlAddSlashes
 * @access	public
 */
function regSetValue ($key, $value)
{
	global $regStorage;
	global $sqlAddSlashes;
	$value = serialize ($value);
	if (!$sqlAddSlashes) $value = AddSlashes ($value);
	if (!regValidKey ($key)) return REG_EXIT (false, E_BADKEY);
	$result = $regStorage->update (TBL_REGISTRY, array (FLD_VAL => $value), array (FLD_KEY => $key));
	return REG_EXIT ($result, $result ? E_SUCCESS:E_KEYNOTEXISTS);
} // end function regSetValue

/**
 * Returns subkeys of the current key.
 *
 * Returns an array of subkeys of the current key with the $key name.
 *
 * @param	string	$key	Key name
 * @return	array	contain array of subkeys
 * @global	object	sqlStorage	$regStorage		registry storage
 * @access	public
 */
function regSubKeys ($key)
{
	global $regStorage;
	if (strlen ($key))
	{
		if (!regValidKey ($key)) return REG_EXIT (false, E_BADKEY);
		if (!regKeyExists ($key)) return REG_EXIT (false, E_KEYNOTEXISTS);
	}
	$condition = 'where REGKEY REGEXP "^' . regKeyFromPathAndName ($key, REG_VALID_NAME) . '$"';
	return REG_EXIT ($regStorage->select_column (TBL_REGISTRY, FLD_KEY, $condition), E_SUCCESS);
} // end function regSubKeys

/**
 * Returns the number of subkeys.
 *
 * Returns the number of subkeys for the $key key.
 *
 * @param	string	$key	Key name
 * @return	integer	number of subkeys
 * @global	object	sqlStorage	$regStorage		registry storage
 * @access	public
 */
function regSubKeysCount ($key)
{
	global $regStorage;
	if (strlen ($key))
	{
		if (!regValidKey ($key)) return REG_EXIT (false, E_BADKEY);
		if (!regKeyExists ($key)) return REG_EXIT (false, E_KEYNOTEXISTS);
	}
	$condition = 'where REGKEY REGEXP "^' . regKeyFromPathAndName ($key, REG_VALID_NAME) . '$"';
	return REG_EXIT ($regStorage->select_count (TBL_REGISTRY, $condition), E_SUCCESS);
} // end function regSubKeysCount

/**
 * Returns an array of subkey values.
 *
 * Returns an array of the $key's subkey values, where a subkey name is the array key and a subkey value is the array value.
 *
 * @param	string	$key	Key name
 * @return	array	array of subkey values
 * @global	object	sqlStorage	$regStorage		registry storage
 * @access	public
 */
function regGetSubValues ($key)
{
	global $regStorage;
	$subkeys = regSubKeys ($key);
	if (regLastError () != E_SUCCESS) return false;
	$result = array ();
	for ($i=0; $i<count ($subkeys); $i++)
		$result[regNameFromKey ($subkeys[$i])] = regGetValue ($subkeys[$i]);
	return $result;
} // end function regGetSubValues

/**
 * Returns tag's attributes as string.
 *
 * Returns the tag's attributes as a string, where the attributes are subkeys of $key and the attribute values are subkey values.
 *
 * @param	string	$key	Key name
 * @return	string	tag's attributes string
 * @global	object	sqlStorage	$regStorage		registry storage
 * @access	public
 */
function regTagAttributes ($key)
{
	$attr = regGetSubValues ($key);
	return listArrayKeysAndValues ($attr, "=", " ", true);
} // end function regTagAttributes

//=======================================//
//    initializing registry storage      //
//=======================================//
$regStorage = new sqlStorage ();
if ($regDefaultConnection) REG_CONNECT ();

?>
