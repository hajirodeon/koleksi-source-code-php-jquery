<?php
//
// +----------------------------------------------------------------------+
// | Softerra PHP developer library                                       |
// +----------------------------------------------------------------------+
// | Copyright (c) 1999-2002 Softerra, LLC                                |
// +----------------------------------------------------------------------+
// | This library is free software; you can redistribute it and/or modify |
// | it  under  the  terms  of  the  GNU Lesser General Public License as |
// | published by the Free Software Foundation; either version 2.1 of the |
// | License, or (at your option) any later version.                      |
// |                                                                      |
// | This  library is distributed in the hope that it will be useful, but |
// | WITHOUT   ANY  WARRANTY;  without  even  the  implied  warranty  of  |
// | MERCHANTABILITY  or  FITNESS  FOR A PARTICULAR PURPOSE.  See the GNU |
// | Lesser General Public License for more details.                      |
// +----------------------------------------------------------------------+
// | Contacts: http://www.softerra.com, mailto:phplib@softerra.com        |
// +----------------------------------------------------------------------+
//

/**
 *
 * Library configuration settings.
 *
 * Softerra PHP developer library configuration settings.
 *
 * @module		Config
 * @modulegroup	SQL
 * @package		Softerra
 * @author		Softerra <phplib@softerra.com>
 * @copyright	(c) 1999-2002 Softerra, LLC
 * @link		http://www.softerra.com/products/ [Softerra PHP Developer Library Home Page]
 * @version		1.0.3
 * @access		public
 * @since		PHP 4.0.1pl2
 */

/**
 *
 *
 * @const	svrMySQL
 * @access	public
 */
define ("svrMySQL", "mysql");

/**
 *
 *
 * @const	svrMSQL
 * @access	public
 */
define ("svrMSQL", "msql");

/**
 *
 *
 * @const	svrMSSQL
 * @access	public
 */
define ("svrMSSQL", "mssql");

/**
 *
 *
 * @const	svrSybaseSQL
 * @access	public
 */
define ("svrSybaseSQL", "sybase");

/**
 *
 *
 * @const	svrPostgreSQL
 * @access	public
 */
define ("svrPostgreSQL", "pgsql");

/**
 *
 *
 * @const	svrODBC
 * @access	public
 */
define ("svrODBC", "odbc");

/**
 *
 *
 * @const	IT_ND
 * @access	public
 */
define ("IT_ND", 0);

/**
 *
 *
 * @const	IT_INT
 * @access	public
 */
define ("IT_INT", 1);

/**
 *
 *
 * @const	IT_DOUBLE
 * @access	public
 */
define ("IT_DOUBLE", 2);

/**
 * Defines SQL server to connect to. Must be defined before including file "sqlstorage.lib.php"
 * The list of servers: svrMySQL, svrMSQL, svrMSSQL, svrSybaseSQL, svrPostgreSQL, svrODBC;
 *
 * @var		string
 * @access	public
 */
	$salServer = svrMySQL;

/**
 * Defines whether to make a persistent connection to an SQL server. Must be defined before calling the sqlStorage->connect () method.
 *
 * @var		boolean
 * @access	public
 */
	$salPersistentConnect = false;

/**
 * Defines whether to add slashes to values posted to query compose functions.
 *
 * @var		boolean
 * @access	public
 * @todo	Analise: magic_quotes_gpc, magic_quotes_sybase, magic_quotes_runtime.
 */
	$sqlAddSlashes = !get_magic_quotes_gpc ();

/**
 * Defines whether the strings in query conditions will be compared with the "like" operation.
 *
 * @var		boolean
 * @access	public
 */
	$sqlLikeStringEquality = true;

/**
 * Defines search mode. Must be defined before including file "sqlsearch.lib.php"
 *
 * @var		boolean
 * @access	public
 */
	$sqlExtendedSearch = false;

/**
 * Defines whether to establish default connection to registry database.
 *
 * @var		boolean
 * @access	public
 */
	$regDefaultConnection = true;

/**
 * Defines the type of number conversion.
 * The list of types:
 *  - IT_ND - not defined;
 *  - IT_INT - convert to int;
 *  - IT_DOUBLE - convert to double.
 *
 * @var		integer
 * @access	public
 */
	$numIntConversionType = IT_DOUBLE;

?>