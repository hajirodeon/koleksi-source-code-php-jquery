<?
// Put it at the begining of you PHP code
// cr�ate object and unhide parameters if they are hide
	require_once("phpsecureurl.pclass");
	$codep = new phpsecureurl ;
?>

<?	// parameters of your application
	$parametre1="var1=12345";
	$parametre2="par=page12";
	$parametre3="qw=ID2301";
	// $parameters ...
	$link="http://".$_SERVER['HTTP_HOST'].$PHP_SELF."?".$parametre1."&".$parametre2."&".$parametre3;
	$link0=$link; // memory parameters just for demo
?>
<? 
	// $link=$codep->encode($link); in your code : uncomment your link is hide comment is normal
	// in the boths case you php code works wirhout other change
	if($_REQUEST[test_ok]){$link=$codep->encode($link);} 

?>
<html>
<head>
<title>Document sans titre</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<div align="center">
  <p><font size="+6"><strong><font size="+2">PHPSecureURL</font></strong></font></p>
  <p><font size="+2"><strong>DEMO</strong></font></p>
  <p>After <font color="#FF0000">activate code</font> <br>
    <font color="#FF0000">Click twice</font> on TESTER to see hide URL</p>
</div>
<form action="<? echo $link ; ?>" method="post">
  <table width="80%" border="1" align="center" cellpadding="0" cellspacing="0" bordercolor="#FFFFFF">
    <tr> 
      <td width="20%" bgcolor="#00FFFF">Normal URL</td>
      <td width="80%"><? echo $link0; ?></td>
    </tr>
    <tr> 
      <td bgcolor="#00FFFF">Hide URL</td>
      <td><? echo $link; ?></td>
    </tr>
    <tr> 
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr> 
      <td><div align="right">Activate code</div></td>
      <td> 
        <input name="test_ok" type="checkbox" value="checkbox" <? if($_REQUEST[test_ok]){?>checked><? }?></td>
    </tr>
    <tr> 
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr> 
      <td colspan="2"> 
        <div align="center"> 
          <input name="envoyer" type="submit" value="TESTER">
        </div></td>
    </tr>
  </table>

</form>

<div align="center">You can hide URL or not, for your PHP page it's the same thing<br>
  You have just to add 3 PHP lines at the top of your page<br>
  and one for each link<br>
</div>
</body>
</html>
