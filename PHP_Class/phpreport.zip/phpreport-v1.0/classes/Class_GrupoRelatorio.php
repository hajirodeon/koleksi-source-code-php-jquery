<?
/***********************************************************************************/
/*                                 PHP Report                                      */
/*                                                                                 */
/* Copyright (c) 2005 by Daniela Toniolo, Leonardo Galv�o and Marli Carneiro       */
/*                                                                                 */
/* This is a free software. You can redistribute it and/or modify it under the     */
/* terms of the GNU General Public License.                                        */
/***********************************************************************************/

class GrupoRel {
	function NivelGrupos($niv,$end,$grupo){ 
		$conecta = Conexao::Conecta();
		$query = "SELECT GRURELCODIGO,GRURELNOME FROM GRUPOREL WHERE GRURELNIVEL='$niv' ORDER BY GRURELNOME";
		$result = $conecta->query($query); 
		if (DB::isError($result)) die ($result->getMessage()); 
		$rows = $result->numRows(); 
		if ($rows > 0){
			while ($i = $result->fetchRow(DB_FETCHMODE_OBJECT)) {
				$codigo = $i->GRURELCODIGO;
				$nome = $i->GRURELNOME;
				$endereco = $end."/".$nome;
				if ($_SESSION["TipoUsu"]==3) {
					$conecta = Conexao::Conecta();
					$query2 = "SELECT GRURELCODIGO FROM GRUPORELACESSO WHERE USUCODIGO=".$_SESSION["CodUsu"]." AND GRURELCODIGO=".$codigo;
					$result2 = $conecta->query($query2); 
					if (DB::isError($result2)) die ($result2->getMessage()); 
					$rows2 = $result2->numRows(); 
					if ($rows2 > 0) {
						print "<option value=\"".$codigo."\"";
						if ($grupo==$codigo) print " selected";
						print ">".$endereco."</option>";
					}
				} else {
					print "<option value=\"".$codigo."\"";
					if ($grupo==$codigo) print " selected";
					print ">".$endereco."</option>";
				}
				GrupoRel::NivelGrupos($codigo,$endereco,$grupo);
			}
		} 
		$conecta = Conexao::Desconecta();
	}
	
	function CaixaGrupos($grupo){
		GrupoRel::NivelGrupos(0,"",$grupo);
	}
	
	function CadGrupoRel(){
		$GruRelNome = $_POST['GruRelNome'];
		$GruRelDescricao = $_POST['GruRelDescricao'];
		$GruRelNivel = $_POST['GruRelNivel'];
		if (($GruRelNome == null) || ($GruRelDescricao == null) || ($GruRelNivel == "null")) die ("<script>alert('Algum campo do formul�rio n�o foi preenchido'); history.go(-1);</script>");
		$conecta = Conexao::Conecta();
		$query = "SELECT GRURELNOME FROM GRUPOREL WHERE GRURELNOME = '$GruRelNome' and GRURELNIVEL = $GruRelNivel";
		$result = $conecta->query($query); 
		if (DB::isError($result)) die ($result->getMessage()); 
		$rows = $result->numRows(); 
		if ($rows>0) die ("<script>alert('"._GRUPOJAEXISTE."'); history.go(-1);</script>");
		$query = "INSERT INTO GRUPOREL (GRURELNOME,GRURELDESCRICAO,GRURELNIVEL) VALUES ('$GruRelNome','$GruRelDescricao', $GruRelNivel)";
		$result = $conecta->query($query); 
		if (DB::isError($result)) die ($result->getMessage()); 
		$conecta = Conexao::Desconecta();
		header("Location: FrGrupoRel.php?msg="._OGRUPO."$GruRelNome"._CADASTRADO);
	}
	
	function Excluir($cod){ 
		$conecta = Conexao::Conecta();
		$query = "SELECT GRURELCODIGO FROM GRUPOREL WHERE GRURELNIVEL=$cod";
		$result = $conecta->query($query); 
		if (DB::isError($result)) die ($result->getMessage()); 
		$rows = $result->numRows(); 
		if ($rows > 0){
			while ($i = $result->fetchRow(DB_FETCHMODE_OBJECT)) {
				$cod_envia = $i->GRURELCODIGO;				
				$query2 = "DELETE FROM GRUPOREL WHERE GRURELCODIGO=$cod";
				$result2 = $conecta->query($query2); 
				if (DB::isError($result2)) die ($result2->getMessage()); 
				GrupoRel::Excluir($cod_envia);
			}
		} else {
			$query2 = "DELETE FROM GRUPOREL WHERE GRURELCODIGO=$cod";
			$result2 = $conecta->query($query2); 
			if (DB::isError($result2)) die ($result2->getMessage()); 
		}
		$conecta = Conexao::Desconecta();
	}

	function ExcGrupoRel($cod){
		$conecta = Conexao::Conecta();
		$query = "SELECT GRURELNOME FROM GRUPOREL WHERE GRURELCODIGO = $cod";
		$result = $conecta->query($query); 
		if (DB::isError($result)) die ($result->getMessage()); 
		$i = $result->fetchRow(DB_FETCHMODE_OBJECT);
		$GruRelNome = $i->GRURELNOME;
		$conecta = Conexao::Desconecta();
		GrupoRel::Excluir($cod);
		header("Location: FrGrupoRel.php?msg="._OGRUPO."$GruRelNome"._EXCLUIDO);
	}
	
	function EditGrupoRel(){
		$cod = $_POST['cod'];
		$GruRelNome = $_POST['GruRelNome'];
		$GruRelDescricao = $_POST['GruRelDescricao'];
		$GruRelNivel = $_POST['nivel'];
		if (($GruRelNome == null) || ($GruRelDescricao == null)) die ("<script>alert('"._CAMPONAOPREENCHIDO."'); history.go(-1);</script>");
		$conecta = Conexao::Conecta();		
		$query = "SELECT GRURELNOME FROM GRUPOREL WHERE GRURELNOME = '$GruRelNome' and GRURELCODIGO != $cod and GRURELNIVEL = '$GruRelNivel'";
		$result = $conecta->query($query); 
		if (DB::isError($result)) die ($result->getMessage()); 
		$rows = $result->numRows(); 

		if ($rows>0) die ("<script>alert('"._GRUPOJAEXISTE."'); history.go(-1);</script>");
		$query = "UPDATE GRUPOREL SET GRURELNOME='$GruRelNome', GRURELDESCRICAO='$GruRelDescricao' WHERE GRURELCODIGO=$cod";
		$result = $conecta->query($query);
		if (DB::isError($result)) die ($result->getMessage()); 
		$conecta = Conexao::Desconecta();
		header("Location: FrGrupoRel.php?msg="._OGRUPO."$GruRelNome"._EDITADO);
	}
	
	function ListGrupoRel(){
		$cod = $_POST['cod'];
		if ($cod == "null") die ("<script>alert('"._SELECIONEUMGRUPO."'); history.go(-1);</script>");
		$conecta = Conexao::Conecta();
		$query = "SELECT GRURELDESCRICAO,GRURELNOME,GRURELNIVEL FROM GRUPOREL WHERE GRURELCODIGO='$cod'";
		$result = $conecta->query($query);
		if (DB::isError($result)) die ($result->getMessage());
		$i = $result->fetchRow(DB_FETCHMODE_OBJECT);
		$GruRelNome = $i->GRURELNOME;
		$GruRelDescricao = $i->GRURELDESCRICAO;
		$GruRelNivel = $i->GRURELNIVEL;
		$vetor = array($GruRelNome, $GruRelDescricao, $GruRelNivel);
		$conecta = Conexao::Desconecta();
		return $vetor;
	}

	function VerificaRel($cod,$grupos){ 
		$conecta = Conexao::Conecta();
		$query3 = "SELECT RELNOME FROM RELATORIO WHERE GRURELCODIGO=$cod";
		$result3 = $conecta->query($query3); 
		if (DB::isError($result3)) die ($result3->getMessage()); 
		$rows3 = $result3->numRows(); 
		if ($rows3 > 0) {
			$query4 = "SELECT GRURELNOME FROM GRUPOREL WHERE GRURELCODIGO=$cod";
			$result4 = $conecta->query($query4); 
			if (DB::isError($result4)) die ($result4->getMessage()); 
			$i = $result4->fetchRow(DB_FETCHMODE_OBJECT);
			$nome_grupo = $i->GRURELNOME;
			if ($grupos==null) $grupos.=$nome_grupo; else $grupos.=", ".$nome_grupo;
		}

		$query = "SELECT GRURELCODIGO,GRURELNOME FROM GRUPOREL WHERE GRURELNIVEL=$cod";
		$result = $conecta->query($query); 
		if (DB::isError($result)) die ($result->getMessage()); 
		$rows = $result->numRows(); 
		if ($rows > 0){
			while ($i = $result->fetchRow(DB_FETCHMODE_OBJECT)) {
				$cod_envia = $i->GRURELCODIGO;				
				GrupoRel::VerificaRel($cod_envia,$grupos);
			}
		}
		$conecta = Conexao::Desconecta();
		return $grupos;
	}

	function VerifRel(){
		$cod = $_POST['cod'];
		if ($cod == "null") die ("<script>alert('"._SELECIONEUMGRUPO."'); history.go(-1);</script>");
		$grupos = GrupoRel::VerificaRel($cod,"");
		if ($grupos==null) GrupoRel::ExcGrupoRel($cod);
		else die("<script>alert('"._EXISTEMRELATORIOS.$grupos."'); history.go(-1);</script>");
	}

	function NivelListaDeGrupos($niv,$end,$cont){
		$conecta = Conexao::Conecta();
		$query = "SELECT GRURELCODIGO,GRURELNOME,GRURELDESCRICAO FROM GRUPOREL WHERE GRURELNIVEL='$niv' ORDER BY GRURELNOME";
		$result = $conecta->query($query); 
		if (DB::isError($result)) die ($result->getMessage()); 
		$rows = $result->numRows(); 
		if ($rows > 0){
			while ($i = $result->fetchRow(DB_FETCHMODE_OBJECT)) {
				$codigo = $i->GRURELCODIGO;
				$nome = $i->GRURELNOME;
				$descricao = $i->GRURELDESCRICAO;
				$descricao = nl2br(htmlspecialchars($descricao, ENT_QUOTES));
				$endereco = $end." / ".$nome;
				if ($cont%2==0) print"<tr bgcolor=\"#F0F0F0\">"; else print"<tr bgcolor=\"#F8F8F8\">";
				print"
				<td>".$endereco."</td>
				<td>".$descricao."</td>
				</tr>";
				$cont++;
				GrupoRel::NivelListaDeGrupos($codigo,$endereco,$cont);
			}
		}
	}
	
	function ListaDeGrupos(){
		print"
		<table width=\"100%\" border=\"0\" align=\"center\" cellpadding=\"2\" cellspacing=\"3\">
		<tr>
		<td><strong>"._NOME."</strong></td>
		<td><strong>"._DESCRICAO."</strong></td>
		</tr>
		";
		GrupoRel::NivelListaDeGrupos(0,"",0);
		print "</table>";
	}
}
?>