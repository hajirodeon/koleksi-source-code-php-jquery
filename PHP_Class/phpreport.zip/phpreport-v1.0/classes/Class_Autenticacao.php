<?
/***********************************************************************************/
/*                                 PHP Report                                      */
/*                                                                                 */
/* Copyright (c) 2005 by Daniela Toniolo, Leonardo Galv�o and Marli Carneiro       */
/*                                                                                 */
/* This is a free software. You can redistribute it and/or modify it under the     */
/* terms of the GNU General Public License.                                        */
/***********************************************************************************/

class Autenticacao { 
		function VerificaUsu(){
		$UsuUsuario = $_POST['UsuUsuario'];
		$UsuSenha = md5($_POST['UsuSenha']);
		$conecta = Conexao::Conecta();
		$query = "SELECT USUCODIGO,USUUSUARIO,USUTIPO,USUIDIOMA FROM USUARIO where USUUSUARIO like '$UsuUsuario' AND USUSENHA like '$UsuSenha'";
		$result = $conecta->query($query); 
		if (DB::isError($result)) die ($result->getMessage()); 
		$rows = $result->numRows(); 
		$usuario = null;
		if ($rows > 0){ 
				while ($i = $result->fetchRow(DB_FETCHMODE_OBJECT)) {
					$UsuCod = $i->USUCODIGO; 
					$UsuTipo = $i->USUTIPO; 
					$usuario = $i->USUUSUARIO;
					$idioma = $i->USUIDIOMA;
					$conecta = Conexao::Desconecta();
					session_start();
					$_SESSION["login"] = $usuario;
					$_SESSION["TipoUsu"] = $UsuTipo;
					$_SESSION["CodUsu"] = $UsuCod;
					if ($idioma==null){
						include("config.inc.php");
						$_SESSION["Idioma"] = $Language;
					} else {
						$_SESSION["Idioma"] = $idioma;
					}
					header("Location: FrPrincipal.php");
				}
			} else { 
				$op = "";
				die ("<script>alert('"._ACESSONEGADO."'); history.go(-1);</script>"); 
			}
		}
		
	function logout($op){
		if ($op == "logout") { 
			unset($_SESSION["login"]);
			unset($_SESSION["TipoUsu"]);
			session_destroy();
		}
	}
}
?>