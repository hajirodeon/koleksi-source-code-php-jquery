<?
/***********************************************************************************/
/*                                 PHP Report                                      */
/*                                                                                 */
/* Copyright (c) 2005 by Daniela Toniolo, Leonardo Galv�o and Marli Carneiro       */
/*                                                                                 */
/* This is a free software. You can redistribute it and/or modify it under the     */
/* terms of the GNU General Public License.                                        */
/***********************************************************************************/

class Conexao {
	function Conecta(){
		include("config.inc.php");
		require_once 'DB.php'; // especificando o DSN (Data Source Name) 
		$dsn= "$DBType://$DBUserName:$DBPassword@$DBHostName/$DBName"; 
		$conn= DB::connect($dsn); 
		if (DB::isError($conn)) { 
			die ($conn->getMessage()); 
		} 
		return $conn;
	}

	function ConectaRel($db){
		include("config.inc.php");
		require_once 'DB.php'; 
		if ($db!=null) $DBName0 = "/".$db;
		$dsn= "$DBType0://$DBUserName0:$DBPassword0@$DBHostName0".$DBName0; 
		$conn= DB::connect($dsn); 
		if (DB::isError($conn)) { 
			die ($conn->getMessage()); 
		} 
		return $conn;
	}

	function Desconecta(){
		include("config.inc.php");
		$conn = Conexao::Conecta();
		$conn->disconnect();
		return $conn;
	}
}
?>