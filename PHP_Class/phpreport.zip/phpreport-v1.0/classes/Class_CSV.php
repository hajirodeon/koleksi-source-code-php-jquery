<?
/***********************************************************************************/
/*                                 PHP Report                                      */
/*                                                                                 */
/* Copyright (c) 2005 by Daniela Toniolo, Leonardo Galv�o and Marli Carneiro       */
/*                                                                                 */
/* This is a free software. You can redistribute it and/or modify it under the     */
/* terms of the GNU General Public License.                                        */
/***********************************************************************************/

class ExportarRelCSV {
	function RelatorioPrinc($id,$addwhere,$from_rel,$from_form,$base,$template,$template_tipo,$template_nume,$sqlselect,$sqlfrom,$sqlwhere,$sqlorder,$sqlgroup,$sqlformgrup){
		$conecta = Conexao::Conecta();
		$query = "SELECT CAMTITULO FROM CAMPO WHERE RELCODIGO=".$id." ORDER BY CAMORDEM";
		$result = $conecta->query($query); 
		if (DB::isError($result)) die ($result->getDebugInfo()); 
		$colunas = $result->numRows(); 
		print "\n";
		if ($colunas > 0){
			while($i = $result->fetchRow(DB_FETCHMODE_OBJECT)){
				$titulo = $i->CAMTITULO;
				print "".$titulo.";";
			}
			print "\n";
		}

		$conecta = Conexao::ConectaRel($base);
		if (($sqlwhere==null)&&($addwhere==null)) $where = null;
		else if (($sqlwhere!=null)&&($addwhere!=null)) $where = $sqlwhere." AND ".$addwhere;
		else if (($sqlwhere==null)&&($addwhere!=null)) $where = " WHERE ".$addwhere; 
		else $where = $sqlwhere;
		$stringsql = $sqlselect.$from_rel.$where.$sqlorder;
		$result = $conecta->query($stringsql);
				if (DB::isError($result)) die ($result->getDebugInfo());
				$linhas = $result->numRows();
				if ($linhas > 0) {
					while($j = $result->fetchRow(DB_FETCHMODE_OBJECT)) {		
						for($id_coluna=0;$id_coluna<$colunas;$id_coluna++){
							
							$pegacoluna = "COLUNA".$id_coluna;
							$dado = $j->$pegacoluna;
							$conecta = Conexao::Conecta();
							$query = "SELECT CAMCAMPO FROM CAMPO WHERE RELCODIGO=".$id." AND CAMORDEM=".$id_coluna;
							$result1 = $conecta->query($query); 
							if (DB::isError($result1)) die ($result1->getDebugInfo()); 
							$i = $result1->fetchRow(DB_FETCHMODE_OBJECT);
							$titulo = $i->CAMCAMPO;
							if ($dado!=null) print "".$dado.";";
						}
						print "\n";
						$conecta = Conexao::ConectaRel($base);
					}
				}
		
		//imprime formulas do grupo
		$conecta = Conexao::Conecta();
		$query = "SELECT FORCAMPO,FORTITULO FROM FORMULA WHERE RELCODIGO=".$id." AND FORAPLICACAO='g' ORDER BY FORORDEM";
		$result = $conecta->query($query);
		if (DB::isError($result)) die ($result->getDebugInfo());
		$rows = $result->numRows();
		if ($rows > 0){
			$formulas=null;
			while($i = $result->fetchRow(DB_FETCHMODE_OBJECT)){
				$campo = $i->FORCAMPO;
				$titulo = $i->FORTITULO;
				$formulas[] = array($campo,$titulo);
			}
			$conecta = Conexao::ConectaRel($base);
			$stringsql = $sqlformgrup.$from_form.$where.$sqlgroup;
			$result = $conecta->query($stringsql);
			if (DB::isError($result)) die ($result->getDebugInfo());
			$rows2 = $result->numRows();
			if ($rows2 > 0){
				$i = $result->fetchRow(DB_FETCHMODE_OBJECT);
				for($cont=0;$cont<count($formulas);$cont++) {
					$pegatitulo = "FormulaGrupo".$formulas[$cont][0];
					$formula = $i->$pegatitulo;
					print "$pegatitulo : ".$formula.";\n\n";
				}
			}
		} 
	}

	function RelatorioGrupo($id,$grupo,$agrupar_por,$tam,$where,$from_rel,$from_form,$base,$template,$template_tipo,$template_nume,$sqlselect,$sqlfrom,$sqlwhere,$sqlorder,$sqlgroup,$sqlformgrup){
		$conecta = Conexao::ConectaRel($base);
		$agrupar = null;
		for ($i=0;$i<=$grupo;$i++) {
			if($i!=0) $agrupar .= ", ";
			$agrupar .= $agrupar_por[$i];
		}
		$select = $agrupar_por[$grupo];
		$addwhere = null;
		for($j=0;$j<$grupo;$j++){
			if ($j!=0) $addwhere.=" AND ";
			$addwhere.=$where[$j];
		}
		if (($sqlwhere==null)&&($addwhere==null)) $imp_where = null;
		else if (($sqlwhere!=null)&&($addwhere!=null)) $imp_where = $sqlwhere." AND ".$addwhere;
		else if (($sqlwhere==null)&&($addwhere!=null)) $imp_where = " WHERE ".$addwhere; 
		else $imp_where = $sqlwhere;
		print "\n";
		$stringsql = "SELECT ".$select." AS GRUPO".$grupo.$from_rel.$imp_where." GROUP BY ".$agrupar;
		$result = $conecta->query($stringsql);
		if (DB::isError($result)) die ($result->getDebugInfo());
		$rows = $result->numRows();
		if ($rows > 0){
			while($i = $result->fetchRow(DB_FETCHMODE_OBJECT)){
				$pegagrupo = "GRUPO".$grupo;
				$dado = $i->$pegagrupo;
				
				print "".$dado."\n";
				
				$where[$grupo] = $select."='".$dado."'";
				if($grupo==$tam-1) {
					$addwhere=null;
					for($j=0;$j<=$grupo;$j++){
						if ($j!=0) $addwhere.=" AND ";
						$addwhere.=$where[$j];
					}
					ExportarRelCSV::RelatorioPrinc($id,$addwhere,$from_rel,$from_form,$base,$template,$template_tipo,$template_nume,$sqlselect,$sqlfrom,$sqlwhere,$sqlorder,$sqlgroup,$sqlformgrup);
				} else if ($grupo<$tam) {
					ExportarRelCSV::RelatorioGrupo($id,$grupo+1,$agrupar_por,$tam,$where,$from_rel,$from_form,$base,$template,$template_tipo,$template_nume,$sqlselect,$sqlfrom,$sqlwhere,$sqlorder,$sqlgroup,$sqlformgrup);
				}
				print "\n";
			}
		}
	}
	
	function VisualizarSalvo($id){
		$conecta = Conexao::Conecta();
		$query = "SELECT RELNOME,RELBASE,RELCABECALHO,RELRODAPE,RELTEMPLATE,RELTEMPLATETIPO,RELTEMPLATENUME,RELSQLSELECT,RELSQLFROM,RELSQLWHERE,RELSQLORDER,RELSQLGROUP,RELSQLFORMGRUP,RELSQLFORMREL FROM RELATORIO WHERE RELCODIGO=".$id;
		$result = $conecta->query($query);
		if (DB::isError($result)) die ($result->getDebugInfo());
		$rows = $result->numRows();
		if ($rows > 0){
			$i = $result->fetchRow(DB_FETCHMODE_OBJECT);
			$nomerel = $i->RELNOME;
			$base = $i->RELBASE;
			$cabecalho = $i->RELCABECALHO;
			$cabecalho = str_replace("[[aspas]]","\"",$cabecalho);
			$rodape = $i->RELRODAPE;
			$rodape = str_replace("[[aspas]]","\"",$rodape);
			$template = $i->RELTEMPLATE;
			$template_tipo = $i->RELTEMPLATETIPO;
			$template_nume = $i->RELTEMPLATENUME;
			$sqlselect = $i->RELSQLSELECT;
			$sqlfrom = $i->RELSQLFROM;
			$sqlwhere = $i->RELSQLWHERE;
			$sqlorder = $i->RELSQLORDER;
			$sqlgroup = $i->RELSQLGROUP;
			$sqlformgrup = $i->RELSQLFORMGRUP;
			$sqlformrel = $i->RELSQLFORMREL;
			if ($sqlselect==null) die(""._ERRORELATORIO."");
		} else die(""._RELNAOENCONTRADO."");
		
		$from_rel = VisualizarRel::From($id,"rel");
		$from_form = VisualizarRel::From($id,"form");
		
		$conecta = Conexao::Conecta();
		$query = "SELECT AGRTABELA,AGRCAMPO FROM AGRUPAMENTO WHERE RELCODIGO=".$id." ORDER BY AGRNIVEL";
		$result = $conecta->query($query);
		if (DB::isError($result)) die ($result->getDebugInfo());
		$grupos = $result->numRows();
		if ($grupos > 0){
			$agrupar_por=null;
			while($i = $result->fetchRow(DB_FETCHMODE_OBJECT)){
				$grup_tab = $i->AGRTABELA;
				$grup_cam = $i->AGRCAMPO;
				$agrupar_por[]="`".$grup_tab."`.`".$grup_cam."`";
			}
			ExportarRelCSV::RelatorioGrupo($id,0,$agrupar_por,count($agrupar_por),null,$from_rel,$from_form,$base,$template,$template_tipo,$template_nume,$sqlselect,$sqlfrom,$sqlwhere,$sqlorder,$sqlgroup,$sqlformgrup);
		} else ExportarRelCSV::RelatorioPrinc($id,null,$from_rel,$from_form,$base,$template,$template_tipo,$template_nume,$sqlselect,$sqlfrom,$sqlwhere,$sqlorder,$sqlgroup,$sqlformgrup);

		//imprime formulas do relatorio geral
		$conecta = Conexao::Conecta();
		$query = "SELECT FORCAMPO,FORTITULO FROM FORMULA WHERE RELCODIGO=".$id." AND FORAPLICACAO='r' ORDER BY FORORDEM";
		$result = $conecta->query($query);
		if (DB::isError($result)) die ($result->getDebugInfo());
		$rows = $result->numRows();
		if ($rows > 0){
			$formulas=null;
			while($i = $result->fetchRow(DB_FETCHMODE_OBJECT)){
				$campo = $i->FORCAMPO;
				$titulo = $i->FORTITULO;
				$formulas[] = array($campo,$titulo);
			}
			$conecta = Conexao::ConectaRel($base);
			$stringsql = $sqlformrel.$from_form.$sqlwhere;
			$result = $conecta->query($stringsql);
			if (DB::isError($result)) die ($result->getDebugInfo());
			$rows2 = $result->numRows();
			if ($rows2 > 0){
				$i = $result->fetchRow(DB_FETCHMODE_OBJECT);
				for($cont=0;$cont<count($formulas);$cont++) {
					$pegatitulo = "Formula".$formulas[$cont][0];
					$formula = $i->$pegatitulo;
					print "".$pegatitulo." : ".$formula.";\n\n";
				}
			}
		}
	}

}
?>