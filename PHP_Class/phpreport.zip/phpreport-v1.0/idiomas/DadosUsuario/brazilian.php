<?php
//FORMUL�RIO DADOSUSUARIO
define("_TITULO","Editar Minha Conta");
define("_NOME","Nome");
define("_EMAIL","E-mail");
define("_USUARIO","Usu&aacute;rio");
define("_SENHA","Trocar Senha");
define("_DE6A8CARACTERES","(De 6 a 8 caracteres)");
define("_REPSENHA","Repete Senha");
define("_IDIOMA","Idioma");
define("_PADRAO","Idioma Padr&atilde;o");
define("_CONFIRMAR","Confirmar");
define("_SELECIONE",":: Selecione ::");

//CLASSE DADOSUSUARIO
define("_SENHASIGUAIS","Os dois campos da Senha devem ser iguais!");
define("_SENHADE6A8CARACTERES","A Senha deve conter de 06 a 08 caracteres!");
define("_CAMPONAOPREENCHIDO","Algum campo do formul�rio n�o foi preenchido!");
define("_EMAIL","E-mail inv�lido!");
define("_USUARIOJAEXISTE","J� existe um registro com o mesmo usu�rio!");
define("_OUSUARIO","O usu�rio ");
define("_CADASTRADO"," foi editado com sucesso!");
?>