<?php
//FORM DADOSUSUARIO
define("_TITULO","Edit My Account");
define("_NOME","Name");
define("_EMAIL","E-mail");
define("_USUARIO","User");
define("_SENHA","Change Password");
define("_DE6A8CARACTERES","(Between 6 and 8 characters)");
define("_REPSENHA","Repeat Password");
define("_IDIOMA","Language");
define("_PADRAO","Default Language");
define("_CONFIRMAR","Apply");
define("_SELECIONE",":: Select ::");

//CLASS DADOSUSUARIO
define("_SENHASIGUAIS","The two Password fields must be the same!");
define("_SENHADE6A8CARACTERES","The Password must contain between 06 and 08 characters!");
define("_CAMPONAOPREENCHIDO","Some fields was not filled!");
define("_EMAIL","Invalid e-mail!");
define("_USUARIOJAEXISTE","Already exists a register with the same user!");
define("_OUSUARIO","The user ");
define("_CADASTRADO"," was successfully edited!");
?>