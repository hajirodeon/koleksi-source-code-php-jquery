<?php
//FORMUL�RIO PRINCIPAL
define("_TITULO","Bem-vindo ao PHP Report!");
define("_MSG","Utilize os bot&otilde;es acima para navegar.");
?>