<?php
//FORMUL�RIO USUARIO
define("_TITULO","Usu&aacute;rios");
define("_NOME","Nome");
define("_EMAIL","E-mail");
define("_USUARIO","Usu&aacute;rio");
define("_TROCARSENHA","Trocar Senha");
define("_SENHA","Senha");
define("_DE6A8CARACTERES","(De 6 a 8 caracteres)");
define("_REPSENHA","Repete Senha");
define("_TIPO","Tipo");
define("_SELECIONE",":: Selecione ::");
define("_ADMINISTRADOR","Administrador");
define("_ELABORADOR","Elaborador");
define("_VISUALIZADOR","Visualizador");
define("_BASEDADOS","Bases de Dados");
define("_GRUPORELATORIO","Grupos de Relat&oacute;rio");
define("_CONFIRMAR","Confirmar");
define("_EXCLUIR","Excluir");
define("_CANCELAR","Cancelar");
define("_CADASTRAR","Cadastrar");
define("_TITULO2","Usu&aacute;rios Cadastrados");
define("_EDITAR","Editar");
define("_VER","Usu&aacute;rios");
define("_CTRL","Segure &lt;Ctrl&gt; para selecionar mais de uma op&ccedil;&atilde;o.");
define("_VERDESCRICAO","Ver descri&ccedil;&atilde;o dos grupos");
define("_ACESSO","Acesso");

//CLASSE USUARIO
define("_SENHASIGUAIS","Os dois campos da Senha devem ser iguais!");
define("_SENHADE6A8CARACTERES","A Senha deve conter de 06 a 08 caracteres!");
define("_CAMPONAOPREENCHIDO","Algum campo do formul�rio n�o foi preenchido!");
define("_EMAILINVALIDO","E-mail inv�lido!");
define("_USUARIOJAEXISTE","J� existe um registro com o mesmo usu�rio!");
define("_OUSUARIO","O usu�rio ");
define("_CADASTRADO"," foi editado com sucesso!");
define("_SELECIONEUMUSUARIO","Selecione um usu�rio!");
define("_EXCLUIDO"," foi exclu�do com sucesso!");
define("_EDITADO"," foi editado com sucesso!");
define("_CONFIRMAEXCL","Deseja excluir este usu�rio?");
?>