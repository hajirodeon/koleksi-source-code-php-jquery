<?php
//FORM USUARIO
define("_TITULO","Users");
define("_NOME","Name");
define("_EMAIL","E-mail");
define("_USUARIO","User");
define("_TROCARSENHA","Change Password");
define("_SENHA","Password");
define("_DE6A8CARACTERES","(Between 6 and 8 characters)");
define("_REPSENHA","Repeat Password");
define("_TIPO","Type");
define("_SELECIONE",":: Select ::");
define("_ADMINISTRADOR","Administrator");
define("_ELABORADOR","Creator");
define("_VISUALIZADOR","Reader");
define("_BASEDADOS","Databases");
define("_GRUPORELATORIO","Report Groups");
define("_CONFIRMAR","Apply");
define("_EXCLUIR","Delete");
define("_CANCELAR","Cancel");
define("_CADASTRAR","Save");
define("_TITULO2","Registered Users");
define("_EDITAR","Edit");
define("_VER","Users");
define("_CTRL","Hold &lt;Ctrl&gt; button to select more than one option.");
define("_VERDESCRICAO","View groups description");
define("_ACESSO","Access");

//CLASS USUARIO
define("_SENHASIGUAIS","The two Password fields must be the same!");
define("_SENHADE6A8CARACTERES","The Password must contain between 06 and 08 characters!");
define("_CAMPONAOPREENCHIDO","Some fields was not filled!");
define("_EMAILINVALIDO","Invalid e-mail");
define("_USUARIOJAEXISTE","Already exists a register with the same user!");
define("_OUSUARIO","The user ");
define("_CADASTRADO"," was successfully registered!");
define("_SELECIONEUMUSUARIO","Select a user!");
define("_EXCLUIDO"," was successfully deleted!");
define("_EDITADO"," was successfully edited!");
define("_CONFIRMAEXCL","Would you like do delete this user?");
?>