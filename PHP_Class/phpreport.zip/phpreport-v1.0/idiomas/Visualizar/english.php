<?php
//FORM VISUALIZARREL
define("_TITULO","Report");
define("_VISUALIZAR","View");
define("_EDITAR","Edit");
define("_MODOEDICAO","Back to<br>edition mode");
define("_SALVAR","Save");
define("_EXCLUIR","Delete");
define("_EXPORTAR","Export");
define("_AVISO","For not losing this report, click on Save or Back to edition mode button.");

//CLASS VISUALIZARREL
define("_ERRORELATORIO","It seems an error occurred during this report recording, edit it and try again.");
define("_RELNAOENCONTRADO","Report not found.");
define("_USUNAOENCONTRADO","User not found.");
define("_GRUPO","Group");
define("_DATACRIACAO","Date created");
define("_USUCRIACAO","User created");
define("_DATAEDICAO","Date modified");
define("_USUEDICAO","User modified");
define("_BASEDADOS","Database");
define("_PAGINA","Page");
define("_DE","of");

//CLASS GERARRELSALVAR
define("_PREENCHATODOS","Some fields was not filled!");

//CLASS GERARREL
define("_RELACIONMSMTABELA","There is(are) relantionship(s) between the same table!");
define("_RELACIONDUPLICADO","There is(are) duplicated relantionship(s)!");
define("_PREENCHARELACION","Define all the relantionships between the tables!");
define("_ACESSOBD","Access denied to this database!");
?>