<?php
//FORM RELATORIO
define("_TITULO","Reports");
define("_BUSCARREL","Search Reports");
define("_BUSCAR","Search");
define("_GRUPO","Group");
define("_TODOS","All");
define("_USUMODIFICACAO","User modified");
define("_DATAMODIFICACAO","Date modified");
define("_DE","from");
define("_ATE","to");
define("_VERDESCRICAO","View groups description");

//CLASS RELATORIO
define("_RELATORIO","Report");
define("_USUARIO","User");
define("_DATA","Date");
define("_VISUALIZAR","View");
define("_EDITAR","Edit");
define("_EXCLUIR","Delete");
define("_DESEJAEXCLUIR","Would you like to delete the report: ");
define("_PREENCHAMODIFICACAO","Fill in all the fields of the modification period");
define("_PREENCHAANO","Fill in the year field using 4 characters.");
define("_ORELATORIO","The report ");
define("_FOIEXCLUIDO"," was successfully deleted.");

//CLASS GERARREL
define("_ACESSOBD","Access denied to this database!");

?>