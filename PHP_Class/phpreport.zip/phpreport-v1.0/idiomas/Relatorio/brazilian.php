<?php
//FORMUL�RIO RELATORIO
define("_TITULO","Relat&oacute;rios");
define("_BUSCARREL","Buscar Relat&oacute;rios");
define("_BUSCAR","Buscar");
define("_GRUPO","Grupo");
define("_TODOS","Todos");
define("_USUMODIFICACAO","Usu&aacute;rio da modifica&ccedil;&atilde;o");
define("_DATAMODIFICACAO","Data de modifica&ccedil;&atilde;o");
define("_DE","de");
define("_ATE","at&eacute;");
define("_VERDESCRICAO","Ver descri&ccedil;&atilde;o dos grupos");

//CLASSE RELATORIO
define("_RELATORIO","Relat&oacute;rio");
define("_USUARIO","Usu&aacute;rio");
define("_DATA","Data");
define("_VISUALIZAR","Visualizar");
define("_EDITAR","Editar");
define("_EXCLUIR","Excluir");
define("_DESEJAEXCLUIR","Deseja excluir o relat�rio: ");
define("_PREENCHAMODIFICACAO","Preencha todos os campos do per�odo de modifica��o.");
define("_PREENCHAANO","Preencha os campos do ano com 4 caracteres.");
define("_ORELATORIO","O relat�rio ");
define("_FOIEXCLUIDO"," foi exclu�do com sucesso.");

//CLASSE GERARREL
define("_ACESSOBD","Acesso n�o autorizado � esta base de dados!");
?>