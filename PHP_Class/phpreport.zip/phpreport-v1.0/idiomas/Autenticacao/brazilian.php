<?php
//FORMUL�RIO GRUPOREL
define("_TITULO","Autentica&ccedil;&atilde;o");
define("_USUARIO","Usu&aacute;rio");
define("_SENHA","Senha");
define("_ENTRAR","Entrar");

//CLASSE GRUPOREL
define("_ACESSONEGADO","Usu�rio e/ou senha incorretos!");
?>