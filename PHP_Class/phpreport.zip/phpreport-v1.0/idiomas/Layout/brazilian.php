<?php
//CLASSE LAYOUT
define("_LAYGRUPOS","Grupos");
define("_LAYUSUARIOS","Usu&aacute;rios");
define("_LAYGERARREL","Criar Relat&oacute;rio");
define("_LAYRELATORIOS","Relat&oacute;rios");
define("_LAYMEUSDADOS","Minha Conta");
define("_LAYHOME","IN&Iacute;CIO");
define("_LAYLOGOUT","SAIR");
define("_LAYAJUDA","AJUDA");
define("_LAYDATE","Hoje � ".strftime("%d-%m-%Y"));
define("_DESENVOLVIDOPOR","Desenvolvido por");
?>