<?php
//CLASS LAYOUT
define("_LAYGRUPOS","Groups");
define("_LAYUSUARIOS","Users");
define("_LAYGERARREL","Create Report");
define("_LAYRELATORIOS","Reports");
define("_LAYMEUSDADOS","My Account");
define("_LAYHOME","HOME");
define("_LAYLOGOUT","LOGOUT");
define("_LAYAJUDA","HELP");
define("_LAYDATE","Today is ".strftime("%Y-%m-%d"));
define("_DESENVOLVIDOPOR","Developed by");
?>