<?php
//FORMUL�RIO GRUPOREL
define("_TITULO","Grupos");
define("_NOME","Nome");
define("_DESCRICAO","Descri&ccedil;&atilde;o");
define("_NIVEL","N&iacute;vel");
define("_EDITAR","Editar");
define("_EXCLUIR","Excluir");
define("_CANCELAR","Cancelar");
define("_CADASTRAR","Cadastrar");
define("_CONFIRMAR","Confirmar");
define("_VER","Grupos");
define("_GRUCADASTRADOS","Grupos Cadastrados");
define("_SELECIONE",":: Selecione ::");

//CLASSE GRUPOREL
define("_GRUPOJAEXISTE","J� existe um grupo deste n�vel com o nome indicado!");
define("_OGRUPO","O grupo ");
define("_CADASTRADO"," foi cadastrado com sucesso!");
define("_EXCLUIDO"," foi exclu�do com sucesso!");
define("_CAMPONAOPREENCHIDO","Algum campo do formul�rio n�o foi preenchido!");
define("_EDITADO"," foi editado com sucesso!");
define("_SELECIONEUMGRUPO","Selecione um Grupo!");
define("_EXISTEMRELATORIOS","Existem relat�rios dentro dos seguintes grupos: ");
define("_CONFIRMAEXCL","Deseja excluir este grupo?");
?>