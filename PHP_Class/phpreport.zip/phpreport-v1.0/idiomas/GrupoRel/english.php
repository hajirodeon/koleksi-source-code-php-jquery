<?php
//FORM GRUPOREL
define("_TITULO","Group");
define("_NOME","Name");
define("_DESCRICAO","Description");
define("_NIVEL","Level");
define("_EDITAR","Edit");
define("_EXCLUIR","Delete");
define("_CANCELAR","Cancel");
define("_CADASTRAR","Save");
define("_CONFIRMAR","Apply");
define("_VER","Groups");
define("_GRUCADASTRADOS","Registered Groups");
define("_SELECIONE",":: Select ::");

//CLASS GRUPOREL
define("_GRUPOJAEXISTE","Already exists a group in this level with the same name!");
define("_OGRUPO","The group ");
define("_CADASTRADO"," was successfully registered!");
define("_EXCLUIDO"," was successfully deleted!");
define("_CAMPONAOPREENCHIDO","Some fields was not filled!");
define("_EDITADO"," was successfully edited!");
define("_SELECIONEUMGRUPO","Select a Group!");
define("_EXISTEMRELATORIOS","There are reports registered in the following groups: ");
define("_CONFIRMAEXCL","Would you like do delete this group?");
?>