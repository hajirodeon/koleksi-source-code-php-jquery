<?php
//FORM EXPORTARREL
define("_TITULO","Export Report");
define("_SELECIONE",":: Select ::");
define("_TIPOARQUIVO","Extension");
define("_ORIENTACAO","Orientation");
define("_MARGENS","Margins (mm)");
define("_FONTE","Font");
define("_PAPEL","Paper");
define("_TAMANHO","Size");
define("_DIR","Right");
define("_TOP","Top");
define("_ESQ","Left");
define("_EXPORTAR","Export");
define("_CANCELAR","Cancel");
define("_RETRATO","Portrait");
define("_PAISAGEM","Landscape");

//CLASS EXPORTARREL
define("_ESCOLHAARQ","Choose an extension type!");
define("_PREENCHAPARAM","Fill in all configuration fields!");
?>