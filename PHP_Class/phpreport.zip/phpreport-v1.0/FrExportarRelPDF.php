<?
/***********************************************************************************/
/*                                 PHP Report                                      */
/*                                                                                 */
/* Copyright (c) 2005 by Daniela Toniolo, Leonardo Galv�o and Marli Carneiro       */
/*                                                                                 */
/* This is a free software. You can redistribute it and/or modify it under the     */
/* terms of the GNU General Public License.                                        */
/***********************************************************************************/

	define('FPDF_FONTPATH','scripts/font/');
	require('scripts/fpdf.php');

	session_start();
	include("classes/Class_Layout.php");
	Layout::AcessoPagina("Visualizar");
	include("idiomas/Exportar/".$_SESSION["Idioma"].".php");
	include("classes/Class_Conexao.php");
	include("classes/Class_ExportarRel.php");
	include("classes/Class_VisualizarRel.php");
	
	$tipoarquivo = $_GET['tipoarquivo'];
	$estilo = $_GET['estilo'];
	$fonte = $_GET['fonte'];
	$folha = $_GET['folha'];
	$tam = $_GET['tam'];
	$top = $_GET['top'];
	$dir = $_GET['dir'];
	$esq = $_GET['esq'];
	
	class MeuPDF extends FPDF {
		function Header(){
		$id = $_GET['id'];
		$conecta = Conexao::Conecta();
		$query = "SELECT RELCABECALHO FROM RELATORIO WHERE RELCODIGO=".$id;
		$result = $conecta->query($query);
		if (DB::isError($result)) die ($result->getDebugInfo());
		$rows = $result->numRows();
		if ($rows > 0){
		$tam = $_GET['tam'];
		$fonte = $_GET['fonte'];
			$i = $result->fetchRow(DB_FETCHMODE_OBJECT);
			$cabecalho = $i->RELCABECALHO;
			$cabecalho = str_replace("[[aspas]]","\"",$cabecalho);
			$cabecalho = str_replace("<STRONG>","",$cabecalho);
			$cabecalho = str_replace("</STRONG>","",$cabecalho);
			$cabecalho = str_replace("<EM>","",$cabecalho);
			$cabecalho = str_replace("</EM>","",$cabecalho);
			$cabecalho = str_replace("<BR>","     ",$cabecalho);
			$cabecalho = str_replace("<P>","          ",$cabecalho);
			$cabecalho = str_replace("<P align=center>","          ",$cabecalho);
			$cabecalho = str_replace("<P align=right>","          ",$cabecalho);
			$cabecalho = str_replace("<P align=left>","          ",$cabecalho);
			$cabecalho = str_replace("</P>","",$cabecalho);
			$cabecalho = strip_tags($cabecalho,$cabecalho);
			$this->SetFont($fonte,'',$tam+2);
			//$this->Image($imagem, 1200, 2, 50); //insere uma imagem 
			$this->Cell(0, 10,$cabecalho,0,1,'C');
			$this->ln();
			}
		}
		function Footer()
		{
		$id = $_GET['id'];
		$top = $_GET['top'];
		$conecta = Conexao::Conecta();
		$query = "SELECT RELRODAPE FROM RELATORIO WHERE RELCODIGO=".$id;
		$result = $conecta->query($query);
		if (DB::isError($result)) die ($result->getDebugInfo());
		$rows = $result->numRows();
		if ($rows > 0){
			$tam = $_GET['tam'];
			$fonte = $_GET['fonte'];
			$i = $result->fetchRow(DB_FETCHMODE_OBJECT);
			$rodape = $i->RELRODAPE;
			$rodape = str_replace("[[aspas]]","\"",$rodape);
			$rodape = str_replace("<BR>","",$rodape);
			$rodape = str_replace("<STRONG>","",$rodape);
			$rodape = str_replace("</STRONG>","",$rodape);
			$rodape = str_replace("<BR>","     ",$rodape);
			$rodape = str_replace("<P>","          ",$rodape);
			$rodape = str_replace("<P align=center>","          ",$rodape);
			$rodape = str_replace("<P align=right>","          ",$rodape);
			$rodape = str_replace("<P align=left>","          ",$rodape);
			$rodape = str_replace("</P>","",$rodape);
			$rodape = strip_tags ($rodape,$rodape);
			
			$this->SetY(-($top));
			$this->SetFont($fonte,'',$tam+2);
			//$this->Cell(0,10,'P�gina '.$this->PageNo().'/{nb}',0,0,'C');
			$this->Cell(0, 10,$rodape,0,1,'C');
			/*$this->SetFont($fonte,'',$tam+2);
			$this->Cell(0, 5,$rodape,0,1,'C');
			$this->Cell(0,5,$this->PageNo(),0,0,'R');*/
			}
		}
	
		function RelatorioPrinc($id,$pdf,$largura,$addwhere,$from_rel,$from_form,$base,$template,$template_tipo,$template_nume,$sqlselect,$sqlfrom,$sqlwhere,$sqlorder,$sqlgroup,$sqlformgrup){
		$conecta = Conexao::Conecta();
		$query = "SELECT CAMTITULO FROM CAMPO WHERE RELCODIGO=".$id." ORDER BY CAMORDEM";
		$result = $conecta->query($query); 
		if (DB::isError($result)) die ($result->getDebugInfo()); 
		$colunas = $result->numRows(); 
		$larg = $largura / $colunas;
		//$pdf->ln();
		if ($colunas > 0){
			while($i = $result->fetchRow(DB_FETCHMODE_OBJECT)){
				$titulo = $i->CAMTITULO;
				$pdf->SetFont($_GET["fonte"],'',$_GET["tam"]);
				$pdf->Cell($larg,5,$titulo,1);
			}
			$pdf->ln();
		}

		$conecta = Conexao::ConectaRel($base);
		if (($sqlwhere==null)&&($addwhere==null)) $where = null;
		else if (($sqlwhere!=null)&&($addwhere!=null)) $where = " ".$sqlwhere." AND ".$addwhere;
		else if (($sqlwhere==null)&&($addwhere!=null)) $where = " WHERE ".$addwhere; 
		else $where = " ".$sqlwhere;
		$stringsql = $sqlselect." ".$from_rel.$where." ".$sqlorder;
		
		$result = $conecta->query($stringsql);
				if (DB::isError($result)) die ($result->getDebugInfo());
				$linhas = $result->numRows();
				if ($linhas > 0) {
					while($j = $result->fetchRow(DB_FETCHMODE_OBJECT)) {		
						for($id_coluna=0;$id_coluna<$colunas;$id_coluna++){
							
							$pegacoluna = "COLUNA".$id_coluna;
							$dado = $j->$pegacoluna;
							$conecta = Conexao::Conecta();
							$query = "SELECT CAMCAMPO FROM CAMPO WHERE RELCODIGO=".$id." AND CAMORDEM=".$id_coluna;
							$result1 = $conecta->query($query); 
							if (DB::isError($result1)) die ($result1->getDebugInfo()); 
							$i = $result1->fetchRow(DB_FETCHMODE_OBJECT);
							$titulo = $i->CAMCAMPO;
							//$dado = wordwrap($dado, 10);
							$pdf->SetFont($_GET["fonte"],'',$_GET["tam"]);
							if ($dado!=null) $pdf->Cell($larg,5,$dado,1); 
						}
						$pdf->ln();
						$conecta = Conexao::ConectaRel($base);
					}
				}
		
		//imprime formulas do grupo
		$conecta = Conexao::Conecta();
		$query = "SELECT FORCAMPO,FORTITULO FROM FORMULA WHERE RELCODIGO=".$id." AND FORAPLICACAO='g' ORDER BY FORORDEM";
		$result = $conecta->query($query);
		if (DB::isError($result)) die ($result->getDebugInfo());
		$rows = $result->numRows();
		if ($rows > 0){
			$formulas=null;
			while($i = $result->fetchRow(DB_FETCHMODE_OBJECT)){
				$campo = $i->FORCAMPO;
				$titulo = $i->FORTITULO;
				$formulas[] = array($campo,$titulo);
			}
			$conecta = Conexao::ConectaRel($base);
			$stringsql = $sqlformgrup.$from_form.$where.$sqlgroup;
			$result = $conecta->query($stringsql);
			if (DB::isError($result)) die ($result->getDebugInfo());
			$rows2 = $result->numRows();
			if ($rows2 > 0){
				$i = $result->fetchRow(DB_FETCHMODE_OBJECT);
				for($cont=0;$cont<count($formulas);$cont++) {
					$pegatitulo = "FormulaGrupo".$formulas[$cont][0];
					$formula = $i->$pegatitulo;
					$pdf->SetFont($_GET["fonte"],'',$_GET["tam"]);
					$pdf->Cell(0,10,$titulo.": ".$formula,0,1,'R');
					//$pdf->ln();
					//$pdf->ln();
				}
			}
		} 
	}

	function RelatorioGrupo($id,$pdf,$grupo,$largura,$agrupar_por,$tam,$where,$from_rel,$from_form,$base,$template,$template_tipo,$template_nume,$sqlselect,$sqlfrom,$sqlwhere,$sqlorder,$sqlgroup,$sqlformgrup){
		
		$agrupar = null;
		for ($i=0;$i<=$grupo;$i++) {
			if($i!=0) $agrupar .= ", ";
			$agrupar .= $agrupar_por[$i];
		}
		$select = $agrupar_por[$grupo];
		$addwhere = null;
		for($j=0;$j<$grupo;$j++){
			if ($j!=0) $addwhere.=" AND ";
			$addwhere.=$where[$j];
		}
		if (($sqlwhere==null)&&($addwhere==null)) $imp_where = null;
		else if (($sqlwhere!=null)&&($addwhere!=null)) $imp_where = $sqlwhere." AND ".$addwhere;
		else if (($sqlwhere==null)&&($addwhere!=null)) $imp_where = " WHERE ".$addwhere; 
		else $imp_where = $sqlwhere;
		
		$conecta = Conexao::ConectaRel($base);
		$stringsql = "SELECT ".$select." AS GRUPO".$grupo.$from_rel.$imp_where." GROUP BY ".$agrupar;
		$result = $conecta->query($stringsql);
		if (DB::isError($result)) die ($result->getDebugInfo());
		$rows = $result->numRows();
		if ($rows > 0){
			while($i = $result->fetchRow(DB_FETCHMODE_OBJECT)){
				$pegagrupo = "GRUPO".$grupo;
				$dado = $i->$pegagrupo;
				for ($k=0;$k<$grupo;$k++) $espa�o.="     ";
				if ($grupo==0) {
					$tam_font = $_GET["tam"]+2;
					$pdf->SetFont($_GET["fonte"],'',$tam_font); 
				} else {
					$tam_font = $_GET["tam"]+1;
					$pdf->SetFont($_GET["fonte"],'',$tam_font); 
				}
				//$pdf->Cell($larg,5,$dado,1);
				$pdf->Cell(0,10,$espa�o.$dado,0,1,'L');
				//$pdf->ln();
				
				$where[$grupo] = $select."='".$dado."'";
				if($grupo==$tam-1) {
					$addwhere=null;
					for($j=0;$j<=$grupo;$j++){
						if ($j!=0) $addwhere.=" AND ";
						$addwhere.=$where[$j];
					}
					MeuPDF::RelatorioPrinc($id,$pdf,$largura,$addwhere,$from_rel,$from_form,$base,$template,$template_tipo,$template_nume,$sqlselect,$sqlfrom,$sqlwhere,$sqlorder,$sqlgroup,$sqlformgrup);
				} else if ($grupo<$tam) {
					MeuPDF::RelatorioGrupo($id,$pdf,$grupo+1,$largura,$agrupar_por,$tam,$where,$from_rel,$from_form,$base,$template,$template_tipo,$template_nume,$sqlselect,$sqlfrom,$sqlwhere,$sqlorder,$sqlgroup,$sqlformgrup);
				}
				//$pdf->ln();
			}
		}
	}
	function VisualizarSalvo($id,$pdf,$largura){
		$conecta = Conexao::Conecta();
		$query = "SELECT RELNOME,RELBASE,RELCABECALHO,RELRODAPE,RELTEMPLATE,RELTEMPLATETIPO,RELTEMPLATENUME,RELSQLSELECT,RELSQLFROM,RELSQLWHERE,RELSQLORDER,RELSQLGROUP,RELSQLFORMGRUP,RELSQLFORMREL FROM RELATORIO WHERE RELCODIGO=".$id;
		$result = $conecta->query($query);
		if (DB::isError($result)) die ($result->getDebugInfo());
		$rows = $result->numRows();
		if ($rows > 0){
			$i = $result->fetchRow(DB_FETCHMODE_OBJECT);
			$nomerel = $i->RELNOME;
			$base = $i->RELBASE;
			$cabecalho = $i->RELCABECALHO;
			$cabecalho = str_replace("[[aspas]]","\"",$cabecalho);
			$rodape = $i->RELRODAPE;
			$rodape = str_replace("[[aspas]]","\"",$rodape);
			$template = $i->RELTEMPLATE;
			$template_tipo = $i->RELTEMPLATETIPO;
			$template_nume = $i->RELTEMPLATENUME;
			$sqlselect = $i->RELSQLSELECT;
			$sqlfrom = $i->RELSQLFROM;
			$sqlwhere = $i->RELSQLWHERE;
			$sqlorder = $i->RELSQLORDER;
			$sqlgroup = $i->RELSQLGROUP;
			$sqlformgrup = $i->RELSQLFORMGRUP;
			$sqlformrel = $i->RELSQLFORMREL;
			//Header($cabecalho);//chamando a funcao
			if ($sqlselect==null) die(""._ERRORELATORIO."");
		} else die(""._RELNAOENCONTRADO."");
		
			$from_rel = VisualizarRel::From($id,"rel");
			$from_form = VisualizarRel::From($id,"form");
		
		$conecta = Conexao::Conecta();
		$query = "SELECT AGRTABELA,AGRCAMPO FROM AGRUPAMENTO WHERE RELCODIGO=".$id." ORDER BY AGRNIVEL";
		$result = $conecta->query($query);
		if (DB::isError($result)) die ($result->getDebugInfo());
		$grupos = $result->numRows();
		if ($grupos > 0){
			$agrupar_por=null;
			while($i = $result->fetchRow(DB_FETCHMODE_OBJECT)){
				$grup_tab = $i->AGRTABELA;
				$grup_cam = $i->AGRCAMPO;
				$agrupar_por[]="`".$grup_tab."`.`".$grup_cam."`";
			}
			MeuPDF::RelatorioGrupo($id,$pdf,0,$largura,$agrupar_por,count($agrupar_por),null,$from_rel,$from_form,$base,$template,$template_tipo,$template_nume,$sqlselect,$sqlfrom,$sqlwhere,$sqlorder,$sqlgroup,$sqlformgrup);
		} else MeuPDF::RelatorioPrinc($id,$pdf,$largura,null,$from_rel,$from_form,$base,$template,$template_tipo,$template_nume,$sqlselect,$sqlfrom,$sqlwhere,$sqlorder,$sqlgroup,$sqlformgrup);
		
		//Imprime formulas do relatorio geral
		$conecta = Conexao::Conecta();
		$query = "SELECT FORCAMPO,FORTITULO FROM FORMULA WHERE RELCODIGO=".$id." AND FORAPLICACAO='r' ORDER BY FORORDEM";
		$result = $conecta->query($query);
		if (DB::isError($result)) die ($result->getDebugInfo());
		$rows = $result->numRows();
		if ($rows > 0){
			$formulas=null;
			while($i = $result->fetchRow(DB_FETCHMODE_OBJECT)){
				$campo = $i->FORCAMPO;
				$titulo = $i->FORTITULO;
				$formulas[] = array($campo,$titulo);
			}
			$conecta = Conexao::ConectaRel($base);
			$stringsql = $sqlformrel.$from_form.$sqlwhere;
			$result = $conecta->query($stringsql);
			if (DB::isError($result)) die ($result->getDebugInfo());
			$rows2 = $result->numRows();
			if ($rows2 > 0){
				$i = $result->fetchRow(DB_FETCHMODE_OBJECT);
				for($cont=0;$cont<count($formulas);$cont++) {
					$pegatitulo = "Formula".$formulas[$cont][0];
					$formula = $i->$pegatitulo;
					//$pdf->Cell($larg,5,$titulo.": ".$formula,1);
					$pdf->SetFont($_GET["fonte"],'',$_GET["tam"]);
					$pdf->Cell(0,10,$titulo.": ".$formula,0,1,'R');
				}
			}
		}
	}
}

	$pdf = new MeuPDF($estilo,'mm',$folha);
	$pdf->Open();
	$pdf->AddPage();
	$pdf->SetFont($fonte, '', $tam);
	$pdf->SetAuthor('PHP Report');
	$pdf->SetLeftMargin($esq);
	$pdf->SetRightMargin($dir);
	$pdf->SetTopMargin($top);
	$pdf->SetAutoPageBreak(true,$top);
	if ($folha == "A4"){
		if ($estilo == "P")$largura = 210; else $largura = 297;
	}
	if ($folha == "A3"){
		if ($estilo == "P")$largura = 297;else $largura = 420;
	}
	if ($folha == "A5"){
		if ($estilo == "P")$largura = 148; else $largura = 210;
	}
	if (($folha == "legal") || ($folha == "letter")){
		if ($estilo == "P") $largura = 216; else $largura = 280;
	}
	$largura = $largura - ($dir + $esq);
	
	MeuPDF::VisualizarSalvo($_GET['id'],$pdf,$largura);

	$pdf->Output("Relatorio.pdf","F");
?>