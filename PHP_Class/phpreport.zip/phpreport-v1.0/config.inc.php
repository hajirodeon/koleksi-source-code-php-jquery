<?
/***********************************************************************************/
/*                                 PHP Report                                      */
/*                                                                                 */
/* Copyright (c) 2005 by Daniela Toniolo, Leonardo Galv�o and Marli Carneiro       */
/*                                                                                 */
/* This is a free software. You can redistribute it and/or modify it under the     */
/* terms of the GNU General Public License.                                        */
/***********************************************************************************/

/***********************************************************************************/
/* COMPLETE THESE FIELDS, PLEASE!
/* PHPREPORT SERVER
/***********************************************************************************/
$DBHostName = "localhost"; //Database Host
$DBUserName = ""; //Database User
$DBPassword = ""; //User Password
$DBName     = ""; //Write here the database name you created PhpReport's tables
$DBType		= "mysql"; //Don't change this!
$Language	= "brazilian"; //Default Language: brazilian, english

/***********************************************************************************/
/* YOUR SERVER
/***********************************************************************************/
$DBHostName0 = "localhost"; //Database Host
$DBUserName0 = ""; //Database User
$DBPassword0 = ""; //User Password
$DBType0	 = "mysql";  //Don't change this!
/***********************************************************************************/
?>