<?php
require('frtf.php');

$rtf=new FRTF();
$rtf->Open();
$rtf->SetPaperSize('A4');
$rtf->SetPageOrientation('L');
$rtf->SetViewKind('Page');
$rtf->SetViewScale(100);
$rtf->SetViewZk('None');
$rtf->Write("The first text to be diplayed");
$rtf->Write("This string will be displayed continously",'no');
$rtf->Write('Another string in a new paragraph');
$rtf->Close();
$rtf->Output('loco.rtf');
?>
