<?php
require('frtf.php');

$rtf=new FRTF('Lansdcape','A4','en');
$rtf->Open();
$rtf->SetDocumentView('Page',100);
$rtf->Write("The first text to be diplayed");
$rtf->Write("This string will be displayed continously",'no');
$rtf->Write('Another string in a new paragraph');
$rtf->Close();
$rtf->Output();
?>
