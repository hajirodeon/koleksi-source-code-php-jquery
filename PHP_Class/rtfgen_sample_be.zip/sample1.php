<?php
require('frtf.php');

$rtf=new FRTF();
$rtf->Open();
$rtf->Write('My first rtf document created with RTF Generator');
$rtf->Close();
$rtf->Output();
?>
