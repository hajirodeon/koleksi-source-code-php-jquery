<?
/*
Tipo : classe
Nome : UpLoad
Data : 29/08/2003
Autor: Wonder Alexandre Luz Alves
Desc : Exemplo de como utilizar a class UpLoad
Vers�o: 1.2
*/

include_once("./class_upload.php"); ?>
<html>
<head>
<title>PHP_Upload class</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
.testo {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 10px;
}
.titulo {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
	font-weight: bolder;
	color:#FFFFFF;
}
.eu {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 11px;
}

-->
</style>
</head>

<body>
<table align="CENTER" width="500" border="0">
  <tr> 
    <td bgcolor="000099" colspan="2"><div align="center" class="titulo">PHP Upload 
        class</div></td>
  </tr>
  
  <tr>
    <td height="10" colspan="2">
<div align="left" class="eu">
    /*<br>
Tipo   : classe<br>
Nome   : UpLoad<br>
Data   : 29/08/2003<br>
Autor  : Wonder Alexandre Luz Alves<br>
Desc   : Exemplo de como utilizar a class UpLoad<br>
Vers�o : 1.2<br>
Contato: <a href="mailto:wonderalexandre@yahoo.com.br">wonderalexandre@yahoo.com.br</a><br>

*/<br>

</CENTER>
	</td>
  </tr>
  <tr> 
    <td height="10" colspan="2"><div align="center">
    <?php 
	if ( $send == "ok" && $_FILES[userfile]['name'] ){	
		
		$upload = new upload();
		
		if ($upload -> putFile ("userfile")) {
			print "<div class=\"testo\"><br>UpLoad do arquivo com sucesso.<br>"; 
			print "Arquivo: ";
			print $upload->file_name;
			print "<br>Diretorio: ";
			print $upload->dir;
			print "<br><br></div>";
		}
			
		if ($upload->Miniatura()) { 
			print "<div class=\"testo\">Miniatura criada com sucesso.<br>"; 
			
		    print "Arquivo: ";
			print $upload->MINI_name;
			print "<br>Diretorio: ";
			print $upload->MINI_path;
			print "<br><br></div>";
			$upload->Mostrar_MINI();
		}
	} 
	
	?>
      </div></td>
  </tr>
  <form action="<?php $PHP_SELF; ?>" method="post" enctype="multipart/form-data"> <tr>
    <td colspan="2">
        <p align="center"> 
          <input name="userfile" type="file" class="testo">
        </p>
      </td>
  </tr>
  <tr> 
    <td colspan="2"> <p align="center"> 
        <input name="Submit" type="submit" value="Upload File &gt;&gt;" class="testo">
        <input name="send" type="hidden" value="ok">
      </p></td>
  </tr></form>
</table>
</body>
</html>
