<?
#########################################################
#	GiveMeEnergy Projects				#
#	Powered by []==ThoR�				#
#	Free script under GPL				#
#	Feel free to modify it, but keep credits intact	#
#							#
#	Backup Script					#
#	vers 2.0					#
#		added Database Backup			#
#	vers 1.0					#
#########################################################

include("class.backup.php");
switch($op)	{
	default:
		echo "<a href=\"".$GLOBALS['SCRIPT_NAME']."?op=bk\">Make Backup</a>";
	break;
	case "bk":
		$filename	= date("Y_m_d__H_i");
		###	Start Class			###
		$mkBackup	= new BackUp;
		###	Folder to Backup		###
		$mkBackup->WhatBackup("../AdminTools");
		###	Where to put the gzipped file	###
		$mkBackup->WhereBackup("./backup");
		###	Save as...			###
		$mkBackup->FileName("".$filename."__TestingBK");
		###	If You want to echo the info	###
		//$mkBackup->Debug();
		###	Run Backup			###
		$mkBackup->Backup();
		###	Set Filename .sql	        ###
		$mkBackup->DBFileName("2004_06_01__TestingBK");
		$mkBackup->DBMakeBackup("localhost","","root","","giveme");
	break;
}

?>