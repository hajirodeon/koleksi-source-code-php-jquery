<?
#########################################################
#	GiveMeEnergy Projects				#
#	Powered by []==ThoR�				#
#	Free script under GPL				#
#	Feel free to modify it, but keep credits intact	#
#########################################################

/********************************************************/
/*	         					*/
/*	Backup Script					*/
/*							*/
/********************************************************/

class BackUp	{

	Function WhatBackup($whatBackup)	{
		if (	(!$whatBackup) || ($whatBackup == "")	)	{
			die("Specify folder to backup");
		}
		$this->whatBackup	= $whatBackup;
	}

	###	Make dir if not exists	###
	Function WhereBackup($whereBackup)	{
		$patharr	= explode("/", $whereBackup);
		$progr		= "";
		foreach($patharr as $k => $v)	{
			$progr		.= $v;
			$oldumask	= umask(0);
			if (!file_exists($progr))	{
				mkdir($progr, 0777);
			}
			umask($oldumask);
			$progr		.= "/";
		}
		$this->WhereBackup	= $whereBackup;
	}

	###	Build FileName	###
	Function FileName($fileName)	{
		$today		= date("Y_m_d__H-i");
		$fileName	= (	(!$fileName) || ($fileName == "")	)	? $today : $fileName;
		$this->fileName	= $fileName;
	}

	Function Debug()	{
		$this->msg	= "<br>";
		$this->msg	.= "WhatBackup: ".$this->whatBackup."<br>";
		$this->msg	.= "WhereBackup: ".$this->WhereBackup."<br>";
		$this->msg	.= "FileName: ".$this->fileName.".tar.gz<br>";
	}
	###	Do It	###
	Function Backup()	{
		$theScript	= $GLOBALS['SCRIPT_NAME'];
		$today		= date("Y_m_d__H-i");
		$comm 		= "tar cfvz ".$this->WhereBackup."/".$this->fileName.".tar.gz ".$this->whatBackup."";
		###	If u want All output, use passthru() function	###
		$run		= exec($comm);
		$msg		= ($run != "") ? "Backup OK" : "Backup KO";
		echo "".$this->msg."";
	}

}

?>
