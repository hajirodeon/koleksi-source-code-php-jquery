<?
include("class.backup.php");
switch($op)	{
	default:
		echo "<a href=\"".$GLOBALS['SCRIPT_NAME']."?op=bk\">Make Backup</a>";
	break;
	case "bk":
		###	Start Class			###
		$mkBackup	= new BackUp;
		###	Folder to Backup		###
		$mkBackup->WhatBackup("../AdminTools");
		###	Where to put the gzipped file	###
		$mkBackup->WhereBackup("./backup");
		###	Save as...			###
		$mkBackup->FileName("2004_05_18__TestingBK");
		###	If You want to echo the info	###
		//$mkBackup->Debug();
		###	Run Backup			###
		$mkBackup->Backup();
	break;
}
?>