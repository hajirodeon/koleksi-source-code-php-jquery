<?
#############################################################
#	GiveMeEnergy Projects									#
#	Powered by []==ThoR� aka Kender							#
#															#
#	WebSite Backup Script									#
#															#
#	This program is free software; you can redistribute 	#
#	it and/or modify it under the terms of the 				#
#	GNU General Public License as published by the 			#
#	Free Software Foundation; either version 2 of the 		#
#	License, or (at your option) any later version			#
#############################################################

/*
	VERSION HOSTORY
	vers 0.3.1												
		bugs fixed:											
		- the primary keys are not saved					
		- the type (e.g. myisam) are not saved				
		- duplicated INSERT statement on last one			
		- added AUTO_INCREMENT								
		- added creation date and host in dump comment		
		thanks to Markus Michels							
	vers 0.3												
		Database Backup as 'save as...'						
		or directly to a folder on server					
	vers 0.2												
		added Database Backup								
	vers 0.1												
		1st release											
*/

class BackUp	{

	Function WhatBackup($whatBackup)	{
		if (	(!$whatBackup) || ($whatBackup == "")	)	{
			die("Specify folder to backup");
		}
		$this->whatBackup	= $whatBackup;
	}

	###	Make dir if not exists	###
	Function WhereBackup($whereBackup)	{
		$patharr	= explode("/", $whereBackup);
		$progr		= "";
		foreach($patharr as $k => $v)	{
			$progr		.= $v;
			$oldumask	= umask(0);
			if (!file_exists($progr))	{
				mkdir($progr, 0777);
			}
			umask($oldumask);
			$progr		.= "/";
		}
		$this->WhereBackup	= $whereBackup;
	}

	###	Build FileName	###
	Function FileName($fileName)	{
		$today		= date("Y_m_d__H-i");
		$fileName	= (	(!$fileName) || ($fileName == "")	)	? $today : $fileName;
		$this->fileName	= $fileName;
	}

	###	Database Backup For mySQL	###
	###	This function set the default_filename when page is loaded	###
	###	and set up the Headers										###
	Function DBFileName($filename)	{
		$this->filename	= $filename;
	}
	Function SaveAs($filename)	{
		header("Content-disposition: filename=".$filename."");
		header("Content-type: application/octetstream");
		header("Pragma: no-cache");
		header("Expires: 0");
		$this->dbHeaders	= 1;
	}

	###	Based on script of phpMyAdmin	###
	Function DBMakeBackup($host,$port,$user,$pwd,$dbname)	{
		$crlf	= "\r\n";
		$host	= (!$host)		? "localhost"	: $host;
		$port	= (!$port)		? "3306"		: $port;
		$user	= (!$user)		? "root"		: $user;
		$dbname	= (!$dbname)	? die("No Database specified")		: $dbname;
		$password	= ($pwd == "")	? "NO" : "YES";
		@mysql_pconnect($host.":".$port, $user, $pwd) or die("Can't connect to ".$host.":".$port." (using password: ".$password.") ");
		@mysql_select_db($dbname) or die ("Unable to select database");
		$tables			= mysql_list_tables($dbname);
		$num_tables		= @mysql_numrows($tables);
		$Year		= date("Y");
		$Month		= date("m");
		$Day		= date("d");
		$lang		= $_SERVER['HTTP_ACCEPT_LANGUAGE'];
		$country	= StrToUpper($lang);
		$loc	= array("".$lang."_".$country."@euro","".$lang."_".$country."","".$lang."","".$country."");
		foreach ($loc as $GetRightLocale)	{
			If (setlocale(LC_TIME,$GetRightLocale)) {		//	Found a Valid SetLocale
				break;
			}
		}
		###	Search and Replace \n \r in the INSERT Statement	###
		###	for each records									###
		$search       = array("\x00", "\x0a", "\x0d", "\x1a"); //\x08\\x09, not required
		$replace      = array('\0', '\n', '\r', '\Z');

		$DataCreation	= strftime("%d %B %Y", mktime(0,0,0,$Month,$Day,$Year));
		$Time			= date("H:i:s");
		###	Save to Server	###
		If ($this->dbHeaders == 0)	{
			$content	= "";
			$content	.= $crlf;
		    $content	.= "# --------------------------------------------------------".$crlf."";
		    $content	.= "#".$crlf."";
		    $content	.= "# Dump Script for '".$dbname."' ".$crlf."";
		    $content	.= "#".$crlf."";
			$content	.= "# Host: ".$host."".$crlf."";
			$content	.= "#".$crlf."";
			$content	.= "# created on ".$DataCreation." at ".$Time."".$crlf."";
			$content	.= "#".$crlf."";
		    $content	.= $crlf;
			$content	.= "# --------------------------------------------------------".$crlf."";
			##	Open file for writing	##
			$fp = fopen($this->filename, 'w');
			while($i < $num_tables)	{
				$table	= mysql_tablename($tables, $i);
				$content	.= $crlf;
			    $content	.= "# --------------------------------------------------------".$crlf."";
			    $content	.= "#".$crlf."";
			    $content	.= "# Table Structure for '".$table."' ".$crlf."";
			    $content	.= "#".$crlf."";
			    $content	.= $crlf;
				#################################################
				#	Build Table Structure			#
				#################################################
				/*	Table Structure	*/
				$schema_create = "";
				$schema_create .= "DROP TABLE IF EXISTS ".$table.";".$crlf."";
				$schema_create .= "CREATE TABLE ".$table." (".$crlf."";
				$result			= mysql_db_query($dbname, "SHOW FIELDS FROM ".$table."") or die("error select database");
				while($row = mysql_fetch_array($result))	{
					$schema_create .= "   $row[Field] $row[Type]";
			        $schema_create .= (isset($row["Default"]) && (!empty($row["Default"]) || $row["Default"] == "0"))
									? " DEFAULT `$row[Default]`" : "";
			        $schema_create .= ($row["Null"] != "YES")	? " NOT NULL" : "";
			        $schema_create .= ($row["Extra"] != "")		? " ".$row[Extra]." " : "";
			        $schema_create .= ",$crlf";
				}
				$schema_create		= ereg_replace(",".$crlf."$", "", $schema_create);
				/*	Table Keys	*/
				$result		= mysql_db_query($dbname, "SHOW KEYS FROM ".$table."") or die();
				while($row = mysql_fetch_array($result))	{
					$kname				= $row['Key_name'];
					$kname				= (($kname != "PRIMARY") && ($row['Non_unique'] == 0))	? "UNIQUE|".$kname."" : "PRIMARY";
					$index[$kname]		= (!isset($index[$kname]))	? array() : "";
					$index[$kname][]	= $row['Column_name'];
				}
				//while(list($x, $columns) = @each($index))	{
				foreach($index[$kname] as $x=>$columns[$kname])	{
					$schema_create .= ",$crlf";
			         if($x == "PRIMARY")
						$schema_create .= "   PRIMARY KEY (" . implode($columns, ", ") . ")";
			         elseif (substr($x,0,6) == "UNIQUE")
						$schema_create .= "   UNIQUE ".substr($x,7)." (" . implode($columns, ", ") . ")";
			         else
						$schema_create .= "   KEY ".$x." (" . implode($columns, ", ") . ")";
				}
				#	DataBase Type								#
				$result		= mysql_db_query($dbname, "SHOW TABLE STATUS FROM ".$dbname." LIKE '".$table."' ") or die();
				$row		= mysql_fetch_array($result);
				$schema_create	.= "Type=".$row['Type']." ";
				$schema_create	.= ( 	($row['Auto_increment'] == "NULL")	|| 
										($row['Auto_increment'] == "") 		|| 
										(!$row['Auto_increment']))	
										? "" : " AUTO_INCREMENT=".$row['Auto_increment']." ";
				$schema_create	.= "; ".$crlf."".$crlf."";
				$content	.= $schema_create;
				$schema_create	= "";
				#################################################
				#	Build Table Content (INSERT)		#
				#################################################
				$content	.= "#".$crlf."";
				$content	.= "# Dumping data for table '".$table."'".$crlf."";
				$content	.= "#$crlf";
				$content	.= $crlf;
				$result = mysql_db_query($dbname, "SELECT * FROM $table") or die();
				$a		= 0;
				while($row = mysql_fetch_row($result))	{
					$table_list = "(";
					for($j=0; $j<mysql_num_fields($result);$j++)
						$table_list .= mysql_field_name($result,$j).", ";
						$table_list = substr($table_list,0,-2);
						$table_list .= ")";
					if(isset($GLOBALS["showcolumns"]))
						$schema_insert .= "INSERT INTO ".$table." ".$table_list." VALUES (";
					else
						$schema_insert .= "INSERT INTO ".$table." VALUES (";
					for($j=0; $j<mysql_num_fields($result);$j++)	{
						if(!isset($row[$j]))
							$schema_insert .= " NULL,";
						elseif($row[$j] != "")
							$schema_insert .= " `".Str_Replace($search,$replace,addslashes($row[$j]))."`,";
						else
							$schema_insert .= " ``,";
					}
					$schema_insert = ereg_replace(",$", "", $schema_insert);
					$schema_insert .= ")".$crlf."";
					//$handler(trim($schema_insert));
					$a++;
				}
				$content	.= $schema_insert."".$crlf."";
				$schema_insert	= "";
				$i++;
			}
			##	Write to file	##
			fwrite($fp, $content);
			fclose($fp);
		} else {
		###	Save As			###
			print $crlf;
		    print "# --------------------------------------------------------".$crlf."";
		    print "#".$crlf."";
		    print "# Dump Script for '".$dbname."' ".$crlf."";
		    print "#".$crlf."";
			print "# Host: ".$host."".$crlf."";
			print "#".$crlf."";
			print "# created on ".$DataCreation." at ".$Time."".$crlf."";
			print "#".$crlf."";
		    print $crlf;
			print "# --------------------------------------------------------".$crlf."";
			$schema_insert	= "";
			$table			= "";
			$schema_create	= "";
			while($i < $num_tables)	{
			    print $crlf;
				$table	= mysql_tablename($tables, $i);
				print $crlf;
			    print "# --------------------------------------------------------".$crlf."";
			    print "#".$crlf."";
			    print "# Table Structure for '".$table."' ".$crlf."";
			    print "#".$crlf."";
			    print $crlf;
				#################################################
				#	Build Table Structure			#
				#################################################
				/*	Table Structure	*/
				$schema_create .= "DROP TABLE IF EXISTS ".$table.";".$crlf."";
				$schema_create .= "CREATE TABLE ".$table." (".$crlf."";
				$result			= mysql_db_query($dbname, "SHOW FIELDS FROM ".$table."") or die("error select database");
				while($row = mysql_fetch_array($result))	{
					$schema_create .= "   $row[Field] $row[Type]";
			        $schema_create .= (isset($row["Default"]) && (!empty($row["Default"]) || $row["Default"] == "0"))
									? " DEFAULT `".$row['Default']."`" : "";
			        $schema_create .= ($row["Null"] != "YES")	? " NOT NULL" : "";
			        $schema_create .= ($row["Extra"] != "")		? " ".$row[Extra]." " : "";
			        $schema_create .= ",$crlf";
				}
				$schema_create		= ereg_replace(",".$crlf."$", "", $schema_create);
				/*	Table Keys	*/
				$result		= mysql_db_query($dbname, "SHOW KEYS FROM ".$table."") or die();
				while($row = mysql_fetch_array($result))	{
					$kname				= $row['Key_name'];
					$kname				= (($kname != "PRIMARY") && ($row['Non_unique'] == 0))	? "UNIQUE|".$kname."" : "";
					$index[$kname]		= (!isset($index[$kname]))	? array() : "";
					$index[$kname][]	= $row['Column_name'];
				}
				//while(list($x, $columns) = @each($index))	{
				foreach($index[$kname] as $x=>$columns[$kname])	{
					$schema_create .= ",$crlf";
			         if($x == "PRIMARY")
						$schema_create .= "   PRIMARY KEY (" . implode($columns, ", ") . ")";
			         elseif (substr($x,0,6) == "UNIQUE")
						$schema_create .= "   UNIQUE ".substr($x,7)." (" . implode($columns, ", ") . ")";
			         else
						$schema_create .= "   KEY ".$x." (" . implode($columns, ", ") . ")";
				}
				$schema_create .= "".$crlf.") ";

				#	DataBase Type								#
				$result		= mysql_db_query($dbname, "SHOW TABLE STATUS FROM ".$dbname." LIKE '".$table."' ") or die();
				$row		= mysql_fetch_array($result);
				$schema_create	.= "Type=".$row['Type']." ";
				$schema_create	.= ( 	($row['Auto_increment'] == "NULL")	|| 
										($row['Auto_increment'] == "") 		|| 
										(!$row['Auto_increment']))	
										? "" : " AUTO_INCREMENT=".$row['Auto_increment']." ";
				$schema_create	.= "; ".$crlf."".$crlf."";
				print $schema_create;
				$schema_create	= "";
				#################################################
				#	Build Table Content (INSERT)				#
				#################################################
				print "#".$crlf."";
				print "# Dumping data for table '".$table."'".$crlf."";
				print "#$crlf";
				print $crlf;
				$result = mysql_db_query($dbname, "SELECT * FROM $table") or die();
				$a		= 0;
				while($row = mysql_fetch_row($result))	{
					$table_list = "(";
					for($j=0; $j<mysql_num_fields($result);$j++)
						$table_list .= mysql_field_name($result,$j).", ";
						$table_list = substr($table_list,0,-2);
						$table_list .= ")";
					if(isset($GLOBALS["showcolumns"]))
						$schema_insert .= "INSERT INTO ".$table." ".$table_list." VALUES (";
					else
						$schema_insert .= "INSERT INTO ".$table." VALUES (";
					for($j=0; $j<mysql_num_fields($result);$j++)	{
						if(!isset($row[$j]))
							$schema_insert .= " NULL,";
						elseif($row[$j] != "")
							$schema_insert .= " `".Str_Replace($search,$replace,addslashes($row[$j]))."`,";
						else
							$schema_insert .= " ``,";
					}
					$schema_insert = ereg_replace(",$", "", $schema_insert);
					$schema_insert .= ")".$crlf."";
					//$handler(trim($schema_insert));
					$a++;
				}
				print $schema_insert."".$crlf."";
				$schema_insert	= "";
				$i++;
			}		##	=>	End while
		}			##	=>	End If save as..
	}

	Function Debug()	{
		$this->msg	= "<br>";
		$this->msg	.= "WhatBackup: ".$this->whatBackup."<br>";
		$this->msg	.= "WhereBackup: ".$this->WhereBackup."<br>";
		$this->msg	.= "FileName: ".$this->fileName.".tar.gz<br>";
	}
	###	Do It	###
	Function Backup()	{
		$theScript	= $GLOBALS['SCRIPT_NAME'];
		$today		= date("Y_m_d__H-i");
		$comm 		= "tar cfvz ".$this->WhereBackup."/".$this->fileName.".tar.gz ".$this->whatBackup."";
		###	If u want All output, use passthru() function	###
		$run		= exec($comm);
		$msg		= ($run != "") ? "Backup OK" : "Backup KO";
		echo "".$this->msg."";
	}

}
?>