CodeThatTab JavaScript
Copyright (c) 2003-05 CodeThat.Com
===============================

CodeThatTab is an advanced JavaScript tab control (page control) that fully mimics 
look and the functionality of the tab control found in Windows GUI specifications 
and serves the same purpose. Use CodeThatTab to create a multiple page form within 
the same window. CodeThatTab displays multiple overlapping pages that hold various 
content. The user selects a page by clicking the page's tab that appears at the top 
of the control (or in the other configured position). 


To find out more about the product please visit the following pages:

CodeThat.Com site:
http://www.codethat.com/

CodeThatTab (Standard/PRO):
http://www.codethat.com/tab/

Standard vs PRO:
http://www.codethat.com/standard_vs_pro.html

===============================
CodeThatTab JavaScript
Copyright (c) 2003-05 CodeThat.Com
