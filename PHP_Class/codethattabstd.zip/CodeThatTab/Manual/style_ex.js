var tabDef = {
	"x" : 10, "y" : 10,
	"width" : 440, "height" : 150,
	"offset" : 3,
	"spacing" : 5,
	"padding" : 8,
	"layout" : 'top',
	"cssover" : "over",
	"css": "curr1",
	"csshint" : "curr1",
	"csscurr":"curr2",
	
	"tabs" : [
	{
		"text" : "CodeThat.com",
		"hint" : "is the ultimate source of the high-quality, cutting-edge web technologies. In particular, we offer a JavaScript menu, a JavaScript tree, and other scripts, which can be easily integrated into almost any site providing visitors with a fast, high-quality navigation system. We offer freeware and commercial versions of our scripts so that anybody from students to big corporations can benefit from using our first-class solutions.",
		"csscurr" : "curr0",
		"css" : "curr0"
	},
	{
		"text" : "What's New",
		"hint" : "<li>Now you have a possibility to export only that rows where data was changed <li>You can use user-defined functions for auto-filled columns creation <li>You can perform search in grid right from url <li>You can hide cells with rows/columns names ",
		"csscurr" : "curr1",
		"css" : "curr1"
	},
	{
		"text" : "What's Hot",
		"hint" : ' Visit our <a href="http://www.codethat.com">Hot</a> section for a list of CodeThat.Com scripts that are popular to the visitors.',
		"csscurr" : 'curr2',
		"css" : 'curr2'
	},
	{
		"text" : "Search",
		"hint" : '<form action="http://www.google.com/search" method="get" onSubmit="this.q.value=\'site:www.codethat.com \'+this.qfront.value"><p>Search CodeThat.Com:<br /><input name="q" type="hidden" /><input name="qfront" type=""text"" style="width: 180px" /> <input type="submit" value="Search" /></form>',
		"csscurr" : 'curr3',
		"css" : 'curr3'
	} ]
};