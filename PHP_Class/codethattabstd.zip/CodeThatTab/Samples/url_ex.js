var l = window.location.href;
if (l.indexOf("?") > -1) l = l.slice(0, l.indexOf("?"));
  
var tabDef = {
x : 10,
y : 30,
width : 450,
height : 100,
offset : 4,
spacing : 5,    
 css : 'def',
 cssover: 'over', 	
 csscurr:'curr0',  	 
 border:{width:1, color:'#000000'},
 urlParam:"p", 

tabs:[
{
text:"CodeThat",
hint:"<p>Visit CodeThat for free, award winning DHTML scripts for your site:<br />",
action: {url:l + '?t=0&p=0&n=0'},
csscurr:'curr0'
},

{
text:"What's New",
hint:'<p>Visit our <a href="http://www.codethat.com/new.htm">What\'s New</a> section to see recently added scripts to our archive.',
action:{url: l + "?n=2&p=1"},
csscurr:'curr1'
},

{
text:"What's Hot",
hint:' <p>Visit our <a href="http://www.codethat.com/hot.htm">Hot</a> section for a list of DD scripts that are popular to the visitors.',
action:{url: l + "?p=2"},
csscurr:'curr2'
},

{
text:"Search",
hint:'<form action="http://www.google.com/search" method="get" onSubmit="this.q.value=\'site:www.codethat.com \'+this.qfront.value"><p>Search CodeThat:<br /><input name="q" type="hidden" /><input name="qfront" type="text" style="width: 180px" /> <input type="submit" value="Search" /></form>',
action:{url: l + "?p=3"},
csscurr:'curr3'
}

]
};