var tabDef = {
	x : 10,
	y : 50,
	width : 510,
	height : 100,
	offset : 3,
	spacing : 5,
	padding : 5,
	layout : 'top',
	border : {
		width : 1, color : '#000000'
	},
	cssover : 'over',
	css : 'def',
	tabs : [
	{
		text : "URL",
		hint : "This tab demonstrate action with URL property defined. You will visit CodeThat.com when click on this tab",
		csscurr : 'curr0',
		css : 'curr0',
		action : {
			url : "http://lion/", target : "_blank"
		}
	},
	{
		text : "JS",
		hint : 'This tab demonstrate action with JS property defined',
		csscurr : 'curr1',
		css : 'curr1',
		action : {
			js : "alert('You click on me '+ new Date())"
		}
	},
	{
		text : "JSOVER",
		hint : 'This tab demonstrate action with JSOVER property defined.',
		csscurr : 'curr2',
		css : 'curr2',
		action : {
			jsover : "alert('Your mouse over me at ' + new Date())"
		}
	},
	{
		text : "JSOUT",
		hint : 'This tab demonstrate action with JSOUT property defined.',
		csscurr : 'curr3',
		css : 'curr3',
		action : {
			jsout : "alert('Your mouse out me at ' + new Date())"
		}
	} ]
};