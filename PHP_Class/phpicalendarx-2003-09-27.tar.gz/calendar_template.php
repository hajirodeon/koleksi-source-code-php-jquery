<!-- BEGIN Calendar_Month_Type -->
<link href="{C_STYLESHEET_C}" rel="stylesheet" type="text/css">
<table border="0" cellpadding="0" cellspacing="0" class="{C_CSS_CALENDAR_BOX_C}" width="{C_CAL_WIDTH_C}" height="{C_CAL_HEIGHT_C}">
  <tr>
    <td class="{C_CSS_CALENDAR_BACK_C}">
      <table width="100%" border="0" cellpadding="0" cellspacing="1" class="{C_CSS_CALENDAR_YEAR_BOX_C}">
        <tr align="center" height="{C_CAL_ROW_HEIGHT_C}">
          <td width="20%" class="{C_CSS_CALENDAR_YEAR_PREVIOUS_BUTTON_C}">{C_YEAR_PREV_C}</td>
          <td width="60%" class="{C_CSS_CALEDNDE_YEAR_TEXT_C}">{C_YEAR_C}</td>
          <td width="20%" class="{C_CSS_CALENDAR_YEAR_NEXT_BUTTON_C}">{C_YEAR_NEXT_C}</td>
        </tr>
      </table>
      <table width="100%" border="0" cellpadding="0" cellspacing="1" class="{C_CSS_CALENDAR_MONTH_BOX_C}">
        <tr align="center" height="{C_CAL_ROW_HEIGHT_C}">
          <td width="20%" class="{C_CSS_CALENDAR_MONTH_PREVIOUS_BUTTON_C}">{C_MONTH_PREV_C}</td>
          <td width="60%" class="{C_CSS_CALENDAR_MONTH_TEXT_C}">{C_MONTH_C}</td>
          <td width="20%" class="{C_CSS_CALENDAR_MONTH_NEXT_BUTTON_C}">{C_MONTH_NEXT_C}</td>
        </tr>
      </table>
      <table width="100%" border="0" cellpadding="0" cellspacing="1" class="{C_CSS_CALENDAR_DAYS_OF_WEEK_BOX_C}">
        <tr align="center" valign="middle" height="{C_CAL_ROW_HEIGHT_C}">
          <td class="{C_CSS_WEEK_NO_C}" width="16%">W</td>
          <td class="{C_CSS_DAYS_OF_WEEK_START_C}" width="12%">S</td>
          <td class="{C_CSS_DAYS_OF_WEEK_REST_C}" width="12%">M</td>
          <td class="{C_CSS_DAYS_OF_WEEK_REST_C}" width="12%">T</td>
          <td class="{C_CSS_DAYS_OF_WEEK_REST_C}" width="12%">W</td>
          <td class="{C_CSS_DAYS_OF_WEEK_REST_C}" width="12%">T</td>
          <td class="{C_CSS_DAYS_OF_WEEK_REST_C}" width="12%">F</td>
          <td class="{C_CSS_DAYS_OF_WEEK_REST_C}" width="12%">S</td>
        </tr>
        <tr align="center" valign="middle" height="{C_CAL_ROW_HEIGHT_C}">
          <td class="{C_CSS_WEEK_NO_X_C}">{C_WEEK_NO_1_C}</td>
          <td class="{C_CSS_DAY_MATRIX_1X1_C}">{C_DAY_MATRIX_1X1_C}</td>
          <td class="{C_CSS_DAY_MATRIX_1X2_C}">{C_DAY_MATRIX_1X2_C}</td>
          <td class="{C_CSS_DAY_MATRIX_1X3_C}">{C_DAY_MATRIX_1X3_C}</td>
          <td class="{C_CSS_DAY_MATRIX_1X4_C}">{C_DAY_MATRIX_1X4_C}</td>
          <td class="{C_CSS_DAY_MATRIX_1X5_C}">{C_DAY_MATRIX_1X5_C}</td>
          <td class="{C_CSS_DAY_MATRIX_1X6_C}">{C_DAY_MATRIX_1X6_C}</td>
          <td class="{C_CSS_DAY_MATRIX_1X7_C}">{C_DAY_MATRIX_1X7_C}</td>
        </tr>
        <tr align="center" valign="middle" height="{C_CAL_ROW_HEIGHT_C}">
          <td class="{C_CSS_WEEK_NO_X_C}">{C_WEEK_NO_2_C}</td>
          <td class="{C_CSS_DAY_MATRIX_2X1_C}">{C_DAY_MATRIX_2X1_C}</td>
          <td class="{C_CSS_DAY_MATRIX_2X2_C}">{C_DAY_MATRIX_2X2_C}</td>
          <td class="{C_CSS_DAY_MATRIX_2X3_C}">{C_DAY_MATRIX_2X3_C}</td>
          <td class="{C_CSS_DAY_MATRIX_2X4_C}">{C_DAY_MATRIX_2X4_C}</td>
          <td class="{C_CSS_DAY_MATRIX_2X5_C}">{C_DAY_MATRIX_2X5_C}</td>
          <td class="{C_CSS_DAY_MATRIX_2X6_C}">{C_DAY_MATRIX_2X6_C}</td>
          <td class="{C_CSS_DAY_MATRIX_2X7_C}">{C_DAY_MATRIX_2X7_C}</td>
        </tr>
        <tr align="center" valign="middle" height="{C_CAL_ROW_HEIGHT_C}">
          <td class="{C_CSS_WEEK_NO_X_C}">{C_WEEK_NO_3_C}</td>
          <td class="{C_CSS_DAY_MATRIX_3X1_C}">{C_DAY_MATRIX_3X1_C}</td>
          <td class="{C_CSS_DAY_MATRIX_3X2_C}">{C_DAY_MATRIX_3X2_C}</td>
          <td class="{C_CSS_DAY_MATRIX_3X3_C}">{C_DAY_MATRIX_3X3_C}</td>
          <td class="{C_CSS_DAY_MATRIX_3X4_C}">{C_DAY_MATRIX_3X4_C}</td>
          <td class="{C_CSS_DAY_MATRIX_3X5_C}">{C_DAY_MATRIX_3X5_C}</td>
          <td class="{C_CSS_DAY_MATRIX_3X6_C}">{C_DAY_MATRIX_3X6_C}</td>
          <td class="{C_CSS_DAY_MATRIX_3X7_C}">{C_DAY_MATRIX_3X7_C}</td>
        </tr>
        <tr align="center" valign="middle" height="{C_CAL_ROW_HEIGHT_C}">
          <td class="{C_CSS_WEEK_NO_X_C}">{C_WEEK_NO_4_C}</td>
          <td class="{C_CSS_DAY_MATRIX_4X1_C}">{C_DAY_MATRIX_4X1_C}</td>
          <td class="{C_CSS_DAY_MATRIX_4X2_C}">{C_DAY_MATRIX_4X2_C}</td>
          <td class="{C_CSS_DAY_MATRIX_4X3_C}">{C_DAY_MATRIX_4X3_C}</td>
          <td class="{C_CSS_DAY_MATRIX_4X4_C}">{C_DAY_MATRIX_4X4_C}</td>
          <td class="{C_CSS_DAY_MATRIX_4X5_C}">{C_DAY_MATRIX_4X5_C}</td>
          <td class="{C_CSS_DAY_MATRIX_4X6_C}">{C_DAY_MATRIX_4X6_C}</td>
          <td class="{C_CSS_DAY_MATRIX_4X7_C}">{C_DAY_MATRIX_4X7_C}</td>
        </tr>
        <tr align="center" valign="middle" height="{C_CAL_ROW_HEIGHT_C}">
          <td class="{C_CSS_WEEK_NO_X_C}">{C_WEEK_NO_5_C}</td>
          <td class="{C_CSS_DAY_MATRIX_5X1_C}">{C_DAY_MATRIX_5X1_C}</td>
          <td class="{C_CSS_DAY_MATRIX_5X2_C}">{C_DAY_MATRIX_5X2_C}</td>
          <td class="{C_CSS_DAY_MATRIX_5X3_C}">{C_DAY_MATRIX_5X3_C}</td>
          <td class="{C_CSS_DAY_MATRIX_5X4_C}">{C_DAY_MATRIX_5X4_C}</td>
          <td class="{C_CSS_DAY_MATRIX_5X5_C}">{C_DAY_MATRIX_5X5_C}</td>
          <td class="{C_CSS_DAY_MATRIX_5X6_C}">{C_DAY_MATRIX_5X6_C}</td>
          <td class="{C_CSS_DAY_MATRIX_5X7_C}">{C_DAY_MATRIX_5X7_C}</td>
        </tr>
        <tr align="center" valign="middle" height="{C_CAL_ROW_HEIGHT_C}">
          <td class="{C_CSS_WEEK_NO_X_C}">{C_WEEK_NO_6_C}</td>
          <td class="{C_CSS_DAY_MATRIX_6X1_C}">{C_DAY_MATRIX_6X1_C}</td>
          <td class="{C_CSS_DAY_MATRIX_6X2_C}">{C_DAY_MATRIX_6X2_C}</td>
          <td class="{C_CSS_DAY_MATRIX_6X3_C}">{C_DAY_MATRIX_6X3_C}</td>
          <td class="{C_CSS_DAY_MATRIX_6X4_C}">{C_DAY_MATRIX_6X4_C}</td>
          <td class="{C_CSS_DAY_MATRIX_6X5_C}">{C_DAY_MATRIX_6X5_C}</td>
          <td class="{C_CSS_DAY_MATRIX_6X6_C}">{C_DAY_MATRIX_6X6_C}</td>
          <td class="{C_CSS_DAY_MATRIX_6X7_C}">{C_DAY_MATRIX_6X7_C}</td>
        </tr>
      </table>
	  <!-- START This feature was added to PhpICalenderX by Mr.MatMr.Matthew Waygood ( mwwaygoo@hotmail.com ) -->
      <table width="100%" border="0" cellpadding="0" cellspacing="1" class="{C_CSS_CALENDAR_YEAR_BOX_C}">
        <tr align="center" height="{C_CAL_ROW_HEIGHT_C}">
          <td width="100%" class="{C_CSS_CALENDAR_TODAY_BUTTON_C}">{C_TODAY_C}</td>
        </tr>
      </table>
	  <!-- END This feature was added to PhpICalenderX by Mr.Matthew Waygood ( mwwaygoo@hotmail.com ) -->
    </td>
  </tr>
</table>
<!-- END Calendar_Month_Type -->
