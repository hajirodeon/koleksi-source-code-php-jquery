<?php
/*
	Php ICalenderX version 3.4 
	By Imthiaz Rafiq(hmimthiaz@vsnl.net)
	Credits : Version.txt
	LICENSE : LGPL (License.txt)
	Last Updated : 27-Sep-2003

	Contibutors List
	----------------
	1. Mr.Matthew Waygood (mwwaygoo@hotmail.com)
	2. Mr.Dirk Olten (mail@extrabyte.de)
	3. Mr.Hans Bezemer (hansoft@xs4all.nl)
	4. Mr.Andrei Verovski (aka MacGuru)(andrei_verovski@osxfaq.com)
	5. Mr.Mariano Iglesias (mariano@cricava.com)
	6. Mr.Tjagi (tjagi@tomekjar.xo.pl)
	----------------------------------------------------------------------
	!Any Ideas You Feel About The Same Please Write To Me. I Will Make It!
	----------------------------------------------------------------------
*/

	/* This Function added by Mr.Mariano Iglesias (mariano@cricava.com) */
	$linkForCalendar = $PHP_SCRIPT;
	$addedParameter = false;
	if (IsSet($_GET) && count($_GET) > 0) {
		foreach($_GET as $parameter=>$value) {
			if (strcasecmp($parameter, "show_date") != 0) {
				if ($addedParameter == false) {
					$linkForCalendar .= "?";
					$addedParameter = true;
				} else {
					$linkForCalendar .= "&";
				}
				$linkForCalendar .= $parameter . "=" . urlencode($value);
			}
		}
	 }
	 
	 include "class.calendar.inc.php";
 
	 $my_cal = new calendar(date("d-m-Y"),'calendar_template.php','calendar_stylesheet_black.css','black');
	 $my_cal->set_calendar_link_to_add($linkForCalendar);
	 $my_cal->set_calendar_link_concat_string(($addedParameter == false ? '?' : '&'));
	 $my_cal->set_calendar_link_variable_prefix('show');
	 $my_cal->set_calendar_total_height(175);
	 $my_cal->set_calendar_total_width(175);
	 $my_cal->set_calendar_hour_difference(-12);
 	 /* $_GET By Mr. Matthew Waygood
	 Email Id : matthew@waygoodstuff.co.uk */
	 if (isset($_GET['show_date'])){
		$my_cal->set_calendar_show_date($_GET['show_date']);
	 }
?>
<html>
 <head>
  <title>PhpICalanderX Example</title>
 </head>
<body bgcolor="#006666" text="#999900" link="#FFFFFF" vlink="#FFFFFF" alink="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr align="center" valign="middle">
  <td align="center"><font face="verdana" size="5">Showing Skin Color Black</font></td>
  </tr>
  <tr align="center" valign="middle">
    <td width="33%">
      <?php
		  print '<font face="verdana" size="-1">Calendar Language : English</font>';
		  $my_cal->set_calendar_total_height(200);
		  $my_cal->set_calendar_total_width(250);
		  $my_cal->showmonth();
	 ?>
    </td>
    <td width="33%">
      <?php
		  print '<font face="verdana" size="-1">Calendar Language : German</font>';
		  $my_cal->set_calendar_language('ger');
		  $my_cal->set_calendar_total_height(200);
		  $my_cal->set_calendar_total_width(250);
		  $my_cal->set_calendar_hour_difference(0);
		  $my_cal->showmonth();
	 ?>
    </td>
    <td width="33%">
      <?php
		  print '<font face="verdana" size="-1">Calendar Language : Dutch</font>';
		  $my_cal->set_calendar_language('dut');
		  $my_cal->set_calendar_total_height(200);
		  $my_cal->set_calendar_total_width(250);
		  $my_cal->showmonth();
	 ?>
    </td>
  </tr>
  <tr align="center" valign="middle">
  <td align="center"><font face="verdana" size="5">Showing Skin Color Warm</font></td>
  </tr>
  <tr align="center" valign="middle">
   <td width="33%">
	<?php
		print '<font face="verdana" size="-1">Calendar Language : Espanol</font>';
		$my_cal->set_calendar_stylesheet('calendar_stylesheet_warm.css');
		$my_cal->set_calendar_stylesheet_prefix('warm');
		$my_cal->set_calendar_language('esp');
		$my_cal->set_calendar_total_height(200);
		$my_cal->set_calendar_total_width(250);
		$my_cal->set_calendar_hour_difference(12);
		$my_cal->showmonth();
	?>
   </td>
   <td width="33%">
	<?php
		print '<font face="verdana" size="-1">Calendar Language : Polish</font>';
		$my_cal->set_calendar_stylesheet('calendar_stylesheet_warm.css');
		$my_cal->set_calendar_stylesheet_prefix('warm');
		$my_cal->set_calendar_language('pl');
		$my_cal->set_calendar_total_height(200);
		$my_cal->set_calendar_total_width(250);
		$my_cal->set_calendar_hour_difference(12.35);
		$my_cal->showmonth();
	?>
   </td>
   <td width="33%">&nbsp;</td>
  </tr>
</table>
</body>
</html>