<?php

require("Calc.php");

$month = Date_Calc::getCalendarMonth("3","2002");

print_r($month);

?>
