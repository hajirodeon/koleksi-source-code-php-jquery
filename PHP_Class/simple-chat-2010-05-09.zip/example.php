<html>
<head>
</head>
<body>
<?php	
require_once "class.Chat.php"; 
$chat = new Chat();
$chat->createChat("");
?>
</body>
</html>
