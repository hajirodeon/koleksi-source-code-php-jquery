<?php

require_once("composer.class.php");


$song = "Hatem Ben Yacoub - I PHP the music :d=16,o=5,b=110:d,p,c6,b,c6,32a,32a#,32a,32a#,p,32a,32a#,32a,32a#,g,p,32g,32a,8g,p,f,8g,8a,32a,32a#,32a,32a#,8g,32g,32a,32g,32a,g,f,e,4f,e,f,g,p,32g,32a,32g,32a,f,p,32f,32g,32f,32g,e,p,32e,32f,32e,32f,d,p,d,p,f,e,f,g,e,f,32e,32f,32e,32f,d,p,4d,p";

$c = new composer;
$c->Setsong($song);
$c-> scale_notes($song);
//print_r( $c->s);
//print_r( $c->parse_rttl());
//exit;
$c->gen_partition();

?>