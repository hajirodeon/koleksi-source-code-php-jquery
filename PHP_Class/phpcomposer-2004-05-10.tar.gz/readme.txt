PHP Composer
Author : Ben Yacoub Hatem


README
This class is meant to convert RTTL music notes to an image formatted partition.
PHP Composer is an experimental interface and your feedback will be all welcomed.

REQUIRE
PHP 4 or PHP 5 + GD installed with ttf support


INSTALL
Chmod utils/ folder to 0777. The first execution of the script will generate the PHP Composer logo and a TTF font 


TODO
1 - Adjust page-setting
2 - Fix the write_note() function to support complex notes
3 - Add multiple pages support


AUTHOR
Ben Yacoub Hatem <hatem at php dot net>