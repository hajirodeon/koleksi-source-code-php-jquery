<?php

require_once("utils/utils.class.php");

/**
 * composer class : Generate music partition from RTTL
 * 
 * @package 
 * @author Ben Yacoub Hatem <hatem@php.net>
 * @copyright Copyright (c) 2004
 * @version $Id$ - 22/02/2004 11:56:11 - composer.class.php
 * @access public
 **/
class composer{
	/**
     * Constructor
     * @access protected
     */
	function composer(){
		
	}
	
	/**
	 * 
	 * @access private
	 * @var string
	 **/
    var $_song = '';
	
	/**
	 * 
	 * @access public
	 * @return string 
	 **/
    function Getsong(){
		return $this->_song;
	}
	
	/**
	 * 
	 * @access public
	 * @return void
	 **/
	function Setsong($newValue){
		$this->_song = $this->clean_rttl($newValue);
	}

	/**
	 * composer::clean_rttl()	Function to clean rttl lowercase and beautifier spaces
	 * 
	 * @param string $_rttl
	 * @return 
	 **/
	function clean_rttl($_rttl = "")
	{
		$tones = eregi_replace("\n","" , $_rttl);
		$tones = eregi_replace("\r","" , $tones);
		$tones = eregi_replace("�","" , $tones);
		$tones = strtolower($tones);
		$clean_rttl = implode(", ", explode(",", $tones));
		return $clean_rttl;
	}
	
	/**
	 * composer::parse_rttl()	Parse RTTL data
	 * 
	 * @return 
	 **/
	function parse_rttl(){
		$_rttl = $this->Getsong();
		$_pieces = explode(":", $_rttl);

		$t = $_pieces[0];
		if (ereg("-",$t)) {
		    $t1 = explode("-",$t );
			$_title = $t1[1];
			$_author = $t1[0];
		} else {
			$_title	= $t;
		}
		
		$_spec  = $_pieces[1];
		$_spec = explode(",", $_spec);
		$_duration = $_spec[0];
		$_duration = str_replace("d=","" ,$_duration );
		$_scale = $_spec[1];
		$_scale = str_replace("o=","" ,$_scale );
		$_bpm = $_spec[2];
		$_bpm = str_replace("b=", "", $_bpm);
		
		$_notes = $_pieces[2];
		
		$_rttl_parsed = array("title"    => $_title,
							  "author"	 => $_author,
							  "duration" => $_duration,
							  "scale"    => $_scale,
							  "bpm"		 => $_bpm,
							  "notes"	 => $_notes
							  );
		return $_rttl_parsed;
	}
	
	/**
	 * composer::scale_notes()		Function to parse and convert a note
	 * 
	 * @param string $notes
	 * @return 
	 **/
	function scale_notes($notes = ""){
		$nt = explode(",",$notes );
		$temps_array = array(1,4,8,16,32,64);
		
		$i = 0; $j = 1; $k = 1; $t = 0;
		foreach($nt as $v){

		
			if( ereg ( "([0-9]+)" , $v, $numbers )) { 
				$temps = $numbers[0];
				if (!in_array($temps,$temps_array )) {
					$scale = $temps;
				    $temps = 1;
				} else unset($scale);
			} else {
				$temps = 1;
			}
			if( ereg ( "([a-g]+)" , $v, $note )) { 
				$note = $note[0];
			} else {
				$note = "p";
			}
			
			if( ereg ( "(#+)" , $v )) { 
				$diese = "#";
			} else unset($diese);
			$this->s[$j] .= $this->write_note($note,$diese,$temps,$scale);
			
			$t+= 1/$temps;
			if ($t >= 2) {
			    $this->s[$j] .= "!";
				$i = 0; $k++; $t = 0;
			}
			$i++;
			
			if ($k == 4) {
   				$j++; $k = 1;
			}
		}

		// Clean song
		$G = 0;
		foreach($this->s as $v){
			$G = (strlen($v)>$G)?strlen($v):$G;
		}
		foreach($this->s as $k=>$v){
			if (strlen($v)<$G) {
			    $d = $G-strlen($v);
				do {
					$l = explode("!", $v);
					foreach($l as $k=>$v){
						$l[$k] .= "=";
						$d--;
						if ($d==0) {
						    break;
						}
					}
					$v = implode('!',$l);
				} while($d!=0);
				
				for($i = 1; $i <= $d; $i++){
					$this->s[$k].= "=";
				} // for
			}
		}
		foreach($this->s as $k1=>$v1 ){
			if (!ereg("'&",$v1)) {
			    $this->s[$k1] = "'&0".$v1;
			}
		}
	}
	
	
	/**
	 * composer::write_note()	Write note in PHP Composer format
	 * 
	 * @param $note
	 * @param $diese
	 * @param $temps
	 * @param $scale
	 * @return 
	 **/
	function write_note($note,$diese,$temps,$scale){
		if ($diese == "#") {
		    $v = $note.$diese;
		} else $v = $note;
		
		switch($v) {
			case "c"	:   // Do
				switch($temps){
					case 1:
						$r = "r";
					break;
					
					case 4:
						$r = "b";
					break;
					
					case 8;
						$r = "R";
					break;
					
					case 16:
					break;
					
					case 32:
						$r = "B";
					break;
					
					case 64:
					break;
				} // switch
			break;
			
			
			case "c#"	:		// Do diese
				switch($temps){
					case 1:
						$r = "�r";
					break;
					
					case 4:
						$r = "�b";
					break;
					
					case 8;
						$r = "�R";
					break;
					
					case 16:
					break;
					
					case 32:
						$r = "�B";
					break;
					
					case 64:
					break;
				} // switch
			break;
			
			case "d"	:  	// Re
				switch($temps){
					case 1:
						$r = "s";
					break;
					
					case 4:
						$r = "c";
					break;
					
					case 8;
						$r = "S";
					break;
					
					case 16:
					break;
					
					case 32:
						$r = "C";
					break;
					
					case 64:
					break;
				} // switch
			break;	
			case "d#"	:	// Mi Bemol
				switch($temps){
					case 1:
						$r = "�t";
					break;
					
					case 4:
						$r = "�d";
					break;
					
					case 8;
						$r = "�T";
					break;
					
					case 16:
					break;
					
					case 32:
						$r = "�D";
					break;
					
					case 64:
					break;
				} // switch
			break;	
			
			case "e"	:		// Mi
				switch($temps){
					case 1:
						$r = "t";
					break;
					
					case 4:
						$r = "d";
					break;
					
					case 8;
						$r = "T";
					break;
					
					case 16:
					break;
					
					case 32:
						$r = "D";
					break;
					
					case 64:
					break;
				} // switch
			break;
			case "f"	:		// Fa
				switch($temps){
					case 1:
						$r = "u";
					break;
					
					case 4:
						$r = "e";
					break;
					
					case 8;
						$r = "U";
					break;
					
					case 16:
					break;
					
					case 32:
						$r = "E";
					break;
					
					case 64:
					break;
				} // switch
			break;
			case "f#"	:		// Fa diese
				switch($temps){
					case 1:
						$r = "�u";
					break;
					
					case 4:
						$r = "�e";
					break;
					
					case 8;
						$r = "�U";
					break;
					
					case 16:
					break;
					
					case 32:
						$r = "�E";
					break;
					
					case 64:
					break;
				} // switch
			break;
			
			case "g"	:		// Sol
				switch($temps){
					case 1:
						$r = "v";
					break;
					
					case 4:
						$r = "f";
					break;
					
					case 8;
						$r = "V";
					break;
					
					case 16:
					break;
					
					case 32:
						$r = "F";
					break;
					
					case 64:
					break;
				} // switch
			break;
			
			case "g#"	:		// La bemol
				switch($temps){
					case 1:
						$r = "�w";
					break;
					
					case 4:
						$r = "�g";
					break;
					
					case 8;
						$r = "�W";
					break;
					
					case 16:
					break;
					
					case 32:
						$r = "�G";
					break;
					
					case 64:
					break;
				} // switch
			break;
			
			case "a"	:		// La
				switch($temps){
					case 1:
						$r = "w";
					break;
					
					case 4:
						$r = "g";
					break;
					
					case 8;
						$r = "W";
					break;
					
					case 16:
					break;
					
					case 32:
						$r = "G";
					break;
					
					case 64:
					break;
				} // switch
			break;
			
			case "a#"	:		// Si bemol
				switch($temps){
					case 1:
						$r = "�x";
					break;
					
					case 4:
						$r = "�h";
					break;
					
					case 8;
						$r = "�X";
					break;
					
					case 16:
					break;
					
					case 32:
						$r = "�H";
					break;
					
					case 64:
					break;
				} // switch
			break;
			
			case "b"	:		// Si
				switch($temps){
					case 1:
						$r = "x";
					break;
					
					case 4:
						$r = "h";
					break;
					
					case 8;
						$r = "X";
					break;
					
					case 16:
					break;
					
					case 32:
						$r = "H";
					break;
					
					case 64:
					break;
				} // switch
			break;
			
			case "p"	:		//pause
				switch($temps){
					case 1:
						$r = "<";
					break;
					
					case 4:
						$r = ";";
					break;
					
					case 8;
						$r = ":";
					break;
					
					case 16:
						$r = "9";
					break;
					
					case 32:
						$r = "8";
					break;
					
					case 64:
					break;
				} // switch
			break;
		}
		return "=".$r;
	}

	
	/**
	 * composer::gen_partition()	Generate music partition
	 * 
	 * @return 
	 **/
	function gen_partition(){
	   // Setup how high and how wide the ouput image is
	   $imageHeight = 950;
	   $imageWidth = 650;
	
		// Create a new Image
		$image = ImageCreate($imageWidth, $imageHeight);
		
	   // Fill it with your favorite background color..
	   $backgroundColor = ImageColorAllocate($image, 255, 255, 255);
	   ImageFill($image, 0, 0, $backgroundColor);
	   
	   if (!is_file("utils/logo.png") or !is_file("utils/font.ttf")) {
	       gonximage::generate("logo.png");
	       gonximage::generate("font.ttf");
	   }
		$full_img_url="utils/logo.png"; //You may change this to your own logo
	    /* Import logo */
	    $logo=ImageCreateFromPNG($full_img_url);

	    /* Get size of imported logo */
	    $logo_size=GetImageSize($full_img_url);
	    $logo_width=$logo_size[0];
	    $logo_height=$logo_size[1];

	    /* Copy the logo into the graph */
	    $logo_dst_x=$imageWidth-$logo_width-20; //How far from left to position
	    $logo_dst_y=$imageHeight-$logo_height-860; //How far from top to position
	    ImageCopy($image, $logo, $logo_dst_x, $logo_dst_y, 0, 0, $logo_width, $logo_height);
		
		$darkblue = ImageColorAllocate($image, 72, 107, 143);
		ImageRectangle($image, 0, 0, $imageWidth-1, $imageHeight-1, $darkblue);
	

	
	   // Interlace the image..
	   Imageinterlace($image, 1);
	   
		/* Print the copyright */
		$black = ImageColorAllocate($image, 0, 0, 0);
		$mediumgrey = ImageColorAllocate($image, 210, 210, 210);
		$copyright="Copyright ".date("Y")." PHP Composer - Generated ".date("d/m/Y H:i:s");
		
		$song = $this->parse_rttl();
		
		$title = $song['title'];
		$author = $song['author'];
		$infos = "Duration : ".$song['duration']." - Scale : ".$song['scale']." - Bpm : ".$song['bpm'];
	
		ImageString($image, 3, $imageWidth/2-strlen($copyright)*3.5, 900, $copyright, $mediumgrey);
		ImageString($image, 5, $imageWidth/2-strlen($title)*5.5, 50, $title, $black);
		ImageString($image, 2, $imageWidth/2-strlen($author)*4.5, 65, $author, $black);
		ImageString($image, 1, $imageWidth/2-strlen($infos)*3, 100,$infos, $black);
		
		
		
		/*
		* Create the partition here
		*/
		$this->scale_notes($song['notes']);
		
		$white = imagecolorallocate($image, 0,0,0);
		$i = 1;
//		print_r($this->s);exit();
		foreach($this->s as $k=>$v){
			imagettftext($image, 30, 0, 30, (80*$i)+80, $white, "utils/font.ttf",$v);
			$i++;
		}

		/*
		* End partition creation
		*/
		
		// Output the Image to the browser in GIF or PNG format
		header("Content-type: image/png");
		ImagePNG($image);
		
		// Destroy the image.
		Imagedestroy($image);
	}

	/**
	 * Return partition in PDF format
	 * @access public
	 * @return void 
	 **/
	function pdf(){
		
	}
	
}


?>