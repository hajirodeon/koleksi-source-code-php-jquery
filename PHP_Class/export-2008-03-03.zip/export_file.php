<?php
include_once('databasecon.php');//to make database connecti

$cap="<table align=center border=1px><th>PERSONAL DETAILS</th>";//CAPTION OF THIS REPORT
$title="<tr><td><b>NAME</b></td><td><b>E-MAIL</b></td><td><b>CITY</b></td></tr>";//TABLE HEADER

$tmp_per_res=mysql_query("select * from personalinfo");
while($row=mysql_fetch_array($tmp_per_res,MYSQL_BOTH))
{

$body.="<tr><td>".$row['vName']."</td><td>"
		.$row['vEmail']."</td><td>"
		.$row['vCity']							
		."</td></tr>";
					

}
echo $cap.$title.$body."</table>";						
						
?>	
	
	
	