<?php 
// include the phptrasher class
require_once ('phptrasher.class.php');
// create a new object 
$phptrasher = new phptrasher ();
// initialize the class
$phptrasher->initialize ();
// setup the class
$phptrasher->removecomments = true;
$phptrasher->removelinebreaks = true;
$phptrasher->obfuscateclass = true;
$phptrasher->obfuscatefunction = true;
$phptrasher->obfuscatevariable = true;
// get the obfuscated code
$obfuscated = $phptrasher->trash ('phptrasher.class.php');
// print the formatted code in a beautiful way
highlight_string ($obfuscated);
?>