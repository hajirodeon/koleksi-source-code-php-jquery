<?
   class clserror{
         var $number=0;
         var $description="";
         var $source;
         var $isfotalerr=false;
         function clear(){
                  $this->numbe=0;
                  $this->description="";
                  $this->source=null;
                  $this->isfotalerr=false;
         }
         function clserror(){
                  return $this;
         }
         function raise(){
                  $errmsg="Error at:".$this->source."<br>";
                  $errmsg.="Error number:".$this->number."<br>";
                  $errmsg.="Error Description:".$this->description."<br>";
                  if($this->isfotalerr){
                     die("<font color=red>Fotal Error:<hr>$errmsg</font>");
                  }
                  else{
                       echo "<font color=blue>Generic Error:<hr>$errmsg</font>";
                  }
         }

   }
?>