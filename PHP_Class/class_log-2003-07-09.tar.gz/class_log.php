<?php
/****************************************************************
*****************************************************************

class_log.php: create to work with log file (create and search).
Copyright (C) 2003  Matthieu MARY marym@ifrance.com

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

You can found more information about GPL licence at:
http://www.gnu.org/licenses/gpl.html

for contact me: marym@ifrance.com
****************************************************************
****************************************************************/
/**
 * @shortdesc  allow to use log files
 * @author      Matthieu MARY &lt;<a href="mailto:marym@ifrance.com">marym@ifrance.com</a>&gt;
 * @version     1.0.6
 * @date       june 10th 2003
 */
require_once "class_specif.php";

class log{
     /**
     * pathinfo result on the path
     * @type array
     * @private
     **/
 var $dPath_infos;
      /**
     * path to the log file
     * @type string
     * @private
     **/
 var $sLog;
    /**
     * array of errors
     * @type array
     * @private
     **/
 var $aErrors;
    /**
     * logfile write mode
     * @type string
     * @private
     **/
 var $cMode;
     /**
     * handle on the logfile
     * @type string
     * @private
     **/
 var $fp;
     /**
     * array of extension allowed to be logfiles
     * @type array
     * @private
     **/
 var $aExtensiontypes;
     /**
     * do you wants headers each time a line will be write?
     * @type bool
     * @private
     **/
 var $bWithheaders;   
 
     /**
     * Constructor
     *
     * @type void
     * @public
     * @param string spathtolog , required, path to the log file
     * @param string swritemode , optional, default value 'r'
     * @param bool bwithheaders, optional, default value FALSE, if you wants each line written to have a log format beginning
     **/
 function log($spathtolog,$swritemode='r',$bheaders=FALSE){
    $this->aErrors = array();
    $this->dPath_infos = array();
    $this->sLog = $spathtolog;
    $this->cMode = strtolower($swritemode);
    $this->aExtensiontypes = array('log','txt');
    $this->bWithheaders = $bheaders;
    $this->dPath_infos = pathinfo($this->sLog);
    $this->fp = 0;
    
    // check the parameters
    if(!$this->_CHECK_path($this->dPath_infos['dirname'])) return;
    if ($this->_CHECK_mode('^[rwa]{1}[+]?$')){
         $this->aErrors[] = " the opening mode [".$this->cMode."] seems invalid";
         return;
    }
  // check if the path to save the log already exists
    if (!is_dir($this->dPath_infos['dirname'])){
       $this->aErrors[] = "path [".$this->dPath_infos['dirname']."] doesn't exist";
       return;
    }
    // check the extension logfile
    if (!$this->_CHECK_ext()) return;
    
    // check if the the file exist if the handle mode is read
    if ((eregi("^r.?$",$this->cMode)) && (!file_exists($this->sLog))){
       $this->aErrors[] = "log file [".$this->dPath_infos['filename']."] doesn't exist in the folder [".$this->dPath_infos['dirname']."]";
       return;
    }
 }  // builder
 
     /**
     * get the entire contents of logfile
     *
     * @type array
     * @private
     **/
 function _GET_contents(){
   $aLines = file($this->sLog);
   if (count($aLines)==0) $this->aErrors[] = "logfile [".$this->dPath_infos['basename']."] is empty";
   return $aLines;
 }//_GET_contents()
 

     /**
     * return array of errors
     *
     * @type array
     * @public
     **/
 function GET_errors(){
    return $this->aErrors;
 }#GET_errors

     /**
     * is there any errors?
     *
     * @type int
     * @public
     **/
 function GET_errors_size(){
          return count($this->aErrors);
 } #GET_errors_size()
 
     /**
     * check if the extension file of the log file is ok to be a log file
     *
     * @type bool
     * @private
     **/
 function _CHECK_ext(){
   $this->aErrors = array();
   $bok = TRUE;
   if (!in_array(strtolower(trim($this->dPath_infos['extension'])),$this->aExtensiontypes)){
          $this->aErrors[] = "your logfile extension [".$this->dPath_infos['extension']."] is not allowed";
          $bok = FALSE;
    }
   return $bok;
 }#_CHECK_ext
 
     /**
     * check if the path seems to be valid
     *
     * @type bool
     * @param string spath, the path to check
     * @private
     **/
 function _CHECK_path($sPath){
   $this->aErrors = array();
   if (!is_dir($sPath)){
       $this->aErrors[] = "your path [".$sPath."] doesn't exists";
       return FALSE;
   }
   return TRUE;
 }// __CHECK_path
 
     /**
     * check if the openning write exists
     *
     * @type bool
     * @param string spattern, the pattern for testing cmode
     * @private
     **/
 function _CHECK_mode($sPattern){
   return (eregi('/'.$sPattern.'/',$this->cMode));
 } // _CHECK_mode

     /**
     * open a handle on the logfile
     *
     * @type bool
     * @private
     **/
 function _FILE_opening(){
   $this->aErrors = array();
   if ($this->fp){
        $this->aErrors[] = "file [".$this->dPath_infos['basename']."] already open";
        return FALSE;
   }
   $this->fp = fopen($this->sLog,$this->cMode);
   if (!$this->fp){
       $this->aErrors[] = "unable to open the [".$this->dPath_infos['basename']."]";
       return FALSE;
   }
   return TRUE;
 } // _FILE_opening

     /**
     * close the log file handle
     *
     * @type void
     * @private
     **/
  function _FILE_closing(){
   if (fclose($this->fp)){$this->fp = FALSE;}
 } // _FILE_closing

     /**
     * write a line in the logfile
     *
     * @type void
     * @param string sline - the line must be put in logfile
     * @private
     **/
 function _WRITE_line($sLine){
     fputs($this->fp,(($this->bWithheaders)?$this->FORMAT_string($sLine):$sLine)."\r\n");
 }// WRITE_line
 
     /**
     * write headers in the logfile 'name of file, date and time data)
     *
     * @type void
     * @private
     **/
 function _WRITE_headers(){
   $sHeaders = "";
   $sHeaders = "\r\n\r\n".
               "********************************************\r\n".
               "\t file [".$this->dPath_infos['basename']."]".
               "\t create the :".date("d-m-y")."\r\n".
               "\t at :".date("G:i")."\r\n".
               "********************************************\r\n";
   fputs($this->fp,$sHeaders);
 } // _WRITE_headers_()
 
     /**
     * write datas in the logfile
     *
     * @type void
     * @param array adatas the array with each line will be put in logfile
     * @private
     **/
 function _WRITE_array_body(&$aData){
          $this->aErrors = array();
          if (!$this->fp){
              $this->aErrors[] = "any log file open";
              return;
          }
          foreach($aData as $sKey => $oValue){
                if (is_array($oValue)){
                    $this->_WRITE_array_body($oValue);
                    if (count($this->aErrors)> 0) return;}
                else $this->_WRITE_line($oValue);
          }
          return;
 }  //__WRITE_array_body
 
     /**
     * open the logfile and write data in
     *
     * @type void
     * @param mixed odatas can be string or array - the datas must be put in logfile
     * @public
     **/
 function WRITE($oDatas){
   $this->aErrors = array();
   if (!is_string($oDatas)&& !is_array($oDatas)){
      $this->aErrors[] = "parameter [".$oDatas."] is not valid parameter";
      return;
   }
   // check if the file opening mode allow writing
   if ($this->_CHECK_mode('^[r]{1}$')){
      $this->aErrors[] = "the file mode [".$this->cMode."] not allowed the write in the log file";
      return;
   }

   // open the file
   if (!$this->_FILE_opening()){
        $this->_FILE_closing();
        return;
   }

   //write headers
   $this->_WRITE_headers();

   // write data
   if (is_array($oDatas)){
       $this->_WRITE_array_body($oDatas);
       if (count($this->aErrors)>0) return;
   }
   else $this->_WRITE_line($oDatas);
   // close file
   $this->_FILE_closing();
 } // _WRITE

     /**
     * return a preformated array
     *
     * @type array
     * @public
     * @param string slabel, the title
     **/

function WRITE_subtitle($sLabel){
     $aTitle = array();
     $aTitle[] = "---------------------------------------------";
     $aTitle[] = " ".$sLabel." ";
     $aTitle[] = "--------------------------------------------";
     return $aTitle;
}// WRITE_sbutitle


     /**
     * open the logfile and search for some pattern in each line
     *
     * @type array
     * @public
     * @param string sparam, the pattern must be search for in the logfile
     * @param bool bprint, do you wants print the lines found?
     **/
 function SEARCH($sParam,$bPrint=FALSE){
  // Is the parameter empty?
  if (trim($sParam)==''){
      $this->aErrors[] = "search function: parameter cannot be null";
      return;
  }

    // get the contents
   $aLines = $this->_GET_contents();
   if ($this->GET_errors_size()) return;

   // check for each file where line preg match to the parameter
   $aMatches = array();
   foreach($aLines as $numberLine => $sContent){
       $line = $numberLine + 1;
        if (preg_match("/$sParam/",trim($sContent))) $aMatches[$line] = trim($sContent);
  }
  // if we need to print result
   if ($bPrint){
       $specif = new specif();
       $endline  = $specif->Endline();
      if (count($aMatches)==0) echo "Search in [".$this->dPath_infos['basename']."] for pattern [".$sParam."]: no lines found".$endline;
      else{
           echo "Search in [".$this->dPath_infos['basename']."] for pattern [".$sParam."]: results".$endline;
           foreach($aMatches as $line => $sContents) echo "line [".$line."] : [".$sContents."] ".$endline;
      }
   }
   return $aMatches;
} //SEARCH


     /**
     * print to screen logfile
     *
     * @type void
     * @public
     **/
 function show(){
    // get the contents
   $aLines = $this->_GET_contents();
   if ($this->GET_errors_size()) return;
   
   $specif = new specif();
   $endline  = $specif->Endline();
   foreach($aLines as $line => $value){
    echo "line [".($line+1)."] : ".$value.$endline;
   }
}//PRINT



     /**
     * return a preformated string
     *
     * @type string
     * @private
     * @param string slabel, optional, default value ''
     **/
function FORMAT_string($sString=''){
    // LogFormat "%h %l %u %t \"%r\" %>s %b \"%{Referer}i\"
    return "[".date("d/M/Y:H:i:s Z")."] ".$sString;
}//FORMAT_string

     /**
     * return a preformated array
     *
     * @type string
     * @private
     * @param array aarray, optional, default value array()
     **/
function FORMAT_array($aArray=array()){
         if (count($aArray)>0){
           $aKeys = array_keys($aArray);
           foreach($aKeys as $key => $sKey){
                          $aArray[$sKey] = $this->FORMAT_string($aArray[$sKey]);
           }
         }
         return  $aArray;
}//FORMAT_array

}// log
?>
