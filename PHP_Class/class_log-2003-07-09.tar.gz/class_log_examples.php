<!doctype html public "-//W3C//DTD HTML 4.0 //EN">
<html>
<head>
       <title>Examples of class_log application</title>
</head>
<body>
<?php
 require "class_log.php";
  // create a new object log
     echo "<U>create new object log</U><BR>\r\n";
    // $sPathtolog = "/home/bob/logfile.log";
     $sPathtolog = 'C:\EasyPHP\php\PEAR\test.log';
     $log = new log($sPathtolog,"a+");
     if ($log->GET_errors_size()){
         echo "some errors occurs:\r\n";
         print_r($log->GET_errors());
         exit(0);
     }


     $sError = "Here the string of my error";
   // write a string in the log file
    echo "<U>add the string [".$sError."]</U><BR>\r\n";
     $log->WRITE($sError);
     if ($log->GET_errors_size()){
         echo "some errors occurs:\r\n";
         print_r($log->GET_errors());
         exit(1);
     }

  // write an array in the log file
     echo "<U>the following array will be add in the logfile</U><BR>\r\n";
     $aErrors = array("Here the first string of my error","here the second string");
     $log->WRITE($aErrors);
     if ($log->GET_errors_size()){
         echo "some errors occurs:\r\n";
         print_r($log->GET_errors());
          exit(2);
     }
   // search for pattern in the log file
    echo "<U>searching for string in log file</U><BR>\r\n";
     $aMatches = $log->SEARCH("(string)",TRUE);
     if ($log->GET_errors_size()){
         echo "some errors occurs:\r\n";
         print_r($log->GET_errors());
          exit(2);
     }
     
     // print the entire contents of logfile
    echo "<U>printing the entire contents of logfile</U><BR>\r\n";
    $log->show();
    if ($log->GET_errors_size()){
         echo "some errors occurs:\r\n";
         print_r($log->GET_errors());
          exit(2);
     }
?>
</body>
</html>
