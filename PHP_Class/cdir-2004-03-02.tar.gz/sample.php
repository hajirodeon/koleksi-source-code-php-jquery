<?php

// $Archive: /Homepages/cdir/sample.php $
// $Author: Hannesd $
// $Date: 24.09.03 1:52 $
// $Revision: 2 $

include_once 'dir.php';

$oDir = new CDir();

// Read my Directory, only htm, html and php files
// recursive, files, no directories
// add /cdir/ to any entry
// don't add files/dirs containing _vti_ or vssver.scc
$oDir->Read( "./", "(htm|html|php)\$", true, true, true, "/cdir/", "(_vti_)|(vssver.scc)" );

// Sort entries descending by fullname
$oDir->Sort( 'Fullname', false );

// Output
$oDir->Output();

// Do something
foreach( $oDir->aFiles as $aFile )
{
    $sFullname = $oDir->FullName( $aFile );
    echo "$sFullname<br>\n";
}

?>