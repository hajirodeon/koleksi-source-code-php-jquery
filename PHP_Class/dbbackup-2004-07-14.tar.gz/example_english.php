<?php


	// Feel free to translate this file in your own language
	// then back the localized example to my email address
	// avalaible on my website - www.lashampoo.net


	$action=$_REQUEST['action']; 
	$file=$_REQUEST['file']; 
	$all=$_REQUEST['all']; 
	if(is_array($_REQUEST['table']))
		$tables='`'.join('` `',$_REQUEST['table']).'`';
	$tables=DeQuote($tables);
	$file=DeQuote($file);
	$all=DeQuote($all);
	if($tables==$all)$tables='';
	
	function   Quote($texte) { return str_replace('"','&quote;',$texte); }
	function DeQuote($texte) { return str_replace('&quote;','"',$texte); }
	
	require('inc.dbbackup.php'); // Instantiation of dbBackup class
	
	    // Execute action
	    if($action=='retrieve' && $file) $r=$dbBackup->retrieve($file);
	elseif($action=='delete' && $file) $r=$dbBackup->delete($file);
	elseif($action=='restore' && $file) $r=$dbBackup->restore($file);
	elseif($action=='fromlast') $r=$dbBackup->fromlast();
	elseif($action=='dump') $r=$dbBackup->dump($tables);
	elseif($action=='dumpifneeded') $r=$dbBackup->dumpifneeded($tables);

	    // Explication des erreurs ou r�sultats
	    if($action=='retrieve' && $r) $error="Backup file doesn't seem to exist or be readable";
	elseif($action=='delete' && $r) $error="Couldn't delete backup file";
	elseif($action=='delete') $error="Backup file deleted";
	elseif($action=='restore' && $r) $error="Backup file doesn't seem to exist or be readable";
	elseif($action=='restore') $error="Database restored from backup file";
	elseif($action=='fromlast' && $r=='none') $error="Backup directory seems to be empty, no last backup";
	elseif($action=='fromlast' && $r) $error="Backup directory seems not to be readable or not to exist";
	elseif($action=='fromlast') $error="Database restored from last backup file";
	elseif($action=='dumpifneeded' && $r=='error') $error="Impossible to create backup file";
	elseif($action=='dumpifneeded' && $r=='not needed') $error="No backup needed";
	elseif($action=='dumpifneeded' && !$r) $error="Impossible to create backup file";
	elseif($action=='dumpifneeded' && $r) $error="Backup file created";
	elseif($action=='dump' && !$r) $error="Impossible to deleted backup file";
	elseif($action=='dump') $error="Backup file created";


	list($files,$dates)=$dbBackup->listbackups(); // Retrieve backups list

?><html>
	<head>
		<meta http-equiv="content-type" content="text/html; charset=windows-1252">
		<title>dbBackup</title>
		<style type="text/css" media="All"><!--

body,select,input	{ 
	font-size: 12px;
	background-color: #FFFFFF;
	font-family: verdana, helvetica, arial;
	margin: 5px; padding: 5px; }

-->
		</style>
<script language="JavaScript">
<!--

var ok=false;

function test(ok) {

	var n = document.backup;
	var action=n.elements[0].value;
	var file=n.elements[1].value;
	    file='.'+file.substring(file.indexOf('.[')+2,file.indexOf('].'))+'.'; 
	var all=file.indexOf('..all-tables..');

	if(ok=='files') for (var i = 0; i < n.elements.length; i++) {

		if(n.elements[i].type=='checkbox') { 
			if (file.indexOf('.'+n.elements[i].value+'.')>=0 || all>=0)
				 n.elements[i].checked=true;
			else n.elements[i].checked=false;
		}

	}

	if(action=='dump')     action='backup the database';
	if(action=='dumpifneeded')  action='sauvegarder la base de donn�es si n�cessaire';
	if(action=='restore')  action='restore database from backup file';
	if(action=='fromlast') action='restore database from last backup';
	if(action=='delete')   action='delete the backup file';
	if(action=='retrieve') action='download the backup file';

	if(n.elements[0].value!='dump' 
		&& n.elements[0].value!='fromlast' 
		&& n.elements[0].value!='dumpifneeded' 
		&& n.elements[0].value !='' 
		&& n.elements[1].value == ''
		&& ok==true) 
	 { alert('You must select a backup file'); return false; }

	else if(n.elements[0].value == '' 
		&& n.elements[1].value != ''
		&& ok==true) { 
			alert('You must select an action to perform'); 
			return false;
	}

	else if( n.elements[0].value=='dump' 
		  || n.elements[0].value=='fromlast' 
		  || n.elements[0].value=='dumpifneeded' 
		  || (n.elements[0].value !='' 
		      && n.elements[1].value != '')) {
	
		if(confirm('Confirm '+action+' ?')) 
			if(confirm('Really sur you want to '+action+' ?')) n.submit();
			else return false;

		else return false;
	
	} else return false;

}

//-->
</script>


</head><body><center>

<h1>dbBackup</h1>
<form action="./example_english.php" name="backup" method="GET" onSubmit="return test('end');">

<?php if($error) { ?><b><?=$error?></b><br><br><?php } ?>

<?php if($files==false) { ?>
<b>The backup folder doesn't seem to exist and/or to be writable by Apache</b><br>
Please check the configuration settings in inc.dbbackup.php<br><br><?php } ?>

<select name="action" onchange="if(this.value!='')test('action');">
<option value=""></option>
<option value="dump">Backup database</option>


<?php if($files!='none') { ?>

<option value="dumpifneeded">Backup database if needed</option>
<option value="restore">Restore from backup file:</option>
<option value="fromlast">Restore from last backup</option>
<option value="delete">Delete backup file:</option>
<option value="retrieve">Download backup file:</option>
</select> 

<select name="file" onchange="if(this.value!='')test('files');">
<option value=""></option>

<?php foreach ($files AS $file) { 

	$name=ereg_replace("^.*\.\[(.*)\]\..*$",'\1',$file); 
	$name=ereg_replace(".all-tables.","base compl�te",$name); 
	if(substr_count($name,'.')>=1)$name=(substr_count($name,'.')+1)." tables";
	elseif($name!="base compl�te")$name="only 1 table"; 
	
	echo "<option value=\"".Quote($file)."\">".
	date('\d\u d/m/Y � H\hi, ',array_pop($dates)).$name."</option>\n";

}} ?>

</select><input type="submit" value="ok"><br>


<?php $tables=$dbBackup->listtables(); 

	if($tables) foreach($tables AS $table) { ?>

	<input type="checkbox" name="table[]" value="<?=Quote($table)?>" checked><?=$table?> 

<?php } else { ?>

	No table to select, this databse seems empty.

	<?php } ?>

<input type="hidden" name="all" value="<?='`'.Quote(join('` `',$tables)).'`'?>"></form>


</center></body></html>