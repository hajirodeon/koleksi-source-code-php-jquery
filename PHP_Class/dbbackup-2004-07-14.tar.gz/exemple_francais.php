<?php


	// Soyez libre de traduire ce fichier dans votre langue
	// puis renvoyez l'exemple localis� sur mon adresse email
	// disponible sur mon site web - www.lashampoo.net


	$action=$_REQUEST['action']; 
	$file=$_REQUEST['file']; 
	$all=$_REQUEST['all']; 
	if(is_array($_REQUEST['table']))
		$tables='`'.join('` `',$_REQUEST['table']).'`';
	$tables=DeQuote($tables);
	$file=DeQuote($file);
	$all=DeQuote($all);
	if($tables==$all)$tables='';
	
	function   Quote($texte) { return str_replace('"','&quote;',$texte); }
	function DeQuote($texte) { return str_replace('&quote;','"',$texte); }
	
	require('inc.dbbackup.php'); // Instantiation de la classe dbBackup
	
	    // Executer l'action
	    if($action=='retrieve' && $file) $r=$dbBackup->retrieve($file);
	elseif($action=='delete' && $file) $r=$dbBackup->delete($file);
	elseif($action=='restore' && $file) $r=$dbBackup->restore($file);
	elseif($action=='fromlast') $r=$dbBackup->fromlast();
	elseif($action=='dump') $r=$dbBackup->dump($tables);
	elseif($action=='dumpifneeded') $r=$dbBackup->dumpifneeded($tables);

	    // Explication des erreurs ou r�sultats
	    if($action=='retrieve' && $r) $error="Le fichier de sauvegarde $file ne semble pas exister ou �tre lisible";
	elseif($action=='delete' && $r) $error="Impossible d'effacer le fichier de sauvegarde $file";
	elseif($action=='delete') $error="Fichier de sauvegarde $file effac�";
	elseif($action=='restore' && $r) $error="Le fichier de sauvegarde $file ne semble pas exister ou �tre lisible";
	elseif($action=='restore') $error="Base r�tablie depuis le fichier de sauvegarde $file";
	elseif($action=='fromlast' && $r=='none') $error="Le dossier de sauvegarde semble �tre vide, pas de derni�re sauvegarde";
	elseif($action=='fromlast' && $r) $error="Le dossier de sauvegarde semble ne pas �tre lisible ou exister";
	elseif($action=='fromlast') $error="Base r�tablie depuis la derni�re sauvegarde";
	elseif($action=='dumpifneeded' && $r=='error') $error="Impossible de cr�er le fichier de sauvegarde";
	elseif($action=='dumpifneeded' && $r=='not needed') $error="Aucune sauvegarde n�cessaire";
	elseif($action=='dumpifneeded' && !$r) $error="Impossible de cr�er le fichier de sauvegarde";
	elseif($action=='dumpifneeded' && $r) $error="Le fichier de sauvegarde a �t� cr��";
	elseif($action=='dump' && !$r) $error="Impossible de cr�er le fichier de sauvegarde";
	elseif($action=='dump') $error="Le fichier de sauvegarde a �t� cr��";


	list($fichiers,$dates)=$dbBackup->listbackups(); // R�cup�rer la liste des sauvegarde

?><html>
	<head>
		<meta http-equiv="content-type" content="text/html; charset=windows-1252">
		<title>dbBackup</title>
		<style type="text/css" media="All"><!--

body,select,input	{ 
	font-size: 12px;
	background-color: #FFFFFF;
	font-family: verdana, helvetica, arial;
	margin: 5px; padding: 5px; }

-->
		</style>
<script language="JavaScript">
<!--

var ok=false;

function test(ok) {

	var n = document.backup;
	var action=n.elements[0].value;
	var file=n.elements[1].value;
	    file='.'+file.substring(file.indexOf('.[')+2,file.indexOf('].'))+'.'; 
	var all=file.indexOf('..all-tables..');

	if(ok=='files') for (var i = 0; i < n.elements.length; i++) {

		if(n.elements[i].type=='checkbox') { 
			if (file.indexOf('.'+n.elements[i].value+'.')>=0 || all>=0)
				 n.elements[i].checked=true;
			else n.elements[i].checked=false;
		}

	}

	if(action=='dump')          action='sauvegarder la base de donn�es';
	if(action=='dumpifneeded')  action='sauvegarder la base de donn�es si n�cessaire';
	if(action=='restore')       action='restaurer la base depuis le fichier de sauvegarde';
	if(action=='fromlast')      action='restaurer la base depuis la derni�re sauvegarde';
	if(action=='delete')        action='effacer le fichier de sauvegarde';
	if(action=='retrieve')      action='t�l�charger le fichier de sauvegarde';
	
	if(n.elements[0].value!='dump' 
		&& n.elements[0].value!='fromlast' 
		&& n.elements[0].value!='dumpifneeded' 
		&& n.elements[0].value !='' 
		&& n.elements[1].value == ''
		&& ok=='end') 
	 { alert('Vous devez s�lectionner un fichier de sauvegarde'); return false; }

	else if(n.elements[0].value == '' 
		&& n.elements[1].value != ''
		&& ok=='end') { 
			alert('Vous devez s�lectionner une action � effectuer'); 
			return false;
	}

	else if( n.elements[0].value=='dump' 
		  || n.elements[0].value=='fromlast' 
		  || n.elements[0].value=='dumpifneeded' 
		  || (n.elements[0].value !='' 
		      && n.elements[1].value != '')) {
	
		if(confirm('Confirmez-vous vouloir '+action+' ?')) 
			if(confirm('Vraiment s�r de vouloir '+action+' ?')) n.submit();
			else return false;

		else return false;
	
	} else return false;

}

//-->
</script>


</head><body><center>

<h1>dbBackup</h1>
<form action="./exemple_francais.php" name="backup" method="GET" onSubmit="return test('end');">

<?php if($error) { ?><b><?=$error?></b><br><br><?php } ?>

<?php if($fichiers==false) { ?>
<b>Le r�pertoire de sauvegarde ne semble pas exister et/ou �tre acc�ssible en �criture par Apache.</b>
<br>Veuillez v�rifier les r�glages de configuration du fichier inc.dbbackup.php<br><br><?php } ?>

<select name="action" onchange="if(this.value!='')test('action');">
<option value=""></option>
<option value="dump">Sauvegarder la base de donn�es</option>


<?php if($fichiers!='none') { ?>

<option value="dumpifneeded">Sauvegarder la base de donn�es si n�cessaire</option>
<option value="restore">Restaurer depuis la sauvegarde:</option>
<option value="fromlast">Restaurer depuis la derni�re sauvegarde</option>
<option value="delete">Effacer le fichier de sauvegarde:</option>
<option value="retrieve">T�l�charger le fichier de sauvegarde:</option>
</select> 

<select name="file" onchange="if(this.value!='')test('files');">
<option value=""></option>

<?php foreach ($fichiers AS $fichier) { 

	$nom=ereg_replace("^.*\.\[(.*)\]\..*$",'\1',$fichier); 
	$nom=ereg_replace(".all-tables.","base compl�te",$nom); 
	if(substr_count($nom,'.')>=1)$nom=(substr_count($nom,'.')+1)." tables";
	elseif($nom!="base compl�te")$nom="1 seule table"; 
	
	echo "<option value=\"".Quote($fichier)."\">".
	date('\d\u d/m/Y � H\hi, ',array_pop($dates)).$nom."</option>\n";

}} ?>

</select><input type="submit" value="ok"><br>


<?php $tables=$dbBackup->listtables(); 

	if($tables) foreach($tables AS $table) { ?>

	<input type="checkbox" name="table[]" value="<?=Quote($table)?>" checked><?=$table?> 

<?php } else { 

?>Aucune table � s�lectionner, cette base de donn�es semble �tre vide.

	<?php } ?>

<input type="hidden" name="all" value="<?='`'.Quote(join('` `',$tables)).'`'?>"></form>


</center></body></html>