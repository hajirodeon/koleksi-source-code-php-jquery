<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html>
<head>
	<title>ActiveLink PHP XML Tutorial Script</title>
	<meta http-equiv="content-type" content="text/html; charset=ISO-8859-1"/>
	<meta name="description" content="ActiveLink PHP XML Package example script"/>
	<meta name="author" content="Zurab Davitiani"/>
	<meta name="keywords" content="ActiveLink, PHP, XML, example, IORCA"/>
	<style type="text/css">
		h2 {background-color: #DADCFF;text-align: center;}
		h3 {text-align: center;}
		pre {background-color: #DADCFF;}
		div {border-width: thick;border-style: outset;border-collapse: collapse;padding: 5px;}
		div.foreword {background-color: #FFFF99;border: 1px dotted black;}
		div.example1 {background-color: #F7FFEA;}
		div.example2 {background-color: #F7FFEA;}
		div.example3 {background-color: #F7FFEA;}
		div.example4 {background-color: #F7FFEA;}
		div.finalword {background-color: #FFFF99;border: 1px dotted black;}
	</style>
</head>
<body>

<?php

require_once("classes/include.php");
import("org.active-link.xml.XML");
import("org.active-link.xml.XMLDocument");

?>

<h2>ActiveLink PHP XML Package Tutorial Script</h2>
<div class="foreword">
Thank you for trying out ActiveLink PHP XML Package. Below are simple examples on how to
manipulate XML and XML documents using classes contained in AciveLink PHP XML Package.
<br/><br/>
First and foremost, let's load all classes that we will use:
<pre>
// include a class-loading function
require_once("classes/include.php");

// import XML and XMLDocument classes
import("org.active-link.xml.XML");
import("org.active-link.xml.XMLDocument");
</pre>
</div>

<?php
$myXML = new XML("PREFERENCES");

// add new content by specifying path to new tags and values
$myXML->setTagContent("Blue", "PREFERENCES/COLORSCHEME");
$myXML->setTagContent("Motif", "PREFERENCES/ICONS");
$myXML->setTagContent("", "PREFERENCES/NEWS/HEADLINES");

?>

<hr/>
<div class="example1">
<h3>EXAMPLE 1</h3>
<p>
In the first example, let's construct a simple XML tree from scratch. Let's make
the root element called PREFERENCES and store some user preferences in XML format.
First, let's create an XML object $myXML by:
<pre>
$myXML = new XML("PREFERENCES");
</pre>
This creates an XML object and assigns PREFERENCES as its root tag name. Now, let's
add couple of sub-branches (child tags) under the root tag, let's say COLORSCHEME and
ICONS. This is easily accomplished by calling setTagContent method as follows:
<pre>
$myXML->setTagContent("Blue", "PREFERENCES/COLORSCHEME");
$myXML->setTagContent("Motif", "PREFERENCES/ICONS");
</pre>
setTagContent method takes the supplied tag path and either searches and replaces existing
tag contents, or, as in this case, creates new set of tags. Notice that we set "Blue" and "Motif"
as tag contents of respective branch (children) tags.
<br/><br/>
Next, let's add another branch (child tag) NEWS, but now let's also add a grandchild tag also and
let's call it HEADLINES.
<pre>
$myXML->setTagContent("", "PREFERENCES/NEWS/HEADLINES");
</pre>
Notice that, just like before, by specifying the tagpath setTagContent in this case creates
a new set of tags. The tag path can be as deep as necessary, or left unspecified to assume
current context.
<br/><br/>Here is the final output from our $myXML object at the end of example 1:
<pre>
<?php
print(htmlspecialchars(stripslashes($myXML->getXMLString(0))));
?>
</pre>
</p>
</div>

<?php

// add extra item branches to HEADLINES
$headline1 = new XMLBranch("item");
$headline2 = new XMLBranch("item");
$headline3 = new XMLBranch("item");

// set branch tag attributes and content as required
$headline1->setTagAttribute("id", "1");
$headline1->setTagContent("headline 1 content");
$headline2->setTagAttribute("id", "2");
$headline2->setTagContent("headline 2 content");
$headline3->setTagAttribute("id", "3");
$headline3->setTagContent("headline 3 content");

?>

<hr/>
<div class="example2">
<h3>EXAMPLE 2</h3>
<p>
In the second example, let's perform a slightly more complex manipulation of our $myXML object that
we created in example 1. Under HEADLINES let's add three "item" branches (child tags)
all with different contents. But this time, let's use a different method - let's first create 3 item
branches as separate unassociated objects and then add them under HEADLINES in the XML tree.
<pre>
$headline1 = new XMLBranch("item");
$headline2 = new XMLBranch("item");
$headline3 = new XMLBranch("item");
</pre>
The above syntax should look familiar. XMLBranch class extends XML class, so all methods present in
XML also are available under XMLBranch and work exactly the same way. So, let's assign new contents
to each of our new branches.
<pre>
$headline1->setTagContent("headline 1 content");
$headline2->setTagContent("headline 2 content");
$headline3->setTagContent("headline 3 content");
</pre>
To complicate things a little more, let's set tag "id" attributes to each of the created branches so that
they are easy to locate and identify. Let's assign each of their IDs as 1, 2, and 3 respectively.
<pre>
$headline1->setTagAttribute("id", "1");
$headline2->setTagAttribute("id", "2");
$headline3->setTagAttribute("id", "3");
</pre>
Now these branches are ready to be added to our $myXML tree.
</p>

<?
// get headlines branch with the appropriate path
// $headlines will be an array of references to actual branches
$headlines = $myXML->getBranches("PREFERENCES/NEWS", "HEADLINES");

// add headline items to the headlines branch
// first array element since we know it's the only element
$headlines[0]->addXMLBranch($headline1);
$headlines[0]->addXMLBranch($headline2);
$headlines[0]->addXMLBranch($headline3);

?>

<p>
To add our new branches under HEADLINES, first we have to access and retrieve the HEADLINES branch.
To do so, we use getBranches method as follows:
<pre>
$headlines = $myXML->getBranches("PREFERENCES/NEWS", "HEADLINES");
</pre>
getBranches method, in this case, accepts tag path argument to search the tags in; and also tag name
argument to retrieve only tags with that name. Also, getBranches method returns an array when
match(es) are found, or false when none are. Since we know that $myXML contains one HEADLINES
match under PREFERENCES/NEWS, we can directly go to that element in the array - $headlines[0]
and add our newly created branches.
<pre>
$headlines[0]->addXMLBranch($headline1);
$headlines[0]->addXMLBranch($headline2);
$headlines[0]->addXMLBranch($headline3);
</pre>
As you can see, addXMLBranch method takes our headline branches and adds them to HEADLINES branch in our
main XML tree - $myXML. It is important to remember that getBranches method returns an array of
<i>references</i> to actual branches, so, by modifying $headlines array we are also modifying $myXML
object.
<br/><br/>Here is the final output from our $myXML object at the end of example 2:
<pre>
<?php
print(htmlspecialchars(stripslashes($myXML->getXMLString(0))));
?>
</pre>
</p>
</div>

<?php
// How to parse existing XML string into XML object
// Very easy

$myXMLString = '<PREFERENCES>' .
				'<COLORSCHEME>Blue</COLORSCHEME>' .
				'<ICONS>Motif</ICONS>' .
				'<NEWS>' .
					'<HEADLINES>' .
						'<item id="1">headline 1 content</item>' .
						'<item id="2">headline 2 content</item>' .
						'<item id="3">headline 3 content</item>' .
					'</HEADLINES>' .
				'</NEWS>' .
			'</PREFERENCES>';
$myNewXML = new XML($myXMLString);

// How to access item 2 from HEADLINES
$myItems = $myNewXML->getBranches("PREFERENCES/NEWS/HEADLINES", "item", "id", "2");
$myItems[0]->setTagContent("NEW headline 2 content updated!");

// How to remove item 3 from headlines
$myNewXML->removeBranches("PREFERENCES/NEWS/HEADLINES", "item", "id", "3");
?>

<hr/>
<div class="example3">
<h3>EXAMPLE 3</h3>
<p>
In the third example, we will create an XML object by parsing through an existing XML string,
modify one specific branch, and remove (delete) another completely. Let's assume that the final
output from the previous example is stored in $myXMLString variable. To create a new XML object
by parsing a string, we simply call:
<pre>
$myNewXML = new XML($myXMLString);
</pre>
That was easy! The XML class constructor is smart and knows when it should create a root element
(like in example 1) or parse the string into an XML object itself. In this case, we should have
a $myNewXML object that is identical to previously created $myXML object.
<br/><br/>
Now, let's access the second "item" branch under HEADLINES and modify its content. To do so, we
use getBranches method again as follows:
<pre>
$myItems = $myNewXML->getBranches("PREFERENCES/NEWS/HEADLINES", "item", "id", "2");
</pre>
Notice that getBranches can query a specified tag path by tag name, tag attribute name, and tag
attribute value, and return only those matching branches in an array. It's worth pointing out
that all arguments for getBranches method are optional. Now, since we know that there's only
one branch that will match the specified getBranches query we can go directly to that branch
and modify its contents:
<pre>
$myItems[0]->setTagContent("NEW headline 2 content updated!");
</pre>
It is also important to note that when querying XML object in such way it is a good practice to
test for getBranches returning false when no matches are found; and when matches are found,
iterating through the array to access all getBranches query results.
<br/><br/>
Now that we updated the second "item" contents under PREFERENCES, let's remove the third item
tag altogether. To remove a branch, we use removeBranches method:
<pre>
$myNewXML->removeBranches("PREFERENCES/NEWS/HEADLINES", "item", "id", "3");
</pre>
Notice that the syntax of removeBranches method is similar to getBranches method.
<br/><br/>Here is the final output from our $myNewXML object at the end of example 3:
<pre>
<?php
print(htmlspecialchars(stripslashes($myNewXML->getXMLString(0))));
?>
</pre>
</p>
</div>

<hr/>
<div class="example4">
<h3>EXAMPLE 4</h3>
<p>
In the 4th and final example, we will learn how to save an XML document via an XMLDocument class
and how to read saved XML documents from a file.
<br/><br/>
To save an XML document, first we create an XMLDocument object:
<pre>
$myXMLDoc = new XMLDocument();
</pre>
Then we associate our XML object with the newly created XMLDocument object. Let's say we want to save
our $myNewXML object output from previous example in an XML document:
<pre>
$myXMLDoc->setXML($myNewXML);
</pre>
And, finally, we call save method and supply a filename to save the XML document:
<pre>
$myXMLDoc->save("example.xml");
</pre>
To read and parse an XML document, we create an XMLDocument object and pass the filename to its
constructor:
<pre>
$myNewXMLDoc = new XMLDocument("example.xml");
</pre>
It's that easy! The XML document "example.xml" is read and parsed into $myNewXMLDoc object. Next,
we access XML object stored inside the $myNewXMLDoc by calling getXML method as follows:
<pre>
$myXMLFromFile =&amp; $myNewXMLDoc->getXML();
</pre>
PHP4 users: notice that if we use =&amp; we will actually retrieve a reference to the actual XML
object stored inside $myNewXMLDoc; this way, all modifications to $myXMLFromFile will reflect in
$myNewXMLDoc object automatically. If such functionality is not desired, we can simply use an
assignment operator (=) and work on a copy of an XML object instead.
</p>
</div>

<hr/>
<div class="finalword">
<h3>Final Word</h3>
<p>
Hopefully this example and tutorial was helpful. Remember that this tutorial only touches upon basic
functionality. Please consult documentation for full class and method descriptions. Also, note that
for the purpose of brevity, this tutorial does not go into checking error conditions. Please
remember to use good coding practices for checking such error conditions.
</p>
<p>
If you use and like ActiveLink PHP XML Package, please remember that your contributions, comments,
bug reports are always welcome. Please show your support by reviewing, recommending, linking from
your website, and finally, rating the package at various providers
such as <a href="http://freshmeat.net/rate/35465/">Freshmeat.net</a>,
<a href="http://www.hotscripts.com/cgi-bin/rate.cgi?ID=20918">HotScripts.com</a>,
<a href="http://www.phpclasses.org/browse.html/package/858.html">PHPClasses.org</a>, etc.
Your support will help others find this package and contribute as well.
</p>
</div>

</body>
</html>
