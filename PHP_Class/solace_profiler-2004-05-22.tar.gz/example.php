<?php
     include_once('class.solace.profiler.php');
     declare(ticks=1);
include('example_include.php');

// This example does nothing, just a demonstration

    $a = 1; // direct assignment is the fastest operation
    $b = 20;
    for ($i = 0; $i < 100; $i++) { // 'for' is counted at the ending '}'
        $a = $a; // dummy, just to compare speed
        $aa = &$a; // assigning and referencing takes the same time
        $a++;
        $b += 1; // this is usually a bit slower then $a++ (at least on my slow test PC)
        $c = test($a, $b); // the main time-eater
        if ($c) {  // 'if' is counted at the ending '}'
            $f = @fopen(__FILE__, 'r');
            if ($f) fclose($f); // closing is faster then opening
            $b++;
        }
        else // 'else' is counted at the ending '}'
        {
            $a++;
        } // this line shows 160 (summary of 'else' and overall 'if' passes)
    } // 101 = 100 cycles + 1 initial php parser pass

?>
