<?php

function test($a, $b) // declarations are not counted (no tick)
{
    $c = $a - $b; // 100 cycles
    return $c > 0; // 'return' doesn't produce a tick, so it is ignored
}  // 1 initial php parser pass

?>
