<?PHP

// Previous class

require("COutLook.php");

// Make new instance of the class

$class = new COutLook;

if($folder == "")
{
	$class->staticFolders();
}
else
{
	$class->staticFolders();
	$class->getMessages($folder);
}

?>