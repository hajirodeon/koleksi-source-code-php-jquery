I have always been surprised from what PHP can do.
Using COM objects shows new and best ways for PHP development.

The folowing code, which is designed like Step by Step wizard,
shows the access to Inbox and Outbox folders in your MS Outlook application.

You should do the folowing:

Check the system configuration and registry entires.

System:
OS: Windows 98/NT/2000/XP 
MS Outlook

Registry:

Start regedit.exe from Start Menu->Run ,check the HKEY_CLASSES_ROOT section for the folowing entires:
	
Outlook.Application and MIME.Session (or MIME.Session1).

If the MIME.Session is missing you shold do the folowing:
	
1. Search your computer for the file named cdo.dll if doesn't exists you must download it from the microsoft web site.

2. Move your cdo.dll in the system32 directory and register it with the regsvr32.exe (just drag the file and drop it over regsvr32.exe file).

Make a file named index.php which have 2 frames
In main frame you should put the 'comunread.php' file and in the bottom frame 'view.php'
Then run the index.php!
The class COutLook.php and all files need to be at the same path.

Feel free to report any bugs or doubts.

Ernani Joppert Pontes Martins
Consultant and Developer
S�o Paulo - Brazil
E-mail: ernani@php.net