<?PHP

/*
This class was made by Ernani Joppert Pontes Martins.
It can be shared among others through the BSD Licence.
Author Name: Ernani Joppert Pontes Martins
Email: ernani@php.net
*/

global $UnreadMessagesInFolder;

class COutLook
{
	// function for retreiving messages from the selected folder (Inbox or Outbox)
	function getMessages($folder)
	{
		// Setup the folder table, there is 4 elements:
		// message number, message subject, message type and date received

		echo '
		<body text="darkblue">
		<br><font color="red" face="verdana" size="3"><b>$folder</b></font>
		<table width="100%">
			<tr bgcolor=#EEEFFF>
				<td><font face="verdana" size="2">N:</font></td>
				<td><font face="verdana" size="2">Subject:</td>
				<td><font face="verdana" size="2">Type:</td>
				<td><font face="verdana" size="2">Date:</td>
			</tr>';

		// Creating the COM instance for Outlook.application and MAPI session(access the outlook folders object)
		$oOutlook = new COM("Outlook.Application");
		$session = new COM("MAPI.Session");

		// If you have installed Exchange server you must login 
		// in your account when you create the session
		// $session->Logon("your name","your password", true or false for the show the logon dialog);

		// Log into the session like default user 
		$session->Logon();

		// Selecting working folder Inbox or Outbox
		$inb = $session->$folder;
		
		// Get the total messages in Folder
		$messages = $inb->Messages->Count();

		// Get the elements of the message object
		for($i=1; $i<($messages+1); $i++)
		{
			$item = $inb->Messages->item($i);

			// Date string
			$timeres = $item->TimeReceived();
			$date_vb = getdate($timeres);

			// Date elements
			$year = $date_vb['year'];
			$month = $date_vb['mon'];
			$day = $date_vb['mday'];

			// Entering the folder elements
			echo '
			<tr bgcolor="#F0F0F0">
				<td><font face="verdana" size="2" color="darkblue">'. $i .'</font></td>
				<td><font face="verdana" size="2" color="darkblue"><a href="view.php?id='. $i .'&folder='. $folder .'target="bottomFrame">
				    <font face="verdana" size="2" color="#FF6666">'. $item->Subject .'</font>
				</td>
				<td><font face="verdana" size="2" color="darkblue">'. $item->Type .'</font></td>
				<td><font face="verdana" size="1" color="darkblue">'. $year .'/'. $month .'/'. $day .'</font></td>
			<tr>';
		}

		echo"</table>";
	}

 
	// view mesage from selected folder (Inbox or Outbox) 
	
	function ViewMessageFromFolder($id, $folder)
	{
		// Create new instance of the COM Objects
		$oOutlook = new COM("Outlook.Application");
		$session = new COM("MAPI.Session");

		// If you have installed Exchange server you must login 
		// in your account when you create the session
		// $session->Logon("your name","your password", true or false for the show the logon dialog);

		// Log into the current working session
		$session->Logon();

		// Get default folder
		$inb = $session->$folder;

		if($id == "")
		{
			echo '
			<font face="verdana" size="2' color="darkblue">Message Viewer</font>
			<br><font face="verdana" size="2" color="red">
			<center>No Messages Selected</center></font>';
		else
		{
			$idint = (int)$id;

			// Get the messages in the selested folder
			$items = $inb->Messages->item($idint);

			// Make message status read = true
			$items->Unread = "false";

			// Update the message status into Outlook's Inbox
			$items->Update(true);

			// display the message
			echo '
			<font face="verdana" size="2" color="darkblue">Message Viewer</font>';

			echo '
			<table width="100%">
				<tr>
					<td><font face="verdana" size="2" color="darkblue">'. $i .'</font></td>
					<td><font face="verdana" size="2" color="darkblue"><b>'. $items->Subject .'</b></font></td>
					<td><font face="verdana" size="2" color="darkblue">'. $items->Type .'</td>
					<td></td>
				</tr>
				<tr>
					<td colspan="4">
						<pre>
							'. $items->Text .'
						</pre>
					</td>
				</tr>';
		}
	}

	function getUnreadinInbox()
	{
		// Get unread messages from the Inbox Folder
		$oOutlook = new COM("Outlook.Application");
		$oNs = $oOutlook->GetNamespace("MAPI");
		$oFldr = $oNs->GetDefaultFolder(olFolderInbox);
		$UnreadMessagesInFolder = $oFldr->UnReadItemCount;
		return $UnreadMessagesInFolder;
	}

	function getUnreadinOutbox()
	{
		// Get unread messages from the Outbox Folder
		$oOutlook = new COM("Outlook.Application");
		$oNs = $oOutlook->GetNamespace("MAPI");
		$oFldr = $oNs->GetDefaultFolder(olFolderOutbox);
		$UnreadMessagesInFolder = $oFldr->UnReadItemCount;
		return $UnreadMessagesInFolder;
	}

	function staticFolders()
	{
		// List of the avaailable folders (static !!!)
		$unread = $this->getUnreadinInbox();
		$out_unr = $this->getUnreadinOutbox();
		echo '
		<font color="blue" face="verdana" size="1">
			Available folders in this version are:
		</font>
		<a href="comunread.php?folder=Inbox">Inbox(<font color="red">'. $unread .'</font>)</a>
		<font color="blue" face="verdana" size="1">and</font>
		<a href="comunread.php?folder=Outbox">Outbox(<font color="red">'. $out_unr .'</font>)</a>';
	}

	// End of classs
}

?>