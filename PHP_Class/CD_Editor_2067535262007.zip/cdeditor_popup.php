<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Editor Popup</title>
<style type="text/css">
<!--
/* bbcode and smiles */
	.BBcodeBody { /* bbcode body */
		padding:4px;color:#000;
		background:#dde1e3 url(blue/bbcode_bg.png);border:1px solid #90a1a9;}
	.SmilesBody { /* emoticon body */
		padding:4px;border: 1px solid #90a1a9;
	} 
	.bbcode_code { /* bbcode defs */
		font-family:Courier,sans-serif;color:#246722;
		background-color:#fafafa;border:1px solid #a3b5c2;padding:4px;
	} 
	.bbcode_quote {
		font-family:Arial, Helvetica, sans-serif;color:#444444;
		background-color:#fafafa;border:1px inset #96a7b4;padding:4px;
	}
	.bbcode_helpline{background-color:#dadcde;border-style:none;}
	.bbcode_btn {
		font:bold 0.8em Tahoma,helvetica,sans-serif;color:#373737;
		background:url(blue/bbcode_button.gif)repeat-x;
		border:1px solid;border-color:#b6cbdd #4d687d #41596b #b1c7da;
	}
	.bbcode_btn_down {
		font:bold 0.8em Tahoma,helvetica,sans-serif;color:#114056;
		background:url(blue/bbcode_button_dwn.gif)repeat-x;
		border:1px solid;border-color:#aac1d5 #465d6f #374c5b #aabecf;
	}
	.bbcode_dropdown{font-size:0.9em;border:1px solid #aac1d5;background:#f8f8f8;}

-->
</style>
</head>

<body>
<?php
	switch ( $_GET['a'])
	{
		case 'image':
			new_image();
			break;
	
	}

function new_image()
{
?>
<div class="bbcode_code" align="center">Define Image</div>
<form action="" method="post" enctype="multipart/form-data" name="theform" id="theform">
<table border="0" cellspacing="0" cellpadding="2" class="BBcodeBody">
  <tr>
    <td >Name</td>
    <td ><input type="text" name="name" id="name" size="32" /></td>
    <td>Use Map</td>
    <td>
      <input type="text" name="usemap" id="usemap" size="32" />
    </td>
  </tr>
  <tr>
    <td>Value</td>
    <td><input type="text" name="value" id="value" size="32" /></td>
    <td>Hor. Space</td>
    <td><input type="text" name="hspace" id="hspace" size="6"/></td>
  </tr>
  <tr>
    <td>Source</td>
    <td>
      <input type="file" name="imagesource" id="imagesource" />
    </td>
    <td>Vert. Space</td>
    <td><input type="text" name="vspace" id="vspace" size="6"/></td>
  </tr>
  <tr>
    <td>Align</td>
    <td>
    <select name="align">
      <option value="baseline">Baseline</option>
      <option value="top">Top</option>
      <option value="middle">Middle</option>
      <option value="bottom">Bottom</option>
      <option value="textop">Textop</option>
      <option value="absolute middle">Absolute Middle</option>
      <option value="absolute bottom">Absolute Bottom</option>
      <option value="left">Letf</option>
      <option value="right">Right</option>
    </select>
    </td>
    <td>Height</td>
    <td><input type="text" name="height" id="height" size="6"/></td>
  </tr>
  <tr>
    <td>Alt</td>
    <td><input type="text" name="alt" id="alt" size="32" /></td>
    <td>Width</td>
    <td><input type="text" name="width" id="width" size="6"/></td>
  </tr>
  <tr>
    <td>Title</td>
    <td><input type="text" name="title" id="title" size="32" /></td>
    <td>Border</td>
    <td>
      <input type="text" name="border" id="border" size="6"/>
    </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>
      <input type="submit" name="button" id="button" value="Submit" />
    </td>
    <td>Disable</td>
    <td><label>
      <input type="checkbox" name="disable" id="disable" />
    </label></td>
  </tr>
</table>
</form>
<?php
}
?>

</body>
</html>
