// Javascript for the PM Quick Reply MOD by Rondom <rondom@arcor.de> http://www.rondom.gu2.info
// Based on Editor Mod by Smartor <smartor_xp@hotmail.com> http://smartor.is-root.com
// and Advanced Quick Reply by Rusty Dragon <dev@RustyDragon.com>
// Don't remove these comments!

// set text area field name in calling file eg:
// var tafld='TEXT AREA NAME';

// 05/25/2007	Portions (c) Chuckmachi cmunao@codersdepot.com 2007
// This is a derivitive of some bbcode that I found on the internet.
// Wherever it was in the original, I have kept the credit to the original authors.
// V1.3.1


var tafld;


var clientPC = navigator.userAgent.toLowerCase();
var clientVer = parseInt(navigator.appVersion);

var is_ie = ((clientPC.indexOf("msie") != -1) && (clientPC.indexOf("opera") == -1));
var is_clip_able = ((clientPC.indexOf("msie") != -1));
var is_nav  = ((clientPC.indexOf('mozilla')!=-1) && (clientPC.indexOf('spoofer')==-1)
                && (clientPC.indexOf('compatible') == -1) && (clientPC.indexOf('opera')==-1)
                && (clientPC.indexOf('webtv')==-1) && (clientPC.indexOf('hotjava')==-1));

var is_win   = ((clientPC.indexOf("win")!=-1) || (clientPC.indexOf("16bit") != -1));
var is_mac    = (clientPC.indexOf("mac")!=-1);
var bb_open = new Array(3);


if (window.Event){
  document.captureEvents(Event.KEYDOWN);
  document.captureEvents(Event.KEYUP);
}
document.onkeydown = cdeKeyDown;
document.onkeyup = cdeKeyUp;

var ctrl_pressed = false;
var shift_pressed = false;


function getFormName(form)
{
	alert(form.name);
	var str='';
	for (var x=0; x < document.forms.length;x++)
		str+=document.forms[x].name+'\n';
	
	alert(str);
}


function shortSetSample(frm,fld,value)
{
// alert('Form='+fm+'\nFLD='+fld+'\nValue='+value);
var sample=fld+'_sample';
 //sample=document[frm][sample].className=value;
 document.getElementById(sample).className=value;
}





function cde_getTextarea()  {
	var textarea;
 	 var areas = document.getElementsByTagName("textarea");
		for (var i=0; i<areas.length; i++)  {
			if (areas[i].name==tafld)  {
				textarea = areas[i];
				//alert('tafld='+tafld+'\narees-i-name='+areas[i].name);
				break;
			}
		}

	return textarea;
}

function cde_getTextareaSelection()  {
  var sel;
	if (is_ie)  {
    var range = document.selection.createRange();
		sel = range.text; // Get text selection
	} else {
		sel = window.getSelection(); // Get text selection
		if (sel == "") {
			var textarea = cde_getTextarea();
			sel = textarea.value.substr(textarea.selectionStart,textarea.selectionEnd-textarea.selectionStart);
		}
	
	}

	return sel;
}

function cde_quoteSelection() {
	var textarea = cde_getTextarea();
	var theSelection = cde_getTextareaSelection();
	if (theSelection == '')  {
		if (bb_open[2])  {
			bb_open[2] = false;
			cde_PostWrite('[/quote]');
		} else {
			bb_open[2] = true;
			cde_PostWrite('[quote]');
		}
	} else {
		// Add tags around selection
		cde_PostWrite( '[quote]' + theSelection + '[/quote]');
	}
	return;
}

function cde_setClicked(id)  {


return;
//Not used because of multiple.
	if (id == 'strong') 	var bbcid=0;
	if (id == 'i') 			var bbcid=1;
	if (id == 'quote') 		var bbcid=2;
    if (id == 'center') 	var bbcid=3;
    if (id == 'code') 		var bbcid=4;
    if (id == 'list') 		var bbcid=5;
    if (id == 'olist=') 	var bbcid=6;
    if (id == 'color') 		var bbcid=7;
    if (id == 'size') 		var bbcid=8;
    if (id == 'u') 			var bbcid=9; 
    if (id == 'hr') 		var bbcid=10;
    if (id == 'pre') 		var bbcid=11;
	if (id == 'div') 		var bbcid=12;
	if (id == 'br') 		var bbcid=13;
	if (id == 'tb') 		var bbcid=14;
	if (id == 'form') 		var bbcid=15;
	if (id == 'tfield') 	var bbcid=16;
	if (id == 'hfield') 	var bbcid=17;
	if (id == 'cbox') 		var bbcid=18;
	if (id == 'radio') 		var bbcid=19;
	if (id == 'tarea') 		var bbcid=20;
	if (id == 'label') 		var bbcid=21;
	if (id == 'file') 		var bbcid=22;
	if (id == 'fset') 		var bbcid=23;
	if (id == 'span') 		var bbcid=24;
	if (id == 'css') 		var bbcid=24;
  
	  if (bb_open[bbcid])
		document.getElementById(id).className = 'bbcode_btn_down';
	  else
		document.getElementById(id).className = 'bbcode_btn';

}
function cde_emoticon(text) {
 
if (!tafld)
	var txtarea = document.getElementById('tafld').value;
else
	var txtarea=tafld;

var form = document.getElementById('formname').value;
       text = ' ' + text + ' ';
        if (document[form][txtarea].createTextRange && document[form][txtarea].caretPos) {
                var caretPos = document[form][txtarea].caretPos;
                caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ? caretPos.text + text + ' ' : caretPos.text + text;
                document[form][txtarea].focus();
        } else {
                document[form][txtarea].value  += text;
                document[form][txtarea].focus(); 
        } 
}


function cde_bbfontstyle(bbopen, bbclose) {
	var textarea = cde_getTextarea();
	var theSelection = cde_getTextareaSelection();
	if (!theSelection) {
		textarea.value += bbopen + bbclose;
		textarea.focus();
		return;
	}
	cde_PostWrite(bbopen + theSelection + bbclose);
	textarea.focus();
	return;
}

function storeCaret(textEl) {
	if (is_ie)  {
		if (!textEl) textEl = cde_getTextarea();
		if (textEl.createTextRange) 
			textEl.caretPos = document.selection.createRange().duplicate();
	}
}

function cde_PostWrite(text) {
	var textarea = cde_getTextarea();
	if (is_ie) {
		if (textarea.caretPos)  {
			var caretPos = textarea.caretPos;
			caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ?	text + ' ' : text;
			caretPos.collapse(false);
			textarea.focus(caretPos);
		} else cde_insertAtCursor(textarea,text);
		return;
	} else if (textarea.setSelectionRange) {
		   var len = textarea.selectionStart;
		   textarea.value = textarea.value.substr( 0,len) + textarea.value.substr(textarea.selectionEnd,textarea.value.length);
		   textarea.value = textarea.value.substr( 0, len ) + text + textarea.value.substr( len );
       textarea.selectionStart = len + text.length;
       textarea.selectionEnd = len + text.length;
//		   textarea.setSelectionRange(len,len+text.length);
	} else cde_insertAtCursor(textarea.text);
//	textarea.focus()
}

function newObject(textarea,bbcname,value,type)
{

	bbcsWinPop2('gmcms/includes/bbcode_cde_popup.php?a='+type, 'Pop1', 600, 250, 0,0, 'false')
}

function cde_IMAGE(textarea,bbcname,value,alt) {
	tafld=textarea;

	var spectoken = new Array();
	var textarea = cde_getTextarea();
	var theSelection = cde_getTextareaSelection();
	if (theSelection != '') {
		if (bbcname.indexOf('=') > -1 )
		{
			spectoken=bbcname.split('=');
			cde_PostWrite("<font " + bbcname +'"'+value +'"'+">"  + theSelection + "</font>");
		} else {
			cde_PostWrite("<" + bbcname +">" + theSelection + "</"+ bbcname+">");
		}
		return;
	}
	ToAdd="<img src=\"" + value +"\" alt=\""+alt + "\" title=\"" +alt +"\" />";
	cde_PostWrite(ToAdd);	
}

function cde_BBC(textarea,bbcname,value) {
	tafld=textarea;
	
	var spectoken = new Array();
	var textarea = cde_getTextarea();
	var theSelection = cde_getTextareaSelection();
	if (theSelection != '') {
		if (bbcname.indexOf('=') > -1 )
		{
			spectoken=bbcname.split('=');
			cde_PostWrite("<font " + bbcname +'"'+value +'"'+">"  + theSelection + "</font>");
		} else {
			cde_PostWrite("<" + bbcname +">" + theSelection + "</"+ bbcname+">");
		}
		return;
	}
	if (bbcname == 'strong') 			var bbcid=0;
	if (bbcname == 'i') 				var bbcid=1;
	if (bbcname == 'quote') 			var bbcid=2;
	if (bbcname == 'center') 			var bbcid=3;
	if (bbcname =='code') 				var bbcid=4;
	if (bbcname =='list') 				var bbcid=5;
	if (bbcname =='olist=') 			var bbcid=6;
	if (bbcname.substr(0,4)=='color') 	var bbcid=7;
	if (bbcname.substr(0,4)=='size ') 	var bbcid=8;
	if (bbcname == 'u') 				var bbcid=9;
	if (bbcname == 'hr') 				var bbcid=10;
    if (bbcname == 'pre') 				var bbcid=11;
	if (bbcname == 'div') 				var bbcid=12;
	if (bbcname == 'br') 				var bbcid=13;
	if (bbcname == 'tb') 				var bbcid=14;
	if (bbcname == 'form') 				var bbcid=15;
	if (bbcname == 'tfield')			var bbcid=16;
	if (bbcname == 'hfield')			var bbcid=17;
	if (bbcname == 'cbox')				var bbcid=18;
	if (bbcname == 'radio')				var bbcid=19;
	if (bbcname == 'tarea')				var bbcid=20;
	if (bbcname == 'label')				var bbcid=21;
	if (bbcname == 'file')				var bbcid=22;
	if (bbcname == 'fset')				var bbcid=23;
	if (bbcname == 'span')				var bbcid=24;
	if (bbcname == 'css')				var bbcid=25;
	switch (bbcname)
	{
		case 'fset':
			ToAdd="<fieldset><legend>Legend</legend></fieldset>";
			break;
		case 'file':
			ToAdd="<input name=\"FILEFIELD\" id=\"FILEFIELD\" type=\"file\" />";
			break;
		case 'label':
			ToAdd="<label></label>";
			break;
		case 'tarea':
			ToAdd="<textarea name=\"TextArea\" id=\"TextArea\" cols=\"20\" rows=\"5\"  wrap=\"default\">YOUR TEXT</textarea>";
			break;
		case 'radio':
			ToAdd="<input name=\"Radio\" id=\"Radio\" type=\"radio\"  value=\"value\" />";
			break;
		case 'cbox':
			ToAdd="<input name=\"Checkbox\" id=\"Checkbox\" type=\"checkbox\"  value=\"Value\"  />";
			break;
		case 'hfield':
			ToAdd="<input name=\"Hidden\" id=\"Hidden\" type=\"hidden\" value=\"value\" class=\"CLASSNAME\" />";
			break;
		case 'tfield':
			ToAdd="<input name=\"FIELDNAME\" id=\"FIELDNAME\" type=\"text\" value=\"value\" size=\"32\" maxlength=\"32\" class=\"CLASSNAME\"/>";
			break;
		case 'form':
			ToAdd="<form name=\"theform\" id=\"theform\" action=\"\" method=\"post\">";
			ToAdd+="\n</form>";
			break;
		case 'hr':	
			ToAdd = "<" + bbcname + ">";
			bb_open[bbcid] = 1;
			ToAdd += "</" + bbcname + ">";
			bb_open[bbcid] = 0;
			break;
		case 'class':
			ToAdd ="class=\""+value+"\"";
			break;
		case 'div':
			ToAdd ="<div ></div>";
			break;
		case 'span':
			ToAdd ="<span ></span>";
			break;
		case 'br':
			ToAdd ="<br />";
			break;
		case 'tb':
			ToAdd ="<table width=\"100%\" border=\"0\" cellspacing=\"2\" cellpadding=\"0\">\n";
			ToAdd+="\t<tr>\n";
			ToAdd+="\t\t<td>&nbsp;</td>\n";
			ToAdd+="\t\t<td>&nbsp;</td>\n";
			ToAdd+="\t\t<td>&nbsp;</td>\n";
			ToAdd+="\t</tr>\n";
			ToAdd+="</table>\n";
			break;	
		case 'font':
			ToAdd=value;
			break;
		case 'css':
			ToAdd= "<link href=\"" + value + "\" rel=\"stylesheet\" type=\"text/css\" />";
			break;
		default:
			if (!bb_open[bbcid]) 
			{

				ToAdd = "<" + bbcname + ">";
				bb_open[bbcid] = 1;
			} else {

				ToAdd = "</" + bbcname + ">";
				bb_open[bbcid] = 0;
			}		
	}
	cde_PostWrite(ToAdd);
}

function cde_BBOList(textarea,start) {
	tafld=textarea;
	var textarea = cde_getTextarea();
	var theSelection = cde_getTextareaSelection();
	if (theSelection != '')	
		var ToAdd = "<ol start=\""+start+"\">"+theSelection+"</ol>";
	else
		var ToAdd = "<ol start=\""+start+"\">"+"</ol>";
	cde_PostWrite(ToAdd);
	textarea.focus();
}


function cde_BBCurl(textarea) {
	tafld=textarea;
	var textarea = cde_getTextarea();
	var enterTITLE = cde_getTextareaSelection();
	var FoundErrors = '';
	var enterURL   = prompt("Please enter the URL to link to", "http://");
	if (!enterURL || enterURL == 'http://')    {
		FoundErrors += "Please enter a URL to link to";
	}
	if (FoundErrors)  {
		alert(FoundErrors);
		return;
	}
	if (enterTITLE != '')
		var ToAdd = "<a href=\""+enterURL+"\" target=\"_blank\">"+enterTITLE+"</a>";
	else var ToAdd = "<a href=\""+enterURL+"\" target=\"_blank\">"+enterURL+"</a>";
	cde_PostWrite(ToAdd);
	textarea.focus();
}

function cde_BBCimg(textarea) {
	tafld=textarea;
	var textarea = cde_getTextarea();
	var FoundErrors = '';
	var theSelection = cde_getTextareaSelection();
	if (theSelection == '')
		var enterURL   = prompt("Please enter the image to include","http://");
	else var enterURL = theSelection;
	if (!enterURL || enterURL == 'http://') {
		FoundErrors += "Please enter the address of the image to include";
	}
	if (FoundErrors) {
		alert(FoundErrors);
		return;
	}
	var ToAdd = "<img src= \""+enterURL+"\" />";
	cde_PostWrite(ToAdd);
	textarea.focus();
}

function cde_BBCattachment(src,textarea) {
	tafld=textarea;
	var textarea = cde_getTextarea();
	var FoundErrors = '';
	var theSelection = cde_getTextareaSelection();
	
	var ToAdd = "<img src= \""+src+"\" />";
	cde_PostWrite(ToAdd);
	textarea.focus();
}

function cde_BBCImage(src,textarea) {
	tafld=textarea;
	var textarea = cde_getTextarea();
	var FoundErrors = '';
	var theSelection = cde_getTextareaSelection();
	
	var ToAdd = "<img src= \""+src+"\" />";
	cde_PostWrite(ToAdd);
	textarea.focus();
}



function cde_BBUploadCattachment(src,textarea,form) {
	tafld=textarea;
	document[form].textchanged.value='T';
	var str=new Array();
	str=src.split('\\');
	var path=document[form].attachment_path.value;
	var attachment=str[str.length-1];
	var textarea = cde_getTextarea();
	var FoundErrors = '';
	var theSelection = cde_getTextareaSelection();
	
	var ToAdd = "<img src= \""+path+attachment+"\" />";
	cde_PostWrite(ToAdd);
	textarea.focus();
}



function cde_checkForm() {
	var textarea = cde_getTextarea();
	formErrors = false;
	if (textarea.value.length < 2) {

		formErrors = 'You must enter a message when posting.';
	}
	if (formErrors) {
		alert(formErrors);
		return false;
	} else {
		return true;
	}
}

function cde_insertAtCursor(myField, myValue) {
  //IE support
  if (document.selection) {
    myField.focus();
    sel = document.selection.createRange();
    sel.text = myValue;
  }
  //MOZILLA/NETSCAPE support
  else if (myField.selectionStart || myField.selectionStart == '0') {
    var startPos = myField.selectionStart;
    var endPos = myField.selectionEnd;
    myField.value = myField.value.substring(0, startPos)
    + myValue
    + myField.value.substring(endPos, myField.value.length);
    myField.selectionStart = startPos + myValue.length;
    myField.selectionEnd = endPos + myValue.length;
  } else {
    myField.value += myValue;
  }
}

function cdeKeyDown(e){
  if (window.Event){
    mykey = e.which;
  }
  else{
    mykey = event.keyCode
  }
  switch (mykey)  {
    case 17: // ctrl
      ctrl_pressed = true;
      break;
    case 16: // shift
      shift_pressed = true;
      break;
    case 66: // B
      if (ctrl_pressed && shift_pressed)  {
        cde_BBC(tafld,'strong','');
        cde_setClicked('strong');
        ctrl_pressed = false;
        shift_pressed = false;
        break;
      }
      break;
    case 81: // Q
      if (ctrl_pressed && shift_pressed)  {
        cde_quoteSelection();
        cde_setClicked('quote');
        ctrl_pressed = false;
        shift_pressed = false;
        break;
      }
      break;
    case 73: // I
      if (ctrl_pressed && shift_pressed)  {
        cde_BBC(tafld,'i','');
        cde_setClicked('i');
        ctrl_pressed = false;
        shift_pressed = false;
        break;
      }
      break;
    case 76: // L
      if (ctrl_pressed && shift_pressed)  {
        cde_BBCurl();
        ctrl_pressed = false;
        shift_pressed = false;
        break;
      }
      break;
    default:
    break;
  }
}

function cdeKeyUp(e){
  if (window.Event){
    mykey = e.which;
  }
  else{
    mykey = event.keyCode
  }
  if (mykey == 17)  {
    ctrl_pressed = false;
  } else if (mykey == 16)  {
    shift_pressed = false;
  }
}

function cde_GetParentForm(e) {	// used for bbcode_symbols_dropdown()
	var targ;
	if (!e) var e = window.event;
	if (e.target) targ = e.target; 
	else if (e.srcElement) targ = e.srcElement;
	if (targ.nodeType == 3) { // Safari bug work-around
		targ = targ.parentNode;
	}
	targ = targ.parentNode;
    while (targ.tagName != "FORM") {
		targ = targ.parentNode;
	}
	return targ;
}

function cde_symbol(e) {
	var ThisForm = cde_GetParentForm(e);
	var myindex = ThisForm.dropdown.selectedIndex;
	var symbol = ThisForm.dropdown.options['myindex'].value;
	cde_InsertText(e, symbol);
}

// insert text at current caret position..
// [will replace current selection]

function cde_InsertText(e, text) {

	// grab the textarea element from the current form..
	textarea = GetParentFormTextarea(e);
	StoredUndo = textarea.value;

	// IE...
	if (typeof(textarea.caretPos) != "undefined") { 
		var caretPos = textarea.caretPos;
		caretPos.text = text;
		caretPos.select();
		textarea.focus();

	// Mozish...
	} else if (typeof(textarea.selectionStart) != "undefined") { 
		var begin = textarea.value.substr(0, textarea.selectionStart);
		var end = textarea.value.substr(textarea.selectionEnd);
		var scrollPos = textarea.scrollTop;
		textarea.value = begin + text + end;
		textarea.scrollTop = scrollPos;
		textarea.setSelectionRange(begin.length + text.length, begin.length + text.length );
		textarea.focus();

	// whateva..
	} else {
		textarea.value += text;
		textarea.focus(textarea.value.length - 1);
	}
}

var popUpWin=0;

function cdeWinPop2(URLStr, Name, left, top, width, height)

{

  if(popUpWin)

  {

    if(!popUpWin.closed) popUpWin.close();

  }

  popUpWin = open(URLStr, 'popUpWin', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,copyhistory=yes,width='+width+',height='+height+',left='+left+', top='+top+',screenX='+left+',screenY='+top+'');

}



function cdeWinPop2XX(theURL, Name, popW, popH, left,up, scrollbar) { // V 1.0
var winleft;
var winUp;

if (winleft==null)
	 winleft = (screen.width - popW) / 2;
else
	winleft=left;
	
if (winUp==null)
	winUp = (screen.height - popH) / 2;
else
	winUp=up;
	
//winProp = 'width='+popW+','height='+popH+',left='+winleft+',top='+winUp+',scrollbars='+scrollbar+',resizable,menu=yes,toolbars=yes'

Win = window.open(theURL, Name, 'toolbar = no, status = no');
if (parseInt(navigator.appVersion) >= 4) { Win.window.focus(); }
}
