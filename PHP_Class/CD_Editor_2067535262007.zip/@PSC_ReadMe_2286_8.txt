Title: CD Editor Control
Description: This is a simple cross browser (tested on Mozilla/IE) php editor control written in PHP and javascript. 
In the past I have tried and tried again several of the free javascript editors with the same results.
They are excellent, no doubt about it, but for my needs, they were too bloated and in some cases a bit slow. 
This is by noway a replacement or even a comparison between any javascript editors. 
CD Editor Control is a simple but effective alternative which profiles a low foot print.
It is an extension to BBCode. All credit should be given to those who created it. I found some BBCode php/ js files on the internet and decided that this principle could be applied to a simple editor control for text and HTML syntax.

This is a first release and I hope others will find it useful.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=2286&lngWId=8

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
