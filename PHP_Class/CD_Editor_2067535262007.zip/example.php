<?php 
// 1 ----- Include the controls source code.
include ('cdeditor.php'); 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>CD Editor Control Example</title>
<!-- displayHTML(form) Function -->
<!-- Original:  nsabs@1nsyncfan.com  -->
<!-- Web Site:  http://www.envy.nu/gjelly -->
<!-- This script and many more are available free online at -->
<!-- The JavaScript Source!! http://javascript.internet.com -->
<script language="JavaScript" type="text/javascript">
<!--


function displayHTML(form,tarea) 
{
	var inf = form[tarea].value;
	win = window.open(", ", tarea+'_popup', 'toolbar = no, status = no');
	win.document.write("" + inf + "");
}

//-->
</script> 

<!-- 2 --------- Include the controls javascript file -->
<script language="javascript" type="text/javascript" src="cdeditor.js"></script>
<link href="cdeditor.css" rel="stylesheet" type="text/css" />

</head>

<body>

<a href="http://www.codersdepot.com" title="Codersdepot.com"><img src="../../gmcms/templates/code/blue/logo.png" border="0" alt="Codersdepot.com" /></a>
<hr />
<div align="center" class="ColHeader">CD Editor Control Sample V1.3.1</div>
<form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post" name="theform" id="theform">
    <?php
		// 3 ------- Place the function calls WITHIN your form
    	display_cdedit_control('cdeditor.css','theform','your_text',$attach=true,$value='');
    	display_smiles('your_text');
    ?>
    <!-- This is the Text Area that is passed to the control -->
    <textarea name="your_text"  id="youre_text" cols="70" rows="20" onKeyUp="storeCaret(this)" onSelect="storeCaret(this);" onClick="storeCaret(this);" ></textarea>
    <input type="button" value=" view " onclick="displayHTML(this.form,'your_text')" />
</form>
<?php
/*							To Demonstrate Multiple instances  un comment this section
<hr />
<form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post" name="theform2" id="theform2">
	<script language="JavaScript" type="text/javascript">
    <!--
        tafld='your_text';
    //-->
    </script> 
    <?php
    display_cdedit_control('cdeditor.css','theform2','this_text',$attach=false,$value='');
    display_smiles();
    ?>
    
    <textarea name="this_text"  id="this_text" cols="70" rows="20" onKeyUp="storeCaret(this)" onSelect="storeCaret(this);" onClick="storeCaret(this);" ></textarea>
    <input name="textchanged" type="hidden" value="" /> <!-- This must be in each form  -->
    <input type="button" value=" view " onclick="displayHTML(this.form,'this_text')">

</form>
*/
?>
</body>
</html>
