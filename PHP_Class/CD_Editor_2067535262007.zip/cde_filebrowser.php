<?php


class filebrowser {
/*  File Browser Class by Andy Gajetzki andrewg@athabascau.ca

Security problem - Since PHP is above any access restrictions it will read any directory.
         Eg. /cgi-bin/


If $dir has starting or trailing /, wont work

Any comments/suggestions/flames

$lisdirectory = new filebrowser;
$lisdirectory->fmtdir("$argv[0]", $SERVER_NAME, $DOCUMENT_ROOT, $PHP_SELF);

*/


    function fmtdir($dir,$SERVER_NAME,$root,$self) {
        #some vars
        $linesep = "<br />";
        $homedir = "";      ##Relative to http://localhost/
		$imagepath = 'images'; ##Relative to http://localhost/
		
		global $fmode;
		global $param;
		global $row_Config;
		//echo 'MODE=' . $_POST['fmode'];
		
        #strip trailing / in path
        $docroot = (substr($root, 0, (strrpos($root, "/"))));
        $path = "$docroot$dir";
		
		
        $self = basename($self);
        ##Is the passed value a dir? If it is not, catch inf loop
        if (($validdir=is_dir($path)) == true) {


            ## One of those  Home > Blah > Blah > . COuldnt get it to work.
            ##Its a directory, so...
            if ($dir == ""){ }
            ##Build directory tree
            else { }



			// Table definition is here
			echo '<hr noshade>';
			
            print("<table width=\"100%\" cellpadding=\"1\" cellspacing=\"0\" >");

            #sort dir / and fmt contents
            $handle=opendir($path);
            while ($file = readdir($handle))
            $filelist[count($filelist)] = $file;
            sort($filelist);
            closedir($handle);
            clearstatcache ();

            for ($incr = 0; $incr < (sizeof($filelist)); $incr++) {
				$cbok=false;
                $file = $filelist[$incr];
                #stuff for images
                #make sure we determine image with last extension. eg. blah.ixml.php
                #Its very easy to add extra filetype's.
                $fileext=explode(".", $filelist[$incr]);
				if ($_GET['t'])
				{
					if (($fileext[(sizeof($fileext)) - 1]) <> $_GET['t']) {continue;}
				
				}
				// EXCEMPT LIST
				if (($fileext[(sizeof($fileext)) - 1]) == "LCK") {continue;}
				if (($fileext[(sizeof($fileext)) - 1]) == "db") {continue;}
				if (($fileext[(sizeof($fileext)) - 1]) == "gz") {continue;}
				if (($fileext[(sizeof($fileext)) - 1]) == "tar") {continue;}
				if (($fileext[(sizeof($fileext)) - 1]) == "ico") {continue;}
				//if ($_POST['fmode'] == 'TPL' && $argv[0])
				if ( ($_GET['a'] == 'TPL' || $_GET['a'] == 'ACTTPL' || $_GET['a'] =='SQL') && $param[0] <> '/')
					if (($fileext[(sizeof($fileext)) - 1]) == "tpl")
					 {
					  $fclass='tpl';
					 } else {
					 	$fclass='norm';
					 }
				if ( ($_GET['a'] == 'CAF' || $_GET['a'] == 'ACTCAF') && $param[0] <> '/')
					if (($fileext[(sizeof($fileext)) - 1]) == "php") 
					 {
					  $fclass='caf';
					 } else {
					 	$fclass='norm';
					 }

				if ( ($_GET['a'] == 'IMG' || $_GET['a'] == 'GIMG' || $_GET['a'] == 'TMCE')  && $param[0])
				{
					  $fclass='img';
				
					if (($fileext[(sizeof($fileext)) - 1]) == "gif") {$image = $file;}// } else {continue;}
                	if (($fileext[(sizeof($fileext)) - 1]) == "jpg") {$image = $file;}// } else {continue;}
	               	if (($fileext[(sizeof($fileext)) - 1]) == "png") {$image = $file;}// } else {continue;}				
					if (($fileext[(sizeof($fileext)) - 1]) == "txt")  {$image = "filetype_php.gif";}
					if (($fileext[(sizeof($fileext)) - 1]) == "zip")  {$image = "filetype_zip.gif";}
					if (($fileext[(sizeof($fileext)) - 1]) == "html") {$image = "filetype_html.gif";}
					if (($fileext[(sizeof($fileext)) - 1]) == "htm")  {$image = "filetype_html.gif";}				
					if (($fileext[(sizeof($fileext)) - 1]) == "pdf")  {$image = "filetype_acrobat.gif";  }
					if (($fileext[(sizeof($fileext)) - 1]) == "rar")  {$image = "filetype_rar.gif";}
					if (($fileext[(sizeof($fileext)) - 1]) == "php")  {$image = "filetype_php.gif"; $cbok=true;}
					if (($fileext[(sizeof($fileext)) - 1]) == "tpl")  {$image = "filetype_template.gif"; $cbok=true;}
					if (($fileext[(sizeof($fileext)) - 1]) == "css")  {$image = "filetype_css.gif";} 
					if (($fileext[(sizeof($fileext)) - 1]) == "mid")  {$image = "filetype_midi.gif";}
					if (($fileext[(sizeof($fileext)) - 1]) == "wav")  {$image = "filetype_music_stuff.gif";}


				} // if ( ($_GET['a'] == 'IMG' || $_GET['a'] == 'GIMG')  && $param[0])
				
				if ( ($_GET['a'] <> 'IMG' && $_GET['a'] <> 'GIMG' && $_GET['a'] <> 'TMCE') && $param[0])
				{
								
					if (($fileext[(sizeof($fileext)) - 1]) !== "DONTMATCHTHISPLEASEORELSE") {$image = "question_mark_sm.gif";}
					if (($fileext[(sizeof($fileext)) - 1]) == "txt")  {$image = "filetype_php.gif";}
					if (($fileext[(sizeof($fileext)) - 1]) == "zip")  {$image = "filetype_zip.gif";}
					if (($fileext[(sizeof($fileext)) - 1]) == "html") {$image = "filetype_html.gif";}
					if (($fileext[(sizeof($fileext)) - 1]) == "htm")  {$image = "filetype_html.gif";}				
					if (($fileext[(sizeof($fileext)) - 1]) == "pdf")  {$image = "filetype_acrobat.gif";  }
					if (($fileext[(sizeof($fileext)) - 1]) == "rar")  {$image = "filetype_rar.gif";}
					if (($fileext[(sizeof($fileext)) - 1]) == "php")  {$image = "filetype_php.gif"; $cbok=true;}
					if (($fileext[(sizeof($fileext)) - 1]) == "tpl")  {$image = "filetype_template.gif"; $cbok=true;}
					if (($fileext[(sizeof($fileext)) - 1]) == "css")
					  {
					  	$image = "filetype_css.gif";
						if ($_GET['a'] == 'SKIN')
							$fclass='css';
											
					  } else {
							$fclass='norm';	
					  }
					if (($fileext[(sizeof($fileext)) - 1]) == "gif")  {$image = "filetype_gif.gif";}
					if (($fileext[(sizeof($fileext)) - 1]) == "jpg")  {$image = "filetype_jpeg.gif";}
	               	if (($fileext[(sizeof($fileext)) - 1]) == "png")  {$image = "filetype_jpeg.gif";}// } else {continue;}				
					if (($fileext[(sizeof($fileext)) - 1]) == "mid")  {$image = "filetype_midi.gif";}
					if (($fileext[(sizeof($fileext)) - 1]) == "wav")  {$image = "filetype_music_stuff.gif";}
				if (($fileext[(sizeof($fileext)) - 1]) == "js")  {$image = "filetype_javascript.gif";}
				if (($fileext[(sizeof($fileext)) - 1]) == "sql")  {$image = "filetype_sql.gif";}
		
					//if (($fileext[(sizeof($fileext)) - 1]) == "png") {$image = $file;}					
					//echo $image;
				} // if ( ($_GET['a'] <> 'IMG' && $_GET['a'] <> 'GIMG') && $param[0])
				//$image='bronze_editor_small.gif';
                ##All is good, except "." and ".." showing, so away with them...
                ##Also, show directories as links to this class, so there not view with the browser.
				$vdir=$homedir . '/' . $self . '?' . $dir . '/' . $file;
				$vdir=str_replace("//","/",$vdir);
				$vimage=$imagepath .'/'.'folder3.gif';
				$vimage=str_replace("//","/",$vimage);
			    $doutput = "
                <tr>
					<td  align=\"left\">
						<div style=\"cursor:arrow\">\n
							<a href=\"$homedir/$self?$dir/$file&a=" . $_GET['a'] .'&img=' . $_GET['img'] . '&fld=' . $_GET['fld'] . '&fm=' . $_GET['fm'] . "\"><img hspace=\"5\" width=\"16\" height=\"16\" src=\"$vimage\" ></a>
						</div>
					</td>					
					<td align=\"left\">
						<div>\n									
							<a href=\"$homedir$self?$dir/$file&a=" . $_GET['a'].'&img=' . $_GET['img'] . '&fld=' . $_GET['fld'] . '&fm=' . $_GET['fm'] . "\">$file</a>
						</div>
					</td>";
					if ($_GET['a'] == 'DIR')
						{
						$f=trim($homedir).'/'.trim($dir).'/'.trim($file);
						//$folder.="/"; // needed for root folder
						$folder=str_replace("//","/",trim($f));
						
						$folder= str_replace("//","/",trim($folder));
					
						$vimage=$imagepath .'/'.'folder.sec.gif';
						$vimage=str_replace("//","/",$vimage);
						
												
						$doutput.="
						<td  align=\"left\">
							<div>\n
								<img style=\"cursor:pointer\" hspace=\"5\" width=\"16\" height=\"16\" alt=\"$folder\" src=\"$vimage\" onClick=\"select_file('','$folder')\">
							</div>
						</td>" ;
						}
				$doutput.="
					<td  align=\"right\" nowrap>&lt;DIR&gt;</td>
					<td  align=\"right\">&nbsp;</td>
	            </tr>";
				
				if ($_GET['a'] <> 'DIR')
				{
					if ($_GET['a'] == 'IMG' || $_GET['a'] == 'GIMG' ||  $_GET['a'] == 'TMCE' || $_GET['a'] == 'FILE') // GIMG is global image
					{
						
						if ($file==$image)
						{
							
							$vpath=$dir.'/'.$file;
							$vpath=str_replace("//","/",$vpath);
						} else {
							$vpath=$imagepath. '/' . $image;
							$vpath=str_replace("//","/",$vpath);						
						}
						$foutput = "
						<tr>
							<td  align=\"left\">
								<a href=\"javascript:select_file('$file','$dir');\"><img hspace=\"5\"  vspace=\"5\" src=\"$vpath\"" . " >$file</a>
							</td>
							<td  align=\"right\" nowrap>&nbsp;</td>
							<td  align=\"right\">&nbsp;</td>
							<td  align=\"right\">&nbsp;</td>							
							";						
						$foutput.="</tr>";
					} else {  // if ($_GET['a'] == 'IMG' || $_GET['a'] == 'GIMG')
						$foutput = "
						<tr>
						<td  align=\"left\" nowrap>
							<div  class=\"" . $fclass . "\">\n
								<a href=\"$dir/$file\"><img hspace=\"5\" width=\"16\" height=\"16\" src=\"$imagepath/$image\"" . " ></a>
							</div>						
						</td>
						<td  align=\"left\">
							<div  class=\"". $fclass ."\">\n						
								<a href=\"javascript:select_file('$file','$dir')\">$file</a>
							</div>							
						</td>
							<td  align=\"right\" nowrap>&nbsp;</td>
							<td  align=\"right\">&nbsp;</td>
							<td  align=\"right\">&nbsp;</td>
						</tr>";
					} // if ($_GET['a'] == 'IMG' || $_GET['a'] == 'GIMG')
				} // $_GET['a']  <> 'DIR'
				//                 	<a href=\"$dir/$file\"><img hspace=\"5\" width=\"16\" height=\"16\" src=\"$imagepath/$image\"" . " ></a>


                $curfile = "$path/$file" ;


                if (($file !== ".") && ($file !== "..") &&  (($isitadir=is_dir($curfile)) == true))
				{
				    print( $doutput);
				}
                if (($file !== ".") && ($file !== "..") && (($isitadir=is_file($curfile)) == true))
				{
                    print($foutput);
				}
            } // loop end
$iscript ="<script language=\"JavaScript\">\n";
$iscript.="<!--\n";
//$iscript.="busy = new Image();\n";
$iscript.="document.getElementById('busy').src='images/busy_short.gif'\n";
$iscript.="//-->\n";
$iscript.="</script>";
print ($iscript);
			
            print("</table>");
            }
            else { print("Fail: Not a directory");}
            }
} 
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title><?php echo $row_Config['giz_sitename'];?> File Browser</title>



<script language="JavaScript">
<!--

 function select_file(filename,path)
 {
 
	var mode=document.filebrowser.fmode.value; 
 	var tmp = filename.split('.');
	var last=tmp.length;
	var len=path.length;
	var newpath=path.substr(1,len);
	if (newpath.substr(0,1) == '/')
		newpath= newpath.substr(1,len);

	if (mode=='SKIN')
	{
	
		if (filename.indexOf("css") < 1 )
		{
			alert('You must select a css file!');
			return;
		}	
	
	}
	if (mode=='TPL')
	{
	
		if (filename.indexOf("tpl") < 1 )
		{
			alert('You must select a tpl file!');
			return;
		}	
	
	}

	if (mode=='CAF')
	{
	
		if (filename.indexOf("php") < 1 )
		{
			alert('You must select a php file!');
			return;
		}	
	
	}	

	
	if (mode=='SQL')
	{
		//alert(filename.indexOf("sql"));
		var str=new Array();
		str=filename.split('.');
		if (str.length < 1)
		{
			if (filename.indexOf("sql") < 1 )
			{
				alert('You must select a sql file!');
				return;
			}	
		} else {
			if (str[str.length-1].toUpperCase() != 'SQL')
			{
				alert('You must select a sql file!\n(filename.sql)');
				return;			
			}
		}
	
	}	
	

		
	if (mode=='CSS')
	{
	
		if (filename.indexOf("css") < 1 )
		{
			alert('You must select a css file!');
			return;
		}	
	
	}	
	
	
	if (mode=='TMCE')
	{
		var path=formatPath(newpath+'/'+filename);
		tryInsertImageUrl(path);
		return;
	
	}
		
				var form=document.filebrowser.formname.value;
				var fld=document.filebrowser.fld.value;
				
				var vfld=window.opener.document.getElementById(fld);
				//alert(vfld);
				
				var img=document.filebrowser.img.value;
				//img = new Image();
				if (img)
				{
					window.opener.document[img].src=formatPath(newpath+'/'+filename);
				}
				
				//window.opener.document[form][fld].value=newpath+'/'+filename;
				if (mode='IMG' || mode == 'CAF')
					window.opener.document[form][fld].value=formatPath(newpath+'/'+filename);
				else
					window.opener.document[form][fld].value=formatPath(newpath+filename);
				
					
				window.opener.document[form][fld].focus();
 				window.opener.document[form][fld].select();
	 			self.close ();
 }

 function winPop(theURL, Name, popW, popH, scroll) { // V 1.0
	var winleft = (screen.width - popW) / 2;
	var winUp = (screen.height - popH) / 2;
	winProp = 'width='+popW+',height='+popH+',left='+winleft+',top='+winUp+',scrollbars='+scroll+',resizable';
	Win = window.open(theURL, Name, winProp)
	if (parseInt(navigator.appVersion) >= 4) { Win.window.focus(); }

}

function tryInsertImageUrl(imgUrl) {
   var mywin = opener.tinyMCE.getWindowArg("window");
   var target_field = mywin.document.getElementById('src');
   target_field.value = imgUrl;
   window.close();
 }
 
function formatPath(value)
{
	var f=replace(value,'//','/');
	return(f);
}

function replace(string,text,by) {
// Replaces text with by in string
    var strLength = string.length, txtLength = text.length;
    if ((strLength == 0) || (txtLength == 0)) return string;

    var i = string.indexOf(text);
    if ((!i) && (text != string.substring(0,txtLength))) return string;
    if (i == -1) return string;

    var newstr = string.substring(0,i) + by;

    if (i+txtLength < strLength)
        newstr += replace(string.substring(i+txtLength,strLength),text,by);

    return newstr;
}

 
//-->
</script> 

<link href="cdeditor.css" rel="stylesheet" type="text/css">
</head>
<body>

<div align="center">
	<h2> File Browser V2.1.1</h2>
	<?php echo $_SERVER['HTTP_HOST'] . '<br />';?>
</div>

<table style="width:100%;"  cellspacing="0" cellpadding="4">
  <tr>
    <td colspan="3">
		
		&nbsp;
		<?php
			
		  	//$param=explode('&',$argv[0]);
			$param=explode('&',$_SERVER['argv'][0]);
			?>
			<img name="busy" id="busy" hspace="5" width="16" height="16" src="images/busy.gif" alt="Done" >
			<?php
			if ($param[0])
			{
		?>
			<img  src="images/folder_open.gif" width="16" height="16" hspace="5">&nbsp;
		<?php
			echo str_replace("//","/",$param[0]) ;
			}
		?>
		<hr size="1" noshade>	
    </td>
  </tr>
  <tr>
    <td style="width:65px;">
	<?php
		//if ($param[0] <> '' && $_GET['a'] <> 'TMCE')
		if ($param[0] <> '' && $_GET['disp'] <> 'f')
		{
	?>
		&nbsp;<a href="cde_filebrowser.php?/&a=<?php echo $_GET['a'] .'&img=' . $_GET['img'] . '&fld=' . $_GET['fld'] . '&fm=' . $_GET['fm'];?>" title="Root"><img hspace="5" width="16" height="16" src="images/home2.gif"></a>&nbsp;<a href="javascript:history.back();" title="Back"><img hspace="5" width="16" height="16" src="images/back.gif"></a>
	<?php
		}
	?>
	</td>
    <td>
	<?php
		switch ($_GET['a'])
		{
			case 'TPL':
			case 'ACTTPL':			
				$m='Templates';
				break;
			case 'CAF':
			case 'ACTCAF':			
				$m='Calling files';
				break;
			case 'IMG':
			case 'GIMG':
			case 'TMCE':
				$m='Images';
				break;
			case 'DIR':
				$m='Folders';
				break;
			case 'SKIN':
				$m='Templates';
				break;				
			default:
				$m='Files';
				break;						
		}
		echo 'Listing ' . $m;
	?>
	</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3">
		<form action="" method="post" name="filebrowser">&nbsp;
          <?php 
			
			$lisdirectory = new filebrowser;
			//$lisdirectory->fmtdir("$param[0]", '', $DOCUMENT_ROOT .'/', '../'. $PHP_SELF);
			$lisdirectory->fmtdir("$param[0]", '', $_SERVER['DOCUMENT_ROOT'] .'/',  $_SERVER['PHP_SELF']);
			
			?>		  
          	<input name="path"  	type="hidden"  value="<?php echo $param[0];?>" size="80">
			<input name="fmode" 	type="hidden"  value="<?php echo $_GET['a'];?>">
          	<input name="fld"  		type="hidden"  value="<?php echo $_GET['fld'];?>">
			<input name="img" 		type="hidden"  value="<?php echo $_GET['img'];?>">
			<input name="formname" 	type="hidden"  value="<?php echo $_GET['fm'];?>">
		</form>	
	
	</td>
  </tr>
</table>

</body>
</html>
