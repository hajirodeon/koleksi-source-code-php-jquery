<?php
// 05/25/2007	Portions (c) Chuckmachi cmunao@codersdepot.com 2007
// This is a derivitive of some bbcode that I found on the internet.
// Wherever it was in the original, I have kept the credit to the original authors.
// V1.3.1
// On Line Documentation : http://www.codersdepot.com/bb/viewtopic.php?t=3

function display_error($msg,$msg2,$msg3)
{
?>
	<div align="center" class="WarningText">
	<?php
		echo $msg1 . '<br />';
		echo $msg2 . '<br />';
		echo $msg3;
	?>
	</div>
<?php
}



// Call this after your form is posted.
// upload_attachment($dest,$id)
//	$dest=destination path.
//	$id is an identifier that gets prepended to the file before upload.
function upload_attachment($dest,$id)
{
	display_error('','','Uploading attachment...');
	//$rand = rand(1,30000); // Usse as an identifier if needed
	// eg:
	// if (@move_uploaded_file($file_tmp , $dest. $id . $rand .'_'. $filename ))
	// create file vars to make things easier to read.
	$filename = $_FILES['attachmentupload']['name'];
	$filesize = $_FILES['attachmentupload']['size'];
	$filetype = $_FILES['attachmentupload']['type'];
	$file_tmp = $_FILES['attachmentupload']['tmp_name'];
	$file_err = $_FILES['attachmentupload']['error'];
	$file_ext = strrchr($filename, '.');
	
	if(file_exists($dest.$filename) )
	{
		display_error('','',$filename . ' already exists!');
		return (false); 
	}
	
	if (($file_err == 0) && ($filesize != 0))
	{
		if (!$file_ext)
		{
			unlink($file_tmp);

			 display_error('','File must have an extension!','');
			 return false;			
		} // no ext

		if (is_uploaded_file($file_tmp))
		{
			if (@move_uploaded_file($file_tmp , $dest. $id .'_'. $filename ))
			{
			
			} else {// if (@move_uploaded_file($file_tmp , $filename ))
				// error moving file. check file permissions.
				unlink($file_tmp);
				display_error( '','', 'Unable to move file to designated directory.');
			} // else
 
		} else // if (is_uploaded_file($file_tmp))
		{
			// file seems suspicious... delete file and error out.
			unlink($file_tmp);
			display_error( '','','Error: File does not appear to be a valid upload. Could be a file attack.');
		} 
	} else { // else
		// Kill temp file, if any, and display error.
		if ($file_tmp != '')
		{
			unlink($file_tmp);
		} // filetmp!=""

		switch ($file_err)
		{
			case '0':
				display_error('','', 'That is not a valid file. 0 byte length.');
				break;

			case '1':
				display_error('','', 'This file, at ' . $filesize . ' bytes, exceeds the maximum allowed file size as set in <em>php.ini</em>. '.
				'Please contact your system admin.');
				break;

			case '2':
				display_error('','',  'This file exceeds the maximum file size specified in your HTML form.');
				break;

			case '3':
				display_error('','', 'File was only partially uploaded. This could be the result of your connection '.
				'being dropped in the middle of the upload.');

			case '4':
				display_error('','',  'You did not upload anything... Please go back and select a file to upload.');
				break;
		} // select  
	} // if (($file_err == 0) && ($filesize != 0))
}

// Called by cde_liststyles
function extract_style($f)
{
$fstr=ltrim($f);
$styles=explode("{",$fstr);

if ($styles[0][0] =='.' || $styles[0][0] =='#')
	return ( substr($styles[0],1,strlen($styles[0])) );
} // extract_style($f)



// This function populates a list of styles extracted from $stylesheet
// cde_liststyles($stylesheet,$listname,$fm,$textarea)
//	$stylesheet - The path/filename to the target css file
//	$listname	- The name of the select input. ID uses this argument too.
//	$fm			- The name of the form that the list is in
//	$textarea	- The name of the  textarea input field
//  eg:			- cde_liststyles('/styles/main.css/','styles_list','formname','my_text');
function cde_liststyles($stylesheet,$listname,$fm,$textarea)
{
if (!file_exists( $stylesheet))
{
	//echo 'No CSS file.';
	display_error($stylesheet,'','Not found');
	return;
	
}

global $styleidx;
$lines = file($stylesheet);
if (count($lines) < 1)
{
	echo 'No styles in file!';
	return;
}
sort($lines);
$styleidx=0;
?>

    <select name="<?php echo $listname;?>"  onChange="cde_BBC('<?php echo $textarea;?>','class',this.value);document['<?php echo $fm;?>'].textchanged.value='Y'"  >
		<option value="">Class</option>
      <?php
	// Loop through our file and find styletions.
	
	foreach ($lines as $line_num => $line)
	 {
		if (strstr($line,"{") )
		{
		$str=explode(" ",extract_style($line));
		
		
		$style=$str[0];
			if ($style <> '' && $style <> $laststyle)
			{
			?>
			  <option value="<?php echo  trim($style);?>"   onMouseOver="shortSetSample('<?php echo $fm;?>','<?php echo $listname;?>',this.value)"><?php echo substr($style,0,20);?></option>
			 <?php	
				$styleidx++;
			} // if $style
			$laststyle=$style;
		} // if (strstr($line,"styletion") )	
	 } // foreach ($lines as $line_num => $line)
	?>
    </select>
	<div id="<?php echo $listname;?>_sample" style="display:inline">CLASS SAMPLE</div>
<?php					
} // ltcfg__liststyles($filename,$listname,$fld,$fm)

// Symbols dropdown list
function cde_symbols_dropdown()
{
?>
	<select name="dropdown" onChange="if (this.value !='') cde_emoticon(this.value)" id="symbol-select" class="htmlcode_dropdown">
		<option value="" selected="selected">Symbols</option>
		<option value="&para;">&para;</option>
		<option value="&bull;">&bull;</option>
		<option value="&deg;">&deg;</option>
		<option value="[&lt;]">&lt;</option>
		<option value="[&gt;]">&gt;</option>
		<option value="&plusmn;">&plusmn;</option>
		<option value="&trade;">&trade;</option>
		<option value="&copy;">&copy;</option>
		<option value="&reg;">&reg;</option>
		<option value="[[">[</option>
		<option value="]]">]</option>
		<option value="&hellip;">&hellip;</option>
	</select>
<?php
}

// Primary control
// display_cdedit_control($stylesheet,$formname,$textarea,$attach=false,$value='')
//	$stylesheet - The path/filename to the target css file. This argument is passed to  cde_liststyles()
//	$formname	- The name of the form that the list is in
//	$textarea	- The name of the  textarea input field
//	$attach		- If true it will display a file field. Upon post, add the upload_attachment() call
//	$value		- Reserved.

function display_cdedit_control($stylesheet,$formname,$textarea,$attach=false,$value='')
{
static $ctr=0;
?>
<div class="htmlcodeBody">
		
		<input type="button" onClick="cde_BBC('<?php echo $textarea;?>','strong','');		cde_setClicked('strong');document['<?php echo $formname;?>'].textchanged.value='Y';" value="strong"  	  			id="strong" class="html_btn" alt="Ctrl+Shift+B" title="Ctrl+Shift+B" />
		<input type="button" onClick="cde_BBC('<?php echo $textarea;?>','i','');			cde_setClicked('i');document['<?php echo $formname;?>'].textchanged.value='Y';" value="I" 						id="i" class="html_btn" style="font-style: italic" alt="Ctrl+Shift+I" title="Ctrl+Shift+I" />
		<input type="button" onClick="cde_BBC('<?php echo $textarea;?>','u','');			cde_setClicked('u');document['<?php echo $formname;?>'].textchanged.value='Y';" value="U" 						id="u" class="html_btn" />
		<input type="button" onClick="cde_BBC('<?php echo $textarea;?>','center','');		cde_setClicked('center');document['<?php echo $formname;?>'].textchanged.value='Y';" value="Center" 				id="center" class="html_btn" />
		<input type="button" onClick="cde_BBC('<?php echo $textarea;?>','ul','');			cde_setClicked('ul');document['<?php echo $formname;?>'].textchanged.value='Y';" value="List" 					id="list" class="html_btn" />
		<input type="button" onClick="cde_BBC('<?php echo $textarea;?>','li','');			cde_setClicked('li');document['<?php echo $formname;?>'].textchanged.value='Y';" value="LI" 						id="li" class="html_btn" />		
		<input type="button" onClick="cde_BBOList('<?php echo $textarea;?>','1');			cde_setClicked('ol');document['<?php echo $formname;?>'].textchanged.value='Y';" value="List=" 					id="olist" class="html_btn" />
		<input type="button" onClick="cde_BBC('<?php echo $textarea;?>','blockquote','');	cde_setClicked('blockquote');document['<?php echo $formname;?>'].textchanged.value='Y';" value="Quote" 			id="quote" class="html_btn" alt="Ctrl+Shift+Q" title="Ctrl+Shift+Q" />
        <input type="button" onClick="cde_BBCurl('<?php echo $textarea;?>');				document['<?php echo $formname;?>'].textchanged.value='Y';" value="Url" 											id="link" class="html_btn" alt="Ctrl+Shift+L" title="Ctrl+Shift+L" />
        <input type="button" onClick="document.getElementById('imagediv<?php echo $ctr;?>').style.display = 'block';winPop('cde_filebrowser.php?/images&amp;a=IMG&amp;fld=image<?php echo $ctr . '&amp;fm=' . 'theform';?>','AttachmentBrowser','500','400','yes');return false;document['<?php echo $formname;?>'].textchanged.value='Y';" value="Img" id="image" class="html_btn" />
		<input type="button" onClick="cde_BBC('<?php echo $textarea;?>','p','');			cde_setClicked('p');document['<?php echo $formname;?>'].textchanged.value='Y';" value="&para;" 					id="p" class="html_btn" />
		<input type="button" onClick="cde_BBC('<?php echo $textarea;?>','pre','');			cde_setClicked('pr');document['<?php echo $formname;?>'].textchanged.value='Y';" value="Pre" 						id="pre" class="html_btn" />
		<input type="button" onClick="cde_BBC('<?php echo $textarea;?>','hr','');			cde_setClicked('hr');document['<?php echo $formname;?>'].textchanged.value='Y';" value="hr" 						id="hr" class="html_btn" />
		<input type="button" onclick="cde_BBC('<?php echo $textarea;?>','div','');			cde_setClicked('div');document['<?php echo $formname;?>'].textchanged.value='Y';" value="div" 					id="div" class="html_btn" />
		<input type="button" onclick="cde_BBC('<?php echo $textarea;?>','span','');			cde_setClicked('span');document['<?php echo $formname;?>'].textchanged.value='Y';" value="span" 					id="span" class="html_btn" />
		<input type="button" onClick="cde_BBC('<?php echo $textarea;?>','br','');			cde_setClicked('br');document['<?php echo $formname;?>'].textchanged.value='Y';" value="br" 						id="br" class="html_btn" />
		<input type="button" onClick="cde_BBC('<?php echo $textarea;?>','form','');			cde_setClicked('form');document['<?php echo $formname;?>'].textchanged.value='Y';" value="Form" 					id="form" class="html_btn" />
		<input type="button" onClick="cde_BBC('<?php echo $textarea;?>','tfield','');		cde_setClicked('tfield');document['<?php echo $formname;?>'].textchanged.value='Y';" value="TField" 				id="tfield" class="html_btn" />
		<input type="button" onClick="cde_BBC('<?php echo $textarea;?>','hfield','');		cde_setClicked('hfield');document['<?php echo $formname;?>'].textchanged.value='Y';" value="HField" 				id="hfield" class="html_btn" />
		<input type="button" onClick="cde_BBC('<?php echo $textarea;?>','cbox','');			cde_setClicked('cbox');document['<?php echo $formname;?>'].textchanged.value='Y';" value="CBox" 					id="cbox" class="html_btn" />
		<input type="button" onClick="cde_BBC('<?php echo $textarea;?>','radio','');		cde_setClicked('radio');document['<?php echo $formname;?>'].textchanged.value='Y';" value="Radio" 				id="radio" class="html_btn" />
        <input type="button" onClick="cde_BBC('<?php echo $textarea;?>','tarea','');		cde_setClicked('tarea');document['<?php echo $formname;?>'].textchanged.value='Y';" value="TArea" 				id="tarea" class="html_btn" />
        <input type="button" onClick="cde_BBC('<?php echo $textarea;?>','label','');		cde_setClicked('label');document['<?php echo $formname;?>'].textchanged.value='Y';" value="Label" 				id="label" class="html_btn" />
        <input type="button" onClick="cde_BBC('<?php echo $textarea;?>','file','');			cde_setClicked('file');document['<?php echo $formname;?>'].textchanged.value='Y';" value="File" 					id="file" class="html_btn" />
        <input type="button" onClick="cde_BBC('<?php echo $textarea;?>','fset','');			cde_setClicked('fset');document['<?php echo $formname;?>'].textchanged.value='Y';" value="FSet" 					id="fset" class="html_btn" />
        <input type="button" onclick="cde_BBC('<?php echo $textarea;?>','tb','');			cde_setClicked('tb');document['<?php echo $formname;?>'].textchanged.value='Y';" value="table" 						id="tb" class="html_btn" />
<br />
		
		  <select name="color" id="color" onChange="if (this.value !='') cde_BBC('<?php echo $textarea;?>','color=',this.value);cde_setClicked('color');document['<?php echo $formname;?>'].textchanged.value='Y';" class="htmlcode_dropdown" >
            <option value="" selected="selected" >Color</option>
			<option value="black" style="color:black">Black</option>
            <option value="silver" style="color:silver">Silver</option>
            <option value="gray" style="color:gray">Gray</option>
            <option value="maroon" style="color:maroon">Maroon</option>
            <option value="red" style="color:red">Red</option>
            <option value="purple" style="color:purple">Purple</option>
            <option value="fuchsia" style="color:fuchsia">Fuchsia</option>
            <option value="navy" style="color:navy">Navy</option>
            <option value="blue" style="color:blue">Blue</option>
            <option value="aqua" style="color:aqua">Aqua</option>
            <option value="teal" style="color:teal">Teal</option>
            <option value="lime" style="color:lime">Lime</option>
            <option value="green" style="color:green">Green</option>
            <option value="olive" style="color:olive">Olive</option>
            <option value="yellow" style="color:yellow">Yellow</option>
            <option value="white" style="color:white">White</option>
          </select>

  		 <select name="size" id="size" onChange="if (this.value !='') cde_BBC('<?php echo $textarea;?>','size=',this.value);cde_setClicked('size');document['<?php echo $formname;?>'].textchanged.value='Y';" class="htmlcode_dropdown">
			<option value="" selected="selected" >Size</option>
			<option  value="7px" >Tiny</option>
			<option  value="9px" >Small</option>
			<option  value="12px">Normal</option>
			<option  value="18px">Large</option>
			<option  value="24px">Huge</option>
			<option  value="36px">Gigantic</option>
			<option  value="48px">Humongus</option>
  		</select>
        <input type="hidden" name="helpbox" size="40" />

		<?php cde_symbols_dropdown();?>

        <select name="heading" id="heading" onChange="if (this.value !='')cde_BBC('<?php echo $textarea;?>',this.value,'');cde_setClicked('heading');document['<?php echo $formname;?>'].textchanged.value='Y';" class="htmlcode_dropdown">
			<option value="" selected="selected">Heading</option>
			<option value="h1">H1</option>
			<option value="h2">H2</option>
			<option value="h3">H3</option>
        </select>

		<?php cde_liststyles($stylesheet,$textarea.'_list','theform',$textarea);?><?php cde_display_fontlist($textarea,$formname);?>        
		<div id="imagediv<?php echo $ctr;?>" style="display:none">
			Image:	<input name="image<?php echo $ctr;?>" id="image<?php echo $ctr;?>" onFocus="cde_BBCImage(this.value,'<?php echo $textarea;?>');document.getElementById('imagediv<?php echo $ctr;?>').style.display = 'none';"  type="text" readonly="readonly"  class="FormText" />
		</div>		
		<?php
			if ($attach == true)
			{
		?>
			<br />
			Attachment 
			<input name="attachmentupload" id="attachmentupload" value="" type="file" size="40"  maxlength="255" onclick="document['<?php echo $formname;?>'].textchanged.value='Y';document['<?php echo $formname;?>'].article_attachment.value=''" class="html_btn" />
		<?php	
			}
			 //display_upload_box('theform',$textarea); 
		?>
        <input name="attach" id="attach" type="button" value="CSS" onclick="document.<?php echo $formname;?>.fmode.value='CSS';cdeWinPop2('cde_filebrowser.php?/&amp;a=CSS&amp;fld=cssbuf&amp;fm=<?php echo $formname;?>',  <?php echo $textarea;?>+'_popup', '0','0','600', '600');return false;document['<?php echo $formname;?>'].textchanged.value='Y';"  class="html_btn" />
		<input name="cssbuf" type="text" readonly="true" onfocus="cde_BBC('<?php echo $textarea;?>','css',this.value);" />
</div>	
<input name="textchanged" id="textchanged"	type="hidden" value="" /> <!-- This must be in each form  -->
<input name="tafld" 	  id="tafld"		type="hidden" value="<?php echo $textarea;?>" /> <!-- This must be in each form  -->
<input name="formname" 	  id="formname"		type="hidden" value="<?php echo $formname;?>" /> <!-- This must be in each form  -->
<input name="fmode" 	  id="fmode"		type="hidden" value="" /> <!-- This must be in each form if the file browser is used -->
<?php
$ctr++;
}


// Displays the smiles control
//	$textarea	- The name of the  textarea input field

function display_smiles($textarea)
{
?>
<table class="SmilesBody" cellspacing="0" cellpadding="4">
  <tr>
    <td align="center"><a href="javascript:cde_IMAGE('<?php echo $textarea;?>','smile','smiles/icon_biggrin.gif','Very%20Happy')"><img src="smiles/icon_biggrin.gif" alt="Very%20Happy" title="Very Happy" />		</a></td>
    <td align="center"><a href="javascript:cde_IMAGE('<?php echo $textarea;?>','smile','smiles/icon_smile.gif','Smile')		"><img src="smiles/icon_smile.gif" alt="Smile" title="Smile" />					</a></td>
    <td align="center"><a href="javascript:cde_IMAGE('<?php echo $textarea;?>','smile','smiles/icon_sad.gif','Sad')			"><img src="smiles/icon_sad.gif" alt="Sad" title="Sad" />							</a></td>
    <td align="center"><a href="javascript:cde_IMAGE('<?php echo $textarea;?>','smile','smiles/icon_surprised.gif','Surprised')	"><img src="smiles/icon_surprised.gif" alt="Surprised" title="Surprised" />		</a></td>
    <td align="center"><a href="javascript:cde_IMAGE('<?php echo $textarea;?>','smile','smiles/icon_eek.gif','Shocked')		"><img src="smiles/icon_eek.gif" alt="Shocked" title="Shocked" />					</a></td>
    <td align="center"><a href="javascript:cde_IMAGE('<?php echo $textarea;?>','smile','smiles/icon_confused.gif','Confused')	"><img src="smiles/icon_confused.gif" alt="Confused" title="Confused" />			</a></td>
    <td align="center"><a href="javascript:cde_IMAGE('<?php echo $textarea;?>','smile','smiles/icon_cool.gif','Cool')		"><img src="smiles/icon_cool.gif" alt="Cool" title="Cool" />						</a></td>
    <td align="center"><a href="javascript:cde_IMAGE('<?php echo $textarea;?>','smile','smiles/icon_lol.gif','Laughing')	"><img src="smiles/icon_lol.gif" alt="Laughing" title="Laughing" />				</a></td>
    <td align="center"><a href="javascript:cde_IMAGE('<?php echo $textarea;?>','smile','smiles/icon_mad.gif','Mad')			"><img src="smiles/icon_mad.gif" alt="Mad" title="Mad" />							</a></td>
    <td align="center"><a href="javascript:cde_IMAGE('<?php echo $textarea;?>','smile','smiles/icon_razz.gif','Razz')		"><img src="smiles/icon_razz.gif" alt="Razz" title="Razz" />						</a></td>
  </tr>
  <tr>
    <td align="center"><a href="javascript:cde_IMAGE('<?php echo $textarea;?>','smile','smiles/icon_redface.gif','Embarassed')">				<img src="smiles/icon_redface.gif" alt="Embarassed" title="Embarassed" />							</a></td>
  	<td align="center"><a href="javascript:cde_IMAGE('<?php echo $textarea;?>','smile','smiles/icon_cry.gif','Crying%20or%20Very%20sad')">	<img src="smiles/icon_cry.gif" alt="Crying%20or%20Very%20sad" title="Crying%20or%20Very%20sad" />	</a></td>
  	<td align="center"><a href="javascript:cde_IMAGE('<?php echo $textarea;?>','smile','smiles/icon_evil.gif','Evil%20or%20Very%20Mad')">	<img src="smiles/icon_evil.gif" alt="Evil%20or%20Very%20Mad" title="Evil%20or%20Very%20Mad" />		</a></td>
  	<td align="center"><a href="javascript:cde_IMAGE('<?php echo $textarea;?>','smile','smiles/icon_twisted.gif','Twisted%20Evil')">			<img src="smiles/icon_twisted.gif" alt="Twisted Evil" title="Twisted%20Evil" />						</a></td>
  	<td align="center"><a href="javascript:cde_IMAGE('<?php echo $textarea;?>','smile','smiles/icon_rolleyes.gif','Rolling%20Eyes')">			<img src="smiles/icon_rolleyes.gif" alt="Rolling Eyes" title="Rolling%20Eyes" />					</a></td>
  	<td align="center"><a href="javascript:cde_IMAGE('<?php echo $textarea;?>','smile','smiles/icon_wink.gif','Wink')">						<img src="smiles/icon_wink.gif" alt="Wink" title="Wink" />											</a></td>
  	<td align="center"><a href="javascript:cde_IMAGE('<?php echo $textarea;?>','smile','smiles/icon_exclaim.gif','Exclamation')">				<img src="smiles/icon_exclaim.gif" alt="Exclamation" title="Exclamation" />							</a></td>
  	<td align="center"><a href="javascript:cde_IMAGE('<?php echo $textarea;?>','smile','smiles/icon_question.gif','Question')">					<img src="smiles/icon_question.gif" alt="Question" title="Question" />								</a></td>
  	<td align="center"><a href="javascript:cde_IMAGE('<?php echo $textarea;?>','smile','smiles/icon_idea.gif','Idea')">						<img src="smiles/icon_idea.gif" alt="Idea" title="Idea" />											</a></td>
  	<td align="center"><a href="javascript:cde_IMAGE('<?php echo $textarea;?>','smile','smiles/icon_arrow.gif','Arrow')">						<img src="smiles/icon_arrow.gif" alt="Arrow" title="Arrow" />										</a></td>
  </tr>
</table>


<?php
} // display_smiles


// Display the fontlist
//	$textarea	- The name of the  textarea input field
//	$fm			- The name of the form that the list is in

function cde_display_fontlist($textarea,$fm)
{

?>
<select name="fontlist" id="fontlist" onChange="cde_BBC('<?php echo $textarea;?>','font',this.value);document['<?php echo $fm;?>'].textchanged.value='Y'">
	<option value="">Fonts </option>
    <option value='style="font-family: Arial, Helvetica, sans-serif"'>Arial, Helvetica, sans-serif</option>
	<option value='style="font-family: Verdana;"'>Verdana</option>
	<option value='style="font-family: Arial Black, Gadget, sans-serif"'>Arial Black, Gadget, sans-serif</option>
	<option value='style="font-family: Comic Sans MS, Textile, cursive"'>Comic Sans MS, Textile, cursive</option>
	<option value='style="font-family: Courier New, Courier, monospace"'>Courier New, Courier, monospace</option>
	<option value='style="font-family: Georgia, Times New Roman, Times, serif"'>Times New Roman, Times, serif</option>
	<option value='style="font-family: Impact, Charcoal, sans-serif"'>Impact, Charcoal, sans-serif</option>
	<option value='style="font-family: Lucida Console, Monaco, monospace"'>Lucida Console, Monaco, monospace</option>
	<option value='style="font-family: Lucida Sans Unicode, Lucida Grande, sans-serif"'>Lucida Sans Unicode, 'Lucida Grande', sans-serif</option>
	<option value='style="font-family: Palatino Linotype, Book Antiqua, Palatino, serif"'>Palatino Linotype, 'Book Antiqua', Palatino, serif</option>
	<option value='style="font-family: Tahoma, Geneva, sans-serif"'>Tahoma, Geneva, sans-serif</option>
    <option value='style="font-family: Times New Roman, Times, serif"'>Times New Roman, Times, serif</option>
    <option value='style="font-family: Trebuchet MS, Helvetica, sans-serif"'>Trebuchet MS, Helvetica, sans-serif</option>
    <option value='style="font-family: Verdana, Geneva, sans-serif"'>Verdana, Geneva, sans-serif</option>
    <option value='style="font-family: Symbol"'>Symbol</option>
    <option value='style="font-family: Webdings"'>Webdings</option>
    <option value='style="font-family: Wingdings, Zapf Dingbats"'>Wingdings, Zapf Dingbats</option>
    <option value='style="font-family: MS Sans Serif, Geneva, sans-serif"'>MS Sans Serif, Geneva, sans-serif</option>
    <option value='style="font-family: MS Serif, New York, serif"'>MS Serif, 'New York', serif'</option>
</select>


<?php
}
?>
