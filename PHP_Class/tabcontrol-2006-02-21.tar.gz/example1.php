<?php
require("tabControlClass.php");
$tabControl	= new TabControl();
//Generates a control with the default style and settings values
$tabControl->writeControl();
?>