<?php
require("tabControlClass.php");
$tabControl	= new TabControl();
//Generates a control with the default style but custom settings
$content1	= "<iframe src='http://www.yahoo.com' frameborder='0' width='100%' height='100%'></iframe>";
$content2	= "<iframe src='http://www.google.com' frameborder='0' width='100%' height='100%'></iframe>";
$content3	= "<b>Content 3";
$tabControl->defineSettings(2,550,350,6,2,"center","middle",array("yahoo.com","google.com","Title 3","Title 4","Title 5","Title 6"),array($content1,$content2,$content3,"<i>Content 4</i>","<u>Content 5</u>","&nbsp:"),array("http://www.yahoo.com","http://www.google.com","Status Message 3","Status Message 4","Status Message 5",""));
$tabControl->defineStyle("#D8D7B2","#EAE1BD","#8D9A94","black","1px","solid","Geneva, Arial, Helvetica, sans-serif","center","14px","normal","hand");
//generate control
$tabControl->writeControl();
?>