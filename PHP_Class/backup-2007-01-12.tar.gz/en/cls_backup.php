<?php
include_once ("cls_fecha_hora.php");
include_once ("CreateZipFile.php");
include_once ("mysql_dump.inc.php");

/***********************************************/
/* Class backup                                */
/* ------------------------------------------- */
/* Description: backups BD and file structure. */
/* Author: Eduardo Martos G�mez.               */
/* e-mail: eduardo.martos.gomez@gmail.com.     */
/* License: cite author's name                 */
/* Date: 05/11/2006.                           */
/* Comments: this class requires the classes   */
/* Create ZIP File and mysql_dump, available   */
/* at phpclasses.org and included in this      */
/* package.                                    */
/***********************************************/
class backup
{
	/*************/
	/* Variables */
	/*************/
	var $etiqueta;				// First part of generated filename
	var $dir_origen;			// Source directory (add a slash at the end)
	var $dir_destino;			// Destination directory
	var $fich_destino;		// Generated filename
	var $bd_host;					// DB host
	var $bd_usr;					// DB username
	var $bd_clave;				// DB password
	var $bd_nombre;				// Name of database name to be saved
	var $error;						// Last error happened

	/********************/
	/* Setter functions */
	/********************/
	function set_etiqueta ($valor)
	{
		$this->etiqueta = $valor;
	}
	function set_dir_origen ($valor)
	{
		$this->dir_origen = $valor;
	}
	function set_dir_destino ($valor)
	{
		$this->dir_destino = $valor;
	}
	function set_bd_host ($valor)
	{
		$this->bd_host = $valor;
	}
	function set_bd_usr ($valor)
	{
		$this->bd_usr = $valor;
	}
	function set_bd_clave ($valor)
	{
		$this->bd_clave = $valor;
	}
	function set_bd_nombre ($valor)
	{
		$this->bd_nombre = $valor;
	}

	/********************/
	/* Getter functions */
	/********************/
	function get_error ()
	{
		return $this->error;
	}
	
	/*******************************/
	/* Function inicializar ()     */
	/* --------------------------- */
	/* Initializes some variables. */
	/*******************************/
	function inicializar ()
	{
		$this->error = "";
		$f_h = new fecha_hora;
		$this->fich_destino = $this->dir_destino."/".$this->etiqueta."_".$f_h->hora_bd ().
			"_".$f_h->fecha_bd ();
	}

	/********************************************************/
	/* Function backup_files ()                             */
	/* ---------------------------------------------------- */
	/* Compresses specified directory, generates a file and */
	/* forces its download.                                 */
	/********************************************************/
	function backup_files ()
	{
		$this->inicializar ();
		$fich_destino = $this->fich_destino.".zip";

		$zip = new createZip;  
		$this->make_archive ($this->dir_origen, $zip);
		if (!$zip->addFile ($zip->getZippedfile (), $fich_destino))
		{
			$this->error = "<p>Error writing file $fich_destino</p>";
			$res = false;
		}
		else
		{
			$zip->forceDownload ($fich_destino);
			// Deletes the file (doesn't work without write permissions)
			chmod ($fich_destino, 0777);
			@unlink ($fich_destino);
			$res = true;
		}
		return $res;
	}
	
	/***********************************************************/
	/* Function make_archive ()                                */
	/* ------------------------------------------------------- */
	/* Browse recursively a directory and compress every file. */
	/***********************************************************/
	function make_archive ($dir, &$zip, $extdir = "")
	{
	  if (is_dir ($dir))
	  {
			if ($dh = opendir ($dir))
			{
	    	while (($file = readdir ($dh)) !== false)
				{
	        if ($file != "." && $file != "..")
	        {
	          $c = 0;
						$dir_zip = substr ($dir, $c);
						if (is_dir ($dir.$file))
	          {
							$zip->addDirectory ($dir_zip.$file);
	            $this->make_archive ($dir.$file."/", $zip, $extdir.$file."/");
	          }
	          else
	          {
							$fileContents = file_get_contents ($dir.$file);
							$zip->addFile ($fileContents, $dir_zip.$file);
	          }
	        }
	      }
	      closedir ($dh);
	    }
	  }
		return true;
	}
	
	/***************************************************************/
	/* Funciton backup_mysql ()                                    */
	/* ----------------------------------------------------------- */
	/* Dumps the specified DB into a file and forces its download. */
	/***************************************************************/
	function backup_mysql ()
	{
		$this->inicializar ();
		$fich_destino = $this->fich_destino.".dmp";
	  $mysql = new MYSQL_DUMP ($this->bd_host, $this->bd_usr, $this->bd_clave);
		$mysql->setDBHost($this->bd_host, $this->bd_usr, $this->bd_clave);
		if (!$mysql->save_sql ($mysql->dumpDB ($this->bd_nombre), $fich_destino))
		{
			$this->error = "<p>Error writing file $fich_destino</p>";
			$res = false;
		}
		else
		{
			$mysql->download_sql ($fich_destino);
			// Deletes the file (doesn't work without write permissions)
			chmod ($fich_destino, 0777);
			@unlink ($fich_destino);
			$res = true;
		}
		return $res;
	}
}
?>