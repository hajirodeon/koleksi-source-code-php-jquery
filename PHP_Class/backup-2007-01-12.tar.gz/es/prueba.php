<html>
<head>
<title>Probando Backup</title>
</head>
<body>
<?
	// Incluye de la clase Backup
	include ("cls_backup.php");
	
	// Crea el objeto
	$backup = new backup;
	
	// Asigna los par�metros
	$backup->set_etiqueta ("prueba");
	$backup->set_dir_origen ("dir_origen/");
	$backup->set_dir_destino ("dir_dest");
	$backup->set_bd_host ("host");
	$backup->set_bd_usr ("usuario");
	$backup->set_bd_clave ("clave");
	$backup->set_bd_nombre ("nombre_bd");
	
	// Eval�a el par�metro modo
	switch ($_GET["modo"])
	{
		// Comprime el directorio especificado en set_dir_origen () y descarga el zip
		case "files":
			$backup->backup_files ();
		break;
		// Vuelca la BD a un fichero y lo descarga
		case "bd":
			$backup->backup_mysql ();
		break;
		// Muestra las opciones de backup
		case "":
			echo "<p><a href=\"?modo=files\">Ficheros</a></p>";
			echo "<p><a href=\"?modo=bd\">BD</a></p>";
		break;
	}
?>
</body>
</html>