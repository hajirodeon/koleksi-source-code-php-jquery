<?php
include_once ("cls_fecha_hora.php");
include_once ("CreateZipFile.php");
include_once ("mysql_dump.inc.php");

/*********************************************/
/* Clase backup                              */
/* ----------------------------------------- */
/* Descripci�n: realiza copias de seguridad  */
/* de la estructura de ficheros y de la BD.  */
/* Autor: Eduardo Martos G�mez.              */
/* Correo-e: eduardo.martos.gomez@gmail.com. */
/* Condiciones de uso: citar al autor.       */
/* Fecha: 05/11/2006.                        */
/* Comentarios: esta clase requiere las      */
/* clases Create ZIP File y mysql_dump,      */
/* disponibles en phpclasses.org y que se    */
/* incluyen en este paquete.                 */
/*********************************************/
class backup
{
	/*************/
	/* Variables */
	/*************/
	var $etiqueta;				// Primera parte del nombre del fichero generado
	var $dir_origen;			// Directorio que se va a copiar (a�ade una barra al final)
	var $dir_destino;			// Directorio donde se almacenan los ficheros de backup
	var $fich_destino;		// Nombre del fichero que se va a generar
	var $bd_host;					// Host de la BD MySQL
	var $bd_usr;					// Usuario de la BD
	var $bd_clave;				// Clave de la BD
	var $bd_nombre;				// Nombre de la BD que se quiere salvar
	var $error;						// Contiene el �ltimo error producido

	/****************************************/
	/* Funciones de asignaci�n de atributos */
	/****************************************/
	function set_etiqueta ($valor)
	{
		$this->etiqueta = $valor;
	}
	function set_dir_origen ($valor)
	{
		$this->dir_origen = $valor;
	}
	function set_dir_destino ($valor)
	{
		$this->dir_destino = $valor;
	}
	function set_bd_host ($valor)
	{
		$this->bd_host = $valor;
	}
	function set_bd_usr ($valor)
	{
		$this->bd_usr = $valor;
	}
	function set_bd_clave ($valor)
	{
		$this->bd_clave = $valor;
	}
	function set_bd_nombre ($valor)
	{
		$this->bd_nombre = $valor;
	}

	/****************************************/
	/* Funciones de devoluci�n de atributos */
	/****************************************/
	function get_error ()
	{
		return $this->error;
	}
	
	/*********************************/
	/* Funci�n inicializar ()        */
	/* ----------------------------- */
	/* Inicializa algunas variables. */
	/*********************************/
	function inicializar ()
	{
		$this->error = "";
		$f_h = new fecha_hora;
		$this->fich_destino = $this->dir_destino."/".$this->etiqueta."_".$f_h->hora_bd ().
			"_".$f_h->fecha_bd ();
	}

	/**********************************************************/
	/* Funci�n backup_files ()                                */
	/* ------------------------------------------------------ */
	/* Comprime el directorio especificado, genera un fichero */
	/* y fuerza su descarga.                                  */
	/**********************************************************/
	function backup_files ()
	{
		$this->inicializar ();
		$fich_destino = $this->fich_destino.".zip";

		$zip = new createZip;  
		$this->make_archive ($this->dir_origen, $zip);
		if (!$zip->addFile ($zip->getZippedfile (), $fich_destino))
		{
			$this->error = "<p>Error al guardar el fichero $fich_destino</p>";
			$res = false;
		}
		else
		{
			$zip->forceDownload ($fich_destino);
			// Elimina el fichero (no funciona sin los permisos de escritura)
			chmod ($fich_destino, 0777);
			@unlink ($fich_destino);
			$res = true;
		}
		return $res;
	}
	
	/*******************************************************/
	/* Funci�n make_archive ()                             */
	/* --------------------------------------------------- */
	/* Recorre un directorio recursivamente y lo comprime. */
	/*******************************************************/
	function make_archive ($dir, &$zip, $extdir = "")
	{
	  if (is_dir ($dir))
	  {
			if ($dh = opendir ($dir))
			{
	    	while (($file = readdir ($dh)) !== false)
				{
	        if ($file != "." && $file != "..")
	        {
	          $c = 0;
						$dir_zip = substr ($dir, $c);
						if (is_dir ($dir.$file))
	          {
							$zip->addDirectory ($dir_zip.$file);
	            $this->make_archive ($dir.$file."/", $zip, $extdir.$file."/");
	          }
	          else
	          {
							$fileContents = file_get_contents ($dir.$file);
							$zip->addFile ($fileContents, $dir_zip.$file);
	          }
	        }
	      }
	      closedir ($dh);
	    }
	  }
		return true;
	}
	
	/**********************************************************/
	/* Funci�n backup_mysql ()                                */
	/* ------------------------------------------------------ */
	/* Realiza un volcado de la BD especificada en un fichero */
	/* y fuerza su descarga.                                  */
	/**********************************************************/
	function backup_mysql ()
	{
		$this->inicializar ();
		$fich_destino = $this->fich_destino.".dmp";
	  $mysql = new MYSQL_DUMP ($this->bd_host, $this->bd_usr, $this->bd_clave);
		$mysql->setDBHost($this->bd_host, $this->bd_usr, $this->bd_clave);
		if (!$mysql->save_sql ($mysql->dumpDB ($this->bd_nombre), $fich_destino))
		{
			$this->error = "<p>Error al guardar el fichero $fich_destino</p>";
			$res = false;
		}
		else
		{
			$mysql->download_sql ($fich_destino);
			// Elimina el fichero (no funciona sin los permisos de escritura)
			chmod ($fich_destino, 0777);
			@unlink ($fich_destino);
			$res = true;
		}
		return $res;
	}
}
?>