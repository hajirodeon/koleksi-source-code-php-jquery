<?php
/*********************************************/
/* Clase backup                              */
/* ----------------------------------------- */
/* Descripci�n: trabaja con fechas y horas.  */
/* Autor: Eduardo Martos G�mez.              */
/* Correo-e: eduardo.martos.gomez@gmail.com. */
/* Condiciones de uso: citar al autor.       */
/* Fecha: 10/03/2004.                        */
/*********************************************/
class fecha_hora
{
	/*************/
	/* Variables */
	/*************/
  var $fecha;					// Fecha
	var $hora;					// Hora
	var $desfase = 2;		// Desfase horario
	
	/****************************************/
	/* Funciones de asignaci�n de atributos */
	/****************************************/
  function set_fecha ($valor)
  {
    $this->fecha = $valor;
  }
  function set_hora ($valor)
  {
    $this->hora = $valor;
  }
  function set_desfase ($valor)
  {
    $this->desfase = $valor;
  }

	/*************************************************/
	/* Funciones get_dia (), get_mes (), get_anyo () */
	/* --------------------------------------------- */
	/* Devuelven la fecha por partes.                */
	/*************************************************/
  function get_dia ($ceros = true)
  {
    $res = substr ($this->fecha, 6, 2);
    if ($ceros == true) $res = $this->ceros ($res, 2, 0);
    return $res;
  }
  function get_mes ($ceros = true)
  {
    $res = substr ($this->fecha, 4, 2);
    if ($ceros == true) $res = $this->ceros ($res, 2, 0);
    return $res;
  }
  function get_anyo ($ceros = true)
  {
    $res = substr ($this->fecha, 0, 4);
    if ($ceros == true) $res = $this->ceros ($res, 4, 0);
    return $res;
  }

	/****************************************/
	/* Funciones get_hora (), get_minuto () */
	/* ------------------------------------ */
	/* Devuelven la hora por partes.        */
	/****************************************/
  function get_hora ($ceros = true)
  {
    $res = substr ($this->hora, 0, 2);
    if ($ceros == true) $res = $this->ceros ($res, 2, 0);
    return $res;
  }
  function get_minuto ($ceros = true)
  {
    $res = substr ($this->hora, 2, 2);
    if ($ceros == true) $res = $this->ceros ($res, 2, 0);
    return $res;
  }

	/****************************/
	/* Funci�n fecha ()         */
	/* ------------------------ */
	/* Devuelve la fecha actual */
	/* en formato dd/mm/aaaa    */
	/****************************/
  function fecha ()
  {
  	$dia = $this->ceros (trim (gmdate ("j", time() + (3600 * $this->desfase))), 2, 0);
  	$mes = $this->ceros (trim (gmdate ("n", time() + (3600 * $this->desfase))), 2, 0);
  	$anyo = trim (gmdate("Y", time () + (3600 * $this->desfase)));
  	$fecha = $dia.'/'.$mes. '/'. $anyo;
  	return $fecha;	
  }

	/***************************/
	/* Funci�n hora ()         */
	/* ----------------------- */
	/* Devuelve la hora actual */
	/* en formato hh:mm        */
	/***************************/
  function hora()
  {
    return gmdate ("H:i", time() + (3600 * $this->desfase));
  }

	/******************************************/
	/* Funci�n ceros ()                       */
	/* -------------------------------------- */
	/* A�ade $num ceros en el lado indicado   */
	/* por $izq_dr (0: izquierda, 1: derecha) */
	/* de la cadena $cad.                     */
	/******************************************/
  function ceros ($cad, $num, $izq_dr)
  {
  	if ($izq_dr == 0)
      while (strlen ($cad) < $num) $cad = "0".$cad;
    else
      while (strlen ($cad) < $num) $cad .= "0";
  	return $cad;
  }

	/*******************************************/
	/* Funci�n fecha_bd ()                     */
	/* --------------------------------------- */
	/* Devuelve una fecha en formato aaaammdd. */
	/* Si no se especifica el par�metro $f, se */
	/* toma la fecha $this->fecha.             */
	/*******************************************/
  function fecha_bd ($f = "")
  {
    if ($f == "") $f = $this->fecha ();
    $p1 = strpos ($f, "/");
    $p2 = strpos ($f, "/", $p1 + 1);
    $d = substr ($f, 0, $p1);                 // D�a
    $m = substr ($f, $p1 + 1, $p2 - $p1 - 1); // Mes
    $a = substr ($f, $p2 + 1);                // A�o
    return $a.$m.$d;
  }

	/**********************************************/
	/* Funci�n hora_bd ()                         */
	/* ------------------------------------------ */
	/* Devuelve una hora en formato hhmm.         */
	/* Si no se especifica el par�metro $hora, se */
	/* toma la hora $this->hora.                  */
	/**********************************************/
  function hora_bd ($hora = "")
  {
    if ($hora == "") $hora = $this->hora ();
    $p = strpos ($hora, ":");
    $h = substr ($hora, 0, $p);  // Hora
    $m = substr ($hora, $p + 1); // Minuto
    return $h.$m;
  }

	/***********************************************/
	/* Funci�n fecha_ed ()                         */
	/* ------------------------------------------- */
	/* Devuelve la fecha $f en formato dd/mm/aaaa. */
	/* $f debe estar en formato aaaammdd           */
	/***********************************************/
  function fecha_ed ($f)
  {
    $d = substr ($f, 6);    // D�a
    $m = substr ($f, 4, 2); // Mes
    $a = substr ($f, 0, 4); // A�o
    $m = intval ($m);
    $m = $this->texto_mes ($m);
    return $d."/".$m."/".$a;
  }

	/********************************************/
	/* Funci�n hora_ed ()                       */
	/* ---------------------------------------- */
	/* Devuelve la hora $hora en formato hh:mm. */
	/* $hora debe estar en formato hhmm.        */
	/********************************************/
  function hora_ed ($hora)
  {
    $hora = $this->ceros ($hora, 4, 0);
    $h = substr ($hora, 0, 2); // Hora
    $m = substr ($hora, 2);    // Minuto
    if ($h == 24) $h = "0";
    return $h.":".$m;
  }

	/*************************************/
	/* Funci�n texto_mes ()              */
	/* --------------------------------- */
	/* Devuelve las tres primeras letras */
	/* del mes especificado en $mes.     */
	/*************************************/
  function texto_mes ($mes)
  {
		$arr_meses = split (",", "ENE,FEB,MAR,ABR,MAY,JUN,JUL,AGO,SEP,OCT,NOV,DIC");
  	return $arr_meses[$mes-1];
  }
}
?>