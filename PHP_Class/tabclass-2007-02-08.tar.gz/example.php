<?
include ("./tabClass.php");

# DocumentRootPath     : Is the relative path (unix) to reach the httpd Document Root
$DocumentRootPath = "/var/www/html";

# mySite_Relative_Path : Is the absolute "your website" sub directory from Document Root, where you store the class (optional - leave blank if use document root)
$mySite_Relative_Path = "/TABTest";

$mySite_Absolute_Path = $DocumentRootPath.$mySite_Relative_Path;

# Tabs Configuration   : Specify the absolute path to frame file. Each frame displays the content of the tab.
$FirstTabFrame = $mySite_Absolute_Path."/frame1.php";
$SecondTabFrame = $mySite_Absolute_Path."/frame2.html";
$ThirdTabFrame = $mySite_Absolute_Path."/frame3.txt";


echo "
<table border=0 cellspacing=0 cellpadding=0 bgcolor=\"#CECECE\" width=350>
  <tr height=350 valign=middle>
    <td align=center>
";
$myTab = new tabClass();
$myTab->SetHTMLDir($mySite_Relative_Path);
$myTab->SetTabName("Test2");
$myTab->SetWidth(300);
$myTab->SetHeight(300);
$myTab->AddTab("Frame 1", $FirstTabFrame);
$myTab->AddTab("Frame 2", $SecondTabFrame);
$myTab->AddTab("Frame 3", $ThirdTabFrame);
$myTab->DrawTab();
echo "
    </td>
  </tr>
</table>
";
?>
