<?
class tabClass
{

  # Define class variables
  var $tabName = "defaultTab";
  var $tabTitleArray = Array();
  var $tabFileContentArray = Array();
  var $TabWidthPx = 0;
  var $TabHeightPx = 0;
  var $HPath = "";


  function AddTab($tabTitle, $tabScript_AbsolutePath){
    if((trim($tabTitle)!="")&&(trim($tabScript_AbsolutePath)!="")){
      $this->tabTitleArray[] = trim($tabTitle);
      $this->tabFileContentArray[] = trim($tabScript_AbsolutePath);
    }
  }

  function SetHTMLDir($HDir){
    $this->HPath = trim($HDir);
  }

  function SetTabName($Name){
    $this->tabName = trim($Name);
  }

  function SetWidth($W=0){
    $this->TabWidthPx = trim($W);
  }

  function SetHeight($H=0){
    $this->TabHeightPx = trim($H);
  }

  function DrawTab(){
    $NumberOfTabs = count($this->tabTitleArray);
    $HTML_PathToLibrary = $this->HPath."/TabImgs/";
    if($this->TabWidthPx == 0){
      $this->TabWidthPx = ($NumberOfTabs * 50) + 100;
    }
    if($this->TabHeightPx == 0){
      $this->TabHeightPx = 200;
    }
    ?>
      <style>
        TD.<? echo $this->tabName; ?>_AS_TAB_UP{
          font-family: Arial, Helvetica, sans-serif;
          font-size: 12px;
          color: red;
          /*font-weight: bold;*/
          text-align: center;
          background-image=url(<? echo $HTML_PathToLibrary; ?>back-up.gif);
        }
        TD.<? echo $this->tabName; ?>_AS_TAB_DOWN{
          font-family: Arial, Helvetica, sans-serif;
          font-size: 12px;
          cursor:pointer;
          cursor:hand;
          text-align: center;
          background-image=url(<? echo $HTML_PathToLibrary; ?>back-down.gif);
        }
        TD.<? echo $this->tabName; ?>_AS_NO_TAB{
          font-family: Arial, Helvetica, sans-serif;
          font-size: 12px;
          text-align: center;
          background-image=url(<? echo $HTML_PathToLibrary; ?>back.gif);
        }
        TD.<? echo $this->tabName; ?>_AS_WHITEGRAY_COL{
          font-family: Arial, Helvetica, sans-serif;
          font-size: 12px;
          text-align: center;
          background-image=url(<? echo $HTML_PathToLibrary; ?>back-whitegray.gif);
        }
        TD.<? echo $this->tabName; ?>_AS_GRAYBLACK_COL{
          font-family: Arial, Helvetica, sans-serif;
          font-size: 12px;
          text-align: center;
          background-image=url(<? echo $HTML_PathToLibrary; ?>back-grayblack.gif);
        }
        TD.<? echo $this->tabName; ?>_AS_BOTTOM_ROW{
          font-family: Arial, Helvetica, sans-serif;
          font-size: 12px;
          text-align: center;
          background-image=url(<? echo $HTML_PathToLibrary; ?>bottom.gif);
        }
      </style>

      <script>
        function <? echo $this->tabName; ?>_AS_Show(Tab){
          var lastTab = <? echo $NumberOfTabs; ?>;
          var thisTab;
          // Abbasso tutti i Tabsheet
          for(thisTab=1; thisTab<(lastTab+1); thisTab++){
            document.getElementById('<? echo $this->tabName; ?>_tab_'+thisTab).style.display='none';
            document.getElementById('<? echo $this->tabName; ?>_td_tab_'+thisTab).className='<? echo $this->tabName; ?>_AS_TAB_DOWN';
            document.getElementById('<? echo $this->tabName; ?>_sep_'+thisTab).src='<? echo $HTML_PathToLibrary; ?>down-down.gif';
            document.getElementById('<? echo $this->tabName; ?>_fix_u_'+thisTab).height=4;
            document.getElementById('<? echo $this->tabName; ?>_fix_d_'+thisTab).height=1;
          }
          document.getElementById('<? echo $this->tabName; ?>_sep_0').src='<? echo $HTML_PathToLibrary; ?>left-down.gif';
          document.getElementById('<? echo $this->tabName; ?>_sep_'+lastTab).src='<? echo $HTML_PathToLibrary; ?>right-down.gif';

          // Alzo il tab selezionato
          document.getElementById('<? echo $this->tabName; ?>_tab_'+Tab).style.display='';
          document.getElementById('<? echo $this->tabName; ?>_td_tab_'+Tab).className='<? echo $this->tabName; ?>_AS_TAB_UP';
          if(Tab>1){
            document.getElementById('<? echo $this->tabName; ?>_sep_'+(Tab-1)).src='<? echo $HTML_PathToLibrary; ?>down-up.gif';
          }
          else{
            document.getElementById('<? echo $this->tabName; ?>_sep_'+(Tab-1)).src='<? echo $HTML_PathToLibrary; ?>left-up.gif';
          }
          if(Tab<lastTab){
            document.getElementById('<? echo $this->tabName; ?>_sep_'+Tab).src='<? echo $HTML_PathToLibrary; ?>up-down.gif';
          }
          else{
            document.getElementById('<? echo $this->tabName; ?>_sep_'+Tab).src='<? echo $HTML_PathToLibrary; ?>right-up.gif';
          }
          document.getElementById('<? echo $this->tabName; ?>_fix_u_'+Tab).height=1;
          document.getElementById('<? echo $this->tabName; ?>_fix_d_'+Tab).height=4;

        }
      </script>

<table border=0 cellspacing=0 cellpadding=0>
  <tr height=1>
    <td><img src="<? echo $HTML_PathToLibrary; ?>trasp.gif" border=0 width="<? echo $this->TabWidthPx; ?>" height=1></td>
  </tr>
  <tr>
    <td>
      <table border=0 cellspacing=0 cellpadding=0 width="<? echo $this->TabWidthPx; ?>">
        <tr>
          <td width=0%><img ID="<? echo $this->tabName; ?>_sep_0" src="<? echo $HTML_PathToLibrary; ?>left-down.gif" border=0 width=4 height=21></td>
<?
  for($thisTab=1; $thisTab<($NumberOfTabs+1); $thisTab++){
    $TabTitle = str_replace(" ","&nbsp;",$this->tabTitleArray[($thisTab-1)]);
?>
          <td ID="<? echo $this->tabName; ?>_td_tab_<? echo $thisTab; ?>" class="<? echo $this->tabName; ?>_AS_TAB_DOWN" onMouseDown="<? echo $this->tabName; ?>_AS_Show('<? echo $thisTab; ?>');"><img ID="<? echo $this->tabName; ?>_fix_u_<? echo $thisTab; ?>" src="<? echo $HTML_PathToLibrary; ?>trasp.gif" border=0 width=1 height=1><br>&nbsp;<? echo $TabTitle; ?>&nbsp;<br><img ID="<? echo $this->tabName; ?>_fix_d_<? echo $thisTab; ?>" src="<? echo $HTML_PathToLibrary; ?>trasp.gif" border=0 width=1 height=4></td>
          <td width=0><img ID="<? echo $this->tabName; ?>_sep_<? echo $thisTab; ?>" src="<? echo $HTML_PathToLibrary; ?>down-up.gif" border=0 width=4 height=21></td>
<?
  }
?>

          <td width=100% class="<? echo $this->tabName; ?>_AS_NO_TAB">&nbsp;</td>
          <td class="<? echo $this->tabName; ?>_AS_NO_TAB" align=right><img src="<? echo $HTML_PathToLibrary; ?>no-tab.gif" border=0 width=1 height=21></td>
        </tr>
        <tr>
  <?
    for($thisTab=1; $thisTab<($NumberOfTabs+1); $thisTab++){
  ?>
          <td id="<? echo $this->tabName; ?>_tab_<? echo $thisTab; ?>" style="display:none;" colspan=<? echo (($NumberOfTabs * 2)+3); ?> width="<? echo $this->TabWidthPx; ?>">
            <table border=0 cellspacing=0 cellpadding=0 width=100%>
              <tr>
                <td class="<? echo $this->tabName; ?>_AS_WHITEGRAY_COL"><img src="<? echo $HTML_PathToLibrary; ?>trasp.gif" border=0 width=1 height=<? echo $this->TabHeightPx; ?>></td>
                <td width=100% valign=top><?
                  include($this->tabFileContentArray[($thisTab-1)]);
                ?></td>
                <td background="<? echo $HTML_PathToLibrary; ?>back-grayblack.gif"><img src="<? echo $HTML_PathToLibrary; ?>trasp.gif" border=0 width=2 height=<? echo $this->TabHeightPx; ?>></td>
              </tr>
              <tr>
                <td><img src="<? echo $HTML_PathToLibrary; ?>corner-left.gif" border=0 width=2 height=2></td>
                <td background="<? echo $HTML_PathToLibrary; ?>bottom.gif" width=100%></td>
                <td><img src="<? echo $HTML_PathToLibrary; ?>corner-right.gif" border=0 width=2 height=2></td>
              </tr>
            </table>
          </td>
  <?
    }
  ?>
          </tr>
        </table>
      </td>
    </tr>
  </table>
        <script>
          <? echo $this->tabName; ?>_AS_Show('1');
        </script>
  <?
  }

}
?>
