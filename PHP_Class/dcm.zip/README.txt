Document Content Management System v2.0
By Richard James Kendall
Email: richard@richardjameskendall.com
Copyright (C) 2004 Richard James Kendall.

"A solution for working on documents in small group environments"

##################
# HOW TO INSTALL #
##################

This system requires the following:

 * PHP 4.3.0 or higher (http://www.php.net)
 * MySQL 3.x or higher (http://www.mysql.com)
 * Apache or another web server capable of providing HTTP Authentication (.htaccess) (http://httpd.apache.org)

1. Using the MySQL command line tool (or your favourite interface to MySQL e.g. http://www.phpmyadmin.net) run the file
   dcm.sql.

2. Edit the users table adding the usernames, full names and email addresses of all the users.

3. Create a folder and make sure the Apache can access it, e.g.:

   If the folder was /data1/dcm then in your httpd.conf you would put:
   
   Alias /dcm "/data1/dcm"
   
   <Directory "/data1/dcm">
        AuthType Basic
	AuthName DCM
	AuthUserFile /data1/admin/dcm.validation
	Require valid-user
   </Directory>
   
   You can find out where your http.conf file is kept by executing: whereis httpd.
   
   There is more information on this here: http://httpd.apache.org/docs-2.0/howto/auth.html

4. Edit the users table to add all the users that you want to access the system.

5. For each of the users you have addedd make sure that they are able to access the directory, e.g:
   
   htpassword -b[c] /data1/admin/dcm.validation <username> <password>
   
   NOTE: the c is only required the first time to create the file.

6. Put the contents of the dcm.zip archive into the folder (in this case /data1/dcm) and edit the global/_top.php file
   to suit your needs.

############
# OPTIONAL #
############

You may want to increase the amount of data that can be sent to MySQL be changing the max_allowed_packet server
parameter.  You can find out how to do this here: http://dev.mysql.com/doc/mysql/en/Server_parameters.html

You may also want the maximum file size that PHP will accecpt for upload, details on this can be found here:
http://uk.php.net/manual/en/ini.sect.file_uploads.php#ini.upload-max-filesize

###########
# CONTACT #
###########

If you have any problems then please email me: richard@richardjameskendall.com.