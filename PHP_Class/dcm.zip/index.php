<?php
// Part of DCM v2.0 by Richard James Kendall
// richard@richardjameskendall.com

require("global/_top.php");

function getend($str) {
   $strbits = explode(".", $str);
   $fext = $strbits[count($strbits) - 1];
   return $fext;
}
?>
<html>
<head>
   <title><?php print($dcm_name); ?></title>
</head>
<script language="javascript">
function downloadToView(docid) {
   self.location = "op.php?type=view&id=" + docid;
}

function downloadToEdit(docid) {
   self.location = "op.php?type=checkout&id=" + docid;
}

function releaseLock(docid) {
   if (confirm("You are about to release the lock on this file, this means that any changes you make to you copy of the document cannot be re-integrated into the system.\n\nAre you sure? (Ok = Yes, Cancel = No)")) {
   	  self.location = "op.php?type=release&id=" + docid;
   }
}

function checkBackIn(docid) {
   self.location = "op.php?type=checkin&id=" + docid;
}

function viewHistory(docid) {
   newWindow = window.open("",'','scrollbars=yes, toolbars=no, width=410, height=500');
   newWindow.self.location = 'op.php?type=hist&id=' + docid;
}

function deleteDocument(docid) {
   if (confirm("You are about to delete every version of this document that exists on the system.\n\nAre you sure? (Ok = Yes, Cancel = No)")) {
      self.location = "op.php?type=delete&id=" + docid;
   }
}
</script>
<body>
<h1><?php print($dcm_name); ?></h1>
<?php
print ("You are: " . $usr_obj->full_name . "<br>");
print ("You have " . numberCheckedOut() . " document(s) checked out.<br>");
print ("<br>");
if (isset($message)) {
   print ("<font color=\"#FF0000\"><b>" . $message . "</b></font><br><br>");
}
$sql = "select document_name from documents";
$docs = mysql_query($sql, $link);
if (mysql_num_rows($docs) == 0) {
   ?>
   <table width="100%" cellspacing="0" cellpadding="0" border="1"><tr><td width="100%" align="middle">
   <i>There are no documents available!</i>
   </td></tr></table>
   <?php
} else {
   $sql = "SELECT document_id, document_name, document_version, document_timestamp, document_uploader, document_size, document_cat, document_desc, document_out, document_out_with, document_file_name FROM documents order by document_timestamp desc";
   $documents = mysql_query($sql, $link);
   while ($row = mysql_fetch_object($documents)) {
   	  $d = date("j/m/Y \@ H:i:s", $row->document_timestamp);
      ?>
      <table width="100%" cellpadding="0" cellspacing="0" border="1">
         <tr>
            <?php
            if (checkedOutByUser($row->document_id)) {
               ?>
               <td width="100%" colspan="3" bgcolor="#FF8080"><b><?php print($row->document_name . " v" . $row->document_version); ?></b></td>
               <?php
            } else {
               ?>
               <td width="100%" colspan="3" bgcolor="#EFEFEF"><b><?php print($row->document_name . " v" . $row->document_version); ?></b></td>
               <?php
            }
            ?>
         </tr>
         <tr>
            <td width="10%" rowspan="10" colspan="1" align="middle" valign="middle"><img src="images/file.jpg"><br><font size="5"><?php print(getend($row->document_file_name)); ?></font></td>
            <td width="20%" rowspan="1" colspan="1"><b>File Name:</b></td>
            <td width="70%" colspan="1" rowspan="1"><?php print($row->document_file_name); ?></td>
         </tr>
         <tr>
            <td width="20%" rowspan="1" colspan="1"><b>Author:</b></td>
            <td width="70%" colspan="1" rowspan="1"><?php print($row->document_uploader); ?></td>
         </tr>
         <tr>
            <td width="20%" rowspan="1" colspan="1"><b>File Version:</b></td>
            <td width="70%" colspan="1" rowspan="1"><?php print($row->document_version); ?></td>
         </tr>
         <tr>
            <td width="20%" rowspan="1" colspan="1"><b>Last Updated:</b></td>
            <td width="70%" colspan="1" rowspan="1"><?php print($d); ?></td>
         </tr>
         <tr>
            <td width="20%" rowspan="1" colspan="1"><b>Size (bytes):</b></td>
            <td width="70%" colspan="1" rowspan="1"><?php print($row->document_size); ?></td>
         </tr>
         <tr>
            <td width="20%" rowspan="1" colspan="1"><b>Development Phase:</b></td>
            <td width="70%" colspan="1" rowspan="1"><?php print($row->document_cat); ?></td>
         </tr>
         <tr>
            <td width="20%" rowspan="1" colspan="1" align="top"><b>Description:</b></td>
            <td width="70%" colspan="1" rowspan="1"><?php print($row->document_desc); ?></td>
         </tr>
         <?php
         if ($row->document_out == 0) {
         	 ?>
         	 <tr>
                <td width="20%" rowspan="1" colspan="1" align="top"><b>Document Out:</b></td>
                <td width="70%" colspan="1" rowspan="1"><b><font color="#008000">No</font></b></td>
             </tr>
         	 <?php
         } else {
         	 ?>
         	 <tr>
                <td width="20%" rowspan="1" colspan="1" align="top"><b>Document Out:</b></td>
                <td width="70%" colspan="1" rowspan="1"><b><font color="#FF0000">Yes</font></b> with <?php print(getFullName($row->document_out_with) . " &lt;<a href=\"mailto:" . getEmailAddr($row->document_out_with) . "\">" . getEmailAddr($row->document_out_with) . "</a>&gt;"); ?></td>
             </tr>
         	 <?php
         }
         ?>
         <tr>
            <td width="20%" rowspan="1" colspan="1" align="top"><b>Previous Versions:</b></td>
            <td width="70%" colspan="1" rowspan="1">
            <?php
            $sql2 = "select document_version from prev_versions where document_id=$row->document_id";
            $prev_vers = mysql_query($sql2, $link);
            if (mysql_num_rows($prev_vers) == 0) {
            	print ("<i>None</i>");
            } else {
               while ($pv = mysql_fetch_object($prev_vers)) {
         	      print ("[<a href=\"op.php?type=getprevversion&id=" . $row->document_id . "&ver=" . $pv->document_version . "\">" . $pv->document_version . "</a>] ");
               }
            }
            ?>
            </td>
         </tr>
         <tr>
            <td width="20%" rowspan="1" colspan="1" align="top"><b>Edited by:</b></td>
            <td width="70%" colspan="1" rowspan="1">
            <?php
            $sql3 = "select * from history where document_id=$row->document_id and hist_action='UL_CHECKIN' group by hist_person";
            $editors = mysql_query($sql3, $link);
            if (mysql_num_rows($editors) == 0) {
            	print ("<i>Nobody</i>");
            } else {
               while ($ed = mysql_fetch_object($editors)) {
         	      print ("[" . getFullName($ed->hist_person) . "] ");
               }
            }
            ?>
            </td>
         </tr>
         <tr>
            <td width="1000%" colspan="3" align="right">
            <input type="button" value="Download to View" onClick="javascript:downloadToView('<?php print($row->document_id); ?>');">
            <?php
            if ($row->document_out == 0) {
               ?>
               <input type="button" value="Download and Check Out" onClick="javascript:downloadToEdit('<?php print($row->document_id); ?>');">
               <?php
            } else {
               ?>
               <input type="button" value="Check In" onClick="javascript:checkBackIn('<?php print($row->document_id); ?>');">
               <input type="button" value="Release Lock" onClick="javascript:releaseLock('<?php print($row->document_id); ?>');">
               <?php
            }
            ?>
            <input type="button" value="View History" onClick="javascript:viewHistory('<?php print($row->document_id); ?>');">
            <input type="button" value="Delete this Document" onClick="javascript:deleteDocument('<?php print($row->document_id); ?>');">
            </td>
         </tr>
      </table><br>
      <?php
   }
}
?>
<a href="add.php"><font size="4"><b>Upload a new file into the system...</b></font></a>
<br><br>
<font size="1">
<i>DCM System Version 2.0.  By Richard James Kendall. Bugs: <a href="mailto:richard@richardjameskendall.com">Mail Me</a></i>
</font>
</body>
</html>
<?php
require("global/_bottom.php");
?>