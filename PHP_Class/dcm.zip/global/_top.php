<?php
// Part of DCM v2.0 by Richard James Kendall
// richard@richardjameskendall.com

// general config
$dcm_name = "Document Content Management";
$dcm_url = "http://10.0.0.3/cm_system/";
$dcm_email = "richard@richardjameskendall.com";
$dcm_send_email_alerts = true;

// user who can delete files
$admin_user = "richard";

// mysql config
$mysql_username = "";
$mysql_password = "";
$mysql_database = "dcm";
$mysql_server = "localhost";

$link = mysql_connect($mysql_server, $mysql_username, $mysql_password);
mysql_select_db($mysql_database, $link);
$username = $_SERVER["REMOTE_USER"];
$results = mysql_query("select * from users where username='$username'", $link);
$usr_obj = mysql_fetch_object($results);

foreach ($_GET as $key => $value) {
	$$key = $value;
}

foreach ($_POST as $key => $value) {
	$$key = $value;
}

function mailTheList($subject, $message) {
   global $dcm_email, $dcm_send_email_alerts, $link;
   if ($dcm_send_email_alerts) {
	   $headers = "";
	   $headers .= "From: " . $dcm_email . "\n";
	   $headers .= "X-Sender: DCMSender\n";
	   $headers .= "X-Mailer: dcmPHP (v2b)\n";
	   $sql = "select email_addr from users";
	   $emails = mysql_query($sql, $link);
	   while ($email = mysql_fetch_object($emails)) {
	   	   mail($email->email_addr, $subject, $message, $headers);
	   }
   }
}

function getFullName($usern) {
   global $link, $username;
   $sql = "select * from users where username='$usern'";
   $row = mysql_fetch_object(mysql_query($sql, $link));
   return $row->full_name;
}

function getEmailAddr($usrn) {
   global $link, $username;
   $sql = "select * from users where username='$usrn'";
   $row = mysql_fetch_object(mysql_query($sql, $link));
   return $row->email_addr;
}

function addHistory($id, $type) {
   global $link, $username;
   $htime = time();
   $sql = "insert into history (document_id, hist_action, hist_person, hist_timestamp) values ($id, '$type', '$username', '$htime')";
   $ok = mysql_query($sql, $link);
   return $ok;
}

function numberCheckedOut() {
   global $link, $username;
   $sql = "select document_name from documents where document_out_with='$username'";
   $results = mysql_query($sql, $link);
   return mysql_num_rows($results);
}

function checkedOutByUser($id) {
   global $link, $username;
   $sql = "select document_name from documents where document_id=$id and document_out_with='$username'";
   $results = mysql_query($sql, $link);
   return mysql_num_rows($results) == 1;
}
?>