<?php
// Part of DCM v2.0 by Richard James Kendall
// richard@richardjameskendall.com
	
mysql_close($link);
?>