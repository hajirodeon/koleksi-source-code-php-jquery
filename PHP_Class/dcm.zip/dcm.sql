CREATE TABLE `documents` (
  `document_id` bigint(20) NOT NULL auto_increment,
  `document_name` longtext NOT NULL,
  `document_version` varchar(20) NOT NULL default '',
  `document_timestamp` longtext NOT NULL,
  `document_uploader` longtext NOT NULL,
  `document_size` bigint(20) NOT NULL default '0',
  `document_cat` longtext NOT NULL,
  `document_desc` longtext NOT NULL,
  `document_data` longblob NOT NULL,
  `document_out` char(1) NOT NULL default '',
  `document_out_with` longtext NOT NULL,
  `document_file_name` longtext NOT NULL,
  PRIMARY KEY  (`document_id`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;

CREATE TABLE `history` (
  `document_id` bigint(20) NOT NULL default '0',
  `hist_action` varchar(50) NOT NULL default '',
  `hist_person` varchar(100) NOT NULL default '',
  `hist_timestamp` longtext NOT NULL
) TYPE=MyISAM;

CREATE TABLE `phases` (
  `phase` varchar(100) NOT NULL default ''
) TYPE=MyISAM;

INSERT INTO `phases` VALUES ('Domain Analysis');
INSERT INTO `phases` VALUES ('Requirments');
INSERT INTO `phases` VALUES ('Design');
INSERT INTO `phases` VALUES ('Implementation');
INSERT INTO `phases` VALUES ('Testing');
INSERT INTO `phases` VALUES ('Marketing');
INSERT INTO `phases` VALUES ('Maintenance');

CREATE TABLE `prev_versions` (
  `document_id` bigint(20) NOT NULL default '0',
  `document_version` longtext NOT NULL,
  `document_desc` longtext NOT NULL,
  `document_data` longblob NOT NULL,
  `document_size` bigint(20) NOT NULL default '0',
  `document_file_name` longtext NOT NULL
) TYPE=MyISAM;

CREATE TABLE `users` (
  `username` varchar(100) NOT NULL default '',
  `full_name` longtext NOT NULL,
  `email_addr` longtext NOT NULL,
  PRIMARY KEY  (`username`)
) TYPE=MyISAM;


