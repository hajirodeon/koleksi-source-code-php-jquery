<?php 
         
/** 
* gonximage class : Generated based on directory (images/tabs/gonxv2) 
* 
* @package 
* @author Ben Yacoub Hatem <hatem@php.net> 
* @copyright Copyright (c) 2004 
* @version $Id$ - 2004-04-17 16:32:02 - gonximage.class.php 
* @access public 
**/ 
class gonximage{ 
    /** 
     * Constructor 
     * @access protected 
     */ 
    function gonximage(){ 
         
    } 
	 
    /** 
     * Return image based on it name 
     * @access public 
     * @return void 
     **/ 
    function getimage($img){ 
        switch($img){ 

            case "bar_b_gif":  
                gonximage::bar_b_gif(); 
            break; 

            case "bar_l_gif":  
                gonximage::bar_l_gif(); 
            break; 

            case "bar_r_gif":  
                gonximage::bar_r_gif(); 
            break; 

            case "bar_t_gif":  
                gonximage::bar_t_gif(); 
            break; 

            case "corner_bl_gif":  
                gonximage::corner_bl_gif(); 
            break; 

            case "corner_br_gif":  
                gonximage::corner_br_gif(); 
            break; 

            case "corner_tl_gif":  
                gonximage::corner_tl_gif(); 
            break; 

            case "corner_tr_gif":  
                gonximage::corner_tr_gif(); 
            break; 

            case "delete_gif":  
                gonximage::delete_gif(); 
            break; 

            case "e_blank_gif":  
                gonximage::e_blank_gif(); 
            break; 

            case "fleche_blue_gif":  
                gonximage::fleche_blue_gif(); 
            break; 

            case "fleche_red_gif":  
                gonximage::fleche_red_gif(); 
            break; 

            case "fleche_gif":  
                gonximage::fleche_gif(); 
            break; 

            case "left_gif":  
                gonximage::left_gif(); 
            break; 

            case "left_on_gif":  
                gonximage::left_on_gif(); 
            break; 

            case "right_gif":  
                gonximage::right_gif(); 
            break; 

            case "right_on_gif":  
                gonximage::right_on_gif(); 
            break; 

            case "stab_bg_gif":  
                gonximage::stab_bg_gif(); 
            break; 

            case "stab_bs_gif":  
                gonximage::stab_bs_gif(); 
            break; 

            case "stab_bu_gif":  
                gonximage::stab_bu_gif(); 
            break; 

            case "stab_es_gif":  
                gonximage::stab_es_gif(); 
            break; 

            case "stab_eu_gif":  
                gonximage::stab_eu_gif(); 
            break; 

            case "stab_msu_gif":  
                gonximage::stab_msu_gif(); 
            break; 

            case "stab_mus_gif":  
                gonximage::stab_mus_gif(); 
            break; 

            case "stab_muu_gif":  
                gonximage::stab_muu_gif(); 
            break; 

            case "stab_sb_gif":  
                gonximage::stab_sb_gif(); 
            break; 

            case "stab_ub_gif":  
                gonximage::stab_ub_gif(); 
            break; 

        } // switch 
    } 
    function bar_b_gif()  
    { 
        header("Content-type: image/gif"); 
        header("Content-length: 53"); 
        echo base64_decode( 
'R0lGODlhBQAFAJEAAAAAAP///8zMzP///yH5BAEAAAMALAAAAAAFAAUAQAIG'. 
'nC2Zx30FADs='. 
''); 
    }

    function bar_l_gif()  
    { 
        header("Content-type: image/gif"); 
        header("Content-length: 54"); 
        echo base64_decode( 
'R0lGODlhBQAFAJEAAAAAAP///8zMzP///yH5BAEAAAMALAAAAAAFAAUAQAIH'. 
'1D6Gepw4CgA7'. 
''); 
    }

    function bar_r_gif()  
    { 
        header("Content-type: image/gif"); 
        header("Content-length: 54"); 
        echo base64_decode( 
'R0lGODlhBQAFAJEAAAAAAP///8zMzP///yH5BAEAAAMALAAAAAAFAAUAQAIH'. 
'nCeHmtcmCgA7'. 
''); 
    }

    function bar_t_gif()  
    { 
        header("Content-type: image/gif"); 
        header("Content-length: 52"); 
        echo base64_decode( 
'R0lGODlhBQAFAJEAAAAAAP///8zMzP///yH5BAEAAAMALAAAAAAFAAUAQAIF'. 
'lD2py1wAOw=='. 
''); 
    }

    function corner_bl_gif()  
    { 
        header("Content-type: image/gif"); 
        header("Content-length: 99"); 
        echo base64_decode( 
'R0lGODlhBQAFALMAAAAAAP///9TV1+Xp7uPn69XW19zf4fPz8/Ly8ufn59zc'. 
'3NnZ2dLS0s/Pz8zMzP///yH5BAEAAA8ALAAAAAAFAAUAQAQQsI1HQziKIWfo'. 
'KtQTJI5ARAA7'. 
''); 
    }

    function corner_br_gif()  
    { 
        header("Content-type: image/gif"); 
        header("Content-length: 99"); 
        echo base64_decode( 
'R0lGODlhBQAFALMAAAAAAP///9TV1+Xp7uPn69XW1/Pz8/Ly8ufn59zc3NnZ'. 
'2dLS0s/Pz8zMzP///wAAACH5BAEAAA4ALAAAAAAFAAUAQAQQ0MnBVjIhSNfO'. 
'LgohNEgQAQA7'. 
''); 
    }

    function corner_tl_gif()  
    { 
        header("Content-type: image/gif"); 
        header("Content-length: 99"); 
        echo base64_decode( 
'R0lGODlhBQAFALMAAAAAAP///9TV1+Xp7uPn69XW19zf4fPz8/Ly8ufn59zc'. 
'3NnZ2dLS0s/Pz8zMzP///yH5BAEAAA8ALAAAAAAFAAUAQAQQMISjWBsvI2dy'. 
'SI5ALEX2RAA7'. 
''); 
    }

    function corner_tr_gif()  
    { 
        header("Content-type: image/gif"); 
        header("Content-length: 99"); 
        echo base64_decode( 
'R0lGODlhBQAFALMAAAAAAP///9TV1+Xp7uPn69XW19zf4fPz8/Ly8ufn59zc'. 
'3NnZ2dLS0s/Pz8zMzP///yH5BAEAAA8ALAAAAAAFAAUAQAQQkKkTwrujXeMQ'. 
'EU5iXcUSAQA7'. 
''); 
    }

    function delete_gif()  
    { 
        header("Content-type: image/gif"); 
        header("Content-length: 531"); 
        echo base64_decode( 
'R0lGODlhEAAQAOYAAAAAAP///9jRxO/i2O/j2+i2n+yvlfLYzP3KuPzJt/zO'. 
'vvfSw/bUx/XUyfl9VvmNafu9qf3HtfjIuPvLu/9iOP9lOv9VJ/9wR/9aK/lh'. 
'NfhkO/9xR/9xSPptRf9/WflxTPl5VP+0neQsAPEuAPQvAP8zA/oxAP83Cf87'. 
'CvoxAOgwAPkvAP88DP9IGf9JGv9JGv9DF/81Av9ADv41AP9GFv9GF/9YMP9F'. 
'F/9WKv9JGv9GGeYnAOAnAPcsAP4vAP8zBvwuAP8kAPYjAPIlAOojAOkhAOAk'. 
'AN0jANUgANUiAPojANsdANkeAOIaANYXAP///wAAAAAAAAAAAAAAAAAAAAAA'. 
'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'. 
'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'. 
'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAEAAE8A'. 
'LAAAAAAQABAAAAdwgE+Cg4SFghctCoaLNkEnCIsFA4QvSiUJhR4uBoU4Qj4R'. 
'ggQUKBOLFUM9Dw0wPwuLghsjJCYsDLCDNEVEHLhPBzU7MikiDrASK003gkBG'. 
'IIYhPEs5hDFHH4QQTkgYhjpMHYQqGbAWSRq+hBkz6e2+gQA7'. 
''); 
    }

    function e_blank_gif()  
    { 
        header("Content-type: image/gif"); 
        header("Content-length: 43"); 
        echo base64_decode( 
'R0lGODlhAQABAID/AMDAwAAAACH5BAEAAAAALAAAAAABAAEAQAICRAEAOw=='. 
''); 
    }

    function fleche_blue_gif()  
    { 
        header("Content-type: image/gif"); 
        header("Content-length: 858"); 
        echo base64_decode( 
'R0lGODlhCQAOAPcAAABHlgBs5jGS/2mw/5/M/8fh/////wAAAAAAAAAAAAAA'. 
'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'. 
'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'. 
'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'. 
'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'. 
'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'. 
'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'. 
'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'. 
'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'. 
'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'. 
'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'. 
'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'. 
'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'. 
'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'. 
'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'. 
'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'. 
'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'. 
'AAAAAAAAAAAAAAAAAAAAACwAAAAACQAOAEAIPwABADBAsKABAAUECAgAYACB'. 
'gwkXDiQo0KFBiAwvIlSoMCNChhYpZtSYcCTFiBJPcgQJUWJIACAfGiQg02BA'. 
'AAA7'. 
''); 
    }

    function fleche_red_gif()  
    { 
        header("Content-type: image/gif"); 
        header("Content-length: 97"); 
        echo base64_decode( 
'R0lGODlhCQAOAKIAALWytc7Pzv8xMbUxMWUxMf/Gxv///wAAACH5BAEAAAYA'. 
'LAAAAAAJAA4AAAMmSGTcRmO5V+IkRdiGhZaU9zGdaJUfEKZBGAEt9cbP7Cjw'. 
'ZAR0kwAAOw=='. 
''); 
    }

    function fleche_gif()  
    { 
        header("Content-type: image/gif"); 
        header("Content-length: 97"); 
        echo base64_decode( 
'R0lGODlhCQAOAKIAALWytc7PzmNlMbWaMf/zxv/PMf///wAAACH5BAEAAAYA'. 
'LAAAAAAJAA4AAAMmKGLcJmO5R+IUpNiGi5aU9zGdaJUfEKZBGAEt9cbP7Cjw'. 
'ZAR0kwAAOw=='. 
''); 
    }

    function left_gif()  
    { 
        header("Content-type: image/gif"); 
        header("Content-length: 1004"); 
        echo base64_decode( 
'R0lGODlhCQCWAPcAAKWlpbW1tcbGxs7OztbW1ufn5+/v7/f39///zv//////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'/////////////////////ywAAAAACQCWAEAI0QATCEwgIACAgwAMIFjIEAGA'. 
'Ag0ZPoy4cCJFixExNtQoEeJFjxlBbhTZkaJDkhVRnjTJMSVLlQIGHJh5wIDN'. 
'hC9zftQZkudInyV3Cu059GfRoEQjJhggwMDMBAcSJKyZUeFRl1dXZm2pNalR'. 
'r0i/ig1LFitYs2PRlu2alu1arnBVxgWqtq7bhQIHBBhQgGaCAAWg0jQAeGZV'. 
'wxutVmWpuO3crXIj071L+fHZypIhT7bsOPNlzm89d94sOjTp05pTfy5tF3Rr'. 
'1phRr5Y9WnXtiAEBADs='. 
''); 
    }

    function left_on_gif()  
    { 
        header("Content-type: image/gif"); 
        header("Content-length: 1071"); 
        echo base64_decode( 
'R0lGODlhCQCWAPcAAP///2ZmZv7+/v39/fn5+fj4+P39/fv7+/j4+Pf39/Ly'. 
'8vT09PHx8e/v7/Pz8/X19dnZ2bOzs/T09HFxcebm5ouLi4aGhoWFhaSkpNHR'. 
'0e7u7tHR0by8vLCwsK6uruDg4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'. 
'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'. 
'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'. 
'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'. 
'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'. 
'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'. 
'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'. 
'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'. 
'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'. 
'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'. 
'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'. 
'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'. 
'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'. 
'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'. 
'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'. 
'AAAAAAAAAAAAAAAAAAAAACH5BAEAAB8ALAAAAAAJAJYAAAj+AD8IzNChwoQA'. 
'AQRysBABggQAAD5wwEABosUNFypahOghwkaLFSB8hDjh4cgAIyGihCigZcsA'. 
'Lg0YGEAzwMwBBwgQKFAgAM2cCBIkeBBAZwEEDxwoYFD0aAKlDRo0DeqAQQMN'. 
'RXcmWLCUac6jD7gqCHDga9AFC3zi3IkgqM2ZOXf2lHmz7AGYLenWZOnyZUoA'. 
'K0/+DfyR8EbDFhGrHMw4pWLAjQU7jlyY8mHLiTEvnsxZsufKnUF/vhya9OjM'. 
'pVGf3rwacmrWomOblq2aNuzZuGvnvq27N+/frls/Hq45uG3ju5H7Vg6c+Gvm'. 
'0J0LLy79ePXk15dnb069+/Pt0b0NT/8u3np57Oe1pwceEAA7'. 
''); 
    }

    function right_gif()  
    { 
        header("Content-type: image/gif"); 
        header("Content-length: 1599"); 
        echo base64_decode( 
'R0lGODlhkAGWAPcAAKWlpa2trb29vcbGxs7OztbW1t7e3ufn5+/v7/f39///'. 
'zv//////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'/////////////////////ywAAAAAkAGWAEAI/gABCBxIsKDBgwgTKlzIsKHD'. 
'hxAjSpxIsaLFixgzatwIMcCABSAXKBhJsqTJkyhTqlzJsqXLlzBjypxJs6bN'. 
'mzhz6tzJ0yaAnkCDCh1KtKjRo0iTHv2ptKnTp1CjSp1KlSXTqlizat3KtWvT'. 
'q17Dih1LtqxWsGbTql3Ltu1LtG7jyp1LFyvcunjz6t2L8y7fv4AD//UruLDh'. 
'w2YJI17MuHFUxY4jS57MEzLly5gzr7SsubNnypw/ix5tODTp06jxmk7NurXa'. 
'1a5jy+YKe7bt21AF4N7N+2zv38Cf1g5OvDjM4caTKzeJfLlz482fS/8dfbr1'. 
'29Wva3edfbv3092//ov3HH68+cvlz6t3nH69+8Pt38sHHH++/bz17+uXm3+/'. 
'/7X9/ScgWQAkYGACCxiYIIIKNsjggwtG6KCEEE5oYYUYUqjhhRtmyOGHHobY'. 
'4YggkihiiSieqKKJLKbY4oouxgjjjCYaiAACBhQggAAiDegjYwH+KGRWQQ5p'. 
'pFRFHqnkV0s2WVeSTkYpFJRSVrkTlVZm6ZOWXIaFZZdgtvRlmGSiNGaZaI50'. 
'ZpplrslmmG6+2WWccmpJZ51W3omnlHru6WSffi4JaKBHDkrokIYe+mOiig7I'. 
'aKP/PQrpfpJOel+lls6Haabvbcrpep5+el6ooo5HaqnfnYrqdqquel2r/q5O'. 
'V+CCB9Zq66245qrrrrz26uuvwAYr7LDEFmvsscgmq+yyzP6KQAEDBMBjj7FC'. 
'SkAABFSbaQDaWgprt8p9Cy504zYqbrnBnYsudesSqm67u70LL3bz7ilvvbLd'. 
'iy93+8qpb7+p/QsweAOnKXDBoh2MMHkLk6lww5k9DDF6E89ZMZcSXxxZxho3'. 
'xnHHi30MMnwj81lylCKfHFjKKg/WsqAvK8lyzPjRbOTMNtOFc8788byozz7u'. 
'DDRbQg/9mtGRIu1f0UoT2LR+TD/tpdT2RU01bVfLZ3XWRHLt3tZeUwV22EiS'. 
'ParZ5o2NtlNqr61U224jBXfcRs1NN1F23z2lJ96v8m1d3n5XFrh0gA+eU+GG'. 
'34R44jUtzvhMjj8eU+SSv1V5cQAEBAA7'. 
''); 
    }

    function right_on_gif()  
    { 
        header("Content-type: image/gif"); 
        header("Content-length: 2067"); 
        echo base64_decode( 
'R0lGODlhkAGWAPcAAP////39/f7+/vHx8fj4+O7u7mZmZu/v7/n5+fX19fT0'. 
'9Pf398nJyYODg93d3eHh4evr66Kiovj4+OTk5Ojo6ODg4PLy8vPz8/39/e3t'. 
'7fv7++zs7LOzs+Xl5XBwcODg4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'. 
'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'. 
'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'. 
'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'. 
'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'. 
'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'. 
'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'. 
'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'. 
'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'. 
'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'. 
'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'. 
'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'. 
'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'. 
'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'. 
'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'. 
'AAAAAAAAAAAAAAAAAAAAACH5BAEAAB8ALAAAAACQAZYAAAj+AA0IHEiwoMGD'. 
'CBMqXMiwocOHECNKnEixosWLGDNq3PjQQ4MIDD6IBECypMmTKFOqXMmypcuX'. 
'MGPKnEmzps2bOHPq3Mmzp0sBASRQYBChAYeRPpMqXcq0qdOnUKNK5QlUgoUN'. 
'QyMcncq1q9evYMOKHVuyqgUIHR4waMCArNu3cOPKndvULNoHDiJEoMu3r9+/'. 
'gMPaTVthbeDDiBMrXrxyMF4HHhhLnky5suCgZwk7MCCgs+fPoEOLHk26tOnT'. 
'qFOrXs26tevXsGPLnk27tu3TGDRIGHDXweYAwIMLH068uPHjyJMrX868ufPn'. 
'0KNLn069uvXr2LMr10AgAe8Jjw3+EBhPvrz58+jTq1/Pvr379/Djy59Pv779'. 
'+/jz69/P3/2CCwVQ8EAFvhmQwIEIJqjgggw26OCDEEYo4YQUVmjhhRhmqOGG'. 
'HHbo4YcgRqjABQdskJZvmw2g4oostujiizDGKOOMNNZo44045qjjjjz26OOP'. 
'QAYp5JA0HlAiBeChaEABTDbp5JNQRinllFRWaeWVWGap5ZZcdunll2CGKeaY'. 
'ZJZ5ZQYQIPnYZma26eabcMYp55x01mlnmRlskCZhFVRggJGABirooIQWauih'. 
'iCaq6KKMNuroo5BGKumklFZq6aWYLloAmhSk9cADBhAp6qiklmrqqaimquqq'. 
'oh7AKQX+nRqgwKy01mrrrbjmquuuvPbq66/ABivssMQWa+yxyCar7LLM9nrB'. 
'BRYMsKmeEBiwwLXYZqvtttx26+234IYr7rjklmvuueimq+667Lbr7rvwinsg'. 
'tAMAKl5/+Oar77789uvvvwAH3J8ECyQw67MGIKDwwgw37PDDEEcs8cQUV2zx'. 
'xRhnrPHGHHfs8ccghyzyyBePJ8HJEhig3cost+zyyzDHLPPMNLOswc0Lc3bb'. 
'zjz37PPPQAct9NBE74zB0UgbYNnSTDftdFJKPy311FRXXVLUVmet9daIYc31'. 
'12CHLZbXYpdt9tlQo6322mzPRHbbcMfN9tty123313Tfrff+3k/nzfffgDPm'. 
'd+CEF97X4IYnrvhYiC/u+ONRNQ755JT3JHnlmGfutuacd37T5Z6H7jnoopeO'. 
'Oemmp/446qq3bjjrrsf+N+yy12437bbn3jbuuvd+Nu++Bw828MIXnzXxxicv'. 
'NfLKN780885HLxn00lfftfXYc0199tzPtX334Lv1ffjkgzV++ehPdX767Du1'. 
'fvvwpx3//IfTb7/39+f/1vv69+8S//4LYEoAKMACkoSABhQgAhPovwUyUH8O'. 
'fOD9IihB+lGwgvG7IAbbp8ENpq+DHiwfCEMYvhGSsHsmPGH2UqhC67GwhdJ7'. 
'IQydJ8MZKq+GNjQeDnMovB3y0Hf0Pvyh7oIoRNsRsYiyOyISXafEJaquiU40'. 
'HRSjKLopUnF0V/SgFbOouS1y8XRfrKAXwzi5MZJxdWdkoBnTqLg1svF1byyg'. 
'G+MYuDnScXZ3bGAe+2fHPd6tj36sGyADGbdBEnJ3h7RgIudnyEWirZGONBsk'. 
'Iym2SVJyeJf8YCbRZ8lNaq2TnrQaKENJtVGScnmnRGEquWfKVTKtla60DCxj'. 
'SZlZ0nJ6t4xhLqNny10mppe+PAwwgwmYYRLTL8Y8Jl+SqUz8NTN4zHwmXKIp'. 
'TfFVs3fUvObYtJm7bHLzK978ZlfCKU71lTN25DwnVNKpTve184kBAQA7'. 
''); 
    }

    function stab_bg_gif()  
    { 
        header("Content-type: image/gif"); 
        header("Content-length: 396"); 
        echo base64_decode( 
'R0lGODlhEAAYANUAAPr6+vj4+Pz8/Pv7+/7///n5+fj49/z8/fn5+Pb39/z7'. 
'+/j5+fn5+vn4+fz7/P/+//7//v3+/ff4+Pr7+vr6+/3+/v39/vn6+fr5+vb3'. 
'9vf29vz9/fz9/Pb29/r5+f39/Pf49/n6+vr6+ff3+Pv7+v79/vj4+fj3+P38'. 
'/P7+/f38/fv7/Pf39vv6+/v8+////vf29/v8/P39/f7+/vf394yKjPb29v//'. 
'/wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACwAAAAAEAAYAEAGscCbcEgs3giQ'. 
'B+H2uEGWhFfyaAgEJAGDpGrFGk4go3jocCgUjoFAfXYJYoOVbU6v223jvL4Y'. 
'Scn+Fn+CMhYRMhEXDCIXAB4MDAAiIQAhHhgYCTQJLAkZGjA0GR02mhqjd6hz'. 
'e6usra0zsLAlsBUlFbGwKCobAhwyBwIfBx8bB8AcAyQTABQkLRQTEwMAzNQL'. 
'CwUmCAgNCAUF3AUN2DQ0BiPl6egg6TSp7/B2NfP09fY1QQA7'. 
''); 
    }

    function stab_bs_gif()  
    { 
        header("Content-type: image/gif"); 
        header("Content-length: 37"); 
        echo base64_decode( 
'R0lGODlhAQAYAIAAAIyKjAAAACwAAAAAAQAYAEACBISPqVcAOw=='. 
''); 
    }

    function stab_bu_gif()  
    { 
        header("Content-type: image/gif"); 
        header("Content-length: 37"); 
        echo base64_decode( 
'R0lGODlhAQAYAIAAALu7uwAAACwAAAAAAQAYAEACBISPqVcAOw=='. 
''); 
    }

    function stab_es_gif()  
    { 
        header("Content-type: image/gif"); 
        header("Content-length: 859"); 
        echo base64_decode( 
'R0lGODlhCgAYAPcAAIyMjL29vf//zv//////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'/////////////////////ywAAAAACgAYAEAIQAADBBhAsCBBAQgTJgygsCFD'. 
'hQMLNoQ4ceFCgwcnRqyI8GFFjxo5CngYESNEkw4lfhwgEqTDljA5uqQoUySA'. 
'gAAAOw=='. 
''); 
    }

    function stab_eu_gif()  
    { 
        header("Content-type: image/gif"); 
        header("Content-length: 861"); 
        echo base64_decode( 
'R0lGODlhCgAYAPcAAIyMjL29vf//zv//////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'/////////////////////ywAAAAACgAYAEAIQgADBBhAsCBBAQgTJgygsCFD'. 
'hQMLNoQ4ceFCgwcnRqyI8GFFjxo5CngYESNEkw4lfhwgEqTDljA5uqQoE4DN'. 
'mzgDAgA7'. 
''); 
    }

    function stab_msu_gif()  
    { 
        header("Content-type: image/gif"); 
        header("Content-length: 89"); 
        echo base64_decode( 
'R0lGODlhDgAYAJEAAPb29ru7u4yKjP///ywAAAAADgAYAEACMpSPMhPrPxSD'. 
'UIRLn2x57e4BIhgtXPeBKWqSggi4sNuqNTvZOX5mq38D7nwzVRF19B0KADs='. 
''); 
    }

    function stab_mus_gif()  
    { 
        header("Content-type: image/gif"); 
        header("Content-length: 877"); 
        echo base64_decode( 
'R0lGODlhDgAYAPcAAIyMjL29vf//zv//////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'/////////////////////ywAAAAADgAYAEAIUgADCBxIMMCAAQAEKFzI0CBC'. 
'hhAFDEwYcaFDihUlHsSYUSHHiBc7anzYMWTJjSIXfsy4siHKkyQzmpT5kmbM'. 
'ijNx1tR5s2PLiD8hAhhKtKjRgAAAOw=='. 
''); 
    }

    function stab_muu_gif()  
    { 
        header("Content-type: image/gif"); 
        header("Content-length: 869"); 
        echo base64_decode( 
'R0lGODlhDgAYAPcAAIyMjL29vf//zv//////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'/////////////////////ywAAAAADgAYAEAISgADCBxIMMCAAQEEKFzI0CBC'. 
'hhAFEIzY8GBCigodXsTIEaLGjh85hsQ4sqPJkxktglQpkiVJlxRLRpTpEeZM'. 
'myhzdgTAs6dPnwEBADs='. 
''); 
    }

    function stab_sb_gif()  
    { 
        header("Content-type: image/gif"); 
        header("Content-length: 47"); 
        echo base64_decode( 
'R0lGODlhCAAYAIAAAIyKjP///ywAAAAACAAYAEACDoRvocvtD6OctNqLs64F'. 
'ADs='. 
''); 
    }

    function stab_ub_gif()  
    { 
        header("Content-type: image/gif"); 
        header("Content-length: 828"); 
        echo base64_decode( 
'R0lGODlhCAAYAPcAAIyMjL29vf//zv//////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'////////////////////////////////////////////////////////////'. 
'/////////////////////ywAAAAACAAYAEAIIQADCBwoUIDBgwgTKlzIsKHD'. 
'hxAjSpxIsaLFhAAyaswYEAA7'. 
''); 
    }


} 
?>