<?php

/**
 * GONX TABS image
 * 
 * @package 
 * @author Ben Yacoub Hatem <hatem@php.net>
 * @copyright Copyright (c) 2004
 * @version $Id$ - 04/04/2004 15:40:34 - index.php
 * @access public
 **/

error_reporting(0);
extract($_GET);
session_start();
require_once("init.php");

/*
* Set default theme
*/
$tabs = gonxtabs::init();
/*
* end theme
*/

if (is_file("themes/".$tabs."/".$tabs.".class.php")) {
    require_once("themes/".$tabs."/".$tabs.".class.php");
	if (isset($img) and $img!="") {
	    gonximage::getimage($img);
	}
}

?>