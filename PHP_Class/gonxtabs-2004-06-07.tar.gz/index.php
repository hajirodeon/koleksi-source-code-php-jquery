<?php

/**
 * GONX TABS sample usage
 * 
 * @package 
 * @author Ben Yacoub Hatem <hatem@php.net>
 * @copyright Copyright (c) 2004
 * @version $Id$ - 04/04/2004 15:40:34 - index.php
 * @access public
 **/

error_reporting(E_ALL);
session_start();
require_once("init.php");
extract($_GET);

/*
* Set default theme
*/
$tabs = gonxtabs::init();

/*
* end theme
*/


$menus = array("home"=>"Home Page",
				"page1"=>"Page 1",
				"page2"=>"Page 2",
				"page3"=>"Page 3",
				"javascript::window.close()"=>"Close");
				
$t = new gonxtabs();
$res =  "
<html>
<head>
	<title>GONX Tabs</title>
	<style type=\"text/css\" media=\"screen\">@import \"themes/".$tabs."/".$tabs.".css\";</style>
</head>
<body>
<center>
<p><br><span class=title>GONX Tabs</span></p>";
if (!isset($go)) {
    $go = "home";
}
$res .= $t->create($menus,$go,620);

switch($go){
	case "page3": 
		$page = "<li>Page 3 content";
	break;
	
	case "page2": 
		$page = "<li>Page 2 content";
	break;
	
    case "page1": 
		$page = "<li>Page 1 Content";
	break;

	default:
		$page = "<li>Home page";
	break;
} // switch


// I added the theme menu here with the page content.
$res .= $t->block($page,620 );
echo "</center><html>";	
echo $res;
?>