<?php

$GonxAdmin["theme"] = "defaults";

require_once("libs/gonxtabs.class.php");
?>