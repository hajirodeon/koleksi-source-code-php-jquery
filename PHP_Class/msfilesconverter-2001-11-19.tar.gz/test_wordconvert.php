<?php
/* 
 * Example using the wordconvert Class to convert an RTF document to the html format.
 * (c) Alain M. Samoun 10/2001.
 * alain@samoun.com
 * Gnu GPL code (see www.fsf.org for more information).
* Tested on win98 + Apache PHP 4.8 dev, PHP4.6 - Word 2000
*If you try to use COM in win2k/XP or NT, you >need to set-up permissions to the application
 with the program >DCOMCNFG.EXE : 
	Run DCOMCNFG.exe, select the application and add permissions in Security:
	- Custom Access Permissions: �Allow� 
	Then Edit / Add
	- the �IUSR_<servername>� user access to the object.- The user account to run the application:
	 �The interactive user� 
	And close.
* To run this example: Put the wordconvert.php file in your include directory, 
	Edit the filename  and the extension that you wish below.
then call this file from your server or run it from the command line.
	



*/

       require ("wordconvert.php"); # The class file wordconvert.php should be saved on the PHP include directory
	
	# Change as you wish with your own values:
		$filename="c:/windows/desktop/my briefcase/manual.rtf";
		$ext = "htm"; # - will convert above rtf file to htm file
		$ext = 8;     # Same as above. See class info for 
                              # Extension <-> Number correspondence.
		$vis= 1;      # =1Word will be visible, =0 to hide it
	
	# Run the script with the above values	
	new wordconvert($filename,$ext,$vis); #Does the trick
	

	print "done!";
?>