<?php
	include 'calendarSuite.php';
	$cal = new calendarSuite();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
	<title>Calendar</title>
	<link rel="stylesheet" type="text/css" href="stylesheet.css">
</head>

<body marginwidth="0" marginheight="0" topmargin="0" leftmargin="0" bgcolor="#cccccc">
<center>&nbsp;<p>
<table cellspacing="1" cellpadding="4" class="frame" style="border: 1px solid black;" bgcolor="#666666">
<tr>
	<th width="18">So</th>
	<th width="18">Mo</th>
	<th width="18">Di</th>
	<th width="18">Mi</th>
	<th width="18">Do</th>
	<th width="18">Fr</th>
	<th width="18">Sa</th>
</tr>
<?php

$cal->getMonth("now");
$count=0;

	for($i=0; $i < $cal->daysMonth;) {
		if($count==0) { echo "<tr bgcolor=\"#e7e7e7\">\n";}

		if($count==($cal->day[$i][7])) {
			echo "<td align=\"center\" onMouseOver=\"this.bgColor='#f0f0f0'\" onMouseOut=\"this.bgColor='#e7e7e7'\">\n<a href=\"#\">".($cal->day[$i][0])."</a>\n</td>\n"; $i++;
		} else {
			echo "<td>&nbsp;</td>\n";
		}

		if($count==6) { echo "</tr>\n\n"; $count=0; } else { $count++; }
	}

?>
	</td>
	</tr>
	
	</table>
	
</table>

</body>
</html>