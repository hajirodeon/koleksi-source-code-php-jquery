<?
/*
 * Aprint test module
 */
require_once('aprint.php');
$p=new aprint("test_1","aprint_test1.php-1.1.5");

$p->SetMargin(2880,1400,1200);
$p->HeaderText("test_1");
$p->Text("Left text");
$p->Text("Center text",-1,AP_CENTER);
$p->Text("Right text",-1,AP_RIGHT);
$fnt=$p->CreateFont("Arial");
$p->Text("          Arial text",$fnt);
$fnt=$p->CreateFont("arial",300,150,200,false,false,false,'900');
$p->BlankRow();
$p->BlankRow();
$p->BlankRow();
$p->BlankRow();
$p->BlankRow();
$p->Text("Arial text 90",$fnt);

// $p->Text("iiiii iiii");
// $p->Text("mmmmm mmmm");
$p->run();
?>
