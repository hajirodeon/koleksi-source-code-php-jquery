CodeThatGrid JavaScript
Copyright (c) 2003-04 CodeThat.Com
===============================

CodeThatGrid is an advanced JavaScript grid looking like Microsoft Excel grid 
hat enables user to display in efficient and fancy way the massifes of 
data from variety of sources including the CVS and database. Fully customizable 
through the CSS the grid is the definite answer to the numerous cases when 
structured data has to be displayed. 
           
CodeThatGrid comes in two editions STANDARD and PRO. Editions differ by the 
features set and license type. To find out more about the product please visit
the following pages:

CodeThat.Com site:
http://www.codethat.com/

CodeThatGrid (Standard/PRO):
http://www.codethat.com/grid/

CodeThatGrid documentation:
http://www.codethat.com/grid/grid_manual.html

Standard vs PRO:
http://www.codethat.com/standard_vs_pro.html

===============================
CodeThatGrid JavaScript
Copyright (c) 2003-04 CodeThat.Com
