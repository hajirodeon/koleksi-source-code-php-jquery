<?php
/* Examples and Documentation to the Logging class */

# of course, include the file first
include('./class.logging.inc.php');



# Ways to initialize

	# Will log to STDERR
	$Log = new Logging(L_STDERR);
	
	# Will log to STDOUT, with <PRE> and <B> tags wrapped around it
	$Log = new Logging(L_STDOUT);
	
	# Will log to supplied file, attempts to create file if it
	# doesn't exist. If file does not exist and cannot be created
	# it defaults to STDOUT
	$Log = new Logging('/pat/to/file/filename');
	
# Settings
	
	# Disabling a log type will prevent it from being written to
	# anywhere. You should only consider disabling the 'notice'
	# type, since the others might be pretty usefull to view ;)
	$Log->disableType('notice');
	
	# And you can enable it again by invoking:
	$Log->enableType('notice');
	
	# Change the logging type
	$OldType = $Log->setLogType(L_STDERR);
	
	# Restore it
	$Log->setLogType($OldType);
	
# The Logging

	# Methods of spawning a logentry.
	$Log->Error('Some error occured');
	$Log->Notice('Please be notified of the following');
	$Log->Fatal('Fatal error, will die off');
	$Log->Warning('I\'d like to warn you of something');
	
	# And one special one. Will will export $VarName to the specified
	# error log/screen using var_export.
	$Log->Dumper($VarName);

# Internals

	# Is invoked by every logentry spawner to actually write to the
	# error log/screen. For every type that is not notice, it will
	# also print an entire stacktrace from point of begin to point of
	# error.
	$Log->_doWrite($Type, $String);
?>