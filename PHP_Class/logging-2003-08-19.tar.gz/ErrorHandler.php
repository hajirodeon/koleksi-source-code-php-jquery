<?php
# Function for errorHandling
function logging_ErrorHandler ($Code, $String, $File, $Line) {
	global $Log;

	$ErrorString = '['.$File.' (Line '.$Line.')] '.$String;

	switch($Code) {
		case 0:
			# Call was preceeded with a @ sign.. not sure what to do..
			$OLT = $Log->setLogType(L_STDERR);
			if ($OLT != L_STDERR) {
				$Log->Notice('{@} '.$ErrorString);
			}
			$Log->setLogType($OLT);

			break;
		case E_ERROR:
		case E_USER_ERROR:
			$Log->Error($ErrorString);
			break;
		case E_WARNING:
			$Log->Warning($ErrorString);
			break;
		case E_PARSE:
			$Log->Fatal($ErrorString);
			break;
		case E_NOTICE:
			$Log->Notice($ErrorString);
			break;
		default:
			$Log->_doWrite('PHP ERROR: '.$Code, $ErrorString);
	};

}
set_error_handler("logging_ErrorHandler");
?>