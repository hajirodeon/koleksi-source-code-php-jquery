<?php
//<SMARTHEADER>
/*************************************************

Class Header
Author: Chris McCreadie
Copyright (c): 2001 ,SmartEngine all rights reserved

This is the HTML header class for use with the class extender


*************************************************/
//</SMARTHEADER>
//<SMARTHISTORY>
/*************************************************

History

17/08/2001

Coded basic class


*************************************************/
//</SMARTHISTORY>


class headerclass2
{
	
	//<vars>


	//version info
	var $build = "100";
	var $version = "1.0";
	var $author = "Chris McCreadie";
	var $copyright = "Smartengine 2001";
	var $message = "Oh Baby, Lets Render";
	var $classname = "SmartHTMLRender";

	//</vars>

	//<class>
	function givesource(){
		# show_source( __FILE__ );
		#echo __FILE__;
		return(__FILE__);
	}

	function showsource(){
		show_source( __FILE__ );
	}

	function identify(){
		#16/08/2001
		#added identify function
		echo "This is to show that the Class $this->classname($this->title) has loaded<br><br>";
		echo "Build $this->build<br>Version $this->version<br>Author $this->author<br>Copyright $this->copyright<br>Identify Message $this->message<br><br>";
	}

	function test()
	{

	}






	//</class>



}


?>