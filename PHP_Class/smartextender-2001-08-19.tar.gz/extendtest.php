<?php

include "smartextender.php";
#confgiure main class
$tb = new smartextender; 

#give your new class a name
$tb->setup("SmartTest1");

#get the functions of the class
$tb->addfunctions("headerclass","headerclass.class.php");
$tb->addfunctions("headerclass2","headerclass2.class.php");

#get a status report
$tb->status();
#output it and save show source set to n not to show.
$tb->output("file1.php","y");


?>