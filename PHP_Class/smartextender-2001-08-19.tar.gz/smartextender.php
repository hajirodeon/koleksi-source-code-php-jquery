<?php

/*************************************************

Smart Extender 
Author: Chris McCreadie
Copyright (c): 2001 ,SmartEngine all rights reserved


This program Takes a list of functions from various classes and 
complies them into one class.  It is not a super neat solution but
it addresses the PHP problem of having just one extension.  It basically 
works as a compiler for PHP.

Email : chris@simplehq.com
Web   : www.simplehq.com



Enjoy

14/08/2001

*************************************************/

/*************************************************
History

14/08/2001

Added the main procerssing engine and class loaded
Added the class outputter.
it finds duplicate variables and increments it in code IE $build becomes $build1 $this->$build in code
make it check duplicate functions and if it finds it automotaclly update.

To Do

Allow users to turn off display History/header etc.
Allow user to set authors for functions
Add custom function addtion
Add the ability to compile all identifys into one main functions that has it for them all!
Makje it look for a function and var that is above 1 so if name,name,name are 3 vars my system would do name,name1,name1 we need a name 2

replace all $blah->wah to $this-> as that is what is needed when the whole class is compiled

*/
class smartextender
	
{

	var $code = array();
	var $history = array();
	var $header = array();
	var $history = array();
	var $classes = array();
	var $vars = array();
	var $classcount = 0;
	var $mainheader = "/*************************************************\nSmart Extender\nAuthor: Chris McCreadie\nCopyright (c): 2001 ,SmartEngine all rights reserved\nThis program Takes a list of functions from various classes and \ncomplies them into one class.  It is not a super neat solution but\nit addresses the PHP problem of having just one extension.  It basically\nworks as a compiler for PHP\n\n\n\nEnjoy\n\n";

	var $mainfooter = "*************************************************/\n\n";
	var $classname = "";

	var $varchecks = array();
	var $varcheckhistory = array();
	var $functionchecks = array();
	var $funhistory = array();
	var $functiontemp = ")\n{";

	function identify()
	{

	}

	function showsource()
	{

	}

	function setup($name)
	{
		$this->classname = "$name";

	}

	function addafunction($code)
	{
		#17/08/2001
		#
		#
				#echo "Added $code dd<br>";
		$this->functionchecks[] = $code;		
	
	

	}

	function checkfunction($code,$class,$number)
	{
		#17/08/2001
		#
		#
		#echo
		echo "Checking Class $class functions";
		#explode on the functiojn
	
	
		#now split between function and )
		$functions = explode("function",$code);
		
		$i = 0;
		$counter = count($functions);
		while ($i != $counter)
		{
			preg_match("((.*)+(\s))",$functions[$i],$matches);
		#	$functions2 = eregi("function(.*){",$functions[$i]);

			#check if it has (
			if (stristr($matches[0], ")"))
			{
				#now explode on 
				$functionfin = explode("(",$matches[0]);

				$functions3[] = $functionfin[0];
				#echo "functionfin[0]";
			}
			#echo "<br><br> $i: $functions2[0]<br><br>";
			
			$i++;
		}
		#now count
		$counter = count($this->functionchecks);
		$i = 0;
		if ($counter == 0)
		{
			#just add em
			$counter = count($functions3);
			echo "<br>counter $counter  is<br>";
			while ($i != $counter)
			{	
				#echo "BLah $functions3[$i]<br>";
				$this->addafunction($functions3[$i]);
				$i++;
			}
		}
		else
		{
			$i = 0;
			$counter = count($functions3);
			$blah = 1;
			while ($i != $counter)
			{
				$i2 = 0;
				$counter2 = count($this->functionchecks);
				$newfunction = $functions3[$i];
				$check = 0;
				while ($i2 != $counter2)
				{
					$function = $this->functionchecks[$i2];
					#echo "$function fdf<br>";
					if ($function == $newfunction)
					{
						$check = 1;
						
						$code = $this->code[$number];
						$old = "function $newfunction";
						$new = "function $newfunction$blah";
						$old = trim($old);
						$new = trim($new);
						$old = eregi_replace("[[:space:]]+", " ", $old);
						$new = eregi_replace("[[:space:]]+", " ", $new);
						$codefin = str_replace("$old","$new",$code);
						
						#echo "<br><br>$old<br>$new<br>dfdf";
						#echo "<br>$codefin<br>";
						echo "<br>Function Found Updating $function to $newfunction$blah<br>";
						$this->code[$number] = $codefin;
						//update vars history
						$varshistory = $this->funhistory[$number];
						if ($varshistory == "")
						{
							$varshistory = "\n\n//The following functions were changed \n\n";
							$varshistory = $varshistory."//Original = $old | New  = $new\n";
						#	echo "$varshistory ffdsfsdf";
							$this->funhistory[$number] =$varshistory ;
								   
						}
						else
						{
							$varshistory  = $varshistory."//Original = $old | New = $new\n";
							#echo "$varshistory ffdsfsdf";
							$this->funhistory[$number] = $varshistory ;
							$test = $this->funhistory[$number];
						#	echo "$test ffdsfsdf number $number";
						}

					}
					
					$i2++;
				}
				if ($check == 0)
				{
					#echo "Added $newfunction";
					$this->addafunction($newfunction);
				}
				$i++;
			}
		}
		
	}

	

	function addvar($varnew)
	{
		#17/08/2001
		#
		#add a var to the var array	
		$this->varchecks[] = $varnew;
		#echo "Added $varnew<br>";
	}

	function checkvars($vars,$class,$number)
	{
		#17/08/2001
		#
		#Check the vars and see if they do not already exist
		#loop throguh the var array
		$i = 0;
		$breakvars = explode(";",$vars);
		$counter = count($breakvars);

		echo "<br>Checking Vars for $class<br><br>";
		while ($i != $counter)
		{
			$breakvars2 = explode("=",$breakvars[$i]);
			eregi("var(.*)", $breakvars2[0], $breakvars3);	
			$breakvars3[0] = str_replace("var","",$breakvars3[0]);
			$breakvars3[0] = eregi_replace("[[:space:]]+", "",$breakvars3[0]);
			$breakvars3[0] = trim($breakvars3[0]);
			#$breakvars2[0] = str_replace("=","",$breakvars2[0]);
			#$breakvars2[0] = str_replace('"','',$breakvars2[0]);
			if ($breakvars3[0] != "")
			{
				$breakvars[$i] = $breakvars3[0];
			}
				
			#echo "$i : $breakvars[$i]<br>";
			$i++;
		}
		#now pass it through the var checker
		$i = 0;
		$varchecks = $this->varchecks;
		$counter = count($breakvars);
	
		echo "<br>counteris $counter<br>";
		
		if ($number != 0)
		{
			while ($i < $counter-1)
			{
				$vars = $breakvars[$i];
				$counter2 = count($this->varchecks);
				$i2 = 0;
				$varcheck = 0;
				$blah= 1;
				while ($i2 != $counter2)
				{
					$varnew = $this->varchecks[$i2];
					if ($varnew == $vars)
					{
						$varcheck = 1;
						echo "Var $vars found changing to ";
						$vars = "$vars$blah";
						
						$this->addvar($vars);
						echo "$vars and updating code<br>";

						#get element were dealign with
						$code = $this->code[$number];
						$storedvars = $this->vars[$number];
						
						//convert it from org var to $this->var for code achnages
						$vartemp = str_replace("$", "", $varnew);
						$vartemp2 = $vartemp.$blah;

						#relace ti in code
						$code = str_replace("$vartemp", "$vartemp2", $code);
						#replace it in var buffer
						$storedvars = str_replace("$varnew", "$vars", $storedvars);
						#$this->varloop++;
						#debug
						#echo "$storedvars";

						//check that the one aint been found and copy that back
						//copy it back
						$this->code[$number] = $code;
						$this->vars[$number] = $storedvars;
						$i2 = $counter2-1;

						
						//update vars history
						$varshistory = $this->varscheckhistory[$number];
						if ($varshistory == "")
						{
							$varshistory = "\n\n//The following Vars were changed \n\n";
							$varshistory = $varshistory."//Original = $varnew | New  = $vars\n";
						#	echo "$varshistory ffdsfsdf";
							$this->varscheckhistory[$number] = $varshistory;
						}
						else
						{
							$varshistory  = $varshistory."//Original = $varnew | New = $vars\n";
							#echo "$varshistory ffdsfsdf";
							$this->varscheckhistory[$number] = $varshistory;
						}
						
					}
					$i2++;
				}
				if ($varcheck == 0)
				{
					$this->addvar($vars);
					#echo "<br> ddd $vars<br>";
				}
				$i++;
			}
		}
		else
		{
			//just add em
			$counter = count($breakvars);
			$i = 0;
			while ($i < $counter-1)
			{
				$breakvars[$i] = eregi_replace("[[:space:]]+", "", $breakvars[$i]);
				$breakvars[$i] = trim($breakvars[$i]);
				$this->addvar($breakvars[$i]);
			#=	echo "<br> ddd $breakvars[$i]<br>";
				$i++;
			}


		}


	}

	function addfunctions($class,$filename)
	{
		#14/08/2001
		#
		#Add all the functions
		#
		#get them using a file open, use the give source so that thec class you want to add wants to give it,
		#this is used for 2 reasons, 1 Security, 2 so that we can process the headers etc!.

		include($filename);
		#set up a new instance
		$tb1 = new $class; 
	#	echo "$class, $filename";
		$source = $tb1->givesource();
		
		
		$file = fopen($source, "r"); 
		$data = fread($file, filesize($source)); 
		fclose($file); 
		
		//debug
		//echo "$data";
		
		//now break apart the header
		eregi("//<SMARTheader>(.*)//</SMARTHeader>", $data, $header);
			$header[0] = str_replace ("<smartheader>", "", $header[0]);
		$header[0] = str_replace ("//</smartheader>", "", $header[0]);
		$header[0] = str_replace ("//<SMARTHEADER>", "", $header[0]);
		$header[0] = str_replace ("//</SMARTHEADER>", "", $header[0]);
		#echo "$header[0]";
		//now break apart the history
		eregi("//<SMARTHISTORY>(.*)//</SMARTHISTORY>", $data, $history);
		$history[0] = str_replace ("//<smarthistory>", "", $history[0]);
		$history[0] = str_replace ("//</smarthistory>", "", $history[0]);
		$history[0] = str_replace ("//<SMARTHISTORY>", "", $history[0]);
		$history[0] = str_replace ("//</SMARTHISTORY>", "", $history[0]);
		#echo "$history[0]";

		//now break apart the vars
		eregi("//<vars>(.*)//</vars>", $data, $vars);	

		$vars[0] = str_replace ("//<vars>", "", $vars[0]);
		$vars[0] = str_replace ("//</vars>", "", $vars[0]);
		$vars[0] = str_replace ("//<VARS>", "", $vars[0]);
		$vars[0] = str_replace ("//</VARS>", "", $vars[0]);


	#	echo "$vars[0]";



		//break out the bottom php tags
		eregi("//<class>(.*)//</class>", $data, $code);	
		$code[0] = str_replace ("//<class>", "", $code[0]);
		$code[0] = str_replace ("//</class>", "", $code[0]);
		$code[0] = str_replace ("//<CLASS>", "", $code[0]);
		$code[0] = str_replace ("//</CLASS>", "", $code[0]);
		#echo "$code[0]";
		#echo "$data";
		#show_source($data);

		##ADD TO BUFFERS

		$this->vars[$this->classcount] = $vars[0];
		$this->history[$this->classcount] = $history[0];
		$this->code[$this->classcount] = $code[0];
		$this->header[$this->classcount] = $header[0];
		

		//check that the class does not already exist if ti does add a number to it and keep it in a report
		
		$this->classes[$this->classcount] = $class;
		$this->classcount++;
		echo "Class $class Loaded";
		
	}

	function status()
	{
		#Show Class Load Status
		echo "<br>Class Compiling Status<br>There are currently $this->classcount Classes Loaded<br>";
		echo "The name of the Classes are<br>";
		$i = 0;
		while ($i != $this->classcount)
		{
			$class = $this->classes[$i];
			echo "$i : $class<br>";
			$i++;		
		}
	}

	function addfunction($name)
	{
		#14/08/2001
		#
		#Add an indvidual functions.
		
	}

	function output($filename,$screen)
	{	
		#14/08/2001
		#
		#Write it out

		#set The header
		$fin = "<?php\n";
		$fin = $fin.$this->mainheader;
		
		$fin = $fin."\n\n//Compile Classes Are Listed Bleow\n\n\n";
		$i = 0;
		while ($i != $this->classcount)
		{
			$class = $this->classes[$i];
			$fin = $fin."           $class\n";
			$i++;		
		}
		
		$fin = $fin."\n\n\n".$this->mainfooter;
		$fin = $fin."\n\nClass $this->classname\n{\n\n";

		//add the vars
		$i = 0;
		while ($i != $this->classcount)
		{
			$class = $this->classes[$i];
			$fin = $fin."\n//Vars for class $class\n";
			$vars = $this->vars[$i];
			$this->checkvars($vars,$class,$i);
			$vars = $this->vars[$i];
			$varhistory = $this->varscheckhistory[$i];
			$fin = $fin.$varhistory;
			#echo "GGG $vars<br>";
			$fin = $fin.$vars;

			
			#echo " $varhistory fdfdf<br>";
		#	$fin = $fin."$varhistory";
			
				
			

			
			$i++;		
		}


		//add the code, plus hostorys etc.

		$i = 0;
		while ($i != $this->classcount)
		{
			$class = $this->classes[$i];
			$fin = $fin."\n //Header for $class\n";
			$header = $this->header[$i];
			$fin = $fin."\n$header\n";
			$fin = $fin."\n //History for $class\n";
			$history = $this->history[$i];

		
			$fin = $fin."\n$history\n";
			
							  
			#echo "<br> fdfd $varhistory2 $blah3 dsgehyd<br>";
			$fin = $fin.$varhistory2;
			$code = $this->code[$i];
			$this->checkfunction($code,$class,$i);
			$code = $this->code[$i];
			$varhistory2 = $this->funhistory[$i];
			$fin = $fin.$varhistory2;
			$fin = $fin."\n\n///Code For $class\n";
			$fin = $fin."$code";
			$fin = $fin."\n\n//End of Code For $class\n";
			$i++;		
		}
		//addd fin
		$fin = $fin."\n\n}\n?>";
		$myfile = fopen($filename,"w");
		if (!($myfile))
		{
			echo "file could not be opened";
			#exit;
		}
		else
		{
			fputs($myfile,"$fin");
			fclose($myfile);
			$screen = strtolower($screen);
			if ($screen == "y")
			{
				include($filename);
				#set up a new instance
				$showit = new $this->classname;
				echo "<BR><BR>Outputting teh source, Copy and paste it if you want, Also checking for errors<BR>";
				$showit->showsource();
			}
		}

	
	}

	

}


?>