<?
// Requieres the class file -- Requiere el archivo de clase
require("panel_fichas.php");

// Starts session. It has to be done AFTER the class has been loaded, 
// or weird stuff will happen.
// Inicia la sesi�n. Esto debe hacerse LUEGO de cargar la libreria con
// las definiciones de clase, o sucederan cosas extra�as.
session_start();

// Stuff for inside one of the tabs 
// Lo que va adentro de una de las fichas
$stuff = "Hi, I'm your English contents";

// If object doesn't exists, create it
// Si el objeto no existe, lo crea
if (!isset($_SESSION[M])) {
	// Defines tab contents array
	// Define el vector con las fichas
	$Fichas = array("TP" => array(LABEL => "Tareas Pendientes",
				// The type of this tab is "INCLUDE"
				// El tipo de esta ficha es INCLUDE
				TYPE => "INCLUDE",
				// You should specify which file to include
				// Debe indicar el archivo a incluir
				CONTENT => "file_to_include.php"),
				// Uncomment the following to start this tab disabled
				// Descomente para iniciar con esta ficha desactivada
				//DISABLED => true),
			"PR" => array(LABEL => "Procesos",
				// This tab and the following are type "STRING"
				// Esta ficha y la siguiente son tipo STRING
				TYPE => "STRING",
				// You should provide what's inside. It can be any string you like.
				// Debe proveer lo que va adentro. Puede ser cualquier cadena.
				CONTENT => "Hola, soy tu contenido"),
			//DISABLED => true),
			"MS" => array(LABEL => "Mensajes",
				// Here we use the variable defined above
				// Aqui usamos la variable definida mas arriba
				CONTENT => $stuff),
			"AY" => array(LABEL => "Ayuda",
				CONTENT => "Hola, adivina quien soy")
				);
	// Creates object -- Crea el objeto 
	$_SESSION[M] = new panel_Fichas($Fichas,
									0,
									"width=600 height=200 border=\"0\" align=\"center\" cellpadding=\"0\" cellspacing=\"0\"",
									"style=\"background-color: #00aaff;\"",
									"style=\"background-color: #0077cc;\"");
}
?>
<html>
<head><title>Panel Fichas Demo</title></head>
<body>
<h1 align="center">Panel Fichas Demo</h1>
<?php
$_SESSION[M]->estadoFicha($_REQUEST[ficha],true);
// Changes to active tab -- Cambia a la ficha activa
$_SESSION[M]->cambiarActiva($_REQUEST);
echo "<br>";
// Despliega el panel -- Outputs HTML panel
$_SESSION[M]->htmlPanel();
?>
</body>
</html>