Made by: Nadir Latif (nadir1915@yahoo.com)

1) Overview:

-This class can be used to back up very large databases that can only be accessed from a particular host. For e.g in some cases users may need to backup up a very large database, which cannot be backed up automatically using phpmyadmin because of script timeouts.

-The script retrieves a user defined number of rows from the mysql server and then saves its state in a text file. Javascript is used to refresh the page and the backup process continues from where it left off. The script continues to refresh untill all data has been backup up. After the script ends data is stored in a .sql file. After all the data has been placed in the .sql file, a gzip file is created and the .sql file is deleted from the server.

2) Usage:

-The script must be placed on a web server from where the database can be accessed. When the script is run for the first time the folder in which it is placed must be given 777 permission. This permission can be restored after the scipt has run for the first time. The backup file is placed in a folder created by the script (in gzip format).
-In connection_details.csv the first line should be in the format database_folder_path#server_name [e.g database/#localhost].
-The second line should be in the format username:password:database_name [e.g root:nadir:customer_db]
-Run the script as db_backup.php?restart=1

-The script can easily be extended to backup multiple databases and to maintain periodic backups.

-Feel free to contact me for assistance regarding this script.