<?php
if(!defined("PHP_LIBRARY_CALENDAR_CLASS"))
{
 define("PHP_LIBRARY_CALENDAR_CLASS",1);

/*
 *
 * @(#) $Id: calendarclass.class,v 1.3 2000/12/03 22:10:48 mlemos Exp $
 *
 */

class calendar_class extends table_class
{
 var $year=2000;
 var $month=1;
 var $day=0;
 var $week_day_names=array();
 var $error="";
 var $month_days=0;
 var $month_week_day=0;
 var $calendar_rows=0;

 Function fetchcustomcolumn(&$columndata)
 {
  return 1;
 }

 Function fetchcolumn(&$columndata)
 {
  $column=$columndata["column"];
  if(!($column<7))
   return 0;
  $row=$columndata["row"];
  if(($row==0))
  {
   $this->day=0;
   $columndata["data"]=$this->week_day_names[$column];
   $columndata["align"]="center";
  }
  else
  {
   $this->day=(($row-1)*7+$column+1-$this->month_week_day);
   if(($this->day>0 && $this->day<=$this->month_days))
   {
    $columndata["data"]=strval($this->day);
    $columndata["align"]="center";
   }
   else
    $this->day=0;
  }
  return $this->fetchcustomcolumn($columndata);
 }

 Function fetchrow(&$rowdata)
 {
  $row=$rowdata["row"];
  return $row<$this->calendar_rows;
 }

 Function isleapyear($year)
 {
  return (intval($year % 4)==0 && (intval($year % 100)!=0 || intval($year % 400)==0));
 }

 Function weekday($year,$month,$day)
 {
  $corrected_year=$year;
  if(($month<3))
   $corrected_year--;
  $leap_years=(intval($corrected_year/4));
  switch($month)
  {
   default:
   case 1:
    $month_year_day=0;
    break;
   case 2:
    $month_year_day=31;
    break;
   case 3:
    $month_year_day=59;
    break;
   case 4:
    $month_year_day=90;
    break;
   case 5:
    $month_year_day=120;
    break;
   case 6:
    $month_year_day=151;
    break;
   case 7:
    $month_year_day=181;
    break;
   case 8:
    $month_year_day=212;
    break;
   case 9:
    $month_year_day=243;
    break;
   case 10:
    $month_year_day=273;
    break;
   case 11:
    $month_year_day=304;
    break;
   case 12:
    $month_year_day=334;
    break;
  }
  return (intval((intval((-473+365*($year-1970)+$leap_years-intval($leap_years/25)+((intval($leap_years % 25)<0) ? 1 : 0)+intval((intval($leap_years/25))/4)+$month_year_day+$day-1) % 7)+7) % 7));
 }

 Function outputcalendar()
 {
  switch($this->month)
  {
   case 1:
   case 3:
   case 5:
   case 7:
   case 8:
   case 10:
   case 12:
    $this->month_days=31;
    break;
   case 4:
   case 6:
   case 9:
   case 11:
    $this->month_days=30;
    break;
   case 2:
    $this->month_days=(($this->isleapyear($this->year)) ? 29 : 28);
    break;
   default:
    $this->error="it was specified an invalid month";
    return "";
  }
  $this->month_week_day=$this->weekday($this->year,$this->month,1);
  $this->calendar_rows=(intval(($this->month_week_day+$this->month_days+6)/7)+1);
  if((Count($this->week_day_names)!=7))
   $this->week_day_names=array("Sun","Mon","Tue","Wed","Thu","Fri","Sat");
  return $this->outputtable();
 }
};

}
?>