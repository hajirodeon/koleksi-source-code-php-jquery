<?php

/*  *****************************************************************************
**
**  RC4Crypt 2.1
**
**  $Id: rc4test.php,v 2.1 2004/05/03 07:11:46 Owner Exp Owner $
**
**  2003/11/15 -- Cleans urlencode's, fixed the invalid outputs
**  2003/02/22 -- A fix, which turned out to be a bug!
**  2001/02/24 -- Passes RC4 Vector Harness
**
**  Website     : http://www.devhome.org
**  Email       : mukul@devhome.org
**  Description : Provides the example interface for the class
**
**  Copyright Notice:
**
**  RC4 is a registered trademark of the RSA Data Security Inc.
**  This is an implementation of the original algorithm. The author
**  of this program is NOT the original publisher of this algorithm.
**
**  (C) Copyright 2003 Mukul Sabharwal [http://pauridge.org/~mukul]
**  All Rights Reserved
**
**  This program is free software; you can redistribute it and/or
**  modify it under the terms of the GNU General Public License
**  as published by the Free Software Foundation; either version 2
**  of the License, or (at your option) any later version.
**
**  This program is distributed in the hope that it will be useful,
**  but WITHOUT ANY WARRANTY; without even the implied warranty of
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**  GNU General Public License for more details.
**
**  The GNU General Public License can be found at
**  http://www.gnu.org/copyleft/gpl.html
**
**  You should have received a copy of the GNU General Public License
**  along with this program; if not, write to the Free Software
**  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
**
**  ****************************************************************************/

include("./class.rc4crypt.php");

if (strcmp('4.1.0', phpversion()) > 0) {
	global $HTTP_GET_VARS;
	$_GET = &$HTTP_GET_VARS;
}

$pwd = $_GET['pwd'];
$data = $_GET['data'];

if (get_magic_quotes_gpc()) {
	$pwd = stripslashes($pwd);
	$data = stripslashes($data);
}

$rc4 = new rc4crypt();

if (!$_GET['decryption']) {

		$e = $rc4->encrypt($pwd, $data);
		echo urlencode($e).'<br/><br/>';

		$d = $rc4->decrypt($pwd, $e);
		echo $d;
} else {
	echo $rc4->decrypt($pwd, urldecode($data));
}

?>
