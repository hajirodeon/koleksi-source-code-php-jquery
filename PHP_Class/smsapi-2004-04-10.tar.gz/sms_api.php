<?php
/*
################################################################################
# Filename: sms_api.php
# Create date: 09.01.2004.
# Last update: 10.04.2004.
# Project: WSW - Netsector.net
# Description: Simple CLICKATELL SMS API using fopen functions or CURL PHP module
#
# NOTE: PHP must have SSL support for maximum security of Yours
# CLICKATELL account. If PHP is not built with SSL support, change $base_s to
# "http://api.clickatell.com/http" instead "https://api.clickatell.com/http".
#
# For more information about CLICKATELL service visit http://www.clickatell.com
#
# Copyright � 2004 Aleksandar Markovic <miki@netsector.net>
# Copyright � 2003 - 2004 Netsector
###############################################################################
*/

class sms {

/* User Authentication */
var $api_id = "YOUR_CLICKATELL_API_NUMBER";
var $user = "YOUR_CLICKATELL_USERNAME";
var $password = "YOUR_CLICKATELL_PASSWORD";

/* SMS Gateways URLs */
var $base   = "http://api.clickatell.com/http";
var $base_s = "https://api.clickatell.com/http";

/* Define SMS balance limit */
var $balace_limit = 20;

/* Gateway command sending method [curl|fopen] */
var $sending_method = "fopen";

/* Session variable */
var $session;


    /* Class initialization */
    function sms () {
        $this->auth();
    }

    /* SMS gateway authentication */
    function auth() {
    	$comm = sprintf ("%s/auth?api_id=%s&user=%s&password=%s", $this->base_s, $this->api_id, $this->user, $this->password);
        $this->session = $this->_parse_auth ($this->_execgw($comm));
    }

    /* Query SMS credis balance */
    function getbalance() {
    	$comm = sprintf ("%s/getbalance?session_id=%s", $this->base, $this->session);
        return $this->_parse_getbalance ($this->_execgw($comm));
    }

    /* Send SMS message */
    function send($to=null, $from=null, $text=null) {

    	/* Check SMS credits balance */
    	if ($this->getbalance() < $this->balace_linit) {
    	    die ("You have reach the SMS credit limit!");
    	};

    	/* Check SMS $text length */
        if (strlen ($text) > 160) {
    	    die ("Your message is to long! (Current lenght=".strlen ($text).")");
    	}

    	/* Check $to and $from is not empty */
        if (empty ($to)) {
    	    die ("You not specify destination address (TO)!");
    	}
        if (empty ($from)) {
    	    die ("You not specify source address (FROM)!");
    	}

    	/* Reformat $to number */
        $cleanup_chr = array ("+", " ", "(", ")", "\r", "\n", "\r\n");
        $to = str_replace($cleanup_chr, "", $to);

    	/* Send SMS now */
    	$comm = sprintf ("%s/sendmsg?session_id=%s&to=%s&from=%s&text=%s", $this->base, $this->session, rawurlencode($to), rawurlencode($from), rawurlencode($text) );
        return $this->_parse_send ($this->_execgw($comm));
    }


    /* PRIVATE FUNCTIONS */

    /* Execute gateway commands */
    function _execgw($command) {
        if ($this->sending_method == "curl")
            return $this->_curl($command);
        if ($this->sending_method == "fopen")
            return $this->_fopen($command);
        die ("Unsupported sending method!");
    }

    /* CURL sending method */
    function _curl($command) {
        $this->_chk_curl();
        $ch = curl_init ($command);
        curl_setopt ($ch, CURLOPT_HEADER, 0);
        curl_setopt ($ch, CURLOPT_RETURNTRANSFER,1);
        curl_setopt ($ch, CURLOPT_SSL_VERIFYPEER,0);
        $result=curl_exec ($ch);
        curl_close ($ch);
        return $result;
    }

    /* fopen sending method */
    function _fopen($command) {
        $handler = @fopen ($command, 'r');
        if ($handler) {
            while ($line = @fgets($handler,1024)) {
                $result .= $line;
            }
            fclose ($handler);
            return $result;
        } else {
            die ("Error while executing fopen sending method!<br>Please check does PHP have OpenSSL support and check does PHP version is greater than 4.3.0.");
        }
    }

    /* Parse authentication command response text */
    function _parse_auth ($result) {
    	$session = substr($result, 4);
        $code = substr($result, 0, 2);
        if ($code<>"OK") {
            die ("Error in SMS authorization! ($result)");
        }
        return $session;
    }

    /* Parse send command response text */
    function _parse_send ($result) {
    	$code = substr($result, 0, 2);
    	if ($code<>"ID") {
    	    die ("Error sending SMS! ($result)");
    	} else {
    	    $code = "OK";
    	}
        return $code;
    }

    /* Parse getbalance command response text */
    function _parse_getbalance ($result) {
    	$result = substr($result, 8);
        return (int)$result;
    }

    /* Check for CURL PHP module */
    function _chk_curl() {
        if (!extension_loaded('curl')) {
            die ("This SMS API class can not work without CURL PHP module! Try using fopen sending method.");
        }
    }
}

/* Example */
$mysms = new sms();
//echo $mysms->session;
//echo $mysms->getbalance();
echo $mysms->send("38160123","netsector","TEST MESSAGE");

?>
