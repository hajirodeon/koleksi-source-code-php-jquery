<?php
define('LEFT_BRACE','{');
define('RIGHT_BRACE','}');
define('OPTIONAL','\\*');
define('FRTF_VERSION','1.00');
define('SEPARATOR',' ');
define('SEMICOLON',';');
define('ESCAPE',"\\");
define('WORDVer','Microsoft Word');
$txtGenerator="Cristian Muraru  - RTFGen 1.0 - Basic Edition";

$inch=1440;
$point=20;
$cm=5.67;
?>