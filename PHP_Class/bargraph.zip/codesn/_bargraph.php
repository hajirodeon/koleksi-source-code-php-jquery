<?php
function BarGraph ($title = '', $BarArr, $CanvasX, $OutFile = '')  {
//
// ***** 
// * Simple bar graph unit
// * (c) GPL 
// * Author cnovak@gmx.net
// *****
// Parameters:	title = string, array, width = integer, file = boolean
//		- title:		string, optional title string
//		- array:		array, values[0] and labels[1]
//		- width:		integer, x-axis width in px
//		- file:			string '' by default = parse straight to HTTP including HTTP headers
//						or a file 
// Requires:	
//		- GD library
//
// Returns:		
//		- Outfile type of PNG, GIF or JPG if parsed straight to HTTP (default)
//	      or the file created with proper extensions (png, gif, jpg) 
//		- ERR (string) in case the GD library is not installed or accessible
// *****

// margin constants
define ('TitleTopMargin', 2);	
define ('TitleBotMargin', 2);
define ('TitleRightMargin', 2);
define ('TitleLeftMargin', 2);
define ('LabelTopMargin', 2);
define ('LabelBotMargin', 2);
define ('LabelRightMargin', 2);
define ('LabelLeftMargin',2);
define ('BarTopMargin', 2);
define ('BarBotMargin', 2);
define ('BarRightMargin', 2);
define ('BarLeftMargin',2);
define ('ScaleTopMargin', 2);
define ('ScaleBotMargin',2);
define ('ScaleRightMargin', 2);
define ('ScaleLeftMargin', 2);
// font constants
define ('LabelFont',2);
define ('TitleFont',2);
define ('ScaleFont',2);
// determine number of elements (bars, labels)
$BarCount = Count($BarArr);
// determine coords of the title area
$TitleX1 = 0;
$TitleX2 = $CanvasX;
$TitleY1 = 0;
if ($title <> '') {
	$TitleY2 = ImageFontHeight(TitleFont) + TitleTopMargin + TitleBotMargin;
}
// determine coords of the label area 
$LabelX1 = 0;
for ($x=0; $x < $BarCount; $x++) {	
	$max= Max(strlen($BarArr[$x][1]),$max);		// determine widest label
	}
$LabelX2 = $max * ImageFontWidth(LabelFont) + LabelLeftMargin + LabelRightMargin;
$LabelY1 = $TitleY2;
$LabelHeight = ImageFontHeight(LabelFont);
$LabelY2 = $LabelY1 + ($LabelHeight * $BarCount) + LabelBotMargin + LabelTopMargin;
// determine coords for the bar area
$BarX1 = $LabelX2;
$BarX2 = $CanvasX;
$BarY1 = $LabelY1;
$BarY2 = $LabelY2;
$BarWidth = ImageFontHeight(LabelFont);
// determine coords for scale area
$ScaleX1 = 0;
$ScaleX2 = $CanvasX;
$ScaleY1 = $BarY2;
$ScaleY2 = ($ScaleY1 + (ImageFontHeight(ScaleFont) + ScaleTopMargin + ScaleBotMargin) * 2);
// create the image & assign colors
$CanvasY = $ScaleY2 + 1;
$im = ImageCreate($CanvasX + 1, $CanvasY);
$background = ImageColorAllocate($im, 0xFF, 0xFF, 0xFF);
$clr_black = ImageColorAllocate($im, 0, 0, 0);
$clr_footer = ImageColorAllocate($im, 0x8A, 0x8A, 0x8A);
$clr_header = $clr_footer;
$clr_bar_even = ImageColorAllocate($im, 0xD8, 0xD8, 0xD8);
$clr_grid_lines = ImageColorAllocate($im, 0x9A, 0x9A, 0x9A);
$clr_bar_odd = ImageColorAllocate($im, 0xBF, 0xBF, 0xBF);
$clr_white = ImageColorAllocate($im, 0xFF, 0xFF, 0xFF);
// print the title centered
$x =  Abs(($TitleX2 - TitleX1 - TitleLeftMargin - TitleRightMargin)/2) - (strlen($title) * ImageFontWidth(TitleFont) / 2);
imagefilledrectangle ($im, $TitleX1, $TitleY1, $TitleX2, $TitleY2, $clr_header);
ImageString($im, TitleFont, $x, $TitleY1 + TitleTopMargin, $title, $clr_white);

// box the individual areas
ImageRectangle($im, $TitleX1, $TitleY1, $TitleX2, $TitleY2, $clr_black); 
ImageRectangle($im, $LabelX1, $LabelY1, $LabelX2, $LabelY2, $clr_black); 
imagefilledrectangle ($im, $ScaleX1, $ScaleY1, $ScaleX2, $ScaleY2, $clr_footer);
ImageRectangle($im, $ScaleX1, $ScaleY1, $ScaleX2, $ScaleY2, $clr_black); 
ImageRectangle($im, $BarX1, $BarY1, $BarX2, $BarY2, $clr_black); 
// print bar labels
for ($x=0; $x < $BarCount;$x++) {
	$y = $LabelY1 + LabelTopMargin + ($x * $LabelHeight);
	ImageString($im, LabelFont, LabelLeftMargin, $y, $BarArr[$x][1], $clr_black);
	}
// print vertical bars
$Pixel = $BarX2 - $BarX1 - BarLeftMargin - BarRightMargin;
// determine the highest, lowest & total value of the array elements
$max = 0;
$sum = 0;
for ($x=0; $x < $BarCount; $x++) {
	$sum = $sum + $BarArr[$x][0];
	$max= Max(($BarArr[$x][0]),$max);
	}
$min = $max;
$x = $BarX1 + ($Pixel * 0.25);
$y1 = $BarY1 + 1;
$y2 = $BarY2 + 2; 
ImageDashedLine($im, $x, $y1, $x, $y2, $clr_grid_lines);
ImageString($im, ScaleFont, $x - 6, $ScaleY1 + ScaleTopMargin, '25%', $clr_white);
$x = $BarX1 + ($Pixel * 0.5);
ImageLine($im, $x, $y1, $x, $y2, $clr_grid_lines);
ImageString($im, ScaleFont, $x - 6, $ScaleY1 + ScaleTopMargin, '50%', $clr_white);
$x = $BarX1 + ($Pixel * 0.75);
ImageDashedLine($im, $x, $y1, $x, $y2, $clr_grid_lines);
ImageString($im, ScaleFont, $x - 6, $ScaleY1 + ScaleTopMargin, '75%', $clr_white);	
$XRatio = $Pixel / $max;
// draw the bars
for ($x=0; $x < $BarCount; $x++) {
	$y1 = ($BarY1 + BarTopMargin + ($BarWidth * $x-1)) + 2;
	$y2 = ($y1 + $BarWidth) - 2;
	$x2 = ($BarArr[$x][0] * $XRatio) + $BarX1 + BarLeftMargin;
	if ($x % 2 == 0) {$barcolor = $clr_bar_odd;}
	else {$barcolor = $clr_bar_even;}
	ImageFilledRectangle($im, $BarX1 + BarLeftMargin, $y1+1, $x2, $y2-1, $barcolor);
	$LabelYPos = $LabelY1 + LabelTopMargin + ($x * $LabelHeight);
	$min= Min(($BarArr[$x][0]),$min);
	$str = $BarArr[$x][0];
	$str .= ' ('. number_format((($BarArr[$x][0] / $sum) * 100),2). '% tot,';
	$str .= ' '. number_format((($BarArr[$x][0] / $max) * 100),2). '% max)'; 
	ImageString($im, ScaleFont, $BarX1 + BarLeftMargin * 2, $LabelYPos, $str, $clr_black);
	}
// draw the scale values
$str =  'Max=' .number_format($max, 2);
$str .= ', Min=' .number_format($min,2);
$str .= ', Sum=' .number_format($sum, 2); 
$str .= ', Avg=' .number_format(($sum / $BarCount),2);
$x =  Abs(($ScaleX2 - ScaleX1 - ScaleLeftMargin - ScaleRightMargin)/2) - (strlen($str) * ImageFontWidth(ScaleFont) / 2);
ImageString($im, ScaleFont, $x, ($ScaleY2 - ImageFontHeight(ScaleFont) - ScaleBotMargin) , $str, $clr_white);
//
// determine output format by the order of PNG, GIF, JPEG
//
if (function_exists("imagepng")) {
	if (empty($OutFile)) {
		Header("Content-type: image/png");
		ImagePng($im);
		return 'PNG';
		}
	else {
		$OutFile .= '.png';
		ImagePng($im, $OutFile);
		return $OutFile;
		}
	}
elseif (function_exists("imagegif")) {
	if (empty($OutFile)) {
		Header("Content-type: image/gif");
		ImageGif($im);	
		return ('GIF');
		}
	else {
		$OutFile .= '.gif';
		ImageGif($im, $OutFile);						
		return $OutFile;
		}
	}
elseif (function_exists("imagejpeg")) {
	if (empty($OutFile)) {
		Header("Content-type: image/jpeg");
		ImageJpeg($im);
		return 'JPG';
		}
	else {
		$OutFile .= '.jpg';
		ImageJpeg($im, $OutFile);
		return $OutFile;
		}
	}
else {
	die("Error access graph library");
	return 'ERR';
	}
ImageDestroy($im);
}
?>