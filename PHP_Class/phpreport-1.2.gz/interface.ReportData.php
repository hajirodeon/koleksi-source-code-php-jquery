<?php
/*
 * Data class to fill out a report content
 */

interface IReportData {
	abstract function getNextRow();
	abstract function hasMoreRow();
} 
?>