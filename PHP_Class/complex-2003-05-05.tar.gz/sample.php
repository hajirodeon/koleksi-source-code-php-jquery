<?php
	include('complex.class.php');
	//----
	// this class gets 2 complex numbers and calculates add, sub, mul & div of them.
	// useful for educational use.
	//----
	
	//---- 2 complex number.
	$n1['re']=2;
	$n1['im']=-10;
	$n2['re']=-1;
	$n2['im']=0;
	
	$c=new complex($n1, $n2);
	
	$sum=$c->add();
	$sub=$c->sub();
	$mul=$c->mul();
	$div=$c->div();
	
	print ('num1 = '.$n1['re'].' '.$n1['im'].'i'.'<br>');
	print ('num2 = '.$n2['re'].' '.$n2['im'].'i'.'<br><br>');
	
	print ('add = '.$sum['re'].' '.$sum['im'].'i'.'<br>');
	print ('sub = '.$sub['re'].' '.$sub['im'].'i'.'<br>');
	print ('mul = '.$mul['re'].' '.$mul['im'].'i'.'<br>');
	print ('div = '.$div['re'].' '.$div['im'].'i'.'<br>');
	
?>