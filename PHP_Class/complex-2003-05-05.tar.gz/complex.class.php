<?php

///////////////////////////////////////////////////////////////
// Reza Salehi
// zaalion @ yahoo.com
// free for non-commercial use.
///////////////////////////////////////////////////////////////

	class complex
		{
		function complex($first, $second)
			{
			$this->first['re']=$first['re'];
			$this->first['im']=$first['im'];
			$this->second['re']=$second['re'];
			$this->second['im']=$second['im'];
			}
		function add()
			{
			$result['re']=$this->first['re']+$this->second['re'];
			$result['im']=$this->first['im']+$this->second['im'];
			return($result);
			}
		function sub()
			{
			$result['re']=$this->first['re']-$this->second['re'];
			$result['im']=$this->first['im']-$this->second['im'];
			return($result);
			}
		function mul()
			{
			$result['re']=($this->first['re']*$this->second['re'])-($this->first['im']*$this->second['im']);
			$result['im']=($this->first['re']*$this->second['im'])+($this->second['re']*$this->first['im']);
			return($result);
			}
		function div()
			{
			if(($this->second['re']==0 && $this->second['im']==0))
				retuen(-1);
			$a=$this->first['re'];
			$b=$this->first['im'];
			$c=$this->second['re'];
			$d=$this->second['im'];
			@$result['re']=((a*c+b*d)/(c*c-d*d));
			@$result['im']=((b*c-a*d)/(c*c-d*d));
			return($result);
			}
		}
?>