<?php
require ("excel2html.php");
// require ("function.php");
$pathInName = $_POST['inFile'];
$worksheet = $_POST['worksheet'];
$startCell = $_POST['startCell'];
$endCell = $_POST['endCell'];
$pathInName = realpath($pathInName); //some browser store differently

// Instantiate Excel
$E = new Excel2html;
$workbook = $E->myfile($pathInName);
$pathin = $E->mypath($pathInName);



// Default value for Worksheet
if (!$worksheet)$worksheet = 'Sheet1';

// Open the workbook
$E->XL($workbook, $pathin, $sheet);

// Default value for Starting Cell
if (!$startCell)$startCell = 'A1';

// Default value for End Cell
if (!$endCell)$endCell = 'd5';
$sheet = $worksheet;
$startStr = $E->getCellString($startCell);
$startNum = $E->getCellNum($startCell);
$endStr = $E->getCellString($endCell);
$endNum = $E->getCellNum($endCell);

// Read the content of range of cells and output to html file
$cellRange = $startCell . ":" . $endCell;
$content = $E->readrange($sheet, $cellRange);
echo "<html><head><title>Excel to HTML</title></head>";
echo "<body style='background-color: #DEEEF3'>";
echo "<div align='center'><br><table border='1' cellspacing='1' cellpadding='1'>";
if (is_array($content)) {
    $count = sizeof($content);
    for ($num = 0; $num < $count; $num++)
    if (is_array($content[$num])) {
        $countArray = sizeof($content[$num]);
        if ($num == 0) {
            echo "<tr bgcolor='#CDFE98' align='center'><td>&nbsp</td>";
            for ($numArray = 0; $numArray < $countArray; $numArray++) {
                echo "<td>";
                echo strtoupper($startStr++);
                echo "</td>";
            } 
            echo "</tr>";
        } 
        echo "<tr>";
        for ($numArray = 0; $numArray < $countArray; $numArray++) {
            if ($num == 0) {
                if ($numArray == 0)
                    print "<td bgcolor='#CDFE98'>" . $startNum++ . "</td>";
                echo "<td bgcolor='blue'><font size='5' color='white'>";
                echo $content[$num][$numArray];
                echo "</font></td>";
            } else {
                if ($numArray == 0)
                    print "<td bgcolor='#CDFE98'>" . $startNum++ . "</td>";
                echo "<td>";
                echo $content[$num][$numArray];
                echo "</td>";
            } 
        } 
        echo "</tr>";
    } 
} 
echo "</table></div><br><br>";
echo "<div align='right'><font color='blue'>Contact at: bumeshrai@hotmail.com</font></div>";
echo "</body></html>";

// Close the file
$E->closexl();
unset ($E);

?>
