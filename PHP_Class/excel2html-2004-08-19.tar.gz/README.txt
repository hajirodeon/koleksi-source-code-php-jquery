Steps to use the package.

Platform tested on:
	Windows XP + Apache 2 + PHP 5

Unzip the folder: 
	excel2html-2004-08-19.zip  to Apache 2's htdoc folder.

Rename the folder to excel2html (Recommended)

With Apache running, open a browser. Point to 
	http://localhost/excel2html/index.htm

In the form generated, point to the MS Excel file you want to convert. Enter
also the worksheet name and the cell range (Start cell and End cell) you are 
interested in.

Press submit and HTML file will be generated, which you can save on your disk.

contact: bumeshrai@hotmail.com 