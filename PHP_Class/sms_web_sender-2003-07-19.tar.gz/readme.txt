=============================================
SMS Web Sender 2
=============================================

  Documentation is still a work in progress, please check <http://www.k1m.com>
  to view the latest.

Installation
-----------------------------
  
  SMS Web Sender requires HTTP Navigator 2.2 or greater (found at 
  <http://www.k1m.com>).

  Upload all files in the SMS Web Sender distribution and check the test/ 
  folder to see 3 examples of how SMS Web Sender can be used.  The quickest
  way to test is to run web_form.php.
  You will need to edit web_form.php first and specify the path to the
  HTTP Navigator classes, once that's done you can try accessing it from the
  web and you should see a web form asking for site details to be entered, try
  this and see if it works.  If it does then you should look at the other 2
  example files.


Main Classes
-----------------------------

  +--- SMS_Web_Sender
  |
  +--+ SMS_Site
  |  |
  |  +--- SMSSend_Site
  |  |
  |  +--- SMS_Site_sitename* 
  |
  +--- HTML_Functions

  * SMS_Site_sitename is an example of a custom class extending SMS_Site and 
    overriding the send() method to handle the sending. These classes should
    located in the sites/ folder.

  SMS_Web_Sender holds instances of SMSSend_Site or SMS_Site_sitename (both 
  subclasses of SMS_Site).  Users only interact with the SMS_Web_Sender object,
  not the site objects themselves.

  SMS_Site is an abstract class which should be extended to implement specific
  site sending code.  See sites/ folder for examples of this.

  SMSSend_Site is a subclass of SMS_Site which provides limited support for
  SMSSend scripts <http://zekiller.skytech.org/fichiers/smssend/doc_scr_en.html>

  HTML_Functions is a class providing helpful functions for extracting values
  from HTML. An instance of this class is available for all sites extending
  SMS_Site.


Directory Structure
----------------------------

  +--- classes
  |
  +--- sites
  |
  +--+ smssend_sites
  |  |
  |  +--- config
  |
  +--- test

  classes folder holds the following classes:
   - SMS_Web_Sender
   - SMS_Site
   - SMSSend_Site
   - HTML_Functions
  The above classes have been described briefly in the previous section

  sites folder holds custom site classes (extending SMS_Site), SMS_Web_Sender
  will look in this folder (along with smssend_sites) to determine if a site
  specified exists or not. If a site with the same name exists in both the 
  sites/ folder and the smssend_sites folder, then the one found in sites/
  will be used.

  smssend_sites folder holds SMSSend scripts (extension .sms).  SMS Web Sender
  does not fully support SMSSend scripts, but the most basic ones should work
  ok.

  config is a folder within the smssend_sites folder which holds php config
  files for each smssend script. Config files are required for SMSSend scripts
  as SMS Web Sender works differently to SMSSend in that it allows multiple
  sites to be configured to handle SMS sends.  For this to work the SMSSend
  errors and parameters must be mapped to the relevant SMS Web Sender ones.

  test holds php scripts showing how SMS Web Sender can be used in different
  situations.