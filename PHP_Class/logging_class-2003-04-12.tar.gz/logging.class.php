<?php
//***********************************************************************
//***************Written by Rahman Haqparast April 2003***************
//******************a class for logging visitors data********************
//******************* contact:rahman@haqparast.com***********************
class logging 
{
var $folder;
var $logname;
var $xmlname;
	function logging($f,$l,$x)
	{
		$this->folder=$f;
		$this->logname=$l;
		$this->xmlname=$x;
	}
	function create_txt()
	{
		if (!file_exists(getcwd()."\\$this->folder\\")) mkdir (getcwd()."\\$this->folder\\");
		$fp = fopen (getcwd()."\\$this->folder\\$this->logname",a);
		$logs="<logging>\n";
		$logs.="<ip> visitor's IP address: ".$_SERVER['REMOTE_ADDR']." </ip>\n";
		$logs.="<port> visitor's port: ".$_SERVER['REMOTE_PORT']." </port>\n";
		$logs.="<browser> visitor's browser: ".$_SERVER['HTTP_USER_AGENT']." </browser>\n";
		$logs.="<date> date: ".date("D-d-M-Y")." </date>\n";
		$logs.="<time> time: ".date("H:i:s")." </time>\n";
		$logs.="</logging>\n\n";
		fwrite($fp,$logs);
		fclose($fp);
	}
	function create_xml()
	{
		$filename=$this->xmlname;
		$fp=fopen(getcwd()."\\$this->folder\\$this->logname",r);
		$contents=fread($fp,filesize(getcwd()."\\$this->folder\\$this->logname"));
		$final='<?xml version="1.0" encoding="iso-8859-1"?>'."\n".
			   '<!-- generator="logging class Ver:1.0" -->'.
			   "\n".
			   '<start>'
			   .$contents.
			   '</start>';
		fclose($fp);
		$fp=fopen(getcwd()."\\$this->folder\\$filename",w);
		fwrite($fp,$final);
		fclose($fp);
	}
	function show_links()
	{
		if ($this->logname!="") echo '<a href="'.$this->folder."/".$this->logname.'">'.$this->logname.'</a>'."\n<br>";
		if ($this->xmlname!="") echo '<a href="'.$this->folder."/".$this->xmlname.'">'.$this->xmlname.'</a>'."\n<br>";
	}
}
//***********************************************************************
?>