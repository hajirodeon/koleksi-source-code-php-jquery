<?php
include "logging_ver1.1.class.php";
$newlog=new logging("logs","log.txt","log.xml",1); // working on windows
$newlog->create_txt();
$newlog->create_xml();
$newlog->show_links();
?>