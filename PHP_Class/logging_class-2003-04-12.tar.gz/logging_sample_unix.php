<?php
include "logging_ver1.1.class.php";
$newlog=new logging("logs","log.txt","log.xml",0); // working on unix/linux
$newlog->create_txt();
$newlog->create_xml();
$newlog->show_links();
?>