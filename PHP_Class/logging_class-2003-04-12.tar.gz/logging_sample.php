<?php
include "logging.class.php";
$newlog=new logging("logs","log.txt","log.xml");
$newlog->create_txt();
$newlog->create_xml();
$newlog->show_links();
?>