<?
// mysql wrapper class
require_once ('sqlLayer.php');
// stores procedure class
require_once ('STProc.php');

// instantiating new object from the wrapper class with connection parameters and database name
$mysql = new SQLLayer ("localhost", "root", "", "test");

// instantiating new object from the stored procedure class
$sp = new ST_Proc ('default.sp');
// loading the procedures
$sp->load ();

$sp->dump ();
$sp->save_to ('test.sp');

// actual execution
$sp->set_params ('sp_example1', array ("5"));
$sp->execute ('sp_example1', $mysql);

// result can be found in the wrapper object
$row = $mysql->fetch_array ();
echo 'Returned: '.$mysql->num_rows ().' rows';
?>