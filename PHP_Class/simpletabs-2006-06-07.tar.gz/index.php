<?PHP
/**
 * 
 * Patrick J. Mizer
 * <pmizer@mail.utexas.edu>
 * 
 * May 28, 2006
 * 
 * Sample usage.
 * 
 */
require_once('SimpleTabs.class.php');

/**
 * 
 * Documentation by example...
 * 
 * First we define out styles, keys are used within the class
 * to index css keys supplied by you.
 * 
 */
$roundedTabStyle = array(	
							'divId' => 'navTabs',
							'tabBar' => 'tabArea',
							'activeTab' => 'roundedActiveTab',
							'tab' => 'roundedTab',
							'tabLeft' => 'tabLeft',
							'tabRight' => 'tabRight',
							'tabLeftActive' => 'tabLeftActive',
							'tabRightActive' => 'tabRightActive',
					);
					
$subTabStyle = array(
							'divId' => 'subTabs',
							'tabBar' => 'subTabArea',
							'activeTab' => 'activeSubTab',
							'tab' => 'subTab',							
					);
					
$accessoryTabStyle = array(
							'divId' => 'accessoryTabs',
							'tabBar' => 'subTabArea',
							'activeTab' => 'activeSubTab',
							'tab' => 'subTab',							
					);
					
/**
 * 
 * Now we can begin constructing our tab sets.  Notice that we can pass 
 * SimpleTabs object as an argument to a new TabElement, this creates
 * a sub SimpleTab.
 * 
 */
								 
$phpElements = array(
						new TabElement('PHP4.X', '?mod=php4'),
						new TabElement('PHP5.X', '?mod=php5'),
					);
/**
 * 
 * The arguments for a new SimpleTabs object are: Array of Element Tabs, Style Array, 
 * active tab (default true), name of active tab get/session var, and use session (default true).
 * 
 */			
$phpTabs =& new SimpleTabs($phpElements, $accessoryTabStyle, true, 'phpTab', false);					
						
$codeElements = array(
						new TabElement('Java', '?mod=java'),
						new TabElement('PHP', '?mod=php', $phpTabs),
						new TabElement('C++', '?mod=cpp'),
					);			
$subTabs =& new SimpleTabs($codeElements, $subTabStyle, true, 'subTab', true);					
					
$tabElements = array(
						new TabElement('Home', 'index.php'),
						new TabElement('Code', '?mod=code', $subTabs),
						new TabElement('Pictures', '?mod=pictures'),
						new TabElement('Randomness', '?mod=random'),
						new TabElement('Resume\'', '?mod=resume'),
					);					
$navTabs =& new SimpleTabs($tabElements, $roundedTabStyle, true, 'navTabs', true);

/**
 * 
 * Don't forget to include your CSS.
 * 
 */

?>

<link href="style/style.css" rel="stylesheet" type="text/css" />

<?PHP

/**
 * 
 * Now we are ready to render our tabs.
 * 
 */

echo $navTabs->render();

?>
