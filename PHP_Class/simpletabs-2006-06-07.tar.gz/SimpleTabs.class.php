<?php
/**
 * 
 * Patrick J. Mizer
 * <pmizer@mail.utexas.edu>
 * 
 * May 28, 2006
 * 
 * SimpleTabs
 * 
 * This class creates html tabs.
 *  
 */
class SimpleTabs
{
    var $tabs = array();
    var $tabStyle = array();
    var $activeTab;
    var $tabIndex;
    var $useSessions;
    var $sub;
    
    function SimpleTabs($tabs = array(), $style = array(), $activeTab = true, $tabIndex = 'tab', $useSessions = true) 
    {
    	$this->tabs = $tabs;
    	$this->tabStyle = $style;
    	$this->activeTab = $activeTab;
    	$this->tabIndex = $tabIndex;
		
		if($this->useSessions = $useSessions){
			session_start();
		}
		
	
    }
    
    function render()
    {
    	
    	if($this->useSessions){
    		if(isset($_REQUEST[$this->tabIndex])){
    			$_SESSION[$this->tabIndex] = $_REQUEST[$this->tabIndex];
    		}
    	}
    	
    	$renderString = '<div id="'.$this->tabStyle['divId'].'" class="'.$this->tabStyle['tabBar'].'">'. "\n";	
    	
    	$i = 0;
    	foreach($this->tabs as $tabElement){
    		if(is_a($tabElement, 'TabElement') || is_subclass_of($tabElement, 'TabElement')){	
    				$renderString .= $tabElement->render($this, $i);
    		}
    		++$i;
    	}
    	$renderString .= '</div>'. "\n";
    	return $renderString . $this->sub;
    }
}

class TabElement 
{

	var $name;
	var $value;
	var $child;
	
	function TabElement ($name, $value, $child = null)
	{
		$this->name = $name;
		$this->value = $value;
		$this->child =& $child;
	}
	
	function render(&$tabBar, $index)
	{
		
		$delim = ((strpos($this->value, '?') !== false) ? '&' : '?');
		
		if(!$tabBar->activeTab){
			return '<a class="'.$tabBar->tabStyle['tab'].'" href="'.$this->value.'"><span class="'.$tabBar->tabStyle['tabLeft'].'"><span class="'.$tabBar->tabStyle['tabRight'].'">'.$this->name . '</span></span></a>' . "\n";
		}
		
		if(($_REQUEST[$tabBar->tabIndex] == $index && !$tabBar->useSessions) || ($tabBar->useSessions && $_SESSION[$tabBar->tabIndex] == $index)){
			
			if(is_a($this->child, 'SimpleTabs')){
				$tabBar->sub = $this->child->render();
			}
			return '<a class="'.$tabBar->tabStyle['activeTab'].'" href="'.$this->value.$delim.$tabBar->tabIndex.'='.$index.'"><span class="'.$tabBar->tabStyle['tabLeftActive'].'"><span class="'.$tabBar->tabStyle['tabRightActive'].'">'.$this->name . '</span></span></a>' . "\n";
		}
		return '<a class="'.$tabBar->tabStyle['tab'].'" href="'.$this->value.$delim.$tabBar->tabIndex.'='.$index.'"><span class="'.$tabBar->tabStyle['tabLeft'].'"><span class="'.$tabBar->tabStyle['tabRight'].'">'.$this->name . '</span></span></a>' . "\n";
	
	}
}
?>