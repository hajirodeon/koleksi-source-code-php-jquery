<?php
  class CSQLite
  {
    var $linkp;
    
    function CSQLite($file = '', $mode = 0666)
    {
      if (file_exists($file))
      {
        $this->Open($file, $mode);
      }
    }
    
    function open($file, $mode = 0666)
    {
      if ($this->db = sqlite_open($file, $mode, $err))
      {
        return $this->db;
      }
      else
      {
        $this->error = $err;
        return false;
      }
    }
    
    function query($query, $db = false)
    {
      if (is_bool($db)) $db = $this->db;
      $this->result = sqlite_query($db, $query);
      return $this->result;
    }
    
    function fetch_row($result = false)
    {
      if (is_bool($result)) $result = $this->result;
      return sqlite_fetch_array($result, SQLITE_ASSOC);
    }
    
    function get_num_rows($result = false)
    {
      if (is_bool($result)) $result = $this->result;
      return sqlite_num_rows($result);
    }
  }
?>
