<?php
  include "class.sqlite.php";
  
  $sql = new CSQLite();
  if ($sql->open(realpath('') . '/mysqlitedb'))
  {
    $sql->query('CREATE TABLE foo (myfield varchar(10))');
    $sql->query('INSERT INTO foo VALUES (\'bar\')');
    $sql->query('INSERT INTO foo VALUES (\'bear\')');
    $sql->query('SELECT * FROM foo ORDER BY myfield DESC');
    
    header('Content-Type: text/plain');
    
    while ($row = $sql->fetch_row())
    {
      print_r($row);
    }
  }
?>
