<?php
/*  PHP Calendar v1.0
    By Richard James Kendall 
    Bugs to richard@richardjameskendall.com 
    Free to use, please acknowledge me 
    
    Just put the files (date.html, date.css, date_chooser.php) in a PHP enabled
    directory and point your browser at date.html, it is all fairly self
    explanatory.
*/
?>
<html>
<head>
	<title>Choose Date</title>
	<link rel="stylesheet" type="text/css" href="date.css">
</head>
<body>
<?php
$year = "";
$month = "";
$start_date = "";
if (isset($_GET["d"])) {
	$year = substr($_GET["d"], 0, 4);
	$month = substr($_GET["d"], 4, 2);
	$start_date = strtotime($year . "-" . $month . "-01");
} else {
	$year = date("Y");
	$month = date("m");
	$start_date = strtotime(date("Y") . "-" . date("m") . "-01");
}
$first_day = array("Sun" => 0, "Mon" => 1, "Tue" => 2, "Wed" => 3, "Thu" => 4, "Fri" => 5, "Sat" => 6);
$days_in_month = date("t", $start_date);
$prev_month = $month - 1;
$prev_year = $year;
$next_month = $month + 1;
$next_year = $year;
if ($month == 1) {
	$prev_month = 12;
	$prev_year = $year - 1;
}
if ($month == 12) {
	$next_month = 1;
	$next_year = $year + 1;
}
?>
<center>
<script language="javascript">
	function setDate(day) {
		window.opener.setDateText("<?php print($year); ?>-<?php print(str_pad($month, 2, "0", STR_PAD_LEFT)); ?>-" + day);
		window.self.close();
	}
</script>
<table width="100%" cellspacing="1" cellpadding="0" border="0">
	<tr>
		<td bgcolor="#DBDBDB" width="20" align="center"><a href="choose_date.php?d=<?php print($prev_year . $prev_month); ?>"><b>&lt;&lt;</b></a></td>
		<td bgcolor="#E7E7E7" align="center"><b><?php print(date("F, Y", $start_date)); ?></b></td>
		<td bgcolor="#DBDBDB" width="20" align="center"><a href="choose_date.php?d=<?php print($next_year . $next_month); ?>"><b>&gt;&gt;</b></a></td>
	</tr>
</table>
<table width="100%" cellspacing="1" cellpadding="0" border="0">
	<tr>
		<td bgcolor="#FFC0C0" width="14.28%" align="center">S</td>
		<td bgcolor="#A6A6A6" width="14.28%" align="center">M</td>
		<td bgcolor="#A6A6A6" width="14.28%" align="center">T</td>
		<td bgcolor="#A6A6A6" width="14.28%" align="center">W</td>
		<td bgcolor="#A6A6A6" width="14.28%" align="center">T</td>
		<td bgcolor="#A6A6A6" width="14.28%" align="center">F</td>
		<td bgcolor="#A6A6A6" width="14.28%" align="center">S</td>
	</tr>
	<tr>
	<?php
	$tbl_counter = 0;
	$day_counter = 1;
	while ($day_counter <= $days_in_month) {
		if ($tbl_counter >= $first_day[date("D", $start_date)]) {
			if (($tbl_counter % 7) == 0 && $day_counter != 1) {
				print ("</tr><tr>");
			}
			print ("<td bgcolor=\"#C3C3C3\" width=\"14.28%\" align=\"center\"><a href=\"javascript:setDate('" . str_pad($day_counter, 2, "0", STR_PAD_LEFT) . "');\">" . $day_counter . "</a></td>");
			$day_counter++;
		} else {
			print ("<td bgcolor=\"#EBEBEB\" width=\"14.28%\" align=\"center\">~</td>");
		}
		$tbl_counter++;
	}
	?>
	</tr>
</table>
</center>
</body>
</html>