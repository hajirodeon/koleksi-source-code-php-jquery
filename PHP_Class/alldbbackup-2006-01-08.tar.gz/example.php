<?php
//include the class file
include('mysql_backup_class_inc.php');

//set up the variables we will need
//NOTE: This has only been tested on MySQL!!

//set up our site name and application name for the sql file that is generated
$appname = 'MySQL Backup Class';
$myurl = 'http://www.example.com';
$backupPath = '/var/www/phpclasses/mysql_backup/';

//SQL server variables (MySQL)
$sql_type = 'mysql';
$sql_user = 'myUser';
$sql_pass = 'password123';
$sql_server = 'localhost';
$database = 'myDB';

//Instantiate the class
$dumper = new dbdump($sql_type,$sql_user,$sql_pass,$sql_server,$database,NULL);

//Get the table structure only
$struct = $dumper->structureOnly($appname, $myurl,$backupPath);
echo $struct;

//Dump out some breaks so that it looks cool
echo "<br><br><hr>";

//Get the database structure and data
$dataandstruct = $dumper->dataAndStruct($appname, $myurl, $backupPath);
echo $dataandstruct;
?>