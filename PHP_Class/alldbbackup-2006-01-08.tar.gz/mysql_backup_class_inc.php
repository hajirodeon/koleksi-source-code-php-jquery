<?php
/**
 * Class to backup a mysql database through with PEAR::DB
 * @author Paul Scott
 * @package mysql_backup
 */

require_once 'DB.php';

class dbdump 
{
    /**
     * @param  vars for PEAR::DB
     */
	var $USE_PREPARED_STATEMENTS = true;
    var $_db = null;
    var $_tableName = null;
    var $_errorCallback;
    var $_inTransaction = false;
    var $_serverName = "";
    var $_lastId = null;
    // The database config object
    var $objDBConfig;
    var $_dsn;
    //end PEAR::DB Vars
    
    function dbdump($dbtype='mysql',$dbuser,$dbpass,$dbserver,$dbname, $table=NULL)
	{
		$dsn = array(
			'phptype'  => $dbtype,
    		'username' => $dbuser,
    		'password' => $dbpass,
    		'hostspec' => $dbserver,
    		'database' => $dbname,
		);
		
		$this->_dsn = $dsn;
		
		$options = array(
    		'debug'       => 2,
    		'portability' => DB_PORTABILITY_ALL,
		);

		$this->_db =& DB::connect($dsn, $options);
		if (PEAR::isError($this->_db)) 
		{
    		die($this->_db->getMessage());
		}	
		
		//not sure if we need this...
		//$this->setTable($table);
	}
	
	/**
 	 * Method to change the table name
 	 * @param string $table
 	 * @return void
 	 */
 	function changeTable($table)
 	{
 		$this->_tableName = $table;
 	}

   /**
    * Wrapper for the getListOf method of PEAR DB
    * @param string $what The item to get a list of as per PEAR DB
    */
    function getListOf($what)
    {
        return $this->_db->getListOf($what);
    }

    /**
	 * Method to resolve table names 
	 * @param void
	 * @return array $tables
	 */
	function get_tablenames() 
	{
    	$tables = $this->getListOf('tables'); 
    	return $tables;
	}//end function
	
   /**
    * Method to execute a query against the database and return an array.
    * @param string $stmt the SQL query string
    * @return array |FALSE Rows as an array of associate arrays, or FALSE on failure
    */
    function getArray($stmt)
    { 
        // note: we specific FETCHMODE_ASSOC even though it is the default
        // to work around a bug in some versions of PEAR. May not be necessary
        $ret = $this->_db->getAll($stmt, array(), DB_FETCHMODE_ASSOC);
        if (PEAR::isError($ret)) {
            $ret = false;
        } 
        return $ret;
    }
    
    /**
    * Method to get all items from the table. 
    * Override in derived classes to implement access restrictions
    * @param string $filter a SQL WHERE clause (optional)
    * @return array |FALSE Rows as an array of associative arrays, or FALSE on failure
    */
    function getAll($filter = null)
    {
        $stmt = "SELECT * FROM {$this->_tableName} $filter";
        return $this->getArray($stmt);
    }
    
    /**
     * End of pear db methods
     * Start of backup methods
     */

    /**
	 * Methd to get the dump of the table structures only
	 * @author Paul Scott
	 * @param array $tablearray
	 * @return array $results
	 */
	function dbStructure($tablearray)
	{
		foreach($tablearray as $table)
		{
			$this->changeTable($table);
			$filter = "SHOW CREATE table $table";
			$results[] = $this->getArray($filter);
		}
		return $results;
	}
	
	/**
	 * Methd to get the dump of the table structures only
	 * @author Paul Scott
	 * @param array $tablearray
	 * @return array $dataResults
	 */
	function getData($tablearray)
	{
		foreach($tablearray as $table)
		{
			$this->changeTable($table);
			//table INSERT statements
			$dataResults[] = $this->getAll();
		}
		//return the dbdump
		return $dataResults;
	}
	
	/**
	 * Method to extract the data from the db from the array from PEAR DB::GetAll
	 * @param array $dataArray
	 * @return string
	 */
	function processData($dataArray)
	{
		$writefile = null;
		foreach($dataArray as $entries)
        {
        	$count = count($entries);
            if($count <= 0)
            {
            	$writefile .= "TABLE CONTAINS NO DATA<br><Br>";
            	continue;
            }
            else {
            	foreach($entries as $statements)
                {
                  	$fields = array_keys($statements);
                  	$statement = "INSERT INTO `$fields`;";
                }
            }
        }
        return $writefile;
	}


	
	/**
	 * Method to insert the backed up structure only into a new database
	 * @author Paul Scott
	 * @deprecated This function is no longer used!
	 */
	function insertStructure()
	{
		//set up the sql commands
		//disable FK checking for rebuilding the tables
		$preSetup = "SET FOREIGN_KEY_CHECKS = 0;";
		//re enable FK checks again!
		$postSetup = "SET FOREIGN_KEY_CHECKS = 1;";
		//$message = $this->objLanguage->languagetext("msg_insertstructure");
		return $message;
	}

	/**
	 * File writing methods
	 */
	
	/**
	 * Method to build the sql headers
	 * @param string $appname - the application name
	 * @param string $myurl - your app's url
	 * @return string headers
	 */
	function sqlfileHeaders($appname, $myurl)
	{
		//Build the sql file headers
		//disable FK checks
		$file = "SET FOREIGN_KEY_CHECKS = 0;";
		$file .=  "\n\n";
		$file .= "-- " . $appname . " Database SQL Dump \n";
		$file .= "-- Version 0.9 \n";
		$file .= "-- " . $myurl . " \n";
		$file .= "--  \n";
		$file .= "-- Generation Time: " . date('r') . "\n";
		$file .= "-- PHP Version: " . phpversion() . "\n";
		$file .= "-- -------------------------------------------------------- \n";
		$file .= "-- \n";
		$file .= "\n\n";
		return $file;
	}
	
	/**
	 * Method to output the structure of the db to a file
	 * @param array
	 * @return file
	 */
	function writeStructure($structarray)
	{
		//get the array
		$file = null;
		foreach($structarray as $structure)
		{
			$definition = $structure['table'];
			$createTable = $structure['create table'];
			
			$file .= "-- \n";
			$file .= "-- \n";
			$file .= "-- Table definition for " . $definition . "\n";
			$file .= "-- \n";
			$file .= "-- \n";
			$file .= "\n\n";
			$file .= $createTable . ";\n";
			$file .= "\n\n";
		}
			
		return $file;
	}

	/**
	 * write the file to a .sql file
	 * file will live with the current timestamp in
	 * $backupPath . "/time().Structure.sql"
	 * @param array $input
	 * @return bool true on success
	 */
	function writeSQL($backupPath, $input)
	{
		/**
		 * write the file to a .sql file
		 * file will live with the current timestamp in
		 * $backupPath . "/time().Structure.sql"
		 */
		$filename = $backupPath . "/" . time() . "_dbdump.sql";
		touch($filename);
		// Let's make sure the file exists and is writable first.
		if (is_writable($filename)) {
			   if (!$handle = fopen($filename, 'w')) {
    		    	return false;
         			exit;
   				}
   				if (fwrite($handle, $input) === FALSE) {
       				return false;
   					exit;
   				}
 		  // Success, wrote ($input) to file ($filename)
		   fclose($handle);
		   } else {
   				return false;
		   }
		   // return the filename for the user to find it again
		   return $filename;
 	}//end function

 	/**
 	 * Method to do full db dump of tables
 	 * @param array $tables
 	 * @param array $data
 	 * @param string $tbl_count
 	 * @return string $file
 	 */
 	function dumpAll($tables,$data,$tbl_count)
 	{
 		$increment = 0;
 		//declare $statement
 		$statement = null;
 		while($increment < $tbl_count)
 		{
 			//get the table name from the tables array
 			$table = $tables[$increment];
 			//get the data array for that table
 			$tbl_data = $data[$increment];
 			$fields = array();
 			$fields = array_keys($data[$increment]);
 			
 			//count of fields within each table array
 			$dataCounter = count($data[$increment]);
 			//set up a table data counter
 			$tblIncrement = 0;
 			//iterate through the table data
 			while($tblIncrement < $dataCounter)
 			{
 				$keysArray = array_keys($tbl_data[$tblIncrement]);
 				$dataArray = $tbl_data[$tblIncrement];
 				$fields = null;
 				$datainsert = null;
 				foreach($keysArray as $dbfields)
 				{
 					$fields .= "`" . $dbfields . "`" . ", ";
 					$datainsert .= "'" . addslashes($dataArray[$dbfields]) . "'" . ", ";  
 				}
 				$stat = "INSERT INTO `".$table."` ( " . $fields . ") VALUES (" .$datainsert . ");";
 				$statement[] .= str_replace(", )"," )",$stat);
 				$tblIncrement++;
 			}
 			$increment++;
 		}
 		return $statement;
 	}//end function

 	/**
 	 * Method to get the table structure only
 	 * and dump it to a filename
 	 * @param $appname - the applications name
 	 * @param mixed $myurl - your apps url
 	 * @param mixed $backupPath - the path to back file up to. 
 	 * 		  NOTE: This should be writeable by the webserver user
 	 * @return string to browser (ugh)
 	 */
 	function structureOnly($appname = "mysqlBackup", $myurl = "http://www.example.com", $backupPath)
 	{
 		 //get the tables as an array
         $ar1 = $this->get_tablenames();
         //get the structure
         $struct = $this->dbStructure($ar1);
         //write the file headers
         $writefile = $this->sqlfileHeaders($appname, $myurl);
         //build the sql file
         foreach($struct as $output)
         {
            //print_r($output); 
         	$writefile .= $this->writeStructure($output);
         }
         $this->writeSQL($backupPath, $writefile);
         return "Structure file written to: " . $backupPath;
 	}
 	
 	/**
 	 * Method to do full backup of data and structure
 	 * @param 
 	 */
 	function dataAndStruct($appname, $myurl, $backupPath)
 	{
 		//get the table names
        $ar1 = $this->get_tablenames();
        //get the structure of the db
        $struct = $this->dbStructure($ar1);
        //build the headers bit
        $writefile = $this->sqlfileHeaders($appname, $myurl);
        //set the data variable to null
        $data = null;
        //get the data
        $data = $this->getData($ar1);
        //how many tables are there?
        $tblCount = count($ar1);
        //pass the count and the arrays to the filebuilder function
        $db = $this->dumpAll($ar1,$data,$tblCount);
        //build the writefile for the create table statements
        foreach($struct as $output)
        {
            $writefile .= $this->writeStructure($output);  
        }
        //put in a sql comment to start the table data
        $writefile .= "-- Table data... \n\n";
        //loop through the data array
        foreach($db as $inserts)
        {
            $writefile .= $inserts;
        }
        $filename = $this->writeSQL($backupPath, $writefile);
        return $filename;
 	}
 	
}//end class
?>