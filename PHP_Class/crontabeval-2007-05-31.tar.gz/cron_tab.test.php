<?php
$s_time = microtime(true);
require('cron_tab.class.php');

//an array of tabs
$tabs = array(
 '*#*#*#*#*'          //all wild cards: true
,'*#*#*#*#3'          //every wednesday: true
,'*#*#30#*#3'         //if wednesday is the 30th of the month: true 
,'*#*#30#5#3'         //if wednesday is the 30th of may: true
,'*#*#*#*#1-4'        //monday - thursday: true
,'*#*#*#*#1,2,3'      //monday, tuesday, or wednesday: true
,'*#*#-2#*#*'         //second to last day of the month: true
,'*#*#*#*#1-3,5-6"'   //monday - wednesday or friday - saturday:true
,'*#*#31#5#*'         //31st of may: false
,'*#*#*#3-5#1-5'      //march, april, and may on monday - friday
);

foreach ($tabs as $test_tab){
	++$ii;
	// first param is the tab second is the time to test agenst.
	$test_obj = new CronTab($test_tab, "1180549300");
	echo $test_obj->get_cron_tab()."\n";
	echo $test_obj->get_a_tab()."\n";
	if ($test_obj->test()){
		echo "true\n\n";
	}else{
		echo "false\n\n";
	}
}


//var_dump($test_obj);
$t_time = microtime(true)-$s_time;
echo $t_time." seconds\n";
echo $t_time / $ii  . " adverage seconds per tab\n";
echo $ii ." tabs proccessed\n\n";

?>
