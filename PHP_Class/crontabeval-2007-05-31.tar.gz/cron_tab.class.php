<?php
// class to handel cron tabs evals
// Nathan Casteel 2007
// this file is free as in beer

class CronTab {
	//these are to genaric holding vars not used by the class
	private $id;
	private $extra;

	// cron tab to be tested
	private $min;
	private $hour;
	private $dom;
	private $month;
	private $dow;

	// the time to test the cron tab agenst
	private $a_min;
	private $a_hour;
	private $a_dom;
	private $a_month;
	private $a_dow;
	private $a_time;

	//the separator for cron tab represented by string 
	private $col_sep = '#';
	//string that logs any errors 
	private $error = "";

	public function get_id(){
		return $this->id;
	}

	public function set_id($id){
		$this->id = $id;
		return true;
	}

	public function get_extra(){
		return $this->extra;
	}

	public function set_extra($extra){
		$this->extra = $extra;
		return true;
	}

	// returns a formated string
	public function get_cron_tab(){
		return $this->min.$this->col_sep.$this->hour.$this->col_sep.$this->dom.$this->col_sep.$this->month.$this->col_sep.$this->dow;
	}
	
	// takes an array or a string and fills class vars
	public function set_cron_tab($cron_tab){
		if (!is_array($cron_tab)){
			$cron_tab = $this->convert_string_to_cron_tab_array($cron_tab);
			if (!$cron_tab){
				return false;
			}
		}
		if (count($cron_tab) != 5){
			$this->error .= "set_cron_tab failed cron_tab array unusable.\n";
			return false;
		}
		$this->min = $cron_tab[0];
		$this->hour = $cron_tab[1];
		$this->dom = $cron_tab[2];
		$this->month = $cron_tab[3];
		$this->dow = $cron_tab[4];
		return true;
	}

	// returns a formated string 
	public function get_a_tab(){
		return $this->a_min.$this->col_sep.$this->a_hour.$this->col_sep.$this->a_dom.$this->col_sep.$this->a_month.$this->col_sep.$this->a_dow;
	}
	
	public function get_a_time(){
		return $this->a_time;
	}

	// takes a int representing the time you want to compare the cron tab agenst and fills the agenst class vars.
	public function set_a_time($time){
		$this->a_time = $time;
		$date = getdate($time);
		$this->a_min = $date['minutes'];
		$this->a_hour = $date['hours'];
		$this->a_dom = $date['mday'];
		$this->a_month = $date['mon'];
		$this->a_dow = $date['wday'];
	}

// takes an array or a string and fills a_ class vars
// a_tab can not have any ranges or reverses. If possable you should use set_a_time.
// a_time must be set or reverse months will not work.
	public function set_a_tab($cron_tab){
		if (!is_array($cron_tab)){
			$cron_tab = $this->convert_string_to_cron_tab_array($cron_tab);
			if (!$cron_tab){
				return false;
			}
		}
		if (count($cron_tab) != 5){
			$this->error .= "set_a_tab failed cron_tab array unusable.\n";
			return false;
		}
		$this->a_min = $cron_tab[0];
		$this->a_hour = $cron_tab[1];
		$this->a_dom = $cron_tab[2];
		$this->a_month = $cron_tab[3];
		$this->a_dow = $cron_tab[4];
		$this->a_time = strtotime($cron_tab[2]."-".$cron_tab[3]."-".date("Y"));
		return true;
	}

	public function set_col_sep($col_sep){
		$this->col_sep = $col_sep;
		return true;
	}

	// takes a cron tab string and converts it to an array
	public function convert_string_to_cron_tab_array($in){
		$cron_tab = explode($this->col_sep, $in);
		if (count($cron_tab) != 5){
			$this->error .= "convert_string_to_cron_tab_array failed to convert ".$in."\n";
			return false;
		}
		return $cron_tab;
	}
	
	// compairs to cron tab segments and returns true or false
	// to revese_from is the max value that the segment can have ex. last day of the month
	private function eval_tab($tab, $a_tab, $revese_from = 0){
		if ($tab == "*"){
			return true;
		}
		//will not procces list and ranges
		if (is_numeric($tab)){
			//preforms a reverse if tab is -
			if ($tab < 0){
				$tab = $revese_from + $tab + 1;
			}
			//checks tab agenst a_tab
			if ($tab == $a_tab){
				return true;
			}else{
				return false;
			}
		//proccess list, same as for single it just splits the tab up and runs on each
		}elseif (strpos($tab, ",")){
			$exps = explode(",", $tab);
			foreach ($exps as $exp){
				if (is_numeric($exp)){
					if ($exp < 0){
						$exp = $revese_from + $exp + 1;
					}
					if ($exp == $a_tab){
						return true;
					}
				}else if (ereg("([0-9]+)-([0-9]+)", $exp, $regs) > 0){
					if (($regs[1] <= $exp) && ($exp <= $regs[2])){
						return true;
					}
				}
			}
			return false;
		}
		//checks and pulls out the min and max of a range
		if (ereg("([0-9]+)-([0-9]+)", $tab, $regs) > 0){
			//compairs tab to range
			if (($regs[1] <= $a_tab) && ($a_tab <= $regs[2])){
				return true;
			}
		}
		return false;
	}

	// compares to cron tabs and returns true, on a match,or false
	public function test(){
		if (!$this->eval_tab($this->min, $this->a_min, 59)){
			return false;
		}
		if (!$this->eval_tab($this->hour, $this->a_hour, 23)){
			return false;
		}
		if (!$this->eval_tab($this->dom, $this->a_dom, date("t", $this->a_time))){
			return false;
		}
		if (!$this->eval_tab($this->month, $this->a_month, 12)){
			return false;
		}
		if (!$this->eval_tab($this->dow, $this->a_dow, 6)){
			return false;
		}
		return true;
	}

	public function __construct($tab, $a_time = 'now'){
		$this->set_cron_tab($tab);
		if ($a_time == 'now'){
			$this->set_a_time(time());
		}else{
			$this->set_a_time($a_time);
		}
	}
}
?>
