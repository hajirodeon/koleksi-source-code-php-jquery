# MySQL dump 8.16
#
# Host: localhost    Database: compactos
#--------------------------------------------------------
# Server version	3.23.47-nt

#
# Table structure for table 'cds'
#

CREATE TABLE cds (
  num int(5) NOT NULL auto_increment,
  nombre varchar(50) NOT NULL default '',
  estado char(2) NOT NULL default '',
  posee varchar(30) default NULL,
  fecha date default NULL,
  PRIMARY KEY  (num)
) TYPE=MyISAM;

#
# Dumping data for table 'cds'
#

INSERT INTO cds VALUES (1,'Kool Dance Tour 1997','np','','0000-00-00');
INSERT INTO cds VALUES (2,'Jimmy Hendrix','np','','0000-00-00');
INSERT INTO cds VALUES (3,'PC Player','np','','0000-00-00');
INSERT INTO cds VALUES (4,'Independence Night XXX','pr','Juancho Clavijo','2002-11-28');
INSERT INTO cds VALUES (5,'Allaire ColdFusion (Eval)','np','','0000-00-00');
INSERT INTO cds VALUES (6,'Savage Garden','np','','0000-00-00');
INSERT INTO cds VALUES (7,'Impresora Cannon BJ-2000','np','','0000-00-00');
INSERT INTO cds VALUES (8,'Super CD Plus','np','','0000-00-00');
INSERT INTO cds VALUES (9,'Danger Girl (Play Station)','pr','Daniel','2002-12-16');
INSERT INTO cds VALUES (10,'Microsoft Windows 2000 AS (Eval)','np','','0000-00-00');
INSERT INTO cds VALUES (11,'Microsoft S. Portal Server (Eval)','np','','0000-00-00');
INSERT INTO cds VALUES (12,'Microsoft Windows 98 SE','np','','0000-00-00');
INSERT INTO cds VALUES (13,'Microsoft Visio 2002','np','','0000-00-00');
INSERT INTO cds VALUES (14,'Microsoft Windows XP','np','','0000-00-00');
INSERT INTO cds VALUES (15,'Microsoft Office XP CD 1','np','','0000-00-00');
INSERT INTO cds VALUES (16,'Microsoft Office XP CD 2','np','','0000-00-00');
INSERT INTO cds VALUES (17,'Microsoft Visual Studio .Net  CD 1','np','','0000-00-00');
INSERT INTO cds VALUES (18,'Microsoft Visual Studio .Net  CD 2','np','','0000-00-00');
INSERT INTO cds VALUES (19,'Microsoft Visual Studio .Net  CD 3','np','','0000-00-00');
INSERT INTO cds VALUES (20,'Microsoft Windows Comp. Update','np','','0000-00-00');
INSERT INTO cds VALUES (21,'Microsoft Windows XP Pro (Eval)','np','','0000-00-00');
INSERT INTO cds VALUES (22,'Microsoft Office XP (Eval)','np','','0000-00-00');
INSERT INTO cds VALUES (23,'Microsoft Producer','pr','Yesid','2002-06-14');
INSERT INTO cds VALUES (24,'Oracle 9i A.S for Linux CD 1','np','','0000-00-00');
INSERT INTO cds VALUES (25,'Oracle 9i A.S for Linux CD 2','np','','0000-00-00');
INSERT INTO cds VALUES (26,'Oracle 9i A.S for Linux CD 3','np','','0000-00-00');
INSERT INTO cds VALUES (27,'Oracle 9i A.S for Win. NT CD 1','np','','0000-00-00');
INSERT INTO cds VALUES (28,'Oracle 9i A.S for Win. NT CD 2','np','','0000-00-00');
INSERT INTO cds VALUES (29,'Oracle 9i A.S for Win. 95/98/NT','np','','0000-00-00');
INSERT INTO cds VALUES (30,'Oracle 8i Lite','np','','0000-00-00');
INSERT INTO cds VALUES (31,'Oracle JDeveloper 3.0','np','','0000-00-00');
INSERT INTO cds VALUES (32,'Oracle Forms And Reports 6.0','np','','0000-00-00');
INSERT INTO cds VALUES (33,'Oracle Designer 6i - Repository','np','','0000-00-00');
INSERT INTO cds VALUES (34,'Oracle 8i personal','np','','0000-00-00');
INSERT INTO cds VALUES (35,'IBM Visual Age For Java 3.5','np','','0000-00-00');
INSERT INTO cds VALUES (36,'IBM Application Dev. Kit CD 1','np','','0000-00-00');
INSERT INTO cds VALUES (37,'IBM Application Dev. Kit CD 2','np','','0000-00-00');
INSERT INTO cds VALUES (38,'Molotov-Donde Jugaran las Ni�as','np','','0000-00-00');
INSERT INTO cds VALUES (39,'Lucky falvor CD','np','','0000-00-00');
INSERT INTO cds VALUES (40,'Rammstein','np','','0000-00-00');
INSERT INTO cds VALUES (41,'DJ Music - Punchis','np','','0000-00-00');
INSERT INTO cds VALUES (42,'Coca-Cola Music','np','','0000-00-00');
INSERT INTO cds VALUES (43,'House Electric','np','','0000-00-00');
INSERT INTO cds VALUES (44,'Pc Format - Demo Juegos','np','','0000-00-00');
INSERT INTO cds VALUES (45,'OK CD Gamer','np','','0000-00-00');
INSERT INTO cds VALUES (46,'Quake II','np','','0000-00-00');
INSERT INTO cds VALUES (47,'Swat 3','np','','0000-00-00');
INSERT INTO cds VALUES (48,'Star Wars','np','','0000-00-00');
INSERT INTO cds VALUES (49,'Fifa 2000','np','','0000-00-00');
INSERT INTO cds VALUES (50,'Neo Geo Games CD 1','np','','0000-00-00');
INSERT INTO cds VALUES (51,'Neo Geo Games CD 2','np','','0000-00-00');
INSERT INTO cds VALUES (52,'Samsung SyncMaster Monitor','np','','0000-00-00');
INSERT INTO cds VALUES (53,'Los A�os Maravillosos del Cine','np','','0000-00-00');
INSERT INTO cds VALUES (54,'USB Redes 2002','np','','0000-00-00');
INSERT INTO cds VALUES (55,'Easy CD Creator','np','','0000-00-00');
INSERT INTO cds VALUES (56,'Norton 2002','np','','0000-00-00');
INSERT INTO cds VALUES (57,'Exit Wounds','pr','Hemerson','2002-06-15');
INSERT INTO cds VALUES (58,'Downloads - Zorro1','np','','0000-00-00');
INSERT INTO cds VALUES (59,'Java y Php Utils','np','','0000-00-00');
INSERT INTO cds VALUES (60,'National Semiconductor','np','','0000-00-00');
INSERT INTO cds VALUES (61,'Visual Basic.Net Upgrade guide','np','','0000-00-00');
INSERT INTO cds VALUES (62,'Rational Clear Case','np','','0000-00-00');
INSERT INTO cds VALUES (63,'Rational UML Documents','np','','0000-00-00');
INSERT INTO cds VALUES (64,'Rational XDE JAVA','np','','0000-00-00');
INSERT INTO cds VALUES (65,'Excel XP Training','np','','0000-00-00');
INSERT INTO cds VALUES (66,'Php Installers','np','','0000-00-00');
INSERT INTO cds VALUES (67,'Microsoft Service Packs CD 2','pr','Ana Lucia','2002-11-14');
INSERT INTO cds VALUES (68,'Microsoft Embedded V.T CD 1','np','','0000-00-00');
INSERT INTO cds VALUES (69,'Microsoft Embedded V.T CD 2','np','','0000-00-00');
INSERT INTO cds VALUES (70,'Microsoft Liquid Motion','np','','0000-00-00');
INSERT INTO cds VALUES (71,'Microsoft Exchange 2000 Server','np','','0000-00-00');
INSERT INTO cds VALUES (72,'Microsoft Visio 2002 (Eval)','np','','0000-00-00');
INSERT INTO cds VALUES (73,'Microsoft Visio 2002 Auto Demo','np','','0000-00-00');
INSERT INTO cds VALUES (74,'Renegade CD 1','np','','0000-00-00');
INSERT INTO cds VALUES (75,'Renegade CD 2','np','','0000-00-00');
INSERT INTO cds VALUES (76,'Fifa Soccer International','np','','0000-00-00');
INSERT INTO cds VALUES (77,'Intel Board 850GB','np','','0000-00-00');
INSERT INTO cds VALUES (78,'MSI AGP','np','','0000-00-00');
INSERT INTO cds VALUES (79,'De TODO','np','','0000-00-00');
INSERT INTO cds VALUES (80,'Microsoft Documentacion','np','','0000-00-00');
INSERT INTO cds VALUES (81,'Visio-XML-.NET','np','','0000-00-00');
INSERT INTO cds VALUES (82,'Macromedia Mx Studio - Llamas','np','','0000-00-00');
INSERT INTO cds VALUES (83,'Sound Blaster Live 5.1','np','','0000-00-00');
INSERT INTO cds VALUES (84,'Gigi D-agostino (Musica)','np','','0000-00-00');
INSERT INTO cds VALUES (85,'Printable Expressions','np','','0000-00-00');
INSERT INTO cds VALUES (86,'Solo MP3s #1','np','','0000-00-00');
INSERT INTO cds VALUES (87,'Solo MP3s #2','np','','0000-00-00');
INSERT INTO cds VALUES (88,'Fort� For Java','np','','0000-00-00');
INSERT INTO cds VALUES (89,'Medal Of Honor CD 1','np','','0000-00-00');
INSERT INTO cds VALUES (90,'Medal Of Honor CD 2','np','','0000-00-00');
INSERT INTO cds VALUES (91,'GeoNet','np','','0000-00-00');
INSERT INTO cds VALUES (92,'Datos-Downloads3-PostgreSQL','np','','0000-00-00');
INSERT INTO cds VALUES (93,'Soldier of Fortune 2 CD 1','np','','0000-00-00');
INSERT INTO cds VALUES (94,'Soldier of Fortune 2 CD 2','np','','0000-00-00');
INSERT INTO cds VALUES (95,'Jedi Return','np','','0000-00-00');
INSERT INTO cds VALUES (96,'Juanes - Bacilos','np','','0000-00-00');
INSERT INTO cds VALUES (97,'Cabas - Diego Torres','np','','0000-00-00');
INSERT INTO cds VALUES (98,'Encarta 2002 CD 1','np','','0000-00-00');
INSERT INTO cds VALUES (99,'Encarta 2002 CD 2','np','','0000-00-00');
INSERT INTO cds VALUES (100,'Encarta 2002 CD 3','np','','0000-00-00');
INSERT INTO cds VALUES (101,'Encarta 2002 CD 4','np','','0000-00-00');
INSERT INTO cds VALUES (102,'Java-Together','np','','0000-00-00');
INSERT INTO cds VALUES (103,'SAP - Vision Lounge','np','','0000-00-00');
INSERT INTO cds VALUES (104,'SAP - Funtrions in Detail','np','','0000-00-00');
INSERT INTO cds VALUES (105,'SAP - Database','np','','0000-00-00');
INSERT INTO cds VALUES (106,'SAP - Enjoy sap demo','np','','0000-00-00');
INSERT INTO cds VALUES (107,'SAP - C-Business Map','np','','0000-00-00');
INSERT INTO cds VALUES (108,'Rational Solutions for .NET','np','','0000-00-00');
INSERT INTO cds VALUES (109,'Libro VBScript y CD','np','','0000-00-00');
INSERT INTO cds VALUES (110,'Spanish Rock MP3','np','','0000-00-00');
INSERT INTO cds VALUES (111,'IBM Dev.Works Toolbox sample CD 1','np','','0000-00-00');
INSERT INTO cds VALUES (112,'IBM Dev.Works Toolbox sample CD 2','np','','0000-00-00');
INSERT INTO cds VALUES (113,'IBM Dev.Works Linux Software CD1','np','','0000-00-00');
INSERT INTO cds VALUES (114,'IBM Dev.Works Linux Software CD2','np','','0000-00-00');
INSERT INTO cds VALUES (115,'IBM Dev.Works XML','np','','0000-00-00');
INSERT INTO cds VALUES (116,'IBM Dev.Works Web Services','np','','0000-00-00');
INSERT INTO cds VALUES (117,'IBM RedBooks Lotus Collection','np','','0000-00-00');
INSERT INTO cds VALUES (118,'VPC-VAFJ','np','','0000-00-00');
INSERT INTO cds VALUES (119,'Divers Modem Intel-CA','np','','0000-00-00');
INSERT INTO cds VALUES (120,'IBM AlphaWorks 2002','np','','0000-00-00');
