<!doctype html public "-//W3C//DTD HTML 4.0 //EN"> 
<html>
<head>
       <title>Modificar</title>
</head>
<body bgcolor="#000000" BGPROPERTIES=fixed background="clabkgnd.gif" text="#FFFFFF" link="#6699CC" vlink="#669966" alink="#999999">
    <!--mstheme--><font face="Arial, Arial, Helvetica">
<?php
class Modifica{

      function Mostrar($num){
		$lafecha=(date("Y-m-d"));
               print "<h2>Modificar Estado del CD # $num</h2>";
               print "<form action=confirmar.php method=post><b>Poseedor:</b><input type=text name=poseedor>";
               print "<input type=hidden name=valor value=$num> <br><input type=hidden name=fecha value=$lafecha><br><b>Estado:    </b>";
               print "<SELECT NAME=opcion><OPTION>np<OPTION>pr</SELECT><br><br>";
               print "<input type=submit name=modificar value=Modificar... > </form>";

      }
}

$modificacion= new Modifica;
$modificacion->Mostrar($id);


?>

</body>
</html>

