<?php
session_start();
include "control.inc";
Header("Content-type: text/plain");
include("class.FastTemplate.php3");

    $tpl = new FastTemplate(".");
    $tpl->define(array(main => "conf.tpl"));
    $tpl->parse(RES, "main");
    $tpl->FastPrint(RES);
$laconexion= new Conexion;
$laconexion->Conectar();

if ($modificar){

    $laconexion->modificarCD($valor,$opcion,$poseedor,$fecha);
       

}

else {

	if ($ingresar){

		 if (!$nombre){
       			echo "<b>No Digit� Ningun nombre para el nuevo CD<b><br>";
       			echo "<a href=ingresar.html><- Volver</a>";
   		 }
    		 else{
       
			$laconexion->ingresarCD($nombre);
		 }


	}
}



?>

</body>
</html>
