<?php
    /*Este programa mantiene un inventario de los CD's, permitiendo ver su estado
    y quien lo tiene en caso de estar prestado*/
    //AUTOR: Juan Carlos P�rez Orjuela


    
    require("control.inc");  //contiene la clase de conexion a la bd,y otras funciones de consulta
    
    session_start();


    if(!isset($HTTP_SESSION_VARS["pag"]) || !isset($HTTP_SESSION_VARS["pagant"])){
       $HTTP_SESSION_VARS["pag"]=20;
       $HTTP_SESSION_VARS["pagant"]=0;
    }


    
    $laconexion= new Conexion;
    $laconexion->Conectar();
    
    $limiteinf=$_SESSION["pagant"];
    $limitesup=$_SESSION["pag"];
    $laconexion->setConsulta("select * from $laconexion->dbtable limit $limiteinf,$limitesup");
    $result=$laconexion->Consultar();
 
    Header("Content-type: text/plain");
    include("class.FastTemplate.php3");

    $tpl = new FastTemplate(".");
    $tpl->define(array(main => "main.tpl"));
    $tpl->assign("RUTA" ,"burst.gif");
    $tpl->assign("PRESTADOS" ,$laconexion->obtPrestados()." CD's Prestados");
    $tpl->parse(RES, "main");
    $tpl->FastPrint(RES);

    $laconexion->obtFechaActual();
    $cont=0;

      while ($row = mysql_fetch_array($result)){
        $cont++;
        $laconexion->llenaColumna($row,$cont);
      }

	

       
  echo "</table><!--mstheme--><font face=Arial, Arial, Helvetica>";
  echo "</center>";

  mysql_free_result($result); //libera memoria, limpiando el resultado del query
  mysql_close();              //cierra conexion con la BD
   ?>

    <!--mstheme--></font>

</body>
</html>
