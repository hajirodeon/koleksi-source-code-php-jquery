<?php
    /**
    * This file contains the enhancedTab class that using JS allows to
    * dynamic hide and display different parts of a page like a standard TabSheet.
    * This class is a subclass of the enhancedBase class.
    * @package enhancedUI
    */

	require_once (dirname (__FILE__)."/enhancedBase.php");

    /**
    * enhancedTab class
    *
    * This class allows to dynamically hide and show different HTML contents on a page like
    * a tabsheet.
    *
    * @package enhancedUI
    * @author Setec Astronomy
    * @version 1.0
    * @abstract Dynamically hide and show HTML contents likes Tab Sheets
    * @copyright 2004
    * @example ../examples/enhancedTab1.php An example that uses the getUpdateTab method
    * @example ../examples/enhancedTab2.php An example that uses the getUpdateListTab method
    */
    class enhancedTab extends enhancedBase {

        /**
        * Hidden form name member
        *
        * This is the name of the form that contains the hidden fields.
        * @var string
        */
        var $hidden_form_name = "";
        /**
        * Hidden field name member
        *
        * This is the name of the hidden field used to store the elemenId of the
        * active sheet
        * @var string
        */
        var $hidden_field_name = "";
        /**
        * Default sheet name member
        *
        * This is the name of the default sheet to be displayed
        * @var string
        */
        var $default_sheet = "";

        /**
        * updateTab function name member
        *
        * This is the name of the function updateTab. This member is usefull if you have to use
        * JS on the client side and don't want to change other predefined functions.
        *
        * @var string
        */
        var $function_updateTab = "";

        /**
        * updateListTab function name member
        *
        * This is the name of the function updateListTab. This member is usefull if you have to use
        * JS on the client side and don't want to change other predefined functions.
        *
        * @var string
        */
        var $function_updateListTab = "";

        /**
        * Default constructor
        *
        * This is the default constructor enhancedTab class.
        */
        function enhancedTab () {
            $this->default_sheet = "";
            $this->function_updateTab = "updateTab";
            $this->function_updateListTab = "updateListTab";
            $this->hidden_form_name = "enhancedTabForm";
            $this->hidden_field_name = "enhanced";
        }

        /**
        * The getJS method
        *
        * This method overwrites the base class getJS methods. It returns the JS code
        * needed for the client side scripting.
        * @param boolean $JSTag if true it includes the script tag container
        * @return string the JS code with standard functions
        * @see enhancedBase::getJS()
        */
        function getJS ($JSTag = false) {

            ob_start ();
            if ($JSTag) {
?>
<script language="JavaScript" type="text/JavaScript">
<!--
<?php
            } // if ($JSTag) {
?>
function <?php print ($this->function_updateTab); ?> (tab_id, hidden_form_name, hidden_field_name) {
        var el_old;
        var el_new;

        if (tab_id != "") {
                el_new = document.getElementById (tab_id);

                if ((document.forms[hidden_form_name] != undefined) &&
                   (document.forms[hidden_form_name].elements[hidden_field_name] != undefined)) {
                        if (document.forms[hidden_form_name].elements[hidden_field_name].value != "") {
                                 el_old = document.getElementById (document.forms[hidden_form_name].elements[hidden_field_name].value);
                        }
                        if (el_old != undefined) {
                                el_old.style.cssText = 'display: none;';
                        }
                        if (el_new != undefined) {
                                el_new.style.cssText = 'display: inline;';
                                document.forms[hidden_form_name].elements[hidden_field_name].value = tab_id;
                        }
                }
        }

        return false;
}

function <?php print ($this->function_updateListTab); ?> (list_form_name, list_field_name) {
    if ((document.forms[list_form_name] != undefined) &&
       (document.forms[list_form_name].elements[list_field_name] != undefined) &&
       (document.forms[list_form_name].elements[list_field_name].options.selectedIndex >= 0)) {
       <?php print ($this->function_updateTab); ?> (document.forms[list_form_name].elements[list_field_name].value, '<?php print ($this->hidden_form_name); ?>', '<?php print ($this->hidden_field_name); ?>');
    }
    return false;
}
<?php
            if ($JSTag) {
?>
//-->
</script>
<?php
            } // if ($JSTag) {
            $return = ob_get_contents ();
            ob_end_clean ();
            return $return;
        } // function getJS ($JSTag = false) {

        /**
        * The getInitializationJS method
        *
        * This method overwrites the base class getInitializationJS methods.
        * It returns the JS code needed for the client UI initialization.
        * @param boolean $JSTag if true it includes the script tag container
        * @return string the JS code with standard functions
        * @see enhancedBase::getInitializationJS()
        */
        function getInitializationJS ($JSTag = false) {

            ob_start ();
            if ($JSTag) {
?>
<script language="JavaScript" type="text/JavaScript">
<!--
<?php
            } // if ($JSTag) {

            print ($this->function_updateTab . " ('" . $this->default_sheet . "', '" . $this->hidden_form_name . "', '" .
                   $this->hidden_field_name . "')");

            if ($JSTag) {
?>
//-->
</script>
<?php
            } // if ($JSTag) {
            $return = ob_get_contents ();
            ob_end_clean ();
            return $return;
        } // function getInitializationJS ($JSTag = false) {

        /**
        * The getOpenSheet method
        *
        * This method returns the HTML code needed to open (create) a sheet.
        * @param string $sheet_name contains the elementId of to sheet to be opened.
        * @param string $sheet_tag contains the tag name to be opened (default "div").
        * @param string $visible specify if the sheet have to be visibile or not.
        * @return string the HTML code to open the tag.
        */
        function getOpenSheet ($sheet_name, $sheet_tag = "div", $visible = false) {
            if ($visible) {
                return "<" . $sheet_tag . " id='" . $sheet_name . "' style='display: inline;'>";
            } else {
                return "<" . $sheet_tag . " id='" . $sheet_name . "' style='display: none;'>";
            }
        }

        /**
        * The getCloseSheet method
        *
        * This method returns the HTML code needed to close a sheet.
        * @param string $sheet_tag contains the tag name to be closed (default "div").
        * @return string the HTML code to close the tag.
        */
        function getCloseSheet ($sheet_tag = "div") {
            return "</" . $sheet_tag . ">";
        }

        /**
        * The getHiddenForm method
        *
        * This method returns the HTML code of the hidden form used to store the
        * active sheet information
        * @return string the HTML code of the hidden form.
        */
        function getHiddenForm () {
            return "<form name='" . $this->hidden_form_name . "' id='" . $this->hidden_form_name . "'> " .
                   "<input type='hidden' name='" . $this->hidden_field_name . "' value='" . $this->default_sheet . "' />" .
                   "</form>";
        }

        /**
        * The getUpdateTab method
        *
        * This method returns the JS code to show an hidden sheet and authomatically hide the previous one.
        * @param string $sheet_name the name of the sheet to be showed.
        * @return string the JS code ready to be executed
        */
        function getUpdateTab ($sheet_name) {
            return $this->function_updateTab . " ('" . $sheet_name . "', '" . $this->hidden_form_name . "', '" .
                   $this->hidden_field_name . "')";
        }

        /**
        * The getUpdateListTab method
        *
        * This method returns the JS code to be used in the OnChange event of a list/menu to show an hidden sheet
        * and authomatically hide the previous one.
        * @param string $sheet_name the name of the sheet to be showed.
        * @param string $sheet_name the name of the sheet to be showed.
        * @return string the JS code ready to be executed
        */
        function getUpdateListTab ($list_form_name, $list_field_name) {
            return $this->function_updateListTab . " ('" . $list_form_name . "', '" . $list_field_name . "')";
        }

    } // class enhancedTab extends enhancedBase {
?>