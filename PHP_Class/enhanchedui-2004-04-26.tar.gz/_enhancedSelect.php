<?php
	/**
	* enhancedSelect Example 
	*
	* This example shows how to use the enhancedSelect class to link two (or more) list/menus in a master/detail relationship.
	*
    * @package enhancedUI
    * @subpackage examples
    * @example enhancedSelect.php This file source code
    */

    require_once (dirname (__FILE__)."/enhancedUI.php");
    $enhancedSelect = new enhancedSelect ();
    $enhancedSelect->master_form_name = "master_form";
    $enhancedSelect->master_field_name = "master_list";
    $enhancedSelect->detail_form_name = "detail_form";
    $enhancedSelect->detail_field_name = "detail_list";
    
    $value = array ("value" => "1",
                    "text" => "Language",
                    "details" => array ("2" => "ASP",
                                        "4" => "C++",
                                        "3" => "Javascript",
                                        "1" => "PHP")
                    );
    $enhancedSelect->addSelectItem ($value);
    $value = array ("value" => "2",
                    "text" => "OS",
                    "details" => array ("8" => "FreeBSD",
                                        "5" => "Linux",
                                        "7" => "Mac OS X",
                                        "9" => "Unix",
                                        "6" => "Windows")
                    );
    $enhancedSelect->addSelectItem ($value);
    $value = array ("value" => "3",
                    "text" => "DBMS",
                    "details" => array ("10" => "MySQL",
                                        "14" => "Oracle",
                                        "13" => "MS SQL Server",
                                        "12" => "Interbase",
                                        "11" => "DB2")
                    );
    $enhancedSelect->addSelectItem ($value);
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>enhancedSelect Example</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<?php print ($enhancedSelect->getJS (true)); ?> 
</head>
<body>
<table border="0" cellspacing="5" cellpadding="0"><tr align="left" valign="top">
  <td> Master List<br /> <form name="master_form" action="<?php print ($_SERVER['PHP_SELF']); ?>" method="post">
      <select name="master_list" size="7" onChange="<?php print ($enhancedSelect->updateSelect ("master_form", "master_list", "detail_form", "detail_list")); ?>">
        <option value="1" selected="true">Language</option>
        <option value="2">OS</option>
        <option value="3">DBMS</option>
      </select></select>
      </form></td><td>
  Details List <br /><form name="detail_form" action="<?php print ($_SERVER['PHP_SELF']); ?>" method="post">
  <select name="detail_list" size="7">
  </select></form></td></tr> 
</table>
<?php print ($enhancedSelect->getInitializationJS (true)); ?>
<script language="JavaScript" type="text/JavaScript">
<!--
<?php print ($enhancedSelect->updateSelect ()); ?>
//-->
</script>
</body>
</html>