<?php
    /**
	* enhancedMoving Example 
	*
	* This example shows how to use the class enhancedMoving and the its method {@link enhancedMoving::getJSMoveItem enhancedMoving::getJSMoveItem}.
    * @package enhancedUI
    * @subpackage examples
    * @example enhancedMoving.php This file source code
	*/

    require_once (dirname (__FILE__)."/enhancedUI.php");
    $enhancedMoving = new enhancedMoving ();

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>enhancedMoving Example</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<?php print ($enhancedMoving->getJS (true)); ?>
</head>
<body>
<form name="moving_form" action="<?php print ($_SERVER['PHP_SELF']); ?>" method="post" onSubmit="<?php print ($enhancedMoving->getOnSubmit ('moving_form', array ("todo_list[]", "done_list[]"))); ?>; return true">
  <table border="0" cellspacing="5" cellpadding="0">
    <tr align="left" valign="top"> 
      <td> ToDo list<br />
	  	<select name="todo_list[]" size="7" multiple>
          <option value="1">PHP Debugging</option>
          <option value="2">Performance profiler</option>
          <option value="3">Documentation</option>
          <option value="5">Add class _todo</option>
          <option value="6">Changhe super class implementation</option>
        </select> &nbsp;</td>
      <td align="center" valign="middle"> &nbsp; &nbsp; <input onClick="<?php print ($enhancedMoving->getJSMoveItem ("moving_form", "done_list", "moving_form", "todo_list", "Please select one or more items from the left side list!")); ?>" type="button" value="&lt;&lt;"> 
        &nbsp; &nbsp; <input onClick="<?php print ($enhancedMoving->getJSMoveItem ("moving_form", "todo_list", "moving_form", "done_list", "Please select one or more items from the right side list!")); ?>" type="button" value="&gt;&gt;"> 
        &nbsp; &nbsp;</td>
      <td> 
	  Done List <br />
	  	<select name="done_list[]" size="7" multiple>
          <option value="4">Sample files</option>
        </select> </td>
    </tr>
    <tr align="center" valign="middle"> 
      <td colspan="3"><input type="submit" name="btnSubmit" value="Submit"></td>
    </tr>
  </table>
  <table border="0" cellspacing="5" cellpadding="0">
  </table>
</form>
<pre>
POST Array follows:
<?php 
print_r ($_POST);
?>
</pre>
</body>
</html>