<?php
    /**
    * This file contains the enhancedRecordset and recordsetRow classes, the first one is
    * a subclass of the enhancedBase class.
    * @package enhancedUI
    */

    require_once (dirname (__FILE__)."/enhancedBase.php");

    /**
    * recordsetRow class
    *
    * This is a simple class that contains a record of the recordset for the
    * enhancedRecordset class. See the $enhancedRecordset->recordset member
    * description to understood the use of this class.
    *
    * @package enhancedUI
    * @author Setec Astronomy
    * @version 1.0
    * @abstract A single record for a enhancedRecordset recordset.
    * @copyright 2004
    * @see enhancedRecordset::$recordset
    */
	class recordsetRow {
        /**
        * Value member
        *
        * This field contains the hidden value assigned to the text field.
        * @var mixed
        */
        var $value = "";
        /**
        * Text member
        *
        * The text is the visible value of the value member.
        * @var mixed
        */
        var $text = "";
        /**
        * Details member
        *
        * It contains the array of details values related to the couple value/text
        * throught a master/detail relation.
        * @var array
        */
        var $details = array ();
    } // class recordsetRow {

    /**
    * enhancedRecordset class
    *
    * This class allows to edit on the client side a recordset (a group of records)
    * grouped by a master recordset. This class is a part of the enhancedUI hierarchy.
    *
    * The use is simple, configure all the public members with the needed values, insert
    * the master/detail values in the recordset array and than call the methods to
    * create the form and the client side scripting code.
    * @package enhancedUI
    * @author Setec Astronomy
    * @version 1.0
    * @abstract Edit a recordset on client side
    * @copyright 2004
    * @example ../examples/enhancedRecordset.php An example of using the enhancedRecordset class
    */
  	class enhancedRecordset extends enhancedBase {

        /**
        * List form name member
        *
        * This is the name of the form that contains the master list/menu.
        * @var string
        */
        var $list_form_name = "";
        /**
        * List field name member
        *
        * This is the name of the master list/menu field.
        * @var string
        */
        var $list_field_name = "";
        /**
        * Hidden form name member
        *
        * This is the name of the form that contains the hidden fields.
        * @var string
        */
        var $hidden_form_name = "";
        /**
        * Hidden field name member
        *
        * This is the prefix used for the hidden field needed to store on client the
        * recordset data.
        * @var string
        */
        var $hidden_field_name = "";
        /**
        * Changed hidden field name member
        *
        * This is the name of the hidden field used to identify if the user has made a changhe
        * on the recordset.
        * @var string
        */
        var $hidden_changed_field_name = "";
        /**
        * Fields form name member
        *
        * This is the name of form that contains the field used to show the recordset data.
        * @var string
        */
        var $fields_form_name = "";

        /**
        * Fields names member
        *
        * This is an array that contains the list of the fields names.
        * @var array
        */
        var $fields_names = array ();
        /**
        * Recordset member
        *
        * This member will contain the recordset data. It's an array of recordsetRow objects, to
        * add a new record use the {@link enhancedRecordset::addRecordsetRow() enhancedRecordset::addRecordsetRow()}  method, an example follows:
        *
        * <code>
        *$record = new recordsetRow ();
        *$record->value = "1";
        *$record->text = "Setec Astronomy Biography";
        *$record->details = array ("name" => "Setec", "surname" => "Astronomy", "nation" => "Italy");
        *$enhancedRecordset->addRecordsetRow ($record);
        * </code>
        *
        * @var array
        * @see enhancedRecordset::addRecordsetRow()
        * @see recordsetRow
        */
        var $recordset = array ();

        /**
        * updateUI function name member
        *
        * This is the name of the function updateUI. This member is usefull if you have to use
        * JS on the client side and don't want to change other predefined functions.
        *
        * @var string
        */
        var $function_updateUI = "";
        /**
        * updateData function name member
        *
        * This is the name of the function updateData. This member is usefull if you have to use
        * JS on the client side and don't want to change other predefined functions.
        *
        * @var string
        */
        var $function_updateData = "";

        /**
        * Default constructor
        *
        * This is the default constructor enhancedRecordset class.
        */
        function enhancedRecordset () {

	        parent::enhancedBase ();

            $this->list_form_name = "";
            $this->list_field_name = "";
            $this->hidden_form_name = "";
            $this->hidden_field_name = "hidden";
            $this->hidden_changed_field_name = "hidden_changed";
            $this->fields_form_name = "";

            $this->fields_names = array ();
            $this->recordset = array ();

            $this->function_updateUI = "updateUI";
            $this->function_updateData = "updateData";

		} // function enhancedRecordset () {

        /**
        * The getJS method
        *
        * This method overwrites the base class getJS methods. It returns the JS code
        * needed for the client side scripting.
        * @param boolean $JSTag if true it includes the script tag container
        * @return string the JS code with standard functions
        * @see enhancedBase::getJS()
        */
		function getJS ($JSTag = false) {

			ob_start ();
			if ($JSTag) {
?>
<script language="JavaScript" type="text/JavaScript">
<!--
<?php
			} // if ($JSTag) {
?>
function <?php print ($this->function_updateUI); ?> (list_form_name, list_field_name, hidden_form_name, hidden_field_name, fields_form_name) {
	if (arguments.length >= 5) {
		if ((document.forms[list_form_name] != undefined) &&
			(document.forms[list_form_name].elements[list_field_name] != undefined) &&
			(document.forms[list_form_name].elements[list_field_name].options.selectedIndex >= 0)) 	{

			var elements = new Array (arguments.length - 5);
			for (i=5; i<arguments.length; i++) {
				elements[i-5] = arguments[i];
			}

			var hidden_name = "";
			for (i=0; i<elements.length; i++) {
				hidden_name = hidden_field_name + "[" +  fields_form_name + "][" +  list_field_name + "][" + document.forms[list_form_name].elements[list_field_name].value + "]["  + elements[i] + "]";
				if ((document.forms[fields_form_name] != undefined) &&
					(document.forms[fields_form_name].elements[elements[i]] != undefined) &&
					(document.forms[hidden_form_name] != undefined)  &&
					(document.forms[hidden_form_name].elements[hidden_name] != undefined)) {
					document.forms[fields_form_name].elements[elements[i]].value = document.forms[hidden_form_name].elements[hidden_name].value;
				}
			}
		}
	}
	return (false);
 }

function <?php print ($this->function_updateData); ?> (fields_form_name, input_field_name, list_form_name, list_field_name, hidden_form_name,  hidden_field_name, hidden_changed_field_name) {
	if ((document.forms[fields_form_name] != undefined) &&
		(document.forms[fields_form_name].elements[input_field_name] != undefined) &&
		(document.forms[list_form_name] != undefined) &&
		(document.forms[list_form_name].elements[list_field_name] != undefined) &&
		(document.forms[hidden_form_name] != undefined) &&
		(document.forms[hidden_form_name].elements[hidden_changed_field_name] != undefined)) {
			var hidden_name = hidden_field_name + "[" +  fields_form_name + "][" +  list_field_name + "][" + document.forms[list_form_name].elements[list_field_name].value + "][" + input_field_name + "]";
			if (document.forms[hidden_form_name].elements[hidden_name] != undefined) {
				document.forms[hidden_form_name].elements[hidden_name].value = document.forms[fields_form_name].elements[input_field_name].value;
				document.forms[hidden_form_name].elements[hidden_changed_field_name].value = 1;
			}
	}
	return (false);
}
<?php
            if ($JSTag) {
?>
//-->
</script>
<?php
			} // if ($JSTag) {
			$return = ob_get_contents ();
			ob_end_clean ();
			return $return;
		} // function getJS ($JSTag = false) {

        /**
        * The getInitializationJS method
        *
        * This method overwrites the base class getInitializationJS methods.
        * It returns the JS code needed for the client UI initialization.
        * @param boolean $JSTag if true it includes the script tag container
        * @return string the JS code with standard functions
        * @see enhancedBase::getInitializationJS()
        */
		function getInitializationJS ($JSTag = false) {

			ob_start ();
			if ($JSTag) {
?>
<script language="JavaScript" type="text/JavaScript">
<!--
<?php
			} // if ($JSTag) {

			print ($this->function_updateUI . " ('" . $this->list_form_name . "', '" . $this->list_field_name . "', '" .
				   $this->hidden_form_name . "', '" . $this->hidden_field_name . "', '" . $this->fields_form_name . "', '" .
				   implode ("', '", $this->fields_names) . "');");

			if ($JSTag) {
?>
//-->
</script>
<?php
			} // if ($JSTag) {
			$return = ob_get_contents ();
			ob_end_clean ();
			return $return;
		} // function getInitializationJS ($JSTag = false) {

        /**
        * The getHiddenFields method
        *
        ** This method overwrites the base class getHiddenFields methods.
        * It returns the HTML code needed to store the changes on the recordset on the client
        * side.
        * @return string the HTML code with the hidden fields containing the recordset
        * @see enhancedBase::getHiddenFields()
        */
		function getHiddenFields () {

			ob_start ();

		  	print ("<input type='hidden' name='" . $this->hidden_changed_field_name . "' id='" . $this->hidden_changed_field_name . "' value='0'/>\n");
			foreach ($this->recordset as $record) {
                if (is_a ($record, "recordsetRow")) {
				    foreach ($record->details as $field_name => $field_value) {
					    $field = $this->hidden_field_name . "[" . $this->fields_form_name . "][" . $this->list_field_name . "][" . $record->value . "][" . $field_name . "]";
	  				    print ("<input type='hidden' name='" . $field . "' id='" . $field . "' value='" . $field_value . "'/>\n");
				    }
                }
			}
			
			$return = ob_get_contents ();	
			ob_end_clean ();
			return $return;
		} // function getHiddenFields () {

        /**
        * The getListOnChange method
        *
        * This method returns the JS code that updates the details fields with the data
        * saved in the recordset (hidden fields).
        * @return string the JS code to be insert in the JS OnChange method of the select tag.
        */
		function getListOnChange () {
			return $this->function_updateUI . " ('" . $this->list_form_name . "', '" . $this->list_field_name . "', '" .
	  			   $this->hidden_form_name . "', '" . $this->hidden_field_name . "', '" . $this->fields_form_name . "', '" .
				   implode ("', '", $this->fields_names) . "')";
		} // function getListOnChange () {

        /**
        * The getFieldOnChange method
        *
        * This method returns the JS code that updates the recordset data edited by the user.
        * @param string $field_name the field name which value is to be updated
        * @return string the JS code to be insert in the JS OnChange method of the input/textarea tag.
        */
		function getFieldOnChange ($field_name = "") {

			return $this->function_updateData . " ('" . $this->fields_form_name . "', '" . $field_name . "', '" .
	  			   $this->list_form_name . "', '" . $this->list_field_name . "', '" . $this->hidden_form_name . "', '" .
				   $this->hidden_field_name . "','" . $this->hidden_changed_field_name . "')";

		} // function getFieldOnChange ($field_name = "") {

        /**
        * The addRecordsetRow method
        *
        * This method add a record to the {@link enhancedRecordset::$recordset enhancedRecordset::$recordset}
        * @param recordsetRow $record the record to be added to the recordset
        * @return boolean it returns true if the push is completed succesfully otherwise returns false
        * @see enhancedRecordset::$recordset
        * @see recordsetRow
        */
		function addRecordsetRow ($record) {

			if (is_a ($record, "recordsetRow")) {
				array_push ($this->recordset, $record);
				return true;
			} else {
				return false;
			}

		} // function addRecord ($record) {

	} // class enhancedRecordset extends enhancedBase {
?>