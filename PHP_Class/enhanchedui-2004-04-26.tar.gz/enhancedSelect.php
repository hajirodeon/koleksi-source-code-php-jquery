<?php
	/**
	* This file contains the enhancedSelect class that allows to display two or
	* more lists/menus linked via a master/detail relation, this class is a subclass of the
	* enhancedBase class.
	* @package enhancedUI
	*/

	require_once (dirname (__FILE__)."/enhancedBase.php");

    /**
    * enhancedSelect class
    *
    * This class allows to dynamically link two list/menu and update the detail list/menu starting from
	* the selected item in the master list/menu
    *
    * @package enhancedUI
    * @author Setec Astronomy
    * @version 1.0
    * @abstract Dynamically update a details list/menu from a master list/menu
    * @copyright 2004
    * @example ../examples/enhancedSelect.php An example of using the enhancedSelect class
	*/
    class enhancedSelect extends enhancedBase {


        /**
        * $master_form_name member
        *
        * This is the name of the master list/menu form.
        * @var string
        */
        var $master_form_name = "";
        /**
        * $master_field_name member
        *
        * This is the name of the master list/menu field.
        * @var string
        */
        var $master_field_name = "";
        /**
        * $detail_form_name member
        *
        * This is the name of the detail list/menu form.
        * @var string
        */
        var $detail_form_name = "";
        /**
        * $detail_field_name member
        *
        * This is the name of the detail list/menu field.
        * @var string
        */
        var $detail_field_name = "";
        /**
        * values member
        *
        * This is an array that contains the master and details list/menu values.
		* To add a new item use the {@link enhancedRecordset::addSelectItem() enhancedRecordset::addSelectItem()}  method.
        * @var array
        */
        var $values = array ();

        /**
        * updateSelect function name member
        *
        * This is the name of the function updateSelect. This member is usefull if you have to use
        * JS on the client side and don't want to change other predefined functions.
        *
        * @var string
        */
        var $function_updateSelect = "";

        /**
        * variable_values JS variable name member
        *
        * This is the name of the JS array "values". This member is usefull if you have to use
        * JS on the client side and don't want to change other variabiles.
        *
        * @var string
        */
        var $variable_values = "";

        /**
        * Default constructor
        *
        * This is the default constructor enhancedSelect class.
        */
        function enhancedSelect () {

            $this->function_updateSelect = "updateSelect";
            $this->variable_values = "values";
        }

        /**
        * The getJS method
        *
        * This method overwrites the base class getJS methods. It returns the JS code
        * needed for the client side scripting.
        * @param boolean $JSTag if true it includes the script tag container
        * @return string the JS code with standard functions
        * @see enhancedBase::getJS()
        */
        function getJS ($JSTag = false) {

            ob_start ();
            if ($JSTag) {
?>
<script language="JavaScript" type="text/JavaScript">
<!--
<?php
            } // if ($JSTag) {
?>
function <?php print ($this->function_updateSelect); ?> (master_form_name, master_field_name, detail_form_name, detail_field_name, values) {
	if ((document.forms[master_form_name] != undefined) &&
	(document.forms[master_form_name].elements[master_field_name] != undefined) &&
	(document.forms[detail_form_name] != undefined) &&
	(document.forms[detail_form_name].elements[detail_field_name] != undefined) &&
	(values != undefined) && (values.length != undefined)) {
		for (var i = 0; i<values.length; i++) {
			var key = values[i][0];
			if (key == document.forms[master_form_name].elements[master_field_name].value) {
				document.forms[detail_form_name].elements[detail_field_name].options.length = values[i][2][0].length;
				for (var j = 0; j<values[i][2][0].length; j++) {
					document.forms[detail_form_name].elements[detail_field_name].options[j].value = values[i][2][0][j]; 
					document.forms[detail_form_name].elements[detail_field_name].options[j].text = values[i][2][1][j]; 
				}
				break;	
			}
		}
	}
	return false;
}
<?php
            if ($JSTag) {
?>
//-->
</script>
<?php
            } // if ($JSTag) {
            $return = ob_get_contents ();
            ob_end_clean ();
            return $return;
        } // function getJS ($JSTag = false) {

        /**
        * The getInitializationJS method
        *
        * This method overwrites the base class getInitializationJS methods.
        * It returns the JS code needed for the client UI initialization.
        * @param boolean $JSTag if true it includes the script tag container
        * @return string the JS code with standard functions
        * @see enhancedBase::getInitializationJS()
        */
        function getInitializationJS ($JSTag = false) {

            ob_start ();
            if ($JSTag) {
?>
<script language="JavaScript" type="text/JavaScript">
<!--
<?php
            } // if ($JSTag) {

            $join_1 = "";   
            print ("var " . $this->variable_values . " = new Array (\n" );
            foreach ($this->values as $value) {
                if (isset ($value["value"]) && isset ($value["text"]) &&
                    isset ($value["details"]) && is_array ($value["details"])) {
                    print ("\t" . $join_1 . " new Array (\n");
                    print ("\t '" . addslashes ($value["value"]) . "', \n");
                    print ("\t '" . addslashes ($value["text"]) . "', \n");
                    print ("\t new Array (\n");
                    print ("\t\t new Array (");
                    $join_2 = "";
                    foreach ($value["details"] as $detail_value => $detail_text) {
                        print ($join_2 . "'" . $detail_value . "'");
                        $join_2 = ", ";
                    }
                    print ("),\n");
                    print ("\t\t new Array (");
                    $join_2 = "";
                    foreach ($value["details"] as $detail_value => $detail_text) {
                        print ($join_2 . "'" . $detail_text . "'");
                        $join_2 = ", ";
                    }
                    print (")\n");
                    print ("\t )\n");
                    print ("\t )\n");
                    $join_1 = ",";
                }
            }
            print ("    );\n" );
		
            if ($JSTag) {
?>
//-->
</script>
<?php
            } // if ($JSTag) {
            $return = ob_get_contents ();
            ob_end_clean ();
            return $return;
        } // function getInitializationJS ($JSTag = false) {

        /**
        * The addSelectItem method
        *
        * This method add a value to the {@link enhancedSelect::$values enhancedSelect::$values}.
		* The $value must follows the seguent structure	
		*<code>
		*$value = array ("value" => "1",
		*				 "text" => "OS",
		*				 "details" => array ("1" => "FreeBSD",
		*                                     "2" => "Windows",
		*									 "3" => "Linux",
		*									 "4" => "Solaris")
		*				)
		*</code> 
        * @param array $value the value to be added to the values array
        * @return boolean it returns true if the push is completed succesfully otherwise returns false
        * @see enhancedSelect::$values
        */
		function addSelectItem ($value) {
			if (is_array ($value) && isset ($value["value"]) && isset ($value["text"]) &&
				isset ($value["details"]) && is_array ($value["details"])) {
				array_push ($this->values, $value);
				return true;
			} else {
				return false;
			}
		}
        /**
        * The updateSelect method
        *
        * This method returns the JS code to show an hidden sheet and authomatically hide the previous one.
        * @return string the JS code ready to be executed
        */
        function updateSelect () {
            return $this->function_updateSelect . " ('" . $this->master_form_name . "', '" . $this->master_field_name . "', '" .
                   $this->detail_form_name . "', '" . $this->detail_field_name . "', " . $this->variable_values . ")";
        }

    } // class enhancedSelect extends enhancedBase {
?>