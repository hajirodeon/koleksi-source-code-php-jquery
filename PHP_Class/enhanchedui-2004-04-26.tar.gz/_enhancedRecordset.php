<?php
	/**
	* enhancedRecordset Example 
	*
	* This example shows how to use the class enhancedRecordset to edit on the client side a recordset of data and, 
	* whe finished, how to send it to the server (a simple form submit).
	*
	* @package enhancedUI
    * @subpackage examples
    * @example enhancedRecordset.php This file source code
	*/

	require_once (dirname (__FILE__)."/enhancedUI.php");

	$enhancedRecordset = new enhancedRecordset ();

	$enhancedRecordset->list_form_name = "list_form";
	$enhancedRecordset->list_field_name = "list";
	$enhancedRecordset->hidden_form_name = "list_form";
	$enhancedRecordset->hidden_field_name = "hidden";
	$enhancedRecordset->hidden_changed_field_name = "hidden_changed";
	$enhancedRecordset->fields_form_name = "list_form";

	$enhancedRecordset->fields_names = array ("url", "structure", "description", "group");
		  
	$recordset = new recordsetRow ();
	$recordset->value = "1";
	$recordset->text = "unlink";
	$recordset->details = array ("url" => "http://www.php.net/unlink", 
								 "structure" => "bool unlink ( string filename )", 
								 "description" => "Deletes a file (PHP 3, PHP 4)", 
								 "group" => "Filesystem functions");
	$enhancedRecordset->addRecordsetRow ($recordset);

	$recordset = new recordsetRow ();
	$recordset->value = "2"; 
	$recordset->text = "addslashes";
	$recordset->details = array ("url" => "http://www.php.net/addslashes", 
								 "structure" => "string addslashes ( string str )", 
								 "description" => "Quote string with slashes (PHP 3, PHP 4)", 
								 "group" => "String functions");
	$enhancedRecordset->addRecordsetRow ($recordset);

	$recordset = new recordsetRow ();
	$recordset->value = "3"; 
	$recordset->text = "array_pop";
	$recordset->details = array ("url" => "http://www.php.net/array_pop", 
								 "structure" => "mixed array_pop ( array array )", 
								 "description" => "Pop the element off the end of array (PHP 4)", 
								 "group" => "Array Functions");
	$enhancedRecordset->addRecordsetRow ($recordset);

	$recordset = new recordsetRow ();
	$recordset->value = "4"; 
	$recordset->text = "call_user_func";
	$recordset->details = array ("url" => "http://www.php.net/call_user_func", 
								 "structure" => "mixed call_user_func ( callback function [, mixed parameter [, mixed ...]] )", 
								 "description" => "Call a user function given by the first parameter (PHP 3>= 3.0.3, PHP 4)", 
								 "group" => "Function Handling functions");
	$enhancedRecordset->addRecordsetRow ($recordset);

	$recordset = new recordsetRow ();
	$recordset->value = "5"; 
	$recordset->text = "define";
	$recordset->details = array ("url" => "http://www.php.net/define", 
								 "structure" => "bool define ( string name, mixed value [, bool case_insensitive] )", 
								 "description" => "Defines a named constant. (PHP 3, PHP 4)", 
								 "group" => "Miscellaneous functions");
	$enhancedRecordset->addRecordsetRow ($recordset);

	$enhancedRecordset->function_updateUI = "updateUI";
	$enhancedRecordset->function_updateData = "updateData";
	
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>enhancedRecordset Example</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<?php print ($enhancedRecordset->getJS (true)); ?> 
</head>
<body>
<form action="<?php print ($_SERVER['PHP_SELF']); ?>" method="post" name="list_form">
  <table border="0" cellspacing="0" cellpadding="2">
    <tr> 
      <td rowspan="4" align="left" valign="top"><select name="list" size="5" onChange="<?php print ($enhancedRecordset->getListOnChange ()); ?>">
          <option value="1" selected="true">unlink</option>
          <option value="2">addslashes</option>
          <option value="3">array_pop</option>
          <option value="4">call_user_func</option>
          <option value="5">define</option>
        </select></td>
      <td align="left" valign="top">Manual URL:</td>
      <td align="left" valign="top"><input type="text" name="url" size="50" onChange="<?php print ($enhancedRecordset->getFieldOnChange ("url")); ?>" /></td>
    </tr>
    <tr> 
      <td align="left" valign="top">Structure:</td>
      <td align="left" valign="top"><input type="text" name="structure" size="50" onChange="<?php print ($enhancedRecordset->getFieldOnChange ("structure")); ?>" /></td>
    </tr>
    <tr> 
      <td align="left" valign="top">Description:</td>
      <td align="left" valign="top"><input type="text" name="description" size="50" onChange="<?php print ($enhancedRecordset->getFieldOnChange ("description")); ?>" /></td>
    </tr>
    <tr> 
      <td align="left" valign="top">Group:</td>
      <td align="left" valign="top"><input type="text" name="group" size="50" onChange="<?php print ($enhancedRecordset->getFieldOnChange ("group")); ?>" /></td>
    </tr>
    <tr align="center"> 
      <td colspan="3" valign="top"> <?php print ($enhancedRecordset->getHiddenFields ()); ?> 
        <input name="btnSave" type="submit" value="Save" /> </td>
    </tr>
  </table>
</form>
<?php print ($enhancedRecordset->getInitializationJS (true)); ?>
<pre>
POST Array follows:
<?php 
print_r ($_POST);
?>
</pre>
</body>
</html>