<?php
    /**
    * This file includes all the other classes of the enhancedUI hierarchy.
    * Its target is to have an unique file te be included for using the whole hierarchy.
    * @package enhancedUI
    */

    require_once (dirname (__FILE__)."/enhancedBase.php");
    require_once (dirname (__FILE__)."/enhancedTab.php");
    require_once (dirname (__FILE__)."/enhancedMoving.php");
    require_once (dirname (__FILE__)."/enhancedSelect.php");
    require_once (dirname (__FILE__)."/enhancedRecordset.php");

?>