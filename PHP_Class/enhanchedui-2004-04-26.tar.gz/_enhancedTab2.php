<?php
	/**
	* enhancedTab Example 2
	*
	* This example shows how to use the enhancedTab class and its method {@link enhancedTab::getUpdateListTab enhancedTab::getUpdateListTab}
	* to have a TabSheet behaviour on the client side.
	*
    * @package enhancedUI
    * @subpackage examples
    * @example enhancedTab2.php This file source code
    */


	require_once (dirname (__FILE__)."/enhancedUI.php");

	$enhancedTab = new enhancedTab ();
	$enhancedTab->default_sheet = "main";

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>enhancedTab Example 2</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<?php print ($enhancedTab->getJS (true)); ?> 
<style type="text/css">
<!--
.menuList {
	font-size: xx-small;
}
-->
</style>
</head>
<body>
<table border="0" cellspacing="0" cellpadding="5" width="500">
  <tr> 
    <td width="100" align="left" valign="top"><form name="list_form" method="post" action="">
        <select name="list" size="4" onChange="<?php print ($enhancedTab->getUpdateListTab ("list_form", "list")); ?>" class="menuList">
          <option value="main" selected="true">Main</option>
          <option value="options">Options</option>
          <option value="system_preferences">System preferences</option>
          <option value="status">Status</option>
        </select>
      </form></td>
    <td width="400" align="left" valign="top"><?php print ($enhancedTab->getOpenSheet ("main", "div", true)); ?> 
      <h3>Main</h3>
      <p>This is the main sheet, here you can put whatever you want!</p>
      <?php print ($enhancedTab->getCloseSheet ()); ?> <?php print ($enhancedTab->getOpenSheet ("options", "div", false)); ?> 
      <h3>Options</h3>
      <p>This is the options sheet, here you can put whatever you want!</p>
      <?php print ($enhancedTab->getCloseSheet ()); ?> <?php print ($enhancedTab->getOpenSheet ("system_preferences", "div", false)); ?> 
      <h3>System preferences</h3>
      <p>This is the system preferences sheet, here you can put whatever you want!</p>
      <?php print ($enhancedTab->getCloseSheet ()); ?> <?php print ($enhancedTab->getOpenSheet ("status", "div", false)); ?> 
      <h3>Status</h3>
      <p>This is the status sheet, here you can put whatever you want!</p>
      <?php print ($enhancedTab->getCloseSheet ()); ?> </td>
  </tr>
</table>
<?php print ($enhancedTab->getHiddenForm ()); ?>
<?php print ($enhancedTab->getInitializationJS (true)); ?>
</body>
</html>