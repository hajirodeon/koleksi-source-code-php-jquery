<?php
    /**
    * This file contains the enhancedBase class, that base class for
    * the enhancedUI hierarchy.
    * @package enhancedUI
    */

    /**
    * enhancedBase class
    *
    * This class is the abstract super class of the enhancedUI hierarchy.
    * It defines some standard methods that will be overwritten in the
    * children classes.
    * @package enhancedUI
    * @author Setec Astronomy
    * @version 1.0
    * @abstract Base class for the enhancedUI hierarchy.
    * @copyright 2004
    */
	class enhancedBase {

        /**
        * Default constructor
        */
		function enhancedBase () {
		}

        /**
        * Default getJS implementation
        *
        * This method must be overwritten, its default implementation will
        * ever die. In this method insert the JS functions code needed to execute
        * the client side scriptin.
        * @param boolean $JSTag if true it includes the script tag container
        */
		function getJS ($JSTag = false) {
			die ("The getJS method must be overwritten!");
		}

        /**
        * Default getInitializationJS implementation
        *
        * This method must be overwritten, its default implementation will
        * ever die. In this method insert the JS code for initialize the client UI.
        * @param boolean $JSTag if true it includes the script tag container
        */
		function getInitializationJS ($JSTag = false) {
			die ("The getInitializationJS method must be overwritten!");
		}

        /**
        * Default getHiddenFields implementation
        *
        * This method must be overwritten, its default implementation will
        * ever die. This method will return the HTML with hidden form fields
        * used to store needed data for client side scripting.
        */
		function getHiddenFields () {
			die ("The getHiddenFields method must be overwritten!");
		}

	} 
	 
?>