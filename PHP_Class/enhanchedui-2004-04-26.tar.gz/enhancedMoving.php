<?php
    /**
    * This file contains the enhancedMoving class that allows to move items on
    * client side between two or more lists, this class is a subclass of the
    * enhancedBase class.
    * @package enhancedUI
    */

    require_once (dirname (__FILE__)."/enhancedBase.php");


    /**
    * enhancedMoving class
    *
    * This class allows to display two or more lists/menus and to move items from to them
    * directly on the client side (uses JS). This class is a part of the enhancedUI hierarchy.
    *
    * @package enhancedUI
    * @author Setec Astronomy
    * @version 1.0
    * @abstract Move items between lists/menus on the client side
    * @copyright 2004
    * @example ../examples/enhancedMoving.php An example of using the enhancedMoving class
    */
    class enhancedMoving extends enhancedBase {

        /**
        * moveItems function name member
        *
        * This is the name of the function moveItems. This member is usefull if you have to use
        * JS on the client side and don't want to change other predefined functions.
        *
        * @var string
        */
        var $function_moveItems = "";
		
        /**
        * selectAll function name member
        *
        * This is the name of the function selectAll. This member is usefull if you have to use
        * JS on the client side and don't want to change other predefined functions.
        *
        * @var string
        */
		var $function_selectAll = "";

        /**
        * Default constructor
        *
        * This is the default constructor enhancedMoving class.
        */
        function enhancedMoving () {
            $this->function_moveItems = "moveItems";
            $this->function_selectAll = "selectAll";
        }

        /**
        * The getJS method
        *
        * This method overwrites the base class getJS methods. It returns the JS code
        * needed for the client side scripting.
        * @param boolean $JSTag if true it includes the script tag container
        * @return string the JS code with standard functions
        * @see enhancedBase::getJS()
        */
        function getJS ($JSTag = false) {
            ob_start ();
            if ($JSTag) {
?>
<script language="JavaScript" type="text/JavaScript">
<!--
<?php
                        } // if ($JSTag) {
?>
function <?php print ($this->function_moveItems); ?> (fromForm, fromItem, toForm, toItem, advice)
{
	var fItem = fromItem +"[]";
	var tItem = toItem +"[]";
	
	if ((document.forms[fromForm] != undefined) &&
		(document.forms[fromForm].elements[fItem] != undefined) &&
		(document.forms[toForm] != undefined) &&
		(document.forms[toForm].elements[tItem] != undefined) &&
		(document.forms[fromForm].elements[fItem].options.selectedIndex >= 0)) {
		
		while (document.forms[fromForm].elements[fItem].options.selectedIndex >= 0) {
			ind = document.forms[fromForm].elements[fItem].options.selectedIndex;
			
			text  = document.forms[fromForm].elements[fItem].options[ind].text;
			value = document.forms[fromForm].elements[fItem].options[ind].value;
			
			document.forms[fromForm].elements[fItem].options[ind] = null;
			
			var newOption = new Option(text, value);
			toFormLength = document.forms[toForm].elements[tItem].options.length;
			document.forms[toForm].elements[tItem].options[toFormLength] = newOption;
		}
	} else {
		if ((advice != undefined) && (advice != "")) {
			alert (advice);
		}
	}
	return (false);
}

function <?php print ($this->function_selectAll); ?> (form_name) {
	for (var i = 1; i < arguments.length; i++) {      
		if ((document.forms[form_name] != undefined) &&
			(document.forms[form_name].elements[arguments[i]] != undefined) &&
			(document.forms[form_name].elements[arguments[i]].options != undefined)) {
			for (var j = 0; j < document.forms[form_name].elements[arguments[i]].options.length; j++) {
				document.forms[form_name].elements[arguments[i]].options[j].selected = true;
			}      
		}
	}
	return true;
}
<?php
            if ($JSTag) {
?>
//-->
</script>
<?php
            } // if ($JSTag) {
            $return = ob_get_contents ();
            ob_end_clean ();
            return $return;
        } // function getJS ($JSTag = false) {

        /**
        * The getJSMoveItem method
        *
        * This method returns the JS code that can be used with the OnClick method (or whatever you prefer) to move
        * the selected items froma a list/menu to another.
        * <code>
        *<input onClick="<?php $enanachedMoving->getJSMoveItem ("left_form", "left_list", "right_form", "right_list", "Please select one or more items from the left side list!"); ?>" type="button" value="&gt;&gt;" />
        *<input onClick="<?php $enanachedMoving->getJSMoveItem ("right_form", "right_list", "left_form", "left_list", "Please select one or more items from the right side list!"); ?>" type="button" value="&lt;&lt;" />
        * </code>
        * @param string $from_form_name the list/menu name from which move the items.
        * @param string $from_list_name the form name that contains the source list/menu.
        * @param string $to_form_name the form name that contains the destination list/menu.
        * @param string $to_list_name the list/menu name to which the items have to be moved.
        * @param string $error_msg the error message to be displaied if no items is selected, leave blank if no message is needed.
        * @return string the JS code to be insert in the chousen JS method.
        */
        function getJSMoveItem ($from_form_name, $from_list_name, $to_form_name, $to_list_name, $error_msg = "") {
            $error_msg = addslashes ($error_msg);
            return "return " . $this->function_moveItems . "('" . $from_form_name . "', '" . $from_list_name . "', '" . $to_form_name . "', '" . $to_list_name . "', '" . $error_msg . "')";
        }

        /**
        * The getOnSubmit method
        *
        * This method returns the JS code that can be used with the OnClick method (or whatever you prefer) to move
        * the selected items froma a list/menu to another.
        * <code>
		*<form name="moving_form" action="..." method="post" onSubmit="<?php print ($enhancedMoving->getOnSubmit ('moving_form', array ("todo_list[]", "done_list[]"))); ?>; return true">
        * </code>
        * @param string $form_name the name of the form containing the list/menu fields to be selected.
        * @param array $list_fields an array containing a list of all list/menu fields to be selected before the form submit
        * @return string the JS code to be insert in the OnSubmit JS method.
        */
        function getOnSubmit ($form_name, $list_fields) {
            return $this->function_selectAll . "('" . $form_name . "', '" . implode ("', '", $list_fields) . "');";
        }

    } // class enhancedMoving extends enhancedBase {
?>