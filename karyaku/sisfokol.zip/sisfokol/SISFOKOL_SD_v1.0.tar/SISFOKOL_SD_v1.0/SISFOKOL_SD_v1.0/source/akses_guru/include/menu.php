<?php
//Sistem Informasi ini berbasis OPEN SOURCE dengan lisensi GNU/GPL. 
//
//OPEN SOURCE HAJIROBE dengan segala hormat tidak bertanggung jawab dan tidak memiliki pertanggungjawaban
//kepada apapun atau siapa pun akibat terjadinya kehilangan atau kerusakan yang mungkin muncul yang berasal
//dari buah karya ini.
//
//Sistem Informasi ini akan selalu dikembangkan dan jika ditemukan kesalahan logika ataupun kesalahan program,
//hal ini bukanlah disengaja. Melainkan hal tersebut adalah salah satu dari tahapan pengembangan lebih lanjut. 

//Sistem Informasi Sekolah (SISFOKOL) untuk SD v1.0, dikembangkan oleh OPEN SOURCE HAJIROBE (Agus Muhajir).
//Dan didistribusikan oleh BIASAWAE PRODUCTION (http://www.biasawae.com)
//
//Bila Anda mempunyai pertanyaan, komentar, saran maupun kritik layangkan saja ke hajirodeon@yahoo.com .
//Semoga program ini berguna bagi Anda.
//
//Ikutilah perkembangan terbaru Sistem Informasi ini di BIASAWAE PRODUCTION.
?><table width="990" border="0" cellspacing="0" cellpadding="2">
  <tr>
    <td><a href="index.php">Halaman Depan</a> | <a href="password.php">Ganti Password</a> 
      | <a href="jadwal_mengajar.php">Jadwal Mengajar</a> | <a href="soal_essay.php">Soal 
      Essay</a> | <a href="soal_pil.php">Soal Pilihan Ganda</a> | <a href="nilai.php">Daftar 
      Nilai</a> | <a href="../logout.php">KELUAR</a></td>
  </tr>
</table>