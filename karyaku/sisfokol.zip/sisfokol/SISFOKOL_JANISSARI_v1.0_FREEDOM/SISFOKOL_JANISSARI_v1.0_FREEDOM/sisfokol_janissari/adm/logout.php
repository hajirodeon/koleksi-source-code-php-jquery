<?php
///////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////
/////// SISFOKOL JANISSARI v1.0                     ///////
/////// (E-Learning untuk Sekolah)                  ///////
///////////////////////////////////////////////////////////
/////// Dibuat oleh :                               ///////
/////// Agus Muhajir, S.Kom                         ///////
/////// URL     : http://sisfokol.wordpress.com     ///////
/////// E-Mail  :                                   ///////					
///////     * hajirodeon@yahoo.com                  ///////
///////     * hajirodeon@gmail.com                  ///////
/////// HP/SMS  : 081-829-88-54                     ///////
///////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////


session_start();

//ambil nilai
require("../inc/config.php"); 
require("../inc/fungsi.php"); 

nocache;

//hapus session
session_unset($hajirobe_session);
session_unset($kd3_session);
session_unset($adm_session);
session_unset($username3_session);
session_unset($pass3_session);

session_unregister('$hajirobe_session');
session_unregister('$kd3_session');
session_unregister('$adm_session');
session_unregister('$username3_session');
session_unregister('$pass3_session');

session_unset();
session_destroy();

//re-direct
xloc($sumber);
exit();
?>