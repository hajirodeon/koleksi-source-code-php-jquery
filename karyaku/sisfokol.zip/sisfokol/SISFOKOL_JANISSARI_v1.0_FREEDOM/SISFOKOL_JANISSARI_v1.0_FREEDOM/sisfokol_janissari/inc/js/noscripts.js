<noscript>
Halaman ini mengandung menu berbasis JavaScript, 
tapi Browser Anda tidak mendukung JavaScript. 
Silahkan diaktifkan atau gunakan Browser terbaru. [BIASAWAE] 
</noscript>