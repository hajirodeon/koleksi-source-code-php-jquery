<SCRIPT LANGUAGE="JavaScript">
<!-- Begin
///////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////
/////// SISFOKOL JANISSARI v1.0                     ///////
/////// (E-Learning untuk Sekolah)                  ///////
///////////////////////////////////////////////////////////
/////// Dibuat oleh :                               ///////
/////// Agus Muhajir, S.Kom                         ///////
/////// URL     : http://sisfokol.wordpress.com     ///////
/////// E-Mail  :                                   ///////					
///////     * hajirodeon@yahoo.com                  ///////
///////     * hajirodeon@gmail.com                  ///////
/////// HP/SMS  : 081-829-88-54                     ///////
///////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////







function checkAll(x) 
	{
	for (var j = 1; j <= x; j++) 
		{
		box = eval("document.formx.item" + j); 
		if (box.checked == false) box.checked = true;
		}
	}

function uncheckAll(x) 
	{
	for (var j = 1; j <= x; j++) 
		{
		box = eval("document.formx.item" + j); 
		if (box.checked == true) box.checked = false;
	   }
	}


//  End -->
</script>