// UK lang variables

kampungan.addToLang('',{
iespell_desc : 'Run spell checking',
iespell_download : "ieSpell not detected. Click OK to go to download page."
});

