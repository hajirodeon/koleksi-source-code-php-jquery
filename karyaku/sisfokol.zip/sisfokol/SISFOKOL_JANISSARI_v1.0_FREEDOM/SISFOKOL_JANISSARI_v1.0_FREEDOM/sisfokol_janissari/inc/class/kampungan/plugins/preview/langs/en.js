// UK lang variables

kampungan.addToLang('',{
preview_desc : 'Preview'
});
