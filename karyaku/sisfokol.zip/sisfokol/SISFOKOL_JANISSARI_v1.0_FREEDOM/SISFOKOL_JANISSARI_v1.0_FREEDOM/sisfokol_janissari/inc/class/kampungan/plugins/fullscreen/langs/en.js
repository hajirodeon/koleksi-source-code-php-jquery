// UK lang variables

kampungan.addToLang('',{
fullscreen_title : 'Fullscreen mode',
fullscreen_desc : 'Toggle fullscreen mode'
});
