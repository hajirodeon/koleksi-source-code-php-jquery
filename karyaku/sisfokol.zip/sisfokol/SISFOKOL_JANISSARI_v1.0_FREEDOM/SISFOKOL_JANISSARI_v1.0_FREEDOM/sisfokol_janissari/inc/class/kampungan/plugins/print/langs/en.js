// UK lang variables

kampungan.addToLang('',{
print_desc : 'Print'
});
