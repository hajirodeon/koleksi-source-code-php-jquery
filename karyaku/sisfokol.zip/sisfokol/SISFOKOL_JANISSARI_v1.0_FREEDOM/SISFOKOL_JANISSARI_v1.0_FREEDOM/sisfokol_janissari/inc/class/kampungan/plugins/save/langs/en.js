// UK lang variables

kampungan.addToLang('',{
save_desc : 'Save'
});
