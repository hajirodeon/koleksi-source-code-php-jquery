<?php
///////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////
/////// SISFOKOL JANISSARI v1.0                     ///////
/////// (E-Learning untuk Sekolah)                  ///////
///////////////////////////////////////////////////////////
/////// Dibuat oleh :                               ///////
/////// Agus Muhajir, S.Kom                         ///////
/////// URL     : http://sisfokol.wordpress.com     ///////
/////// E-Mail  :                                   ///////					
///////     * hajirodeon@yahoo.com                  ///////
///////     * hajirodeon@gmail.com                  ///////
/////// HP/SMS  : 081-829-88-54                     ///////
///////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////



//ambil nilai
require("inc/config.php"); 
require("inc/fungsi.php"); 
require("inc/koneksi.php"); 
$tpl = LoadTpl("template/login.html"); 


nocache;

//nilai
$filenya = "login.php";
$judul = "SISFOKOL_JANISSARI_v1.0_FREEDOM***";
$diload = "document.formx.tipe.focus();";
$pesan = "PASSWORD SALAH. HARAP DIULANGI...!!!";


//PROSES ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
if ($HTTP_POST_VARS['btnOK'])
	{
	//ambil nilai
	$tipe = nosql($_POST["tipe"]);
	$username = nosql($_POST["usernamex"]);
	$password = md5(nosql($_POST["passwordx"]));
	
	//cek null
	if ((empty($tipe)) OR (empty($username)) OR (empty($password)))
		{
		//diskonek
		xclose($koneksi);
		
		//re-direct
		$pesan = "Input Tidak Lengkap. Harap Diulangi...!!";
		pekem($pesan,$filenya);
		exit();
		}
	else
		{
		//jika tp01 --> GURU ............................................................................................................
		if ($tipe == "tp01")
			{
			//query
			$q = mysql_query("SELECT * FROM m_user ".
								"WHERE usernamex = '$username' ".
								"AND passwordx = '$password' ".
								"AND tipe = 'GURU'");
			$row = mysql_fetch_assoc($q);
			$total = mysql_num_rows($q);
		
			//cek login	
			if ($total != 0) 
				{
				session_start();
				
				//netralkan session dahulu...
				session_unset();
				session_destroy();
				
				//nilai
				$kd1_session = nosql($row['kd']);
				$no1_session = nosql($row['nomor']);
				$nm1_session = balikin($row['nama']);
				$username1_session = $username;
				$pass1_session = $password;
				$tipe_session = "GURU";
				$hajirobe_session = $hajirobe;	
						
				//bikin session
				session_register("kd1_session");
				session_register("no1_session");
				session_register("nm1_session");
				session_register("username1_session");
				session_register("pass1_session");
				session_register("tipe_session");
				session_register("hajirobe_session");
				
				//diskonek
				xfree($q);
				xclose($koneksi);
		
				//re-direct
				$ke = "janissari/index.php";
				xloc($ke);	
				exit();
				} 
			else 
				{		
				//diskonek
				xfree($q);
				xclose($koneksi);
				
				//re-direct
				pekem($pesan,$filenya);
				exit();
				}
			}
		//...............................................................................................................................





		//jika tp02 --> SISWA ...........................................................................................................
		if ($tipe == "tp02")
			{
			//query
			$q = mysql_query("SELECT * FROM m_user ".
								"WHERE usernamex = '$username' ".
								"AND passwordx = '$password' ".
								"AND tipe = 'SISWA'");
			$row = mysql_fetch_assoc($q);
			$total = mysql_num_rows($q);
		
			//cek login	
			if ($total != 0) 
				{
				session_start();
				
				//netralkan session dahulu...
				session_unset();
				session_destroy();
				
				//nilai
				$kd1_session = nosql($row['kd']);
				$no1_session = nosql($row['nomor']);
				$nm1_session = balikin($row['nama']);
				$username1_session = $username;
				$pass1_session = $password;
				$tipe_session = "SISWA";
				$hajirobe_session = $hajirobe;	
						
				//bikin session
				session_register("kd1_session");
				session_register("no1_session");
				session_register("nm1_session");
				session_register("username1_session");
				session_register("pass1_session");
				session_register("tipe_session");
				session_register("hajirobe_session");
				
				//diskonek
				xfree($q);
				xclose($koneksi);
		
				//re-direct
				$ke = "janissari/index.php";
				xloc($ke);	
				exit();
				} 
			else 
				{		
				//diskonek
				xfree($q);
				xclose($koneksi);
				
				//re-direct
				pekem($pesan,$filenya);
				exit();
				}
			}
		//................................................................................................................................





		//jika tp03 --> Administrator ....................................................................................................
		if ($tipe == "tp03")
			{	
			//query
			$q = mysql_query("SELECT * FROM adminx ".
								"WHERE usernamex = '$username' ".
								"AND passwordx = '$password'");
			$row = mysql_fetch_assoc($q);
			$total = mysql_num_rows($q);
		
			//cek login	
			if ($total != 0) 
				{
				session_start();		
					
				//netralkan session...
				session_unset();
				session_destroy();
	
				//nilai
				$kd3_session = nosql($row['kd']);
				$username3_session = $username;
				$pass3_session = $password;
				$adm_session = "Administrator";
				$hajirobe_session = $hajirobe;	
						
				//bikin session
				session_register("kd3_session");
				session_register("username3_session");
				session_register("pass3_session");
				session_register("adm_session");
				session_register("hajirobe_session");
				
				//diskonek
				xfree($q);
				xclose($koneksi);
				
				//re-direct
				$ke = "adm/index.php";
				xloc($ke);	
				exit();
				} 
			else 
				{
				//diskonek
				xfree($q);
				xclose($koneksi);
				
				//re-direct		
				pekem($pesan,$filenya);
				exit();
				}
			}
		//................................................................................................................................
		}
	}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



//isi *START
ob_start();

//view //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
echo '<table width="990" border="0" cellspacing="0" cellpadding="3">
<tr bgcolor="'.$warnaover.'">
<td align="center">
<h1>
'.$sek_nama.'
</h1>
<em>
'.$sek_alamat.'
<br>
'.$sek_kontak.'
</em>
</td>
<td>
<img src="img/linux.gif" alt="Linux." width="300" height="130" border="0">
</td>
</tr>

<tr bgcolor="'.$warna02.'" valign="top">
<td>
Tipe : 
<select name="tipe">
<option value="" selected></option>
<option value="tp01">Guru</option>
<option value="tp02">Siswa</option>
<option value="tp03">Administrator</option>
</select>, 
Username : 
<input name="usernamex" type="text" size="10" maxlength="15">, 
Password : 
<input name="passwordx" type="password" size="10" maxlength="15"> 
<input name="btnBTL" type="reset" value="BATAL">
<input name="btnOK" type="submit" value="OK &gt;&gt;&gt;">
</td>
<td>
</td>
</tr>

<tr bgcolor="'.$warnaheader.'" valign="top">
<td>
&copy;2009. <strong><a href="{url}" target="_blank" title="{versi} . Info Selengkapnya : {url}">{versi}</a></strong>
<br>
<em>Dibuat Oleh : <a href="#" onmouseover="showToolTip(event,\'Dibuat Oleh ; <br><strong>Agus Muhajir,S.Kom</strong>. <br>E-Mail : <br><i>hajirodeon@yahoo.com</i>\');return false" onmouseout="hideToolTip()"><font color="#FF0000">Agus Muhajir,S.Kom</font></a>.</em>
</td>
<td>
</td>
</tr>
</table>';
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//isi
$isi = ob_get_contents();
ob_end_clean();

require("inc/niltpl.php");


//diskonek
xclose($koneksi);
exit();
?>