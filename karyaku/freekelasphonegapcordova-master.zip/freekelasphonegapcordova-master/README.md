# freekelasphonegapcordova

Free Kelas phonegap Cordova. Group khusus untuk belajar membuat aplikasi android basis web, dengan phonegap cordova. http://t.me/freekelasphonegapcordova . 


Bila ingin Kelas Excellent berbayar, 

https://github.com/hajirodeon/les-private-telegram-wappsandroid


