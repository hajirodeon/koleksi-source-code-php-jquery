<SCRIPT LANGUAGE="JavaScript">
<!-- Begin
function checkAll(x)
	{
	for (var j = 1; j <= x; j++)
		{
		box = eval("document.formx.item" + j);
		if (box.checked == false) box.checked = true;
		}
	}

function uncheckAll(x)
	{
	for (var j = 1; j <= x; j++)
		{
		box = eval("document.formx.item" + j);
		if (box.checked == true) box.checked = false;
	   }
	}


//  End -->
</script>