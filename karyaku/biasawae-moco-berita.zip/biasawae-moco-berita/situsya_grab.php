<?
sleep(1);
ini_set('max_execution_time', 0);
error_reporting(0);


//ambil nilai
require("inc/config.php");
require("inc/fungsi.php");
require("inc/koneksi.php");
include("inc/class/simple_html_dom.php");



//jumlah detik
$jml_detik = 30000;



$filenya = "situsya_grab.php";





//cek
$qccx = mysql_query("SELECT * FROM situs ".
						"ORDER BY RAND()");
$rccx = mysql_fetch_assoc($qccx);
$ccx_ke = $rccx['link_url'];
$ccx_ke_berita = $rccx['link_url_berita'];
$ccx_kategori = $rccx['kategori'];
$ccx_tanda_awal = $rccx['tanda_awal'];
$ccx_tanda_akhir = $rccx['tanda_akhir'];
$ccx_judul_awal = $rccx['judul_awal'];
$ccx_judul_akhir = $rccx['judul_akhir'];

$ccx_link_count = strlen($ccx_ke_berita);




//ambil daftar  /////////////////////////////////////////////////////////////////////////////////////////// 
$qcc = mysql_query("SELECT * FROM situs_grabdata ".
						"WHERE link_url = '$ccx_ke' ".
						"AND isi = '' ".
						"ORDER BY postdate DESC");
$rcc = mysql_fetch_assoc($qcc);
$tcc = mysql_num_rows($qcc);



$cc_linknya = $rcc['sub_link_url'];



echo 'PENGAMBILAN DATA DARI : 
<br>
'.$cc_linknya.'
<hr>
Refreh tiap <b>'.$jml_detik.' Detik</b>.
<hr>';




$base = $cc_linknya;




$curl = curl_init();
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($curl, CURLOPT_HEADER, false);
curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($curl, CURLOPT_URL, $base);
curl_setopt($curl, CURLOPT_REFERER, $base);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);
$str = curl_exec($curl);
curl_close($curl);



// Create a DOM object
$html_base = new simple_html_dom();

// Load HTML from a string
$grab = $html_base->load($str);




	
//judul........
$start = '<title>';
$end = '</title>';

$startPosisition = strpos($grab, $start);
$endPosisition   = strpos($grab, $end); 

$longText = $endPosisition - $startPosisition;

$result_judulx = substr($grab, $startPosisition, $longText);


 
 
//sempurnakan title
function titelkuya($str)
	{
    $str = trim($str);
	$search = array ("'<title>'", "'</title>'");
	$replace = array ("", "");

	$str = preg_replace($search,$replace,$str);
	return $str;
  	}

 
$result_judul = titelkuya($result_judulx);



	
		
	

	
	
//isinya........
$start = $ccx_tanda_awal;
$end   = $ccx_tanda_akhir;


$startPosisition = strpos($grab, $start);
$endPosisition   = strpos($grab, $end); 

$longText = $endPosisition - $startPosisition;

$result = substr($grab, $startPosisition, $longText);


$resultnya = cegah($result);




//simpan ke database
mysql_query("UPDATE situs_grabdata SET kategori = '$ccx_kategori', ".
				"judul = '$result_judul', ".
				"isi = '$resultnya', ".
				"postdate = '$today' ".
				"WHERE sub_link_url = '$cc_linknya'");





preg_match('/(<img[^>]+>)/i', $result, $i_gambare); 


$i_gambarku = $i_gambare[0];







//judulnya
$x_judul = seo_friendly_url($result_judul);

//cek
$qcc2 = mysql_query("SELECT item_id FROM rssingest ".
						"where item_title = '$result_judul'");
$tcc2 = mysql_num_rows($qcc2);
$cc2_kd = nosql($rcc2['kd']);

if (empty($tcc2))
	{
	echo "<font color=green>MASUK DATABASE..</font><br/>";
	
	mysql_query("INSERT INTO rssingest(prety_url, item_id, thumbnail, feed_url, item_title, item_content, item_date, item_url, fetch_date, kategori) VALUES ".
					"('$x_judul', '$x', '$i_gambarku', '$cc_linknya', '$result_judul', '$result', '$today', '$cc_linknya', '$today', '$ccx_kategori')");
	}
else
	{
	echo "<font color=blue>SUDAH ADA..</font><br/>";
	
	//update
	mysql_query("UPDATE rssingest SET prety_url = '$x_judul', ".
					"img_url = '$i_gambarku', ".
					"item_content = '$result', ".
					"kategori = '$ccx_kategori' ".
					"WHERE item_id = '$cc2_kd'");
	}




$html_base->clear(); 
unset($html_base);


?>
<script>setTimeout("location.href='<?php echo $filenya;?>'", <?php echo $jml_detik;?>);</script>

<?php
exit();
?>