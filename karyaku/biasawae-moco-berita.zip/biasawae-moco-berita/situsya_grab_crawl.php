<?
sleep(1);
ini_set('max_execution_time', 0);
error_reporting(0);


//ambil nilai
require("inc/config.php");
require("inc/fungsi.php");
require("inc/koneksi.php");
include("inc/class/simple_html_dom.php");





//jumlah detik
$jml_detik = 30000;


$filenya = "situsya_grab_crawl.php";



//cek
$qccx = mysql_query("SELECT * FROM situs ".
						"ORDER BY RAND()");
$rccx = mysql_fetch_assoc($qccx);
$ccx_ke = $rccx['link_url'];
$ccx_ke_berita = $rccx['link_url_berita'];
$ccx_kategori = $rccx['kategori'];
$ccx_tanda_awal = $rccx['tanda_awal'];
$ccx_tanda_akhir = $rccx['tanda_akhir'];
$ccx_judul_awal = $rccx['judul_awal'];
$ccx_judul_akhir = $rccx['judul_akhir'];

$ccx_link_count = strlen($ccx_ke_berita);




//base url
$base = $ccx_ke;


echo 'PENGAMBILAN DATA : '.$base.'
<hr>
Refreh tiap <b>'.$jml_detik.' Detik</b>.
<hr>';


$curl = curl_init();
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($curl, CURLOPT_HEADER, false);
curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($curl, CURLOPT_URL, $base);
curl_setopt($curl, CURLOPT_REFERER, $base);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);
$str = curl_exec($curl);
curl_close($curl);

// Create a DOM object
$html_base = new simple_html_dom();
// Load HTML from a string
$html_base->load($str);

//get all category links
foreach($html_base->find('a') as $element) {
	
	$nilku = $element->href;

	$nilkux = substr($nilku,0,$ccx_link_count);
	
	if ($nilkux == $ccx_ke_berita)
		{
	    echo "<pre>";
	
		echo $nilku;
	
		//cek
		$qcc = mysql_query("SELECT * FROM situs_grabdata ".
								"WHERE sub_link_url = '$nilku'");
		$rcc = mysql_fetch_assoc($qcc);
		$tcc = mysql_num_rows($qcc);
		
		//jika null
		if (empty($tcc))
			{
			//insert
			mysql_query("INSERT INTO situs_grabdata(link_url, sub_link_url, postdate, kategori) VALUES ".
							"('$ccx_ke', '$nilku', '$today', '$ccx_kategori')");
			}

		
	    echo "</pre>";
		}
}

$html_base->clear(); 
unset($html_base);



?>
<script>setTimeout("location.href='<?php echo $filenya;?>'", <?php echo $jml_detik;?>);</script>

<?php
exit();
?>