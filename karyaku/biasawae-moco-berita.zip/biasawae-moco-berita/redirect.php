<?php
ini_set('max_execution_time', 0);
error_reporting(0);


//ambil nilai
require("inc/config.php");
require("inc/fungsi.php");
require("inc/koneksi.php");
require("inc/class/paging.php");
$tpl = LoadTpl("template/cp_depan2.html");

	


nocache;

//nilai
$filenya = "redirect.php";
$kd = nosql($_REQUEST['kd']);
$limit = 50;







//detail beritanya
$qku = mysql_query("SELECT * FROM rssingest ".
						"WHERE item_id = '$kd'");
$rku = mysql_fetch_assoc($qku);
$ku_judul = balikin($rku['item_title']);
$ku_isi = balikin($rku['item_content']);
$ku_link = balikin($rku['item_url']);
$ku_img_url = balikin($rku['img_url']);
						


$ku_judul2 = seo_friendly_url($ku_judul);
$sek_url = "$sumber/$filenya?$ku_judul2&kd=$kd";
$sek_img_url = $ku_img_url;




$judul = $ku_judul;
$judulku = $judul;


//isi *START
ob_start();








echo '<table width="100%" border="0" cellpadding="5" cellspacing="0">
<tr>
<td>
<i>
'.$ku_isi.'
</i>


</td>
</tr>

<tr>
<td align="center">
<hr>
<p>
[Sumber : <a href="'.$ku_link.'" target="_blank">'.$ku_link.'</a>].
</p>
</td>
</tr>
</table>
<hr>


<h3>BERITA TERBARU LAINNYA : </h3>';



$limit = "50";

// membuat tabel 
echo '<div class="container">

<div class="row" align="center">';


	

$qyuk = mysql_query("SELECT * FROM rssingest ".
						"WHERE item_title <> '' ".
						"ORDER BY fetch_date DESC LIMIT 0,$limit");
$ryuk = mysql_fetch_assoc($qyuk);


	
do
	{
	echo '<div class="col-md-4 col">	
	<h3>'.$ku_nilku.'</h3>';
	
	

	$i_kd = nosql($ryuk['item_id']);
	$i_judul = balikin($ryuk['item_title']);
	$i_isi = balikin($ryuk['item_content']);
	$i_isi2 = $i_isi;
	$i_url = balikin($ryuk['item_url']);
	$i_img_url = $ryuk['img_url'];
	$i_prety_url = $ryuk['prety_url'];
	$i_postdate = $ryuk['fetch_date'];
	$i_thumbnail = $ryuk['thumbnail'];
	$i_kategori = balikin($ryuk['kategori']);


	$x_string = $i_thumbnail;
	preg_match('/<img(.*)src(.*)=(.*)"(.*)"/U', $x_string, $x_result);
	$x_foo = array_pop($x_result);



	if ($warnax_set ==0)
		{
		$warnax = $warna01;
		$warnax_set = 1;
		}
	else
		{
		$warnax = $warna02;
		$warnax_set = 0;
		}
	
	


		
	//jika null
	if (empty($i_img_url))
		{
		//update img url
		mysql_query("UPDATE rssingest SET img_url = '$x_foo' ".
						"WHERE item_id = '$i_kd'");
		}
		

	
	//jika null
	if (empty($i_thumbnail))
		{
		echo "<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"3\">
		<tr valign=\"top\">
		<td>
		<p>
		<i>$i_postdate</i>
		<br>
		<a href=\"$filenya?kd=$i_kd\" target=\"_blank\">$i_judul</a>
		</p>
		</td>
		</tr>
		</table>
		<hr>";
		}
	else
		{
		echo "<table width=\"100%\" border=\"0\" cellspacing=\"3\" cellpadding=\"3\">
		<tr valign=\"top\">
		
		<td width=\"100\">
		<p>
		<a href=\"$filenya?kd=$i_kd\" target=\"_blank\"><img src=\"$x_foo\" border=\"0\" width=\"100\"></a>
		</p>
		</td>
		
		<td>
		<p>
		<i>$i_postdate</i>
		<br>
		<a href=\"$filenya?kd=$i_kd\" target=\"_blank\">$i_judul</a>
		</p>
		</td>
		</tr>
		</table>
		<hr>";
		}



	echo "</div>";
	}
while ($ryuk = mysql_fetch_assoc($qyuk));



echo '</div>
</div>';





//isi
$isi = ob_get_contents();
ob_end_clean();

require("inc/niltpl.php");


exit();
?>