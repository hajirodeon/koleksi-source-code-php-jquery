<?php
ini_set('max_execution_time', 0);
error_reporting(0);


//ambil nilai
require("inc/config.php");
require("inc/fungsi.php");
require("inc/koneksi.php");
require("inc/class/paging.php");
$tpl = LoadTpl("template/cp_depan.html");

	


nocache;

//nilai
$filenya = "d_sumber.php";
$judul = "Sumber Pengambilan Berita";
$judulku = $judul;






//isi *START
ob_start();




echo '<form action="'.$filenya.'" enctype="multipart/form-data" method="post" name="formx">
<table width="100%" border="0" cellspacing="0" cellpadding="3">
<tr>
<td>
<h1>
PENGAMBILAN DATA SECARA RSS FEED :
</h1>

<UL>';

//daftar rss feed
$qku = mysql_query("SELECT * FROM daftar_rss ".
						"ORDER BY link_url ASC");
$rku = mysql_fetch_assoc($qku);

do
	{
	$ku_link = balikin($rku['link_url']);
	
	echo '<LI>
	'.$ku_link.'
	</LI>';
	}
while ($rku = mysql_fetch_assoc($qku));




echo '</UL>
</td>
</tr>
</table>

<hr>




<table width="100%" border="0" cellspacing="0" cellpadding="3">
<tr>
<td>
<h1>
PENGAMBILAN DATA SECARA GRABING / SCRAPING :
</h1>

<UL>';

//daftar rss feed
$qku = mysql_query("SELECT * FROM situs ".
						"ORDER BY link_url ASC");
$rku = mysql_fetch_assoc($qku);

do
	{
	$ku_link = balikin($rku['link_url']);
	
	echo '<LI>
	'.$ku_link.'
	</LI>';
	}
while ($rku = mysql_fetch_assoc($qku));




echo '<LI>
http://babe.news
</LI>

</UL>
</td>
</tr>
</table>';





//isi
$isi = ob_get_contents();
ob_end_clean();

require("inc/niltpl.php");


exit();
?>