<?
sleep(1);
ini_set('max_execution_time', 0);
error_reporting(0);

//ambil nilai
require("inc/config.php");
require("inc/fungsi.php");
require("inc/koneksi.php");

include("inc/class/simple_html_dom.php");




//jumlah detik
$jml_detik = 30000;



//mengambil secara acak, dari situs babe
$nirand = rand(7878000,8999999);



$filenya = "situsya_babe.php";



	
$ke = $filenya;






//pengambilan hanya dari situs babe ///////////////////////////////////////////////////////////////////////
$base = 'https://babe.news/read/'.$nirand.'';


echo ''.$base.' 
<hr>
Refreh tiap <b>'.$jml_detik.' Detik</b>.
<hr>';


$curl = curl_init();
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($curl, CURLOPT_HEADER, false);
curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($curl, CURLOPT_URL, $base);
curl_setopt($curl, CURLOPT_REFERER, $base);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);
$str = curl_exec($curl);
curl_close($curl);



// Create a DOM object
$html_base = new simple_html_dom();

// Load HTML from a string
$grab = $html_base->load($str);



//ambil semua dulu ya...
$start = '<html>';
$end = '</html>';

$startPosisition = strpos($grab, $start);
$endPosisition   = strpos($grab, $end); 

$longText = $endPosisition - $startPosisition;

$result_semua = substr($grab, $startPosisition, $longText);




//judul........
$start = '<title>';
$end = '<base href="https://babe.news/">';

$startPosisition = strpos($result_semua, $start);
$endPosisition   = strpos($result_semua, $end); 

$longText = $endPosisition - $startPosisition;

$result_judulx = substr($result_semua, $startPosisition, $longText);


 
 
//sempurnakan title
function titelkuya($str)
	{
    $str = trim($str);
	$search = array ("'<title>'", "'</title>'");
	$replace = array ("", "");

	$str = preg_replace($search,$replace,$str);
	return $str;
  	}

 
$result_judul = titelkuya($result_judulx);
 
echo "$result_judul
<br>";





//isinya........
$start = '<div class="source">';
$end = '<div id="reply-popup" class="reply-popup overlay">';

$startPosisition = strpos($result_semua, $start);
$endPosisition   = strpos($result_semua, $end); 

$longText = $endPosisition - $startPosisition;

$result_isix = substr($result_semua, $startPosisition, $longText);
$result_isi = cegah2($result_isix);








//ketahui sumber situs
$start = '<span id="news-link">';
$end = '</span></div><div class="news-gap">';

$startPosisition = strpos($result_semua, $start);
$endPosisition   = strpos($result_semua, $end); 

$longText = $endPosisition - $startPosisition;

$result_sumberx = substr($result_semua, $startPosisition, $longText);
$result_sumber = substr($result_sumberx,21,255);
 


echo "SUmber : $result_sumber
<hr>";



preg_match('/(<img[^>]+>)/i', $result_isix, $i_gambare); 


$i_gambarku = $i_gambare[0];




$x_string = $i_gambarku;
preg_match('/<img(.*)src(.*)=(.*)"(.*)"/U', $x_string, $x_result);
$x_foox = array_pop($x_result);
$x_foo = "http:$x_foox";

$x_thumbnail = '<img src="'.$x_foo.'" border="0" width="100">';







//judulnya
$x_judul = seo_friendly_url($result_judul);

//cek
$qcc2 = mysql_query("SELECT item_id FROM rssingest ".
						"where item_title = '$result_judul'");
$tcc2 = mysql_num_rows($qcc2);
$cc2_kd = nosql($rcc2['kd']);

if (empty($tcc2))
	{
	echo "<font color=green>MASUK DATABASE..</font><br/>";
	
	mysql_query("INSERT INTO rssingest(prety_url, item_id, thumbnail, feed_url, item_title, item_content, item_date, item_url, fetch_date, kategori) VALUES ".
					"('$x_judul', '$x', '$i_gambarku', '$cc_linknya', '$result_judul', '$result', '$today', '$cc_linknya', '$today', '$ccx_kategori')");
	}
else
	{
	echo "<font color=blue>SUDAH ADA..</font><br/>";
	
	//update
	mysql_query("UPDATE rssingest SET prety_url = '$x_judul', ".
					"img_url = '$i_gambarku', ".
					"item_content = '$result', ".
					"kategori = '$ccx_kategori' ".
					"WHERE item_id = '$cc2_kd'");
	}




$html_base->clear(); 
unset($html_base);






?>
<script>setTimeout("location.href='<?php echo $filenya;?>'", <?php echo $jml_detik;?>);</script>

<?php
exit();
?>