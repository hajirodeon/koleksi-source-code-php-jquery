var nhapus = window.confirm('Yakin Akan Dihapus...?');

if (nhapus)
	{
	document.formx.submit();
	}
else
	{
	return false
	}