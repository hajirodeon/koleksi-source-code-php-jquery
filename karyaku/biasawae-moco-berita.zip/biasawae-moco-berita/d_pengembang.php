<?php
sleep(1);
ini_set('max_execution_time', 0);
error_reporting(0);



//ambil nilai
require("inc/config.php");
require("inc/fungsi.php");
require("inc/koneksi.php");
$tpl = LoadTpl("template/cp_depan2.html");

	


nocache;

//nilai
$filenya = "d_pengembang.php";
$judul = "PENGEMBANG BIASAWAE-MOCO-Berita";
$judulku = $judul;
$s = nosql($_REQUEST['s']);





//isi *START
ob_start();


echo '<h3>'.$judul.'</h3>

<p>
BIASAWAE-MOCO-Berita ini dikembangkan oleh <b>Agus Muhajir, S.Kom</b> 
</p>

<p>
Pengembangan ini berdasarkan pengalaman pribadi, dalam menikmati beragam informasi berita terbaru dan penyajiannya yang bisa cepat diperoleh. 
Dan juga terinspirasi dari Sistem Indeks Berita yang sudah ada, seperti BABE dan KURIO.
</p>

<p>
Saat ini masih memasuki versi 1.0, dan selanjutnya akan terus disempurnakan. Dan akan ada selalu dalam rilis secara OpenSource. 
</p>

<hr>

<p>
Informasi lebih lanjut, bisa hubungi :
<br>
E-Mail : 
<br>
<b>
hajirodeon@yahoo.com / hajirodeon@gmail.com
</b>
<br>
<br>

Web : 
<br>
<b>
http://omahbiasawae.com
</b>
<br>
<br>

Wordpress / Instagram / Twitter / Facebook / Google+ :
<br>
<b>
hajirodeon
</b>

</p>';
	





//isi
$isi = ob_get_contents();
ob_end_clean();

require("inc/niltpl.php");



exit();
?>