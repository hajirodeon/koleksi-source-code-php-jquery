<?php
sleep(1);
ini_set('max_execution_time', 0);
error_reporting(0);



//ambil nilai
require("inc/config.php");
require("inc/fungsi.php");
require("inc/koneksi.php");
$tpl = LoadTpl("template/cp_depan2.html");

	


nocache;

//nilai
$filenya = "d_proses.php";
$judul = "Proses Pengambilan Data";
$judulku = $judul;
$s = nosql($_REQUEST['s']);





//isi *START
ob_start();


echo '<h3>'.$judul.'</h3>


<UL>
<LI>
<a href="situsya_rss.php" target="_blank">RSS FEED</a>
</LI>

<LI>
<a href="situsya_grab_crawl.php" target="_blank">GRAB DATA CRAWL</a>
</LI>

<LI>
<a href="situsya_grab.php" target="_blank">GRAB DATA</a>
</LI>

<LI>
<a href="situsya_babe_ambil.php" target="_blank">GRAB DATA BABE</a>
</LI>

<LI>
<a href="situsya_babe.php" target="_blank">GRAB DATA BABE CRAWL</a>
</LI>


</UL>


';
	





//isi
$isi = ob_get_contents();
ob_end_clean();

require("inc/niltpl.php");



exit();
?>