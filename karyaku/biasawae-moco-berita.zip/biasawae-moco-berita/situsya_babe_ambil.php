<?php
sleep(1);
ini_set('max_execution_time', 0);
error_reporting(0);


//ambil nilai
require("inc/config.php");
require("inc/fungsi.php");
require("inc/koneksi.php");
require("inc/class/simple_html_dom.php");



$filenya = "situsya_babe_ambil.php";



//jumlah detik
$jml_detik = 30000;



//BABE.NEWS ///////////////////////////////////////////////////////////////////////////////////////////////
//base url
$base = 'https://babe.news';


echo 'PENGAMBILAN DATA DARI : '.$base.'
<hr>
Refreh tiap <b>'.$jml_detik.' Detik</b>.
<hr>';



$curl = curl_init();
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($curl, CURLOPT_HEADER, false);
curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($curl, CURLOPT_URL, $base);
curl_setopt($curl, CURLOPT_REFERER, $base);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);
$str = curl_exec($curl);
curl_close($curl);

// Create a DOM object
$html_base = new simple_html_dom();
// Load HTML from a string
$html_base->load($str);

//get all category links
foreach($html_base->find('a') as $element) {
	
	$nilku = $element->href;
	$nilkuy = "http://babe.news$nilku";
	
    echo "<pre>";
	$i_kd = $x;
	
	
	//deteksi, hanya yang /read/
	if ((substr($nilku,0,6)) == "/read/")
		{
		echo $nilkuy;
	
		//cek
		$qcc = mysql_query("SELECT item_id FROM rssingest ".
								"where feed_url = '$nilkuy'");
		$rcc = mysql_fetch_assoc($qcc);
		$tcc = mysql_num_rows($qcc);
		$cc_kd = nosql($rcc['item_id']);
		
		
		if (empty($tcc))
			{
			echo "<font color=green>MASUK DATABASE..</font><br/>";
			
			mysql_query("INSERT INTO rssingest(item_id, feed_url, item_url, fetch_date, kategori) VALUES ".
							"('$i_kd', '$nilkuy', '$nilkuy', '$today', 'UMUM')");
			}
		else
			{
			echo "<font color=blue>SUDAH ADA..</font><br/>";
			
			//update
			mysql_query("UPDATE rssingest SET feed_url = '$nilkuy', ".
							"item_url = '$nilkuy', ".
							"fetch_date = '$today' ".
							"WHERE item_id = '$cc_kd'");
			}
		
		}
	
	
    echo "</pre>";
	
	

	
	
	
}

$html_base->clear(); 
unset($html_base);









?>
<script>setTimeout("location.href='<?php echo $filenya;?>'", <?php echo $jml_detik;?>);</script>

<?php
exit();
?>