<?php
sleep(1);
ini_set('max_execution_time', 0);
error_reporting(0);



//ambil nilai
require("inc/config.php");
require("inc/fungsi.php");
require("inc/koneksi.php");
$tpl = LoadTpl("template/cp_depan2.html");

	


nocache;

//nilai
$filenya = "d_rss.php";
$judul = "RSS FEED";
$judulku = $judul;
$s = nosql($_REQUEST['s']);





//isi *START
ob_start();


echo '<h3>'.$judul.'</h3>

[RSS FEED bisa akses di <a href="'.$sumber.'/rss.php" target="_blank">'.$sumber.'/rss.php</a>].';
	





//isi
$isi = ob_get_contents();
ob_end_clean();

require("inc/niltpl.php");



exit();
?>