<?php
ini_set('max_execution_time', 0);
error_reporting(0);


//ambil nilai
require("inc/config.php");
require("inc/fungsi.php");
require("inc/koneksi.php");
require("inc/class/paging.php");
$tpl = LoadTpl("template/cp_depan.html");

	


nocache;

//nilai
$filenya = "index.php";
$judul = "BIASAWAE-MOCO-Berita";
$judulku = $judul;
$s = nosql($_REQUEST['s']);
$kunci = cegah($_REQUEST['kunci']);
$page = nosql($_REQUEST['page']);
if ((empty($page)) OR ($page == "0"))
	{
	$page = "1";
	}


$sek_url = $sumber;
$sek_img_url = "";





//cari
if ($_POST['btnCARI'])
	{
	//nilai
	$kunci = cegah($_POST['kunci']);


	//cek
	if (empty($kunci))
		{
		//re-direct
		$pesan = "Input Pencarian Tidak Lengkap. Harap diperhatikan...!!";
		pekem($pesan,$filenya);
		exit();
		}
	else
		{
		//re-direct
		$ke = "$filenya?kunci=$kunci";
		xloc($ke);
		exit();
		}
	}




//batal
if ($_POST['btnBTL'])
	{
	//re-direct
	xloc($filenya);
	exit();
	}








$limit = "50";







//isi *START
ob_start();




echo '<form action="'.$filenya.'" enctype="multipart/form-data" method="post" name="formx">
<table width="100%" border="0" cellspacing="0" cellpadding="3">
<tr bgcolor="orange">
<td align="center">
<input name="kunci" type="text" value="'.$kunci.'" size="20">
<input name="btnCARI" type="submit" value="CARI">
<input name="btnBTL" type="submit" value="RESET">
</td>
</tr>
</table>

<hr>';




// membuat tabel 
echo '<div class="container">

<div class="row" align="center">';

//query
$p = new Pager();
$start = $p->findStart($limit);

	
if (!empty($kunci))
	{
	$kuerine = "SELECT * FROM rssingest ".
				"WHERE item_title <> '' ".
				"AND (item_title LIKE '%$kunci%' ".
				"OR item_content LIKE '%$kunci%') ".
				"ORDER BY fetch_date DESC";
	}
else
	{
	$kuerine = "SELECT * FROM rssingest ".
				"WHERE item_title <> '' ".
				"ORDER BY fetch_date DESC";
	}

$sqlcount = $kuerine;
$sqlresult = $sqlcount;

$count = mysql_num_rows(mysql_query($sqlcount));
$pages = $p->findPages($count, $limit);
$result = mysql_query("$sqlresult LIMIT ".$start.", ".$limit);
$target = "$filenya?kunci=$kunci";
$pagelist = $p->pageList($_GET['page'], $pages, $target);
$data = mysql_fetch_array($result);



	
do
	{
	echo '<div class="col-md-4 col">';
	
	

	$i_kd = nosql($data['item_id']);
	$i_judul = balikin($data['item_title']);
	$i_isi = balikin($data['item_content']);
	$i_isi2 = $i_isi;
	$i_url = balikin($data['item_url']);
	$i_postdate = $data['fetch_date'];
	$i_img_url = $data['img_url'];
	$i_prety_url = $data['prety_url'];
	$i_thumbnail = $data['thumbnail'];
	$i_kategori = balikin($data['kategori']);


	$x_string = $i_thumbnail;
	preg_match('/<img(.*)src(.*)=(.*)"(.*)"/U', $x_string, $x_result);
	$x_foo = array_pop($x_result);



	if ($warnax_set ==0)
		{
		$warnax = $warna01;
		$warnax_set = 1;
		}
	else
		{
		$warnax = $warna02;
		$warnax_set = 0;
		}
	


		
	//jika null
	if (empty($i_img_url))
		{
		//update img url
		mysql_query("UPDATE rssingest SET img_url = '$x_foo' ".
						"WHERE item_id = '$i_kd'");
		}
		
		

	
	//jika null
	if (empty($i_thumbnail))
		{
		echo "<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"3\">
		<tr valign=\"top\">
		<td>
		<p>
		<i>$i_postdate</i>
		<br>
		<a href=\"redirect.php?kd=$i_kd\" target=\"_blank\">$i_judul</a>
		</p>
		</td>
		</tr>
		</table>
		<hr>";
		}
	else
		{
		echo "<table width=\"100%\" border=\"0\" cellspacing=\"3\" cellpadding=\"3\">
		<tr valign=\"top\">
		<td width=\"100\">
		<p>
		<a href=\"redirect.php?kd=$i_kd\" target=\"_blank\"><img src=\"$x_foo\" border=\"0\" width=\"100\"></a>
		</p>
		</td>
		
		<td>
		<p>
		<i>$i_postdate</i>
		<br>
		<a href=\"redirect.php?kd=$i_kd\" target=\"_blank\">$i_judul</a>
		</p>
		</td>
		</tr>
		</table>
		<hr>";
		}


	echo "</div>";
	}
while ($data = mysql_fetch_assoc($result));



echo '</div>
</div>

<hr>
<table width="100%" border="0" cellspacing="0" cellpadding="3">
<tr bgcolor="orange">
<td align="center">
'.$pagelist.'
</td>
</tr>
</table>
<hr>';






	
	
	
	//isi
$isi = ob_get_contents();
ob_end_clean();

require("inc/niltpl.php");


exit();
?>