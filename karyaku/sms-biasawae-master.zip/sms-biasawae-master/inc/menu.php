<?php
////////////////////////////////////////////////////////////
// SMS BIASAWAE v0.1                                      //
// oleh : Agus Muhajir                                    //
////////////////////////////////////////////////////////////
// blog/situs/milist :                                    //
//   http://hajirodeon.wordpress.com/                     //
//   http://sisfokol.wordpress.com/                       //
//   http://yahoogroup.com/groups/sisfokol/               //
//   http://yahoogroup.com/groups/linuxbiasawae/          //
////////////////////////////////////////////////////////////
// e-mail :                                               //
//   hajirodeon@yahoo.com                                 //
////////////////////////////////////////////////////////////


echo '<table border="1">

<TR>
<TD>
<a href="main.php">
Halaman Utama
</a>
</TD>
</TR>

<TR>
<TD>
<a href="ganti_password.php">
Ganti Password
</a>
</TD>
</TR>


<TR>
<TD>
<a href="group.php">
Group
</a>
</TD>
</TR>

<TR>
<TD>
<a href="siswa.php">
Siswa
</a>
</TD>
</TR>


<TR>
<TD>
<a href="sms.php?s=baru">
Kirim SMS Tunggal
</a>
</TD>
</TR>


<TR>
<TD>
<a href="sms.php?s=baru2">
Kirim SMS Massal
</a>
</TD>
</TR>



<TR>
<TD>
<a href="sms.php?s=inbox">
Inbox
</a>
</TD>
</TR>


<TR>
<TD>
<a href="sms.php?s=outbox">
Outbox
</a>
</TD>
</TR>


<TR>
<TD>
<a href="sms.php?s=sentitem">
SentItem
</a>
</TD>
</TR>


<TR>
<TD>
<a href="absensi.php">
Absensi
</a>
</TD>
</TR>



<TR>
<TD>
<a href="sop.php">
S.O.P
</a>
</TD>
</TR>



<TR>
<TD>
<a href="logout.php">
LogOut
</a>
</TD>
</TR>


</table>';
?>