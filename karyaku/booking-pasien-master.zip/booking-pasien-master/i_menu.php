						<div class="col-md-4">
							<div class="price-box to-animate-2">
								<h2 class="pricing-plan">REGISTRASI</h2>
								<p>Belum Terdaftar..?</p>
								<a href="pasien_reg.php" class="btn btn-select-plan btn-sm">Registrasi Dahulu</a>
							</div>
						</div>

						<div class="col-md-4">
							<div class="price-box to-animate-2">
								<h2 class="pricing-plan">BOOKING PERIKSA</h2>
								<p>Punya Rekam Medik..?</p>
								<a href="pasien_login.php" class="btn btn-select-plan btn-sm">Booking Sekarang</a>
							</div>
						</div>

						<div class="col-md-4">
							<div class="price-box to-animate-2 popular">
								<h2 class="pricing-plan">BANTUAN</h2>
								<p>Perlu Bantuan..?</p>
								<a href="#bantuan" class="btn btn-select-plan btn-sm">BANTUAN KLIK DISINI</a>
							</div>
						</div>

