# booking-pasien
booking-pasien



untuk pasien yang ingin booking online, antrian periksa di rumah sakit atau klinik


file database .sql, ada di folder /db

file konfigurasi, ada di folder /inc


akses admin :
http://localhost/admin

user/pass : admin

