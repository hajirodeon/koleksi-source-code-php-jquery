<!-- 
//Kampungan EDITOR v1.0
//oleh AGUS MUHAJIR (hajirodeon@yahoo.com)
-->
<script language="javascript" type="text/javascript" src="<?php echo $sumber;?>/inc/class/kampungan/kampungan.js"></script>
<script language="javascript" type="text/javascript">
    	kampungan.init({
		mode : "exact",
		elements : "editor",
		theme : "advanced",
		editor_deselector : "NoEditor",
		plugins : "table,advimage,advlink,emotions,searchreplace,print,contextmenu,paste,noneditable",
		theme_advanced_buttons1_add_before : "newdocument,separator",
		theme_advanced_buttons1_add : "fontselect,fontsizeselect",
		theme_advanced_buttons2_add : "separator,inseforecolor,backcolor",
		theme_advanced_buttons2_add_before: "cut,copy,paste,separator,search,replace,separator",
		theme_advanced_buttons3_add_before : "tablecontrols,separator",
		theme_advanced_buttons3_add : "emotions,separator,print",
		theme_advanced_toolbar_location : "top",
		theme_advanced_toolbar_align : "left",
		theme_advanced_path_location : "bottom",
		content_css : "<?php echo $sumber;?>/inc/style/editor.css",
	    plugin_insertdate_dateFormat : "%Y-%m-%d",
	    plugin_insertdate_timeFormat : "%H:%M:%S",
		extended_valid_elements : "hr[class|width|size|noshade],font[face|size|color|style],span[class|align|style]",
		theme_advanced_resize_horizontal : false,
		theme_advanced_resizing : true
	});

 function postForm(){
		kampungan.triggerSave(true,true);
		var mceContent = escape($F('editor'));
		var url = '<?php echo $target;?>';
		var pars = 'body=' + mceContent;
		
		var myAjax = new Ajax.Request( 
				url, 
				{ 
						method: 'post', 
						parameters: pars, 
						onComplete: showResponse 
				}
		);
	}

</script>