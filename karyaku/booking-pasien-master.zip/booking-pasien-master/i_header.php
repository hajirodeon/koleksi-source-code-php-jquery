				
				<table width="100%" border="0" cellspacing="0" cellpadding="3">
				<tr>
				<td width="100" height="100">
				logo kiri
				</td>
				
				
				<td align="center">
				<h3>
					Sistem Pendaftaran Online untuk Anda
				</h3>
				[<a href="index.php">BERANDA</a>]. 
				[<a href="pasien_reg.php">REGISTRASI</a>]. 
				[<a href="pasien_login.php">BOOKING PERIKSA</a>].
				</td>
				
				<td width="100">
				logo kanan
				</td>
				</tr>
				</table>

