function init_widgetku(token){
document.getElementById("widgetku").innerHTML='<iframe id="frmku" name="frmku" src="http://localhost/satria_livechat/web_member.php?mbkd='+token+'" scrolling="no" width="100%" height="340" marginheight="0" frameborder="0"></iframe>';
}