# idt-free-kelas
idt-free-kelas


FREE KELAS IDT, Kategori WAPPSANDROID
======================================


selama 7(TUJUH) pertemuan, kita akan membahas tentang pengenalan dasar WAPPSANDROID (Web Apps Android / Pembuatan Aplikasi Android Basis Web, dengan menggunakan Phonegap Cordova)



---



FREE KELAS IDT : WAPPSANDROID

#1 : Membuat akun GIT, PHONEGAP ONLINE, sampai dengan jadi file APK yang siap install ke hp android
1. membuat akun git, pada http://github.com
2. membuat akun phonegap cordova online, pada https://build.phonegap.com/apps
3. compile apk online dengan phonegap cordova online, dari contoh source code https://github.com/hajirodeon/wappswandroid
4. install file apk ke hp android


#2 : Salin, Edit dan compile menjadi file apk
1. salin proyek atau fork contoh source code, ke repository git kita
2. edit repository yang ada
3. compile apk online dengan phonegap cordova online
4. install file apk ke hp android



#3 : membuat webserver lokal pada hp android, dan ftp server
1. membuat webserver lokal pada hp android, dengan palapa webserver atau penguin webserver. Unduh dari playstore.
2. membuat ftpserver lokal pada hp android. Unduh dari playstore.
3. upload dan download, via ftp. antara hp android dengan komputer, melalui jaringan wifi lokal.




#4 : pengenalan php dan mysql
1. pengenalan php
2. pengenalan mysql, sql, dan phpmyadmin
3. membuat database sederhana




#5 : manajemen data : tampil, edit, hapus, tambah
1. manajemen data dengan php : tampil, edit, hapus, tambah
2. menghubungkan webserver dengan phonegap cordova
3. compile apk online dengan phonegap cordova online
4. install file apk ke hp android




#6 : pengenalan jquery
1. pengenalan jquery
2. latihan praktek 





#7 : materi studi kasus : membangun web social media sendiri, dengan CMS BIASAWAE-SOCIAL-MEDIA
1. menyiapkan webserver
2. menyiapkan database
3. menyiapkan apk
4. install file apk ke hp android



