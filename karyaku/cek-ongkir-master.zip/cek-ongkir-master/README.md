# cek-ongkir
cek-ongkir

JNE + POS + TIKI.

Berbasis PHP Mysql, dengan sistem perhitungan otomatis, jarak antar kecamatan, antar kota, dan antar propinsi.

untuk tingkat kesesuaian data, perlu pendataan data lebih lanjut, dari perubahan ongkos kirim dari jasa kirim JNE/POS/TIKI.







file .sql, ada di folder /db

koneksi database, pada file /inc/config.php



di playstore, juga bisa mencoba :

https://play.google.com/store/apps/details?id=ongkir.ongkir.ongkir

