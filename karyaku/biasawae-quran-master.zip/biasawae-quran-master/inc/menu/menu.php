<?php
echo 'BERANDA | SURAT | JUZ
<hr>';


?>