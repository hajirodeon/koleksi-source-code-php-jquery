# kasir-toko
kasir-toko

Berbasis PHP Mysql.


Untuk file .sql database, ada pada folder /db


untuk file konfigurasi, ada pada folder /inc


untuk login admin, user/pass : admin
